---
name: blueaccount-ticket-flow
description: Use when a user gives a Jira ticket key for a BlueAccount task and wants a phased execution flow: read the ticket in Jira, write a local plan under `tickets/`, and implement the work in reviewable phases.
---

# Blueaccount Ticket Flow

## When To Use

Use this skill when the user asks you to work from a Jira ticket in the BlueAccount repo, especially when they want:

- the ticket read from Jira by key
- a local plan written under `tickets/`
- implementation split into reviewable phases
- code changes applied only after the plan is approved

## Workflow

### 1. Read The Ticket

- Resolve the Jira issue by key. Use MCP to read the ticket content, including title, description, and any relevant comments or attachments.
- Summarize the ticket in plain language.
- If the key is missing, ask for it before doing anything else.

### 2. Build The Local Plan

- Read `src/README.md` first, then the exact layer readmes you expect to touch.
- Create or update `tickets/<KEY>.md`.
- Keep the plan explicit and reviewable:
  - objective
  - scope and non-goals
  - assumptions and open questions
  - phased implementation plan
  - acceptance criteria
  - tests and docs to update
  - risks or rollout notes if relevant

- Prefer 3 to 5 phases.
- Each phase should be small enough for the user to review before the next one.
- A good default sequence is:
  1. discovery and contract alignment
  2. backend/domain/data changes
  3. HTTP integration
  4. frontend changes
  5. tests, docs, and cleanup

### 3. Pause For Approval

- Do not edit code until the plan is approved.
- Present the plan clearly and wait.
- If something is ambiguous, surface the question in the plan instead of guessing.

### 4. Implement Phase By Phase

- Implement one phase at a time whenever practical.
- Keep backend, frontend, and test work separated unless the user asks for a fast-track implementation.
- Follow existing BlueAccount patterns and layer boundaries.
- If the ticket touches multiple layers, use `blueaccount-project-navigator` to choose the right files and keep the work aligned with the repo structure.
- After each phase:
  - run the most relevant tests or build
  - update `tickets/<KEY>.md` if the plan changed
  - report what is done and what remains

### 5. Finish Cleanly

- Keep acceptance criteria visible in the plan.
- Make review checkpoints explicit.
- Do not collapse unrelated work into one phase unless the user explicitly wants that.

## Output Expectations

- Always mention the Jira key and the local plan path.
- Keep phase names short and concrete.
- Prefer plain, actionable language over broad summaries.
