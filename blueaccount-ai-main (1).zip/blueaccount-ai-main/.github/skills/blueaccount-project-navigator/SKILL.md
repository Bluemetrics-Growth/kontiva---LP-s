---
name: blueaccount-project-navigator
description: Use when working in the BlueAccount MVP repo to navigate the current architecture quickly, choose the right layer, and generate code, tests, and docs without breaking the project structure.
---

# BlueAccount Project Navigator

Use this skill when you need to work efficiently in the BlueAccount MVP codebase.

## Start here

1. Read `src/README.md` first.
2. Then read the README of the exact layer you will touch:
   - `src/app`
   - `src/modules`
   - `src/http`
   - `src/domain`
   - `src/infrastructure`
   - `src/agent`
   - `src/database`
   - `src/tools`
3. If you are changing execution or setup, check the root `README.md`.
4. If you need full project context, read the plan central in `planos_execucao/migracao_nest_js_step_9.md`.

## Default navigation rule

Always decide the layer before editing code:

- `src/app` for bootstrap and server startup
- `src/modules` for feature composition in Nest
- `src/http` for controllers and HTTP middlewares
- `src/domain` for business rules and use cases
- `src/infrastructure` for technical integrations and implementation details
- `src/modules/auth` and `src/domain/autenticacao` for auth
- `src/modules/agents` and `src/infrastructure/ai` for the core agent flow
- `src/agent` for concrete agent implementations
- `src/database` for entities, datasource, and migrations
- `src/tools` for reusable utility operations

If a file can live in `src/domain` without knowing Nest or HTTP, prefer that.

## Code generation workflow

When asked to add a feature:

1. Find the closest existing feature in the same layer.
2. Reuse the current pattern before inventing a new one.
3. Keep HTTP handlers thin.
4. Move rule-heavy logic into `src/domain`.
5. Put technical integration in `src/infrastructure`.
6. Add or update tests near the layer you changed.
7. Update the matching README if the responsibility moved.

## Project-specific rules

- Do not put new work in `src/middleware`; use `src/http/middlewares`.
- Do not add new Express routes in `src/http/routes`; use Nest controllers and modules.
- Prefer `src/modules/auth` for auth entry points and `src/domain/autenticacao` for auth logic.
- Treat `src/infrastructure` as the home for technical pieces such as database, logging, AI, and external services.
- Root `README.md` is only for startup and `.env.example` setup.
- `src/README.md` is the developer entry point for feature work.
- The plan central lives in `planos_execucao/migracao_nest_js_step_9.md`.

## Fast lookup

Use `rg` for code search and `rg --files` for file discovery.

Useful starting points:

- controllers: `src/http/controllers`
- middlewares: `src/http/middlewares`
- feature modules: `src/modules/*`
- domain services: `src/domain/*`
- agents: `src/modules/agents` and `src/infrastructure/ai`
- tests: `tests/` folders next to the layer being tested
- planning docs: `planos_execucao/`
- tickets: `tickets/`

## When updating docs

If you move responsibility between layers, update the relevant README at the same time.
Keep the docs aligned with the codebase state, especially for:

- `src/README.md`
- `src/http/README.md`
- `src/domain/README.md`
- `src/infrastructure/README.md`
- `src/modules/README.md`
