# `src/agent`

Esta pasta guarda as implementações concretas dos agentes de IA e automação do BlueAccount.

Ela continua sendo importante, mas hoje funciona mais como a camada de execução dos modelos do que como a camada de entrada do sistema.

## Papel da pasta

`src/agent` existe para:

- concentrar agentes concretos de IA
- encapsular prompts e instruções específicas
- preparar e interpretar respostas de LLM
- manter a parte pesada da integração de IA fora de `src/http`

## Agentes principais

### `ExecutorAgent`

- arquivo: `executor-agent.ts`
- função: transformar uma intenção do usuário em um plano de ações estruturado para o BlueAccount
- uso atual: é o agente criado por `src/infrastructure/ai/AiFactoryService`

### `DocumentIngestionAgent`

- arquivo: `document-ingestion-agent.ts`
- função: extrair dados estruturados de documentos e contratos

### `ReportIngestionAgent`

- arquivo: `report-ingestion-agent.ts`
- função: extrair dados estruturados de relatórios operacionais

### `IngestaoPayloadAgent`

- arquivo: `ingestao-payload-agent.ts`
- função: **agente normalizador** — recebe o raw payload extraído pela State Machine e produz o `payload_normalizado_ui`
- o `payload_normalizado_ui` contém:
  - `displayFields`: campos formatados para exibição no frontend
  - `payloadInsercaoDb`: objeto plano com os campos prontos para persistência no banco
- chamado automaticamente por `DocumentosService` após a execução da SM (`gerarPayloadNormalizadoContrato` / `gerarPayloadNormalizadoUiSeAusente`)
- o resultado é salvo em `Documento.payload_normalizado_ui` para que a confirmação do usuário não precise chamar o agente novamente

## Tools acessíveis ao `ExecutorAgent`

O `ExecutorAgent` usa Strands SDK + Bedrock e registra apenas tools de inspeção e leitura:

- `inspect_server_catalog`
- `search_clientes`
- `query_cliente`
- `query_contratos_by_cliente`
- `query_relatorios_by_cliente`

Essas tools vivem em `src/tools` e estão documentadas em `docs/AI_AGENT_TOOLS.md`.

O agente planejador não recebe tools de escrita. Persistência e alterações de estado devem passar por endpoints, módulos Nest e serviços de domínio.

## Onde esta pasta entra hoje

O fluxo principal do app para agentes é:

1. `src/modules/agentes` recebe a request HTTP
2. `src/infrastructure/ai` instancia o executor
3. `src/agent/executor-agent.ts` monta o plano
4. a camada chamadora executa ou interpreta esse plano

Isso significa que `src/agent` ainda é parte central da aplicação, mas sua responsabilidade está ficando mais técnica e mais focada em IA.

## O que deve ficar aqui

- classes e helpers de agentes
- prompts
- parsing de resposta de LLM
- regras de normalização da saída da IA

## O que deve sair daqui com o tempo

- regra de negócio pura
- controllers HTTP
- orquestração de módulo Nest
- integrações técnicas que não dependem diretamente de um agente

## Arquivos de suporte

- `index.ts`: exportações públicas do módulo
- `instructions/`: prompts e instruções separadas por agente

## Regra prática

Se o código conversa com o modelo, monta prompt ou interpreta saída de IA, ele pertence aqui.

Se o código decide o que o negócio faz com o resultado, ele deve ir para `src/domain` ou `src/modules`.
