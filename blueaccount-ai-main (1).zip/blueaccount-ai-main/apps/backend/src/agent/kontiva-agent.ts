import { randomUUID } from "node:crypto";
import {
  BedrockAgentCoreClient,
  InvokeAgentRuntimeCommand,
  type InvokeAgentRuntimeCommandOutput,
} from "@aws-sdk/client-bedrock-agentcore";

import { settings } from "../settings.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";

export interface AcaoGerada {
  titulo: string;
  descricao?: string | null;
  tipo_acao: "cobranca" | "revisao_contrato" | "alerta" | "outro";
  prioridade: "alta" | "media" | "baixa";
  cliente_id?: string | null;
  payload?: Record<string, unknown>;
}

interface KontivaAgentUsage {
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  latencyMs: number | null;
}

interface KontivaAgentCoreResponse {
  result: KontivaAgentResult;
  usage: KontivaAgentUsage | null;
}

export interface KontivaAgentResult {
  acoes: AcaoGerada[];
  resumo: string;
}

export interface KontivaAgentInvokeInput {
  message: string;
  sessionId: string | null;
  instrucoes?: string | null;
  agenteId?: string | null;
  context?: Record<string, unknown>;
  outputS3Uri?: string | null;
}

export interface KontivaAgentInvokeContext {
  escritorioId: string;
  traceId?: string;
}

export class KontivaAgent {
  static readonly agentName = "KontivaAgent";

  private readonly logger: AgentLogger;
  private readonly client: BedrockAgentCoreClient;

  constructor(logger?: AgentLogger) {
    this.logger =
      logger ??
      new AgentLogger(
        KontivaAgent.agentName,
        undefined,
        (settings.LOG_LEVEL as "debug" | "info" | "warn" | "error") ?? "info",
      );
    this.client = new BedrockAgentCoreClient({ region: settings.REGION });
  }

  async gerarAcoes(
    input: KontivaAgentInvokeInput,
    context: KontivaAgentInvokeContext,
  ): Promise<KontivaAgentResult> {
    const agentRuntimeArn = settings.KONTIVA_AGENT_RUNTIME_ARN;
    if (!agentRuntimeArn) {
      throw new Error("Missing required setting: KONTIVA_AGENT_RUNTIME_ARN");
    }

    const traceId = context.traceId ?? `kontiva-${randomUUID()}`;
    const effectivePrompt = buildKontivaPrompt(input.message, input.context ?? {}, input.instrucoes);
    const payload = {
      message: input.message,
      prompt: effectivePrompt,
      session_id: input.sessionId ?? null,
      instrucoes: input.instrucoes ?? null,
      instructions: input.instrucoes ?? null,
      agente_id: input.agenteId ?? null,
      context: input.context ?? {},
      output_s3_uri: input.outputS3Uri ?? null,
    };

    const payloadBytes = Buffer.from(JSON.stringify(payload), "utf-8");
    const command = new InvokeAgentRuntimeCommand({
      agentRuntimeArn,
      qualifier: settings.KONTIVA_AGENT_RUNTIME_QUALIFIER || undefined,
      runtimeSessionId: traceId,
      traceId,
      contentType: "application/json",
      accept: "application/json",
      payload: payloadBytes,
    });

    const startedAt = Date.now();
    const baseContext = {
      escritorio_id: context.escritorioId,
      traceId,
      agente_id: input.agenteId ?? null,
      agentRuntimeArn,
      has_session: Boolean(input.sessionId),
      has_instrucoes: Boolean(input.instrucoes),
      input_bytes: payloadBytes.byteLength,
      prompt: effectivePrompt,
      original_message: input.message,
    };

    this.logger.info("agentcore_invoke_started", baseContext);
    try {
      const response = await this.client.send(command);
      const responseText = await readStreamToString(response);
      const parsed = parseKontivaAgentCoreResponse(responseText);

      this.logger.logLlmUsage(
        "agentcore_invoke_completed",
        {
          modelId: agentRuntimeArn,
          inputTokens: parsed.usage?.inputTokens,
          outputTokens: parsed.usage?.outputTokens,
          totalTokens: parsed.usage?.totalTokens,
          latencyMs: parsed.usage?.latencyMs ?? Date.now() - startedAt,
        },
        {
          ...baseContext,
          output_bytes: Buffer.byteLength(responseText, "utf-8"),
          acoes_count: parsed.result.acoes.length,
        },
      );

      return parsed.result;
    } catch (err) {
      this.logger.logLlmUsage(
        "agentcore_invoke_failed",
        {
          modelId: agentRuntimeArn,
          latencyMs: Date.now() - startedAt,
        },
        {
          ...baseContext,
          error: err instanceof Error ? err.message : String(err),
        },
      );
      throw err;
    }
  }
}

function buildKontivaPrompt(
  message: string,
  context: Record<string, unknown>,
  instrucoes?: string | null,
): string {
  const normalizedInstructions = instrucoes?.trim() ?? "";
  if (normalizedInstructions) return normalizedInstructions;

  const hasContext = Object.keys(context).length > 0;
  if (!hasContext) return message;

  return JSON.stringify({
    mensagem: message,
    contexto: context,
  });
}

async function readStreamToString(response: InvokeAgentRuntimeCommandOutput): Promise<string> {
  if (!response.response) {
    throw new Error("KontivaAgent retornou payload vazio");
  }
  return response.response.transformToString();
}

function parseKontivaAgentCoreResponse(text: string): KontivaAgentCoreResponse {
  const outer = extractJsonObject(text) as KontivaAgentResult & {
    result?: unknown;
    _agent_usage?: unknown;
  };
  const envelopeResult = outer.result;

  if (!("_agent_usage" in outer) || typeof envelopeResult === "undefined") {
    return { result: outer, usage: null };
  }

  const usage = parseUsage(outer._agent_usage);

  if (typeof envelopeResult === "string") {
    return { result: normalizeResult(extractJsonObject(envelopeResult)), usage };
  }

  if (typeof envelopeResult !== "object" || envelopeResult === null || Array.isArray(envelopeResult)) {
    throw new Error("KontivaAgent: resposta não é um objeto JSON.");
  }

  return { result: normalizeResult(envelopeResult as KontivaAgentResult), usage };
}

function normalizeResult(raw: KontivaAgentResult): KontivaAgentResult {
  const acoes = Array.isArray(raw.acoes) ? raw.acoes : [];
  return {
    acoes: acoes.map(normalizeAcao).filter((a): a is AcaoGerada => a !== null),
    resumo: typeof raw.resumo === "string" ? raw.resumo : "",
  };
}

function extractJsonObject(text: string): KontivaAgentResult {
  const stripped = text.trim();
  try {
    const parsed = JSON.parse(stripped) as unknown;
    if (typeof parsed === "string") return extractJsonObject(parsed);
    return parsed as KontivaAgentResult;
  } catch {
    const fenced = stripped.match(/```(?:json)?\s*([\s\S]*?)```/);
    const raw = fenced?.[1] ?? stripped.match(/(\{[\s\S]*\})/)?.[1];
    if (!raw) throw new Error(`KontivaAgent: resposta sem JSON válido: ${stripped.slice(0, 300)}`);
    return JSON.parse(raw) as KontivaAgentResult;
  }
}

function parseUsage(raw: unknown): KontivaAgentUsage | null {
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) return null;
  const u = raw as Record<string, unknown>;
  return {
    inputTokens: nullableInt(u.input_tokens ?? u.inputTokens),
    outputTokens: nullableInt(u.output_tokens ?? u.outputTokens),
    totalTokens: nullableInt(u.total_tokens ?? u.totalTokens),
    latencyMs: nullableInt(u.latency_ms ?? u.latencyMs),
  };
}

function nullableInt(v: unknown): number | null {
  return typeof v === "number" && Number.isFinite(v) ? Math.round(v) : null;
}

const TIPOS_VALIDOS = ["cobranca", "revisao_contrato", "alerta", "outro"] as const;
const PRIORIDADES_VALIDAS = ["alta", "media", "baixa"] as const;

function normalizeAcao(raw: unknown): AcaoGerada | null {
  if (typeof raw !== "object" || raw === null) return null;
  const r = raw as Record<string, unknown>;

  const titulo = typeof r.titulo === "string" ? r.titulo.trim() : "";
  if (!titulo) return null;

  const tipo = TIPOS_VALIDOS.includes(r.tipo_acao as never) ? (r.tipo_acao as AcaoGerada["tipo_acao"]) : "outro";
  const prioridade = PRIORIDADES_VALIDAS.includes(r.prioridade as never) ? (r.prioridade as AcaoGerada["prioridade"]) : "media";

  return {
    titulo,
    descricao: typeof r.descricao === "string" ? r.descricao : null,
    tipo_acao: tipo,
    prioridade,
    cliente_id: typeof r.cliente_id === "string" ? r.cliente_id : null,
    payload: typeof r.payload === "object" && r.payload !== null && !Array.isArray(r.payload)
      ? (r.payload as Record<string, unknown>)
      : undefined,
  };
}
