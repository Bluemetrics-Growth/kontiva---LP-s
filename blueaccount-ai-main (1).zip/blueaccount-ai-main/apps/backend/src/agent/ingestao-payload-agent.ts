import { randomUUID } from "node:crypto";
import {
  BedrockAgentCoreClient,
  InvokeAgentRuntimeCommand,
  type InvokeAgentRuntimeCommandOutput,
} from "@aws-sdk/client-bedrock-agentcore";
import { NodeHttpHandler } from "@smithy/node-http-handler";

import { settings } from "../settings.js";
import { AgentLogger } from "../infrastructure/logging/agent.logger.js";

export type IngestaoPayloadResult = Record<string, unknown>;

interface AgentCoreUsage {
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  latencyMs: number | null;
}

interface AgentCoreParsedResponse {
  result: IngestaoPayloadResult;
  usage: AgentCoreUsage | null;
}

export interface PrepararPayloadFrontendInput {
  aiRawPayload?: Record<string, unknown>;
  rawPayloadAi?: Record<string, unknown>;
  rawPayloadRelatorio?: Record<string, unknown>;
  payloadInsercaoDb?: Record<string, unknown>;
  estatisticasRelatorios?: Record<string, unknown>[];
  edicaoFrontend?: Record<string, unknown>;
  schemaEsperado?: Record<string, unknown>;
}

export interface ValidarEdicaoRawPayloadInput {
  rawPayload: Record<string, unknown>;
  payloadEditado: Record<string, unknown>;
}

export interface MapearCamposExtracaoInput {
  schemaEsperado: Record<string, unknown>;
}

export interface AgentCoreInvocationContext {
  escritorioId: string;
  operation?: string;
  documentoId?: string;
}

export class IngestaoPayloadAgent {
  static readonly agentName = "IngestaoPayloadAgent";

  private readonly logger: AgentLogger;
  private readonly client: BedrockAgentCoreClient;

  constructor(logger?: AgentLogger) {
    this.logger =
      logger ??
      new AgentLogger(
        IngestaoPayloadAgent.agentName,
        undefined,
        (settings.LOG_LEVEL as "debug" | "info" | "warn" | "error") ?? "info",
      );
    this.client = new BedrockAgentCoreClient({
      region: settings.REGION,
      requestHandler: new NodeHttpHandler({ connectionTimeout: 10_000, requestTimeout: 60_000 }),
      maxAttempts: 2,
    });
  }

  async prepararPayloadFrontend(input: PrepararPayloadFrontendInput, context: AgentCoreInvocationContext): Promise<IngestaoPayloadResult> {
    return this.invoke({ ...input }, context);
  }

  async validarEdicaoRawPayload(input: ValidarEdicaoRawPayloadInput, context: AgentCoreInvocationContext): Promise<IngestaoPayloadResult> {
    return this.invoke({ ...input }, context);
  }

  async mapearCamposExtracao(input: MapearCamposExtracaoInput, context: AgentCoreInvocationContext): Promise<IngestaoPayloadResult> {
    return this.invoke({ ...input }, context);
  }

  private async invoke(payload: Record<string, unknown>, context: AgentCoreInvocationContext): Promise<IngestaoPayloadResult> {
    const agentRuntimeArn = settings.INGESTAO_PAYLOAD_AGENT_RUNTIME_ARN;
    if (!agentRuntimeArn) {
      throw new Error("Missing required setting: INGESTAO_PAYLOAD_AGENT_RUNTIME_ARN");
    }

    const traceId = `ingestao-payload-${randomUUID()}`;
    const payloadBytes = Buffer.from(JSON.stringify(payload), "utf-8");
    const command = new InvokeAgentRuntimeCommand({
      agentRuntimeArn,
      qualifier: settings.INGESTAO_PAYLOAD_AGENT_RUNTIME_QUALIFIER || undefined,
      runtimeSessionId: traceId,
      traceId,
      contentType: "application/json",
      accept: "application/json",
      payload: payloadBytes,
    });

    const startedAt = Date.now();
    const baseContext = {
      escritorio_id: context.escritorioId,
      traceId,
      operation: context.operation ?? "preparar_payload_frontend",
      documentoId: context.documentoId ?? null,
      agentRuntimeArn,
      qualifier: settings.INGESTAO_PAYLOAD_AGENT_RUNTIME_QUALIFIER || null,
      input_bytes: payloadBytes.byteLength,
    };

    this.logger.info("agentcore_invoke_started", baseContext);
    try {
      const response = await this.client.send(command);
      const responseText = await readAgentCoreResponse(response);
      const parsed = parseAgentCoreResponse(responseText);
      this.logger.logLlmUsage(
        "agentcore_invoke_completed",
        {
          modelId: agentRuntimeArn,
          inputTokens: parsed.usage?.inputTokens,
          outputTokens: parsed.usage?.outputTokens,
          totalTokens: parsed.usage?.totalTokens,
          latencyMs: parsed.usage?.latencyMs ?? Date.now() - startedAt,
        },
        {
          ...baseContext,
          output_bytes: Buffer.byteLength(responseText, "utf-8"),
        },
      );
      return parsed.result;
    } catch (err) {
      this.logger.logLlmUsage(
        "agentcore_invoke_failed",
        {
          modelId: agentRuntimeArn,
          latencyMs: Date.now() - startedAt,
        },
        {
          ...baseContext,
          error: err instanceof Error ? err.message : String(err),
        },
      );
      throw err;
    }
  }
}

async function readAgentCoreResponse(response: InvokeAgentRuntimeCommandOutput): Promise<string> {
  if (!response.response) {
    throw new Error("AgentCore retornou payload vazio");
  }
  return await response.response.transformToString();
}

function parseAgentResponse(text: string): IngestaoPayloadResult {
  const trimmed = text.trim();
  try {
    const parsed = JSON.parse(trimmed) as unknown;
    if (typeof parsed === "string") return parseAgentResponse(parsed);
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      throw new Error("Resposta do agente nao e um objeto JSON.");
    }
    return parsed as IngestaoPayloadResult;
  } catch {
    const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
    const objectMatch = fenced?.[1] ?? trimmed.match(/(\{[\s\S]*\})/)?.[1];
    if (!objectMatch) {
      throw new Error(`AgentCore retornou resposta sem JSON: ${trimmed.slice(0, 500)}`);
    }
    return JSON.parse(objectMatch) as IngestaoPayloadResult;
  }
}

function parseAgentCoreResponse(text: string): AgentCoreParsedResponse {
  const result = parseAgentResponse(text);
  const envelopeResult = result.result;
  if (!("_agent_usage" in result) || typeof envelopeResult === "undefined") {
    return { result, usage: null };
  }

  if (typeof envelopeResult === "string") {
    return {
      result: parseAgentResponse(envelopeResult),
      usage: parseAgentUsage(result._agent_usage),
    };
  }

  if (typeof envelopeResult !== "object" || envelopeResult === null || Array.isArray(envelopeResult)) {
    throw new Error("Resposta do agente nao e um objeto JSON.");
  }

  return {
    result: envelopeResult as IngestaoPayloadResult,
    usage: parseAgentUsage(result._agent_usage),
  };
}

function parseAgentUsage(value: unknown): AgentCoreUsage | null {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return null;
  }
  const usage = value as Record<string, unknown>;
  return {
    inputTokens: nullableNumber(usage.input_tokens ?? usage.inputTokens),
    outputTokens: nullableNumber(usage.output_tokens ?? usage.outputTokens),
    totalTokens: nullableNumber(usage.total_tokens ?? usage.totalTokens),
    latencyMs: nullableNumber(usage.latency_ms ?? usage.latencyMs),
  };
}

function nullableNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
