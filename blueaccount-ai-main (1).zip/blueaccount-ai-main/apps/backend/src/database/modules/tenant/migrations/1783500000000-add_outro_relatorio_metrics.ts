import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddOutroRelatorioMetrics1783500000000 implements MigrationInterface {
  name = "AddOutroRelatorioMetrics1783500000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "relatorios" ADD COLUMN IF NOT EXISTS "other_metrics" jsonb`);
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_ativos_cliente_tipo_competencia"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_ativos_cliente_tipo_competencia"
      ON "relatorios" ("cliente_id", "tipo_relatorio", "competencia")
      WHERE "relatorio_ativo" = true AND "tipo_relatorio" <> 'outro'
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_outro_ativo_arquivo_origem"
      ON "relatorios" ("arquivo_origem")
      WHERE "relatorio_ativo" = true
        AND "tipo_relatorio" = 'outro'
        AND "arquivo_origem" IS NOT NULL
        AND "arquivo_origem" <> 'Cadastro manual'
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_outro_ativo_arquivo_origem"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_ativos_cliente_tipo_competencia"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_ativos_cliente_tipo_competencia"
      ON "relatorios" ("cliente_id", "tipo_relatorio", "competencia")
      WHERE "relatorio_ativo" = true
    `);
    await queryRunner.query(`ALTER TABLE "relatorios" DROP COLUMN IF EXISTS "other_metrics"`);
  }
}
