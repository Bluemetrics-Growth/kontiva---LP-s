import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateValoresACobrar1777600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS valores_a_cobrar (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        cliente_id UUID NOT NULL REFERENCES clientes(id),
        contrato_id UUID NOT NULL REFERENCES contratos(id),
        competencia VARCHAR(7) NOT NULL,
        data_referencia DATE NOT NULL,
        valores_contratados JSONB NOT NULL DEFAULT '{}',
        valores_observados JSONB NOT NULL DEFAULT '{}',
        valores_calculados JSONB NOT NULL DEFAULT '{"itens":[],"total":0}',
        outros_servicos_prestados JSONB NOT NULL DEFAULT '[]',
        explicacao_ia TEXT,
        status VARCHAR(20) NOT NULL DEFAULT 'rascunho',
        total DECIMAL(12,2) NOT NULL DEFAULT 0,
        relatorios_ids UUID[] NOT NULL DEFAULT '{}',
        recalculado_em TIMESTAMP,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT UQ_valores_a_cobrar_cliente_competencia UNIQUE (cliente_id, competencia)
      );
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_valores_a_cobrar_escritorio
        ON valores_a_cobrar (escritorio_id);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_valores_a_cobrar_cliente_status
        ON valores_a_cobrar (cliente_id, status);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS valores_a_cobrar;`);
  }
}
