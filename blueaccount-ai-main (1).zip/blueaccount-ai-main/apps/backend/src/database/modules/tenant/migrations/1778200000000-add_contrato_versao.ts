import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoVersao1778200000000 implements MigrationInterface {
  name = "AddContratoVersao1778200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "versao_do_contrato" integer`,
    );
    await queryRunner.query(`
      WITH ranked AS (
        SELECT
          id,
          ROW_NUMBER() OVER (
            PARTITION BY escritorio_id, cliente_id
            ORDER BY created_at ASC, id ASC
          ) AS versao
        FROM "contratos"
      )
      UPDATE "contratos"
      SET "versao_do_contrato" = ranked.versao::integer
      FROM ranked
      WHERE "contratos".id = ranked.id
        AND "contratos"."versao_do_contrato" IS NULL
    `);
    await queryRunner.query(
      `ALTER TABLE "contratos" ALTER COLUMN "versao_do_contrato" SET DEFAULT 1`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" ALTER COLUMN "versao_do_contrato" SET NOT NULL`,
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "UQ_contratos_cliente_versao" ON "contratos" ("escritorio_id", "cliente_id", "versao_do_contrato")`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_contratos_cliente_versao"`);
    await queryRunner.query(
      `ALTER TABLE "contratos" DROP COLUMN IF EXISTS "versao_do_contrato"`,
    );
  }
}
