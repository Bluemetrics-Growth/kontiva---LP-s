import { MigrationInterface, QueryRunner } from "typeorm";

export class AddExtrationPath1776383345928 implements MigrationInterface {
    name = 'AddExtrationPath1776383345928'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "s3_textract_path" text`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN "s3_textract_path"`);
    }

}
