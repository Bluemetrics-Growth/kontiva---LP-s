import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddRegimeTributarioSimulacoes1788400000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN IF NOT EXISTS "regime_tributario" varchar(50),
        ADD COLUMN IF NOT EXISTS "opcao_ibs_cbs" varchar(20);
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP COLUMN IF EXISTS "opcao_ibs_cbs",
        DROP COLUMN IF EXISTS "regime_tributario";
    `);
  }
}
