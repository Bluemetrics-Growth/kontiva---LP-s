import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddEmitenteRegimeToSimulacaoNotas1784900000002 implements MigrationInterface {
  name = "AddEmitenteRegimeToSimulacaoNotas1784900000002";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // CRT da NF-e (1 Simples, 2 Simples com excesso de sublimite, 3 Regime Normal, 4 MEI).
    // Já era parseado do XML e descartado; agora fica registrado para auditoria da classificação.
    await queryRunner.query(`ALTER TABLE "simulacao_notas_fiscais" ADD COLUMN IF NOT EXISTS "emitente_regime" smallint`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_notas_fiscais" DROP COLUMN IF EXISTS "emitente_regime"`);
  }
}
