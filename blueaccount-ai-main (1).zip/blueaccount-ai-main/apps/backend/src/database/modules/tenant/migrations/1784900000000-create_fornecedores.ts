import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateFornecedores1784900000000 implements MigrationInterface {
  name = "CreateFornecedores1784900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm`);

    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "fornecedores" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(),
      "escritorio_id" uuid NOT NULL,
      "cnpj" text NOT NULL,
      "razao_social" text NOT NULL,
      "nome_fantasia" text,
      "regime_tributario" text,
      "uf" varchar(2),
      "municipio" text,
      "opcao_ibs_cbs" varchar(20),
      "aliquota_credito_presumido_ibs" numeric(6,4),
      "aliquota_credito_presumido_cbs" numeric(6,4),
      "cnae_principal" varchar(7),
      "cnae_principal_descricao" text,
      "cnaes_secundarios" jsonb,
      "porte" text,
      "natureza_juridica" text,
      "situacao_cadastral" text,
      "optante_simples" boolean,
      "optante_mei" boolean,
      "consulta_cnpj_em" timestamptz,
      "consulta_cnpj_fonte" text,
      "observacoes" text,
      "ativo" boolean NOT NULL DEFAULT true,
      "created_at" timestamptz NOT NULL DEFAULT now(),
      "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_fornecedores" PRIMARY KEY ("id")
    )`);

    // Schema-per-escritório: UNIQUE (cnpj) já é unicidade por escritório.
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_fornecedores_cnpj" ON "fornecedores" ("cnpj")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_fornecedores_escritorio_ativo" ON "fornecedores" ("escritorio_id", "ativo")`);

    // A busca da tela e o seletor da simulação usam ILIKE nos três campos.
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_fornecedores_razao_social_trgm" ON "fornecedores" USING gin ("razao_social" public.gin_trgm_ops)`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_fornecedores_nome_fantasia_trgm" ON "fornecedores" USING gin ("nome_fantasia" public.gin_trgm_ops) WHERE "nome_fantasia" IS NOT NULL`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_fornecedores_cnpj_trgm" ON "fornecedores" USING gin ("cnpj" public.gin_trgm_ops)`);

    await queryRunner.query(`DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_fornecedores_opcao_ibs_cbs'
            AND t.relname = 'fornecedores'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "fornecedores"
            ADD CONSTRAINT "CHK_fornecedores_opcao_ibs_cbs"
            CHECK ("opcao_ibs_cbs" IS NULL OR "opcao_ibs_cbs" IN ('regime_unico', 'regime_regular'));
        END IF;
      END
    $$`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "fornecedores"`);
  }
}
