import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";

export type TipoPlataformaCobranca = "asaas" | "stripe";
export type AmbientePlataformaCobranca = "sandbox" | "producao";

@Entity("plataformas_cobranca")
export class PlataformaCobranca {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  plataforma!: TipoPlataformaCobranca;

  @Column({ type: "text", default: "sandbox" })
  ambiente!: AmbientePlataformaCobranca;

  @Column({ type: "text" })
  api_key_encrypted!: string;

  @Column({ type: "text" })
  api_key_iv!: string;

  @Column({ type: "text" })
  api_key_tag!: string;

  @Column({ type: "text", nullable: true })
  api_key_hint!: string | null;

  /**
   * Token que a Asaas devolve no header `asaas-access-token` de cada webhook. Guardado
   * criptografado (AES-256-GCM via `CryptoService`) como a `api_key` — precisa ser reversível
   * porque é reenviado à Asaas ao registrar/renovar o webhook.
   */
  @Column({ type: "text", nullable: true })
  webhook_auth_token_encrypted!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_auth_token_iv!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_auth_token_tag!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_id_externo!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_secret_encrypted!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_secret_iv!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_secret_tag!: string | null;

  @Column({ type: "text", nullable: true })
  webhook_secret_hint!: string | null;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
