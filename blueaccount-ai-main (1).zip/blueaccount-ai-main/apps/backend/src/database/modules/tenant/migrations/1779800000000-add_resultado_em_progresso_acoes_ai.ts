import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddResultadoEmProgressoAcoesAi1779800000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE acoes_ai ADD COLUMN IF NOT EXISTS resultado text NULL`);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE acoes_ai DROP COLUMN IF EXISTS resultado`);
  }
}
