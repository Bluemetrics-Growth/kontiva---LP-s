import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  ManyToMany,
  JoinColumn,
  JoinTable,
  OneToMany,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { SimulacaoGrupo } from "./simulacao-grupo.entity.js";
import { SimulacaoGrupoItem } from "./simulacao-grupo-item.entity.js";
import { Fornecedor } from "./fornecedor.entity.js";
import type { OpcaoIbsCbs } from "./fornecedor.entity.js";

export type ComposicaoBaseIcms = "sem_ibs_cbs" | "com_ibs_cbs";

/**
 * Destino do IPI destacado quando o regime efetivo do cenário não o admite na receita — hoje, o
 * Simples Nacional, onde o IPI é componente do DAS (LC 123/2006, art. 13, II) e o optante não o
 * destaca. Premissa de comparação de regimes, não correção de dado: numa simulação de troca de
 * regime os lançamentos vêm das NF-e reais do cliente no Lucro Real/Presumido, com IPI legítimo.
 */
export type DestinoIpiSemIncidencia = "receita" | "reducao_preco";
export type TipoValorEntradaPadrao = "valor_total" | "valor_operacao";

@Entity("simulacoes")
export class Simulacao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  /** Cenário-base de uma série vinculada. Null para cenários independentes e para a fonte. */
  @ManyToOne(() => Simulacao, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "simulacao_origem_id" })
  simulacao_origem!: Relation<Simulacao> | null;

  @Column({ type: "uuid", nullable: true })
  simulacao_origem_id!: string | null;

  @Column({ type: "varchar", length: 255 })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  /**
   * Ano do cenário. Define as alíquotas de IBS/CBS vigentes e o fator de retenção de ICMS/ISS via
   * `domain/simulacoes/cronograma-reforma.ts`. Sem default no banco de propósito: um default estático
   * ficaria congelado no ano da migration, e o ano corrente é responsabilidade da aplicação.
   */
  @Column({ type: "int" })
  ano!: number;

  /** Null = herdar o regime tributário atual do cliente. */
  @Column({ type: "varchar", length: 50, nullable: true })
  regime_tributario!: string | null;

  /** Só é persistida para override explícito de Simples Nacional. Null também representa o default. */
  @Column({ type: "varchar", length: 20, nullable: true })
  opcao_ibs_cbs!: OpcaoIbsCbs | null;

  /**
   * Estimativa manual do DAS ainda devido no cenário. No regime único representa o DAS completo;
   * no regime regular, somente a parcela residual sem IBS/CBS. Null = não informado, nunca zero.
   */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  valor_das_estimado!: number | null;

  /** Receita bruta acumulada nos 12 meses anteriores. Null = usar a projeção anual do cenário. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  rbt12!: number | null;

  /** Folha dos 12 meses usada no Fator R. Null = premissa ausente. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  folha_12m!: number | null;

  /**
   * Override da UF do contribuinte simulado. Liga a derivação de ICMS/ISS pela localidade do
   * fornecedor (`domain/simulacoes/localidade/`); `null` herda a UF atual do cliente.
   *
   * A assimetria por tipo de linha importa: num **custo** o fornecedor é a origem da operação e esta
   * UF é o destino, então vale a matriz interestadual; numa **receita** não há fornecedor, esta UF é
   * origem e destino ao mesmo tempo, e a matriz devolve a alíquota interna do próprio estado.
   */
  @Column({ type: "varchar", length: 2, nullable: true })
  uf!: string | null;

  /** Null = derivar do cronograma do `ano`. Valor preenchido é override explícito do cenário. */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_ibs_padrao!: number | null;

  /** Null = derivar do cronograma do `ano`. Valor preenchido é override explícito do cenário. */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_cbs_padrao!: number | null;

  /**
   * Alíquota **nominal** de ICMS do cenário (varia por estado). O motor aplica o fator de transição
   * do `ano` em cima dela. Null = sem ICMS.
   */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_icms_padrao!: number | null;

  /**
   * Alíquota **nominal** de ISS do cenário (varia por município). O motor aplica o fator de transição
   * do `ano` em cima dela. Null = sem ISS.
   */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_iss_padrao!: number | null;

  /**
   * Hipótese padrão para entradas manuais: se os valores de IBS/CBS compõem a base do ICMS.
   * Não muda a base de IBS/CBS, que continua excluindo ICMS e IPI.
   */
  @Column({ type: "varchar", length: 20, default: "sem_ibs_cbs" })
  composicao_base_icms!: ComposicaoBaseIcms;

  /**
   * O que acontece com o IPI destacado nas receitas quando o regime efetivo não o admite.
   * `receita` mantém o preço e o valor vira receita bruta; `reducao_preco` tira o valor do preço, e
   * então todas as bases caem juntas, inclusive a do DAS. Ver `DestinoIpiSemIncidencia`.
   */
  @Column({ type: "varchar", length: 20, default: "receita" })
  destino_ipi_sem_incidencia!: DestinoIpiSemIncidencia;

  /** Contraparte genérica herdada apenas por novas entradas manuais de custo/despesa. */
  @ManyToOne(() => Fornecedor, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "fornecedor_padrao_id" })
  fornecedor_padrao!: Relation<Fornecedor> | null;

  @Column({ type: "uuid", nullable: true })
  fornecedor_padrao_id!: string | null;

  /** Qual campo monetário uma nova entrada manual inicializa com zero. */
  @Column({ type: "varchar", length: 20, default: "valor_total" })
  tipo_valor_entrada_padrao!: TipoValorEntradaPadrao;

  /**
   * Dias entre a data/competência de uma entrada e o caixa efetivo, aplicado pelo fluxo de caixa
   * (`domain/simulacoes/fluxo-caixa.ts`) a toda entrada sem `data_caixa_esperada` própria. Default 0
   * = caixa no mesmo dia da nota; positivo = recebe/paga depois.
   */
  @Column({ type: "int", default: 0 })
  prazo_medio_caixa_dias!: number;

  @ManyToMany(() => SimulacaoGrupo)
  @JoinTable({
    name: "simulacao_grupo_itens",
    joinColumn: { name: "simulacao_id", referencedColumnName: "id" },
    inverseJoinColumn: { name: "simulacao_grupo_id", referencedColumnName: "id" },
  })
  grupos!: Relation<SimulacaoGrupo[]>;

  @OneToMany(() => SimulacaoGrupoItem, (i) => i.simulacao)
  itensGrupo!: Relation<SimulacaoGrupoItem[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
