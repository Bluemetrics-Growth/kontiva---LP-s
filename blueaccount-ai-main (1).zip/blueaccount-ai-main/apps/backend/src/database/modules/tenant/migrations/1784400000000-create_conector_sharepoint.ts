import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateConectorSharePoint1784400000000 implements MigrationInterface {
  name = "CreateConectorSharePoint1784400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "conector_sharepoint_conexoes" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL,
      "url_pasta" text, "site_id" text, "drive_id" text, "root_item_id" text,
      "microsoft_tenant_id" text, "microsoft_account_id" text, "microsoft_account_email" text,
      "status" text NOT NULL DEFAULT 'erro', "ativo" boolean NOT NULL DEFAULT false,
      "access_token_encrypted" text, "access_token_iv" text, "access_token_tag" text,
      "refresh_token_encrypted" text, "refresh_token_iv" text, "refresh_token_tag" text,
      "access_token_expires_at" timestamptz, "conectado_por_usuario_id" uuid,
      "reconectado_por_usuario_id" uuid, "ultimo_erro" text,
      "oauth_nonce_hash" text, "oauth_pkce_verifier_encrypted" text,
      "oauth_pkce_verifier_iv" text, "oauth_pkce_verifier_tag" text,
      "oauth_expires_at" timestamptz, "oauth_url_pasta" text,
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_conector_sharepoint_conexoes" PRIMARY KEY ("id")
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conector_sharepoint_conexao_escritorio" ON "conector_sharepoint_conexoes" ("escritorio_id")`);

    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "conector_sharepoint_execucoes" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "status" text NOT NULL,
      "execution_arn" text, "total_listados" int NOT NULL DEFAULT 0, "sincronizados" int NOT NULL DEFAULT 0,
      "ignorados" int NOT NULL DEFAULT 0, "erros" int NOT NULL DEFAULT 0, "truncada" boolean NOT NULL DEFAULT false,
      "detalhes" jsonb, "erro" text, "iniciada_por_usuario_id" uuid,
      "started_at" timestamptz NOT NULL DEFAULT now(), "finished_at" timestamptz,
      CONSTRAINT "PK_conector_sharepoint_execucoes" PRIMARY KEY ("id")
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conector_sharepoint_exec_ativa" ON "conector_sharepoint_execucoes" ("escritorio_id") WHERE "status" = 'executando'`);

    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "conector_sharepoint_arquivos" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "execucao_id" uuid NOT NULL,
      "sharepoint_item_id" text NOT NULL, "hash_algorithm" text NOT NULL, "hash_value" text NOT NULL,
      "nome_arquivo" text NOT NULL, "mime_type" text, "size_bytes" bigint, "sharepoint_modified_time" timestamptz,
      "modulo" text NOT NULL, "s3_key" text NOT NULL, "documento_id" uuid, "status" text NOT NULL, "motivo" text,
      "created_at" timestamptz NOT NULL DEFAULT now(), "updated_at" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_conector_sharepoint_arquivos" PRIMARY KEY ("id"),
      CONSTRAINT "FK_conector_sharepoint_arquivos_execucao" FOREIGN KEY ("execucao_id") REFERENCES "conector_sharepoint_execucoes"("id") ON DELETE CASCADE
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_conector_sharepoint_arq_dedup" ON "conector_sharepoint_arquivos" ("escritorio_id", "modulo", "hash_algorithm", "hash_value") WHERE "status" = 'sincronizado'`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_conector_sharepoint_arq_item" ON "conector_sharepoint_arquivos" ("escritorio_id", "sharepoint_item_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "conector_sharepoint_arquivos"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "conector_sharepoint_execucoes"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "conector_sharepoint_conexoes"`);
  }
}
