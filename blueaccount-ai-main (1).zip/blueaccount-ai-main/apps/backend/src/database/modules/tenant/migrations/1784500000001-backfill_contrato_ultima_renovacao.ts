import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Garante que `contratos.ultima_renovacao` esteja sempre preenchida (invariante do
 * gate de competência e do lock de renovação). Backfill agressivo: preenche a
 * partir de `data_inicio` (= início do contrato) e, na falta, da data de criação.
 *
 * Idempotente (só age em linhas com `ultima_renovacao` vazia); sem restore no
 * `down` (backfill de dados).
 */
export class BackfillContratoUltimaRenovacao1784500000001 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE contratos
      SET ultima_renovacao = COALESCE(
        NULLIF(TRIM(ultima_renovacao), ''),
        NULLIF(TRIM(data_inicio), ''),
        to_char(created_at, 'YYYY-MM-DD'))
      WHERE NULLIF(TRIM(ultima_renovacao), '') IS NULL;
    `);
  }

  async down(): Promise<void> {
    // Backfill de dados: não há restauração do estado anterior.
  }
}
