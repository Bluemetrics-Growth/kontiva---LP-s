import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Simulacao } from "./simulacao.entity.js";
import { Fornecedor } from "./fornecedor.entity.js";
import { SimulacaoNotaFiscal } from "./simulacao-nota-fiscal.entity.js";
import type { ComposicaoBaseIcms } from "./simulacao.entity.js";
import { AcumuladorSimulacao } from "./acumulador-simulacao.entity.js";
import { Documento } from "./documento.entity.js";

export type SimulacaoEntradaTipo = "receita" | "custo" | "custo_direto" | "outra_receita" | "outra_despesa";
export type RegraCredito = "integral" | "parcial" | "manual" | "sem_credito";
export type RegraCredIcms = "integral" | "parcial" | "manual" | "sem_credito";
export type RegimeFornecedor = "padrao" | "simples_nacional" | "outro_sem_credito";
export type TratamentoIcms = "gera_debito" | "gera_credito" | "credito_transferido_manual" | "sem_efeito";
export type TratamentoIbsCbs = "padrao" | "reduzida" | "aliquota_zero" | "exportacao";
export type OrigemFatorIva = "manual" | "ncm" | "nbs" | "acumulador" | "tratamento";
/**
 * De onde veio a base fiscal da linha. Os três estados são sobre EVIDÊNCIA, não sobre precisão:
 *
 * - `documento`: destacada no documento fiscal. É número da nota.
 * - `informada`: sem documento por trás — o contador digitou a base, ou ela sai por aritmética direta do
 *   valor que ele digitou. Não é estimativa nossa e não há documento para conferir, então não pede revisão.
 * - `estimada`: **nós** projetamos porque o documento existe mas não destacou a base. Único caso que
 *   pede revisão: há uma nota contra a qual conferir.
 *
 * `informada` existe porque colapsá-la em `estimada` marcava toda linha manual como "confiança baixa,
 * requer revisão", afogando os casos reais de NF-e sem base destacada; e colapsá-la em `documento`
 * (quando a base era digitada) afirmava evidência documental inexistente.
 */
export type OrigemBaseFiscal = "documento" | "informada" | "estimada";
export type ConfiancaBaseFiscal = "alta" | "baixa";

@Index("IDX_simulacao_entradas_acumulador", ["acumulador_id"])
@Index("IDX_simulacao_entradas_documento_origem", ["documento_origem_id"])
@Entity("simulacao_entradas")
export class SimulacaoEntrada {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Simulacao, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "simulacao_id" })
  simulacao!: Relation<Simulacao>;

  @Column({ type: "uuid" })
  simulacao_id!: string;

  @Column({ type: "varchar", length: 50 })
  tipo!: SimulacaoEntradaTipo;

  @ManyToOne(() => AcumuladorSimulacao, (acumulador) => acumulador.entradas, { nullable: true, onDelete: "RESTRICT" })
  @JoinColumn({ name: "acumulador_id" })
  acumulador!: Relation<AcumuladorSimulacao> | null;

  @Column({ type: "uuid", nullable: true })
  acumulador_id!: string | null;

  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true })
  fator_ibs!: number | null;

  @Column({ type: "varchar", length: 20, default: "tratamento" })
  origem_fator_ibs!: OrigemFatorIva;

  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true })
  fator_cbs!: number | null;

  @Column({ type: "varchar", length: 20, default: "tratamento" })
  origem_fator_cbs!: OrigemFatorIva;

  @ManyToOne(() => Documento, { nullable: true, onDelete: "CASCADE" })
  @JoinColumn({ name: "documento_origem_id" })
  documento_origem!: Relation<Documento> | null;

  @Column({ type: "uuid", nullable: true })
  documento_origem_id!: string | null;

  @Column({ type: "varchar", length: 255 })
  descricao!: string;

  /** NCM de oito dígitos extraído do item da NF-e/NFC-e. Null para linhas manuais ou sem NCM válido. */
  @Column({ type: "varchar", length: 8, nullable: true })
  ncm!: string | null;

  /**
   * NBS de nove dígitos (Nomenclatura Brasileira de Serviços), mutuamente exclusiva com `ncm` —
   * `CHK_simulacao_entrada_ncm_xor_nbs` garante no banco que uma linha nunca carrega os dois ao
   * mesmo tempo. Diferente do NCM (mercadoria, gateia crédito de ICMS), a NBS dirige exclusivamente
   * IBS/CBS: fator de alíquota, vedação de crédito ao adquirente (art. 57) e sinalização de regime
   * específico. Nunca afeta ICMS, ISS ou DIFAL. Resolvida por
   * `domain/simulacoes/nbs/consulta-nbs.service.ts`.
   */
  @Column({ type: "varchar", length: 9, nullable: true })
  nbs!: string | null;

  /**
   * `true` quando a NBS desta linha veda ao adquirente apropriar crédito de IBS/CBS (LC 214/2025,
   * art. 57). Derivado e persistido no write a partir da regra legal resolvida para `nbs` — o motor
   * (`calculo.ts`) só lê este campo, nunca resolve a regra. `false`/sem NBS = crédito permitido.
   */
  @Column({ type: "boolean", default: false })
  credito_ibs_cbs_vedado!: boolean;

  /**
   * Regime específico da LC 214/2025 (financeiro, planos de saúde, hotelaria/alimentação/turismo,
   * bens imóveis, transporte coletivo de passageiros, ...) identificado pela NBS desta linha.
   * Sinalização apenas — não altera nenhum número do cálculo, pois esses regimes ainda não são
   * modelados pela simulação.
   */
  @Column({ type: "varchar", length: 40, nullable: true })
  regime_especifico!: string | null;

  /**
   * CFOP de quatro dígitos extraído de `det/prod/CFOP` do item da NF-e/NFC-e, ou informado
   * manualmente. Classificador oficial da natureza da operação, sempre na perspectiva do EMITENTE do
   * documento. É o que refina o `tipo` para `outra_despesa`/`outra_receita` (uso e consumo, ativo
   * imobilizado, bonificação, serviço) e o que sinaliza comércio exterior: grupo 3 é importação,
   * grupo 7 é exportação. Interpretação em `domain/simulacoes/nfe/cfop.ts`. Nulo para linhas manuais
   * antigas e para a entrada sintética de nota sem itens legíveis.
   */
  @Column({ type: "varchar", length: 4, nullable: true })
  cfop!: string | null;

  /** CST do ICMS extraído do item da NF-e/NFC-e; nulo para linhas manuais ou Simples Nacional. */
  @Column({ type: "varchar", length: 2, nullable: true })
  cst!: string | null;

  /** CSOSN extraído do item da NF-e/NFC-e; nulo para linhas manuais ou regime normal. */
  @Column({ type: "varchar", length: 3, nullable: true })
  csosn!: string | null;

  /** Data/competência do valor (ex.: emissão da nota importada). Null = sem data. */
  @Column({ type: "date", nullable: true })
  data!: string | null;

  /**
   * Data esperada de pagamento/recebimento em caixa desta linha. Só a perna operacional e a perna
   * transacional de IBS/CBS (split payment/bem de capital) de `fluxo-caixa.ts` leem este campo — a
   * apuração mensal de tributo (ICMS/ISS/PIS-COFINS/DIFAL) segue o vencimento legal, nunca esta data.
   * Null = usa `data` deslocada por `simulacoes.prazo_medio_caixa_dias` (default 0 = mesma data).
   */
  @Column({ type: "date", nullable: true })
  data_caixa_esperada!: string | null;

  /** Valor da operação antes de IBS/CBS. Um dos dois valores monetários é obrigatório. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  valor_operacao!: number | null;

  /** Preço final cobrado. Quando ausente, o motor o forma adicionando IBS/CBS por fora. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  valor_total!: number | null;

  /**
   * IPI informado pelo contador ou extraído da NF-e. É preservado como premissa/auditoria, mas o
   * motor usa zero a partir de 2027, salvo em produto explicitamente concorrente da ZFM.
   */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  valor_ipi!: number | null;

  /** Exceção explícita à alíquota zero de IPI a partir de 2027: produto concorrente da ZFM. */
  @Column({ type: "boolean", default: false })
  produto_concorrente_zfm!: boolean;

  /** ICMS informado em entrada manual. Quando preenchido, prevalece sobre o cálculo por alíquota. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  valor_icms!: number | null;

  /** Null = herdar `simulacoes.composicao_base_icms`. Disponível inicialmente só em entrada manual. */
  @Column({ type: "varchar", length: 20, nullable: true })
  composicao_base_icms_override!: ComposicaoBaseIcms | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  base_ibs_cbs!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  base_icms!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  base_iss!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  base_difal!: number | null;

  @Column({ type: "varchar", length: 12, default: "estimada" })
  origem_base_ibs_cbs!: OrigemBaseFiscal;

  @Column({ type: "varchar", length: 12, default: "estimada" })
  origem_base_icms!: OrigemBaseFiscal;

  @Column({ type: "varchar", length: 12, default: "estimada" })
  origem_base_iss!: OrigemBaseFiscal;

  @Column({ type: "varchar", length: 12, default: "estimada" })
  origem_base_difal!: OrigemBaseFiscal;

  @Column({ type: "varchar", length: 8, default: "baixa" })
  confianca_base_ibs_cbs!: ConfiancaBaseFiscal;

  @Column({ type: "varchar", length: 8, default: "baixa" })
  confianca_base_icms!: ConfiancaBaseFiscal;

  @Column({ type: "varchar", length: 8, default: "baixa" })
  confianca_base_iss!: ConfiancaBaseFiscal;

  @Column({ type: "varchar", length: 8, default: "baixa" })
  confianca_base_difal!: ConfiancaBaseFiscal;

  @Column({ type: "varchar", length: 20, default: "padrao" })
  tratamento_ibs_cbs!: TratamentoIbsCbs;

  /** Fração de redução (0,60 = redução de 60%). Só se aplica a `reduzida`. */
  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true })
  percentual_reducao_ibs_cbs!: number | null;

  @Column({ type: "text", nullable: true })
  fundamento_legal_ibs_cbs!: string | null;

  @Column({ type: "varchar", length: 100, nullable: true })
  categoria!: string | null;

  @Column({ type: "varchar", length: 20, default: "integral" })
  regra_credito!: RegraCredito;

  /**
   * Proxy legado do regime da contraparte, digitado linha por linha. Continua sendo gravado por
   * compatibilidade, mas quando `fornecedor_id` está preenchido o cálculo usa o perfil derivado do
   * cadastro do fornecedor (ver `domain/fornecedores/regime-credito.ts`).
   */
  @Column({ type: "varchar", length: 30, nullable: true })
  regime_fornecedor!: RegimeFornecedor | null;

  /** Fornecedor cadastrado que origina a despesa. Null = linha legada/manual. */
  @ManyToOne(() => Fornecedor, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "fornecedor_id" })
  fornecedor!: Relation<Fornecedor> | null;

  @Column({ type: "uuid", nullable: true })
  fornecedor_id!: string | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_ibs_override!: number | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_cbs_override!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  credito_ibs_manual!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  credito_cbs_manual!: number | null;

  /** Débito explícito de PIS/COFINS da receita em 2026. Null mantém o proxy automático. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  debito_pis_cofins_manual!: number | null;

  /** Crédito explícito de PIS/COFINS do custo/despesa em 2026. Null equivale a zero. */
  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  credito_pis_cofins_manual!: number | null;

  /** Base legal/contábil registrada para sustentar o crédito manual de PIS/COFINS. */
  @Column({ type: "text", nullable: true })
  fundamento_credito_pis_cofins!: string | null;

  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true })
  percentual_credito!: number | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_icms_override!: number | null;

  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true })
  aliquota_iss_override!: number | null;

  /**
   * CNAE manual da linha (7 dígitos, sem pontuação). Nível mais forte da precedência de 2 níveis
   * resolvida por `resolverCnaeEntrada` (`domain/simulacoes/calculo.ts`): vence sobre
   * `fornecedor.cnae_principal` do fornecedor vinculado. Usado só para gatear crédito de ICMS pela
   * allowlist do cliente (`clientes.cnaes_fornecedores_permitidos`) — nunca afeta IBS/CBS/ISS. Sem
   * backfill: nasce `NULL` para toda entrada já existente.
   */
  @Column({ type: "varchar", length: 7, nullable: true })
  cnae_override!: string | null;

  /** Descrição textual do CNAE informado manualmente, exibida ao lado do código na UI. */
  @Column({ type: "text", nullable: true })
  cnae_override_descricao!: string | null;

  /**
   * UF manual da linha, para origem de ICMS/DIFAL. Vence SEMPRE `fornecedor.uf` quando os dois
   * estão presentes — usado só por `resolverLocalidadeDaEntrada` (`domain/simulacoes/
   * simulacao.service.ts`) para resolver a localidade de ICMS e o DIFAL, não introduz um novo
   * nível de precedência. NÃO afeta ISS (chaveado só por `codigo_municipio_ibge`). Sem backfill:
   * nasce `NULL` para toda entrada já existente.
   */
  @Column({ type: "varchar", length: 2, nullable: true })
  uf_override!: string | null;

  @Column({ type: "varchar", length: 20, default: "integral" })
  regra_credito_icms!: RegraCredIcms;

  @Column({ type: "varchar", length: 32 })
  tratamento_icms!: TratamentoIcms;

  @Column({ type: "decimal", precision: 14, scale: 2, nullable: true })
  credito_icms_manual!: number | null;

  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true })
  percentual_credito_icms!: number | null;

  /**
   * Transferência entre estabelecimentos da MESMA empresa (matriz/filial, mesma raiz de CNPJ,
   * ADC 49/STF — ver `domain/simulacoes/nfe/classificador.ts`). Não é fato gerador, então `true` faz a
   * linha não apurar NADA em `domain/simulacoes/calculo.ts`: zera as alíquotas de IBS, CBS, ICMS e ISS
   * (inclusive a bruta), todo débito, todo crédito — inclusive `manual` e `presumido`, que não passam
   * por alíquota — e o DIFAL. Default `false`, sem backfill — nasce `false` para toda entrada já
   * existente. Ver `domain/simulacoes/README.md` → "Transferência intragrupo".
   */
  @Column({ type: "boolean", default: false })
  transferencia_intragrupo!: boolean;

  @Column({ type: "int", default: 0 })
  ordem!: number;

  /**
   * Nota fiscal que gerou esta entrada (uma linha da importação de NF-e = um item do XML, ver
   * `domain/simulacoes/nfe/mapeador.ts` → `mapearItensParaEntradas`). Null para entrada
   * manual/legada e para entrada copiada por `duplicarSimulacao`/`gerarSerieSimulacoes` — a cópia
   * nunca aponta para uma nota de outra simulação (ver `clonarSimulacaoComEntradas`, em
   * `simulacao.service.ts`). `ON DELETE CASCADE`: remover a nota remove as entradas que ela gerou.
   */
  @ManyToOne(() => SimulacaoNotaFiscal, (n) => n.entradas, { nullable: true, onDelete: "CASCADE" })
  @JoinColumn({ name: "nota_id" })
  nota!: Relation<SimulacaoNotaFiscal> | null;

  @Column({ type: "uuid", nullable: true })
  nota_id!: string | null;

  /** Entrada-fonte de uma série vinculada. Null = linha independente ou fonte da série. */
  @Column({ type: "uuid", nullable: true })
  fonte_seed!: string | null;

  /** Hash do payload editável da fonte, usado para sincronização preguiçosa por linha. */
  @Column({ type: "varchar", length: 64, nullable: true })
  fonte_hash!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
