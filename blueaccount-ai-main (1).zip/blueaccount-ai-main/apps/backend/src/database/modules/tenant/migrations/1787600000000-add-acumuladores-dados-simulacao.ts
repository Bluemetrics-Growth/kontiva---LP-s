import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddAcumuladoresDadosSimulacao1787600000000 implements MigrationInterface {
  name = "AddAcumuladoresDadosSimulacao1787600000000";
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "simulacao_entradas_tipo_check", DROP CONSTRAINT IF EXISTS "chk_simulacao_entradas_tratamento_icms_tipo"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD CONSTRAINT "chk_simulacao_entradas_tipo" CHECK ("tipo" IN ('receita','custo','custo_direto','outra_receita','outra_despesa')), ADD CONSTRAINT "chk_simulacao_entradas_tratamento_icms_tipo" CHECK (("tipo" IN ('receita','outra_receita') AND "tratamento_icms" IN ('gera_debito','sem_efeito')) OR ("tipo" IN ('custo','custo_direto','outra_despesa') AND "tratamento_icms" IN ('gera_credito','credito_transferido_manual','sem_efeito')))`);
    await queryRunner.query(`CREATE TABLE "acumuladores_simulacao" ("id" uuid NOT NULL DEFAULT uuid_generate_v7(), "codigo" varchar(30) NOT NULL, "descricao" varchar(255) NOT NULL, "tipo" varchar(10) NOT NULL, "ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "CK_acumuladores_simulacao_codigo" CHECK ("codigo" ~ '^[0-9]+$'), CONSTRAINT "CK_acumuladores_simulacao_tipo" CHECK ("tipo" IN ('receita','custo')), CONSTRAINT "PK_acumuladores_simulacao" PRIMARY KEY ("id"), CONSTRAINT "UQ_acumuladores_simulacao_codigo" UNIQUE ("codigo"))`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD "simulacao_id" uuid`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD CONSTRAINT "FK_documentos_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE`);
    await queryRunner.query(`CREATE INDEX "IDX_documentos_simulacao" ON "documentos" ("simulacao_id")`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD "acumulador_id" uuid, ADD "fator_ibs" numeric(7,6), ADD "fator_cbs" numeric(7,6), ADD "documento_origem_id" uuid`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD CONSTRAINT "CK_simulacao_entradas_fator_ibs" CHECK ("fator_ibs" IS NULL OR "fator_ibs" BETWEEN 0 AND 1), ADD CONSTRAINT "CK_simulacao_entradas_fator_cbs" CHECK ("fator_cbs" IS NULL OR "fator_cbs" BETWEEN 0 AND 1), ADD CONSTRAINT "FK_simulacao_entradas_acumulador" FOREIGN KEY ("acumulador_id") REFERENCES "acumuladores_simulacao"("id") ON DELETE RESTRICT, ADD CONSTRAINT "FK_simulacao_entradas_documento_origem" FOREIGN KEY ("documento_origem_id") REFERENCES "documentos"("id") ON DELETE CASCADE`);
    await queryRunner.query(`CREATE INDEX "IDX_simulacao_entradas_acumulador" ON "simulacao_entradas" ("acumulador_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_simulacao_entradas_documento_origem" ON "simulacao_entradas" ("documento_origem_id")`);
  }
  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "IDX_simulacao_entradas_documento_origem"`);
    await queryRunner.query(`DROP INDEX "IDX_simulacao_entradas_acumulador"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT "FK_simulacao_entradas_documento_origem", DROP CONSTRAINT "FK_simulacao_entradas_acumulador", DROP CONSTRAINT "CK_simulacao_entradas_fator_cbs", DROP CONSTRAINT "CK_simulacao_entradas_fator_ibs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN "documento_origem_id", DROP COLUMN "fator_cbs", DROP COLUMN "fator_ibs", DROP COLUMN "acumulador_id"`);
    await queryRunner.query(`DROP INDEX "IDX_documentos_simulacao"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP CONSTRAINT "FK_documentos_simulacao", DROP COLUMN "simulacao_id"`);
    await queryRunner.query(`DROP TABLE "acumuladores_simulacao"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT "chk_simulacao_entradas_tratamento_icms_tipo", DROP CONSTRAINT "chk_simulacao_entradas_tipo"`);
    await queryRunner.query(`UPDATE "simulacao_entradas" SET "tipo" = 'custo_direto' WHERE "tipo" = 'custo'`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD CONSTRAINT "simulacao_entradas_tipo_check" CHECK ("tipo" IN ('receita','custo_direto','outra_receita','outra_despesa')), ADD CONSTRAINT "chk_simulacao_entradas_tratamento_icms_tipo" CHECK (("tipo" IN ('receita','outra_receita') AND "tratamento_icms" IN ('gera_debito','sem_efeito')) OR ("tipo" IN ('custo_direto','outra_despesa') AND "tratamento_icms" IN ('gera_credito','credito_transferido_manual','sem_efeito')))`);
  }
}
