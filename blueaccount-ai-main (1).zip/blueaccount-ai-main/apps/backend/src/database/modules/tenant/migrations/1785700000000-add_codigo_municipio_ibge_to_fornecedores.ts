import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Guarda o código IBGE do município do fornecedor, que é a chave da tabela curada de ISS em
 * `domain/simulacoes/localidade/iss-municipal.ts`. Sem ele, `municipio` é só um nome livre — dois
 * "Bom Jesus" em estados diferentes são indistinguíveis, e nenhum deles resolve uma alíquota.
 *
 * O CHECK exige 7 dígitos porque a fonte devolve dois campos parecidos para o mesmo CNPJ:
 * `codigo_municipio_ibge` (ex.: 3550308) e `codigo_municipio` (ex.: 7107, o código TOM/SIAFI da
 * Receita). Só o primeiro é IBGE. A validação de prefixo por UF fica no TS
 * (`normalizarCodigoMunicipioIbge`), onde a UF da própria linha está à mão.
 *
 * O backfill aproveita `public.cadastros_cnpj.payload`: a resposta higienizada da BrasilAPI já está
 * gravada lá para todo CNPJ consultado, e a higienização só remove PII (`qsa`, e-mail, telefones).
 * Ou seja, o código já existe no banco — nunca tinha sido promovido a coluna.
 */
export class AddCodigoMunicipioIbgeToFornecedores1785700000000 implements MigrationInterface {
  name = "AddCodigoMunicipioIbgeToFornecedores1785700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "fornecedores"
        ADD COLUMN IF NOT EXISTS "codigo_municipio_ibge" varchar(7)
    `);

    await queryRunner.query(`DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_fornecedores_codigo_municipio_ibge'
            AND t.relname = 'fornecedores'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "fornecedores"
            ADD CONSTRAINT "CHK_fornecedores_codigo_municipio_ibge"
            CHECK ("codigo_municipio_ibge" IS NULL OR "codigo_municipio_ibge" ~ '^[0-9]{7}$');
        END IF;
      END
    $$`);

    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."codigo_municipio_ibge" IS
        'Código IBGE do município (7 dígitos). Chave da tabela curada de ISS em domain/simulacoes/localidade.'
    `);

    // O JOIN com a tabela de prefixos é o que descarta o código TOM de 4 dígitos e qualquer código
    // cuja UF não bate com a do próprio cadastro. Sem ele este backfill grava lixo numa coluna que
    // vira alíquota de imposto.
    //
    // Os dois lados do CNPJ passam por `regexp_replace` mesmo depois de `cadastros_cnpj` ter sido
    // padronizado para mascarado (migration pública `1784800000001`). É de propósito: comparar por
    // dígitos é correto sob os DOIS formatos, então o backfill sobrevive a ambiente meio-migrado ou
    // a mudança na ordem entre as migrations públicas e as de tenant. O modo de falha que isto
    // evita não é erro, é zero linha casada — silencioso.
    await queryRunner.query(`
      UPDATE "fornecedores" f
      SET "codigo_municipio_ibge" = candidato.codigo
      FROM (
        SELECT
          regexp_replace(c."cnpj", '\\D', '', 'g') AS cnpj_digitos,
          c."uf",
          regexp_replace(COALESCE(c."payload" ->> 'codigo_municipio_ibge', ''), '\\D', '', 'g') AS codigo
        FROM "public"."cadastros_cnpj" c
      ) AS candidato
      JOIN (VALUES
        ('AC','12'),('AL','27'),('AP','16'),('AM','13'),('BA','29'),('CE','23'),('DF','53'),
        ('ES','32'),('GO','52'),('MA','21'),('MT','51'),('MS','50'),('MG','31'),('PA','15'),
        ('PB','25'),('PR','41'),('PE','26'),('PI','22'),('RJ','33'),('RN','24'),('RS','43'),
        ('RO','11'),('RR','14'),('SC','42'),('SP','35'),('SE','28'),('TO','17')
      ) AS ibge(uf, prefixo) ON ibge.uf = candidato."uf"
      WHERE regexp_replace(f."cnpj", '\\D', '', 'g') = candidato.cnpj_digitos
        AND f."codigo_municipio_ibge" IS NULL
        AND candidato.codigo ~ '^[0-9]{7}$'
        AND left(candidato.codigo, 2) = ibge.prefixo
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "fornecedores" DROP CONSTRAINT IF EXISTS "CHK_fornecedores_codigo_municipio_ibge"`,
    );
    await queryRunner.query(
      `ALTER TABLE "fornecedores" DROP COLUMN IF EXISTS "codigo_municipio_ibge"`,
    );
  }
}
