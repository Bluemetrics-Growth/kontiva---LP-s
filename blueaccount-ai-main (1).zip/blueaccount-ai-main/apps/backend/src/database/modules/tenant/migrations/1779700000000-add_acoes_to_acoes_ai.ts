import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddAcoesToAcoesAi1779700000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE acoes_ai
      ADD COLUMN IF NOT EXISTS acoes JSONB NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE acoes_ai
      DROP COLUMN IF EXISTS acoes
    `);
  }
}
