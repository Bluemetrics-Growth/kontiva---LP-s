import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddFundamentoCreditoPisCofins1789000000000 implements MigrationInterface {
  name = "AddFundamentoCreditoPisCofins1789000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "fundamento_credito_pis_cofins" text
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP COLUMN "fundamento_credito_pis_cofins"
    `);
  }
}
