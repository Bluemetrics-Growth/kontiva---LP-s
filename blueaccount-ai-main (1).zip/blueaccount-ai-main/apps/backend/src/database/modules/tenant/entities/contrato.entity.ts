import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
  type Relation
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { ClausulasExcedentes } from "./clausulas-excedentes.entity.js";
import { ContratoDocumentoAnexo } from "./contrato-documento-anexo.entity.js";

@Index("UQ_contratos_cliente_ativo", ["cliente_id"], {
  unique: true,
  where: '"contrato_ativo" = true',
})
@Entity("contratos")
export class Contrato {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, (c) => c.contratos, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "int", default: 1 })
  versao_do_contrato!: number;

  @Column({ type: "int", default: 1 })
  complexidade_cobranca!: number;

  // ── Termos gerais ──────────────────────────────────────────────────────

  @Column({ type: "text", nullable: true })
  tipo_contrato!: string | null;

  @Column({ type: "date", nullable: true })
  data_emissao!: string | null;

  @Column({ type: "date", nullable: true })
  data_inicio!: string | null;

  @Column({ type: "int", nullable: true })
  dia_vencimento!: number | null;

  @Column({ type: "date", nullable: true })
  inicio_faturamento!: string | null;

  @Column({ type: "text", nullable: true })
  mes_vencimento!: string | null;

  @Column({ type: "text", nullable: true })
  data_termino!: string | null;

  @Column({ type: "date", nullable: true })
  ultima_renovacao!: string | null;

  // ── Valores e reajustes ────────────────────────────────────────────────

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  valor_original!: number | null;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  valor_mensal!: number | null;

  @Column({ type: "text", nullable: true })
  desconto_por_adimplencia!: string | null;

  @Column({ type: "text", nullable: true })
  multa_por_inadimplencia!: string | null;

  @Column({ type: "text", nullable: true })
  indice_reajuste!: string | null;

  @Column({ type: "varchar", length: 7, nullable: true })
  ultima_competencia_reajuste!: string | null;

  /** Data efetiva do último reajuste; sempre o aniversário de renovação. */
  @Column({ type: "date", nullable: true })
  data_ultimo_reajuste!: string | null;

  @Column({ type: "text", nullable: true })
  instrucoes_de_cobranca!: string | null;

  // ── Adicional anual (JSON) ─────────────────────────────────────────────

  @Column({ type: "jsonb", nullable: true })
  adicional_anual!: Record<string, unknown>[] | null;

  // ── Metadata ───────────────────────────────────────────────────────────

  @Column({ type: "text", nullable: true })
  arquivo_origem!: string | null;

  @Column({ type: "jsonb", nullable: true })
  extracao_bruta!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  valores_contratados!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  excedentes!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  payload_normalizado_ui!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  edicoes!: Record<string, unknown> | null;

  @Column({ type: "boolean", default: true })
  contrato_ativo!: boolean;

  // ── Relations ──────────────────────────────────────────────────────────

  @OneToMany(() => ClausulasExcedentes, (e) => e.contrato, { cascade: true })
  clausulas_excedentes!: Relation<ClausulasExcedentes[]>;

  @OneToMany(() => ContratoDocumentoAnexo, (a) => a.contrato)
  documentos_anexos!: Relation<ContratoDocumentoAnexo[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
