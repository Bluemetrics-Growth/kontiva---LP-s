import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation
} from "typeorm";
import { Cliente } from "./cliente.entity.js";

export type TipoRelatorio =
  | "resumo_folha"
  | "relatorio_excedente"
  | "numero_notas_fiscais"
  | "numero_de_documentos"
  | "lancamentos_contabeis"
  | "multa"
  | "outro";

export interface MetricaOutroRelatorio {
  value: number;
  unit?: string;
  label?: string;
}

export interface ItemMulta {
  valor: number;
  motivo: string | null;
  data: string | null;
  responsavel: string | null;
}

@Index("UQ_relatorios_ativos_cliente_tipo_competencia", ["cliente_id", "tipo_relatorio", "competencia"], {
  unique: true,
  where: '"relatorio_ativo" = true AND "tipo_relatorio" <> \'outro\'',
})
// Inclui `competencia`: a ingestão em lote via planilha usa o MESMO
// `arquivo_origem` (o documento) para todos os clientes/competências do
// arquivo — sem `competencia` aqui, o 2º período do mesmo cliente no mesmo
// upload colidiria com o 1º e o relatório "outro" daquele período nunca seria
// inserido (nem no app, nem no banco).
@Index("UQ_relatorios_outro_ativo_arquivo_origem_cliente_competencia", ["arquivo_origem", "cliente_id", "competencia"], {
  unique: true,
  where: '"relatorio_ativo" = true AND "tipo_relatorio" = \'outro\' AND "arquivo_origem" IS NOT NULL AND "arquivo_origem" <> \'Cadastro manual\'',
})
@Entity("relatorios")
export class Relatorio {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, (c) => c.relatorios, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  // ── Identificação ──────────────────────────────────────────────────────

  @Column({ type: "text" })
  tipo_relatorio!: TipoRelatorio;

  @Column({ type: "text", nullable: true })
  competencia!: string | null;

  @Column({ type: "text", nullable: true })
  razao_social!: string | null;

  // ── Resumo da folha ────────────────────────────────────────────────────

  @Column({ type: "int", nullable: true })
  colaboradores_ativos!: number | null;

  @Column({ type: "int", nullable: true })
  prolabores_ativos!: number | null;

  @Column({ type: "int", nullable: true })
  admissoes!: number | null;

  @Column({ type: "int", nullable: true })
  rescisoes!: number | null;

  @Column({ type: "int", nullable: true })
  afastados!: number | null;

  // ── Notas fiscais ──────────────────────────────────────────────────────

  @Column({ type: "int", nullable: true })
  total_notas_fiscais!: number | null;

  @Column({ type: "int", nullable: true })
  notas_entrada!: number | null;

  @Column({ type: "int", nullable: true })
  notas_saida!: number | null;

  @Column({ type: "int", nullable: true })
  notas_servico!: number | null;

  // ── Lançamentos contábeis ──────────────────────────────────────────────

  @Column({ type: "int", nullable: true })
  total_lancamentos!: number | null;

  @Column({ type: "int", nullable: true })
  lancamentos_debito!: number | null;

  @Column({ type: "int", nullable: true })
  lancamentos_credito!: number | null;

  // ── Excedentes ─────────────────────────────────────────────────────────

  @Column({ type: "jsonb", nullable: true })
  itens_excedentes!: Record<string, unknown>[] | null;

  // ── Multas ─────────────────────────────────────────────────────────────
  // Multas tomadas pelo cliente por erro do escritório; o escritório ressarce
  // o cliente. Entram como abatimento (negativo) na cobrança da competência.

  @Column({ type: "jsonb", nullable: true })
  itens_multa!: ItemMulta[] | null;

  @Column({ type: "jsonb", nullable: true })
  other_metrics!: Record<string, MetricaOutroRelatorio> | null;

  // ── Métricas normalizadas (vocabulário do contrato) ────────────────────
  // Calculado deterministicamente no backend ao salvar; usado para matching
  // com clausulas_excedentes.referencia na consolidação de valores a cobrar.

  @Column({ type: "jsonb", nullable: true })
  metricas_observadas!: Array<{ referencia: string; valor: number }> | null;

  @Column({ type: "jsonb", nullable: true })
  relatorio_qualidade_de_dados!: Record<string, unknown> | null;

  // ── Metadata ───────────────────────────────────────────────────────────

  @Column({ type: "text", nullable: true })
  arquivo_origem!: string | null;

  @Column({ type: "jsonb", nullable: true })
  extracao_bruta!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  payload_normalizado_ui!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  edicoes!: Record<string, unknown> | null;

  @Column({ type: "boolean", default: true })
  relatorio_ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;
}
