import type { MigrationInterface, QueryRunner } from "typeorm";

export class UniqueOutroRelatorioPorDocumentoCliente1783600000000 implements MigrationInterface {
  name = "UniqueOutroRelatorioPorDocumentoCliente1783600000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_outro_ativo_arquivo_origem"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_outro_ativo_arquivo_origem_cliente"
      ON "relatorios" ("arquivo_origem", "cliente_id")
      WHERE "relatorio_ativo" = true
        AND "tipo_relatorio" = 'outro'
        AND "arquivo_origem" IS NOT NULL
        AND "arquivo_origem" <> 'Cadastro manual'
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_outro_ativo_arquivo_origem_cliente"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_outro_ativo_arquivo_origem"
      ON "relatorios" ("arquivo_origem")
      WHERE "relatorio_ativo" = true
        AND "tipo_relatorio" = 'outro'
        AND "arquivo_origem" IS NOT NULL
        AND "arquivo_origem" <> 'Cadastro manual'
    `);
  }
}
