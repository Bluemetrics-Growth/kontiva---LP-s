import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddRbt12Folha12mSimulacoes1789800000001 implements MigrationInterface {
  name = "AddRbt12Folha12mSimulacoes1789800000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        ADD COLUMN "rbt12" numeric(14,2),
        ADD COLUMN "folha_12m" numeric(14,2),
        ADD CONSTRAINT "CK_simulacoes_rbt12_nao_negativo" CHECK ("rbt12" IS NULL OR "rbt12" >= 0),
        ADD CONSTRAINT "CK_simulacoes_folha_12m_nao_negativa" CHECK ("folha_12m" IS NULL OR "folha_12m" >= 0)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes"
        DROP CONSTRAINT "CK_simulacoes_folha_12m_nao_negativa",
        DROP CONSTRAINT "CK_simulacoes_rbt12_nao_negativo",
        DROP COLUMN "folha_12m",
        DROP COLUMN "rbt12"
    `);
  }
}
