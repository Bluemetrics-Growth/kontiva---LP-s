import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddQualidadeDeDadosRelatoriosValoresACobrar1779400000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS qualidade_de_dados_relatorios JSONB NULL,
      ADD COLUMN IF NOT EXISTS score_qualidade NUMERIC(5, 4) NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS qualidade_de_dados_relatorios,
      DROP COLUMN IF EXISTS score_qualidade
    `);
  }
}
