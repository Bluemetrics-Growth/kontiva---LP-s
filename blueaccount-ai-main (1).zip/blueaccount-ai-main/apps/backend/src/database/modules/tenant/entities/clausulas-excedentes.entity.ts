import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  type Relation
} from "typeorm";
import { Contrato } from "./contrato.entity.js";

export type TipoCobrancaExcedente =
  | "por_hora"
  | "por_funcionario"
  | "por_documento"
  | "por_edificio"
  | "por_obra"
  | "por_faixa"
  | "outro";

@Entity("clausulas_excedentes")
export class ClausulasExcedentes {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Contrato, (c) => c.clausulas_excedentes, { nullable: false })
  @JoinColumn({ name: "contrato_id" })
  contrato!: Relation<Contrato>;

  @Column({ type: "uuid" })
  contrato_id!: string;

  @Column({ type: "text" })
  referencia!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text", nullable: true })
  tipo_cobranca!: TipoCobrancaExcedente | null;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  valor!: number | null;

  @Column({ type: "int", nullable: true })
  quantidade_inicial!: number | null;

  @Column({ type: "int", nullable: true })
  quantidade_final!: number | null;

  @CreateDateColumn()
  created_at!: Date;
}
