import type { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateValoresCalculadosStructure1777700000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    // A tabela valores_a_cobrar já tem explicacao_ia e valores_calculados
    // Esta migration documenta a estrutura esperada dos JSONBs após a Lambda processar

    // valores_calculados deve ter esta estrutura:
    // {
    //   "valor_base": number,
    //   "excedentes": [
    //     {
    //       "tipo": string,
    //       "referencia": string,
    //       "valor_unitario": number,
    //       "valor_observado": number,
    //       "quantidade": number,
    //       "faixa": {
    //         "quantidade_inicial": number,
    //         "quantidade_final": number | null
    //       },
    //       "explicacao": string
    //     }
    //   ]
    // }

    // Garantir que as colunas existem (caso a tabela tenha sido criada antes desta migration)
    const hasExplicacaoIa = await queryRunner.hasColumn("valores_a_cobrar", "explicacao_ia");
    if (!hasExplicacaoIa) {
      await queryRunner.query(`
        ALTER TABLE valores_a_cobrar
        ADD COLUMN explicacao_ia TEXT;
      `);
    }

    // Nenhuma alteração de schema necessária — a estrutura já está em lugar
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    // Rollback: remover explicacao_ia se foi adicionada por esta migration
    const hasExplicacaoIa = await queryRunner.hasColumn("valores_a_cobrar", "explicacao_ia");
    if (hasExplicacaoIa) {
      // Mas mantemos para não quebrar a schema anterior
      // Esta é uma migration de documentação/validação, não de destruição
    }
  }
}
