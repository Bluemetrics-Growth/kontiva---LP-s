import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";

/**
 * Opção de recolhimento de IBS/CBS de um fornecedor optante do Simples Nacional (ou MEI).
 *
 * - `regime_unico`: mantém IBS/CBS dentro da guia única (DAS). O adquirente no regime regular
 *   credita apenas o percentual presumido da parcela embutida no DAS (LC 214/2025, art. 47, §9º, II).
 * - `regime_regular`: a chamada "opção híbrida" (LC 214/2025, art. 41) — permanece no Simples para os
 *   demais tributos, mas recolhe IBS/CBS pelo regime regular, com destaque integral na nota. O
 *   adquirente toma crédito cheio.
 */
export type OpcaoIbsCbs = "regime_unico" | "regime_regular";

/** CNAE secundário como devolvido pela consulta de CNPJ. */
export type CnaeSecundario = { codigo: string; descricao: string };

/**
 * Origem de uma alíquota de ICMS/ISS do fornecedor. `manual` é um trava-derivação: a importação de
 * NF-e só escreve onde a fonte é diferente de `manual`.
 */
export type AliquotaFonte = "nfe" | "manual";

const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/**
 * Contraparte de compra usada nas simulações da reforma tributária.
 *
 * Espelha `clientes` na identificação (o campo `cnpj` aceita CNPJ de 14 ou CPF de 11 dígitos), mas
 * existe para responder uma pergunta diferente: quanto de crédito de IBS/CBS aquela compra gera.
 * Por isso carrega regime tributário, UF, ramo (CNAE) e a opção de IBS/CBS.
 *
 * O isolamento é schema-per-escritório, então `UNIQUE (cnpj)` já é unicidade por escritório.
 * `escritorio_id` continua presente e é sempre repetido como predicado nas queries, por padrão do repo.
 *
 * Duas espécies de linha, separadas por `generico` e garantidas por `CHK_fornecedores_generico`:
 *
 * - **real**: tem `cnpj` e aparece na tela de fornecedores. É o cadastro normal.
 * - **genérico**: não tem `cnpj` e fica fora da tela de fornecedores. Um por perfil de regime,
 *   semeado por escritório, para a linha de despesa manual poder afirmar um regime de contraparte sem
 *   inventar um documento, já que sem `fornecedor_id` o motor zera o crédito de IBS/CBS. Ver
 *   `domain/fornecedores/fornecedores-genericos.ts`.
 */
@Entity("fornecedores")
export class Fornecedor {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  /**
   * Contraparte sintética por perfil de regime, semeada por escritório. `true` implica
   * `cnpj IS NULL`. Escondida da listagem de fornecedores e imutável pela API.
   */
  @Column({ type: "boolean", default: false })
  generico!: boolean;

  /** CNPJ (14 dígitos) ou CPF (11), mascarado por `normalizarCnpj`. Null somente em genérico. */
  @Column({ type: "text", nullable: true })
  cnpj!: string | null;

  @Column({ type: "text" })
  razao_social!: string;

  @Column({ type: "text", nullable: true })
  nome_fantasia!: string | null;

  /** Valor canônico de `REGIMES_TRIBUTARIOS` (`domain/clientes/regime-tributario.ts`). */
  @Column({ type: "text", nullable: true })
  regime_tributario!: string | null;

  @Column({ type: "varchar", length: 2, nullable: true })
  uf!: string | null;

  @Column({ type: "text", nullable: true })
  municipio!: string | null;

  /**
   * Código IBGE do município (7 dígitos), chave da tabela curada de ISS em
   * `domain/simulacoes/localidade/iss-municipal.ts`. `municipio` sozinho não serve: é texto livre, e
   * municípios homônimos em estados diferentes são indistinguíveis.
   *
   * Preenchido pela consulta de CNPJ e validado por `normalizarCodigoMunicipioIbge` — a fonte
   * devolve, no campo vizinho `codigo_municipio`, o código TOM/SIAFI de 4 dígitos, que não é IBGE.
   */
  @Column({ type: "varchar", length: 7, nullable: true })
  codigo_municipio_ibge!: string | null;

  /** Só é consultado quando o regime é Simples Nacional ou MEI. Null = não informado (≡ regime_unico). */
  @Column({ type: "varchar", length: 20, nullable: true })
  opcao_ibs_cbs!: OpcaoIbsCbs | null;

  /**
   * Alíquota de crédito presumido de IBS aplicada sobre o **valor bruto** da entrada — não é fração do
   * crédito integral (diferente de `simulacao_entradas.percentual_credito`). Semântica do art. 47,
   * §9º, II: compra × percentual = crédito.
   *
   * Null = zero. O default é deliberadamente nulo: os percentuais oficiais dependem de regulamento
   * conjunto CGIBS/RFB (variável por CNAE, faixa de receita e Anexo) que ainda não foi publicado.
   */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_credito_presumido_ibs!: number | null;

  /** Idem para CBS. Separado porque IBS e CBS são apurados em linhas distintas do resultado. */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_credito_presumido_cbs!: number | null;

  /**
   * Alíquota **nominal** (cheia) de ICMS deste fornecedor, pré-fator de retenção do cronograma.
   * Consolidada por média ponderada das NF-e importadas, ou digitada pelo contador.
   *
   * Nível intermediário de precedência no motor: perde do override da linha, ganha do padrão do
   * cenário (`calculo.ts` → `resolverAliquotasEntrada`).
   */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_icms_nominal!: number | null;

  /** Idem para ISS. Quase sempre nulo: ISS vive na NFS-e municipal, que não é importada. */
  @Column({ type: "decimal", precision: 6, scale: 4, nullable: true, transformer: numericToNumber })
  aliquota_iss_nominal!: number | null;

  /**
   * Origem da alíquota de ICMS: `nfe` (derivada da importação) ou `manual` (digitada). Existe para a
   * importação nunca sobrescrever o número do contador — sem este marcador, o valor digitado sumiria
   * no próximo lote de notas.
   */
  @Column({ type: "varchar", length: 10, nullable: true })
  aliquota_icms_fonte!: AliquotaFonte | null;

  /** Idem para ISS. Por tributo de propósito: editar o ICMS não congela a derivação do ISS. */
  @Column({ type: "varchar", length: 10, nullable: true })
  aliquota_iss_fonte!: AliquotaFonte | null;

  /** CNAE principal (7 dígitos, sem pontuação). */
  @Column({ type: "varchar", length: 7, nullable: true })
  cnae_principal!: string | null;

  @Column({ type: "text", nullable: true })
  cnae_principal_descricao!: string | null;

  @Column({ type: "jsonb", nullable: true })
  cnaes_secundarios!: CnaeSecundario[] | null;

  @Column({ type: "text", nullable: true })
  porte!: string | null;

  @Column({ type: "text", nullable: true })
  natureza_juridica!: string | null;

  @Column({ type: "text", nullable: true })
  situacao_cadastral!: string | null;

  /** O que a Receita disse (null = desconhecido). `regime_tributario` é o que o contador decidiu. */
  @Column({ type: "boolean", nullable: true })
  optante_simples!: boolean | null;

  @Column({ type: "boolean", nullable: true })
  optante_mei!: boolean | null;

  @Column({ type: "timestamptz", nullable: true })
  consulta_cnpj_em!: Date | null;

  @Column({ type: "text", nullable: true })
  consulta_cnpj_fonte!: string | null;

  @Column({ type: "text", nullable: true })
  observacoes!: string | null;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
