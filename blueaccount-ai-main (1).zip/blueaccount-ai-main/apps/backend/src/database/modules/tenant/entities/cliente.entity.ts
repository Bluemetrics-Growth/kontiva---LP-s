import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  type Relation
} from "typeorm";
import { Contrato } from "./contrato.entity.js";
import { Relatorio } from "./relatorio.entity.js";
import { Faturamento } from "./faturamento.entity.js";
import type { OpcaoIbsCbs, CnaeSecundario } from "./fornecedor.entity.js";

/**
 * Item de allowlist de NCM, mesmo shape de `CnaeSecundario` (`fornecedor.entity.ts`) mas para a
 * classificação fiscal da mercadoria (8 dígitos) em vez de CNAE (7 dígitos). Ver
 * `ncms_permitidos` abaixo.
 */
export type NcmPermitido = { codigo: string; descricao: string };

@Entity("clientes")
export class Cliente {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text", unique: true })
  cnpj!: string;

  @Column({ type: "text" })
  razao_social!: string;

  @Column({ type: "text", nullable: true })
  nome_fantasia!: string | null;

  @Column({ type: "text", nullable: true })
  email!: string | null;

  @Column({ type: "text", nullable: true })
  regime_tributario!: string | null;

  @Column({ type: "text", nullable: true })
  endereco!: string | null;

  /** Sugerida pela consulta pública de CNPJ. NULL para cadastros que nunca passaram por enriquecimento. */
  @Column({ type: "text", nullable: true })
  uf!: string | null;

  /**
   * Opção de recolhimento de IBS/CBS do cliente optante do Simples Nacional. Só é consultada quando
   * `regime_tributario === "Simples Nacional"` (ver `domain/clientes/regime-credito.ts`). Diferente
   * do equivalente em `Fornecedor` — aqui gateia o débito/crédito do PRÓPRIO cliente na simulação, não
   * o que um terceiro tomaria da nota dele. Null = não informado (≡ regime_unico).
   */
  @Column({ type: "varchar", length: 20, nullable: true })
  opcao_ibs_cbs!: OpcaoIbsCbs | null;

  @Column({ type: "text", nullable: true })
  representante_legal!: string | null;

  /**
   * CNAE principal (7 dígitos, sem pontuação), espelhando `Fornecedor.cnae_principal`. Preenchido
   * pela consulta pública de CNPJ na criação (ver `createCliente`), editável depois. Sem backfill:
   * clientes já cadastrados nascem `NULL` até a próxima edição manual.
   */
  @Column({ type: "varchar", length: 7, nullable: true })
  cnae_principal!: string | null;

  @Column({ type: "text", nullable: true })
  cnae_principal_descricao!: string | null;

  @Column({ type: "jsonb", nullable: true })
  cnaes_secundarios!: CnaeSecundario[] | null;

  /**
   * Allowlist manual de CNAE de FORNECEDOR considerado elegível a gerar crédito de IBS/CBS para
   * este cliente (LC 214/2025 restringe crédito a insumos ligados à atividade econômica do
   * contribuinte). Nunca vem da consulta de CNPJ — essa resolve o CNAE do próprio cliente, não de
   * terceiros; este campo é 100% digitação do contador. NULL/lista vazia = nenhuma restrição
   * cadastrada. Ainda não é consumido por `calculo.ts`/`resolverCreditoFornecedor` — ver
   * `domain/clientes/regime-credito.ts` → `permiteCreditoPorCnaeFornecedor`.
   */
  @Column({ type: "jsonb", nullable: true })
  cnaes_fornecedores_permitidos!: CnaeSecundario[] | null;

  /**
   * Allowlist manual de NCM (classificação fiscal da mercadoria) considerado elegível a gerar
   * crédito de ICMS para este cliente (LC 214/2025), análoga a `cnaes_fornecedores_permitidos` mas
   * chaveada pelo NCM da LINHA (`simulacao_entradas.ncm`) em vez do CNAE do fornecedor vinculado.
   * Nunca vem de consulta/lookup externo — é 100% digitação do contador. NULL/lista vazia = nenhuma
   * restrição cadastrada. Consumida por `calculo.ts` → `permiteCreditoPorNcm`
   * (`domain/clientes/regime-credito.ts`); quando cadastrada e a linha tem NCM, decide sozinha (CNAE
   * não é consultado) — ver `domain/clientes/README.md`.
   */
  @Column({ type: "jsonb", nullable: true })
  ncms_permitidos!: NcmPermitido[] | null;

  @Column({ type: "jsonb", nullable: true })
  informacoes_gerais!: Record<string, unknown> | null;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  /**
   * Grupo econômico: cliente com holding_id é membro de um grupo cuja holding é
   * outro cliente (um nível só — validado em domain/clientes/grupo.service.ts).
   * NULL = cliente isolado.
   */
  @Column({ type: "uuid", nullable: true })
  holding_id!: string | null;

  @ManyToOne(() => Cliente, (c) => c.membros, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "holding_id" })
  holding!: Relation<Cliente> | null;

  @OneToMany(() => Cliente, (c) => c.holding)
  membros!: Relation<Cliente[]>;

  /**
   * Só relevante quando o cliente é holding. No modo "contrato por empresa",
   * decide quem paga as cobranças individuais dos membros. NULL = 'empresa'.
   */
  @Column({ type: "text", nullable: true })
  pagador_grupo!: "holding" | "empresa" | null;

  @OneToMany(() => Contrato, (c) => c.cliente)
  contratos!: Relation<Contrato[]>;

  @OneToMany(() => Relatorio, (r) => r.cliente)
  relatorios!: Relation<Relatorio[]>;

  @OneToMany(() => Faturamento, (f) => f.cliente)
  faturamentos!: Relation<Faturamento[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
