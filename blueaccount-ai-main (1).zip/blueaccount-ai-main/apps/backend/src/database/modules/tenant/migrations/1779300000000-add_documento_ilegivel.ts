import { type MigrationInterface, type QueryRunner } from "typeorm";

export class AddDocumentoIlegivel1779300000000 implements MigrationInterface {
  name = "AddDocumentoIlegivel1779300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "documento_ilegivel" boolean NOT NULL DEFAULT false`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documentos" DROP COLUMN IF EXISTS "documento_ilegivel"`,
    );
  }
}
