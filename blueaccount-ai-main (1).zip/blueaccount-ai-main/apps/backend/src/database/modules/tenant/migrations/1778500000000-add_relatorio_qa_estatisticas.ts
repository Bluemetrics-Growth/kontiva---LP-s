import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddRelatorioQaEstatisticas1778500000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE relatorios
        ADD COLUMN IF NOT EXISTS relatorio_qualidade_de_dados jsonb;
    `);

    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS relatorios_estatisticas_cliente (
        id uuid NOT NULL DEFAULT gen_random_uuid(),
        escritorio_id uuid NOT NULL,
        cliente_id uuid NOT NULL REFERENCES clientes(id),
        tipo_relatorio text NOT NULL,
        campo text NOT NULL,
        quantidade_amostras integer NOT NULL,
        media numeric(14,4),
        mediana numeric(14,4),
        desvio_padrao numeric(14,4),
        minimo numeric(14,4),
        maximo numeric(14,4),
        competencia_inicial text,
        competencia_final text,
        calculado_em TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        metadados jsonb,
        CONSTRAINT PK_relatorios_estatisticas_cliente PRIMARY KEY (id)
      );
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_relatorios_estatisticas_cliente_tipo_campo
        ON relatorios_estatisticas_cliente (cliente_id, tipo_relatorio, campo);
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS IDX_relatorios_estatisticas_escritorio_cliente
        ON relatorios_estatisticas_cliente (escritorio_id, cliente_id);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS IDX_relatorios_estatisticas_escritorio_cliente;`);
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_relatorios_estatisticas_cliente_tipo_campo;`);
    await queryRunner.query(`DROP TABLE IF EXISTS relatorios_estatisticas_cliente;`);
    await queryRunner.query(`
      ALTER TABLE relatorios
        DROP COLUMN IF EXISTS relatorio_qualidade_de_dados;
    `);
  }
}
