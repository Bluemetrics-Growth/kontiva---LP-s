import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddPisCofinsManualZfmSimulacaoEntradas1788600000000 implements MigrationInterface {
  name = "AddPisCofinsManualZfmSimulacaoEntradas1788600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "produto_concorrente_zfm" boolean NOT NULL DEFAULT false,
        ADD COLUMN "debito_pis_cofins_manual" numeric(14,2),
        ADD COLUMN "credito_pis_cofins_manual" numeric(14,2),
        ADD CONSTRAINT "ck_simulacao_entrada_debito_pis_cofins_manual_nao_negativo"
          CHECK ("debito_pis_cofins_manual" IS NULL OR "debito_pis_cofins_manual" >= 0),
        ADD CONSTRAINT "ck_simulacao_entrada_credito_pis_cofins_manual_nao_negativo"
          CHECK ("credito_pis_cofins_manual" IS NULL OR "credito_pis_cofins_manual" >= 0)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP CONSTRAINT "ck_simulacao_entrada_credito_pis_cofins_manual_nao_negativo",
        DROP CONSTRAINT "ck_simulacao_entrada_debito_pis_cofins_manual_nao_negativo",
        DROP COLUMN "credito_pis_cofins_manual",
        DROP COLUMN "debito_pis_cofins_manual",
        DROP COLUMN "produto_concorrente_zfm"
    `);
  }
}
