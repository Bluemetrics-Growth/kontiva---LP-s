import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `valores_a_cobrar.status` era varchar(20), mas o status "aprovado_para_emissao"
 * tem 21 caracteres e estourava o limite ("value too long for type character varying(20)")
 * ao fechar/aprovar um registro. Alarga para 30 com folga.
 */
export class WidenValoresACobrarStatus1781000000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ALTER COLUMN status TYPE VARCHAR(30)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ALTER COLUMN status TYPE VARCHAR(20)
    `);
  }
}
