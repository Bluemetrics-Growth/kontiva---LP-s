import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { ValoresACobrar, type ValoresACobrarLinhagem, type OutroServicoPrestado } from "./valores-a-cobrar.entity.js";

/**
 * Histórico imutável de versões de cálculo de uma cobrança (billing_run).
 *
 * Uma linha é gravada a cada execução de cálculo bem-sucedida (callback do agente
 * de cobrança). Nunca é atualizada nem removida no fluxo normal — é a fonte de
 * verdade auditável do que foi calculado, com quais insumos, por quem e quando.
 *
 * O id da versão ativa é apontado por `valores_a_cobrar.versao_ativa_id`. O
 * `valores_a_cobrar` em si mantém o id estável (handle externo de cobranças, MCP
 * e rotas do frontend); o versionamento vive aqui, na tabela filha.
 */
@Index("UQ_vac_versoes_vac_versao", ["valor_a_cobrar_id", "versao"], { unique: true })
@Entity("valores_a_cobrar_versoes")
export class ValoresACobrarVersao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => ValoresACobrar, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "valor_a_cobrar_id" })
  valor_a_cobrar!: Relation<ValoresACobrar>;

  @Column({ type: "uuid" })
  valor_a_cobrar_id!: string;

  /** Sequencial por VAC (1, 2, 3, ...). */
  @Column({ type: "integer" })
  versao!: number;

  /** Hash canônico dos insumos usados neste cálculo. */
  @Column({ type: "text", nullable: true })
  input_hash!: string | null;

  // ── Snapshot dos insumos e do resultado no momento do cálculo ───────────────
  @Column({ type: "jsonb", default: () => "'{}'::jsonb" })
  valores_contratados!: Record<string, unknown>;

  @Column({ type: "jsonb", default: () => "'{}'::jsonb" })
  valores_observados!: Record<string, unknown>;

  @Column({ type: "jsonb", default: () => "'{}'::jsonb" })
  valores_calculados!: Record<string, unknown>;

  @Column({ type: "jsonb", nullable: true })
  linhagem!: ValoresACobrarLinhagem | null;

  @Column({ type: "jsonb", default: () => "'[]'::jsonb" })
  outros_servicos_prestados!: OutroServicoPrestado[];

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  total!: number | null;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  total_excedentes!: number | null;

  // ── Auditoria ───────────────────────────────────────────────────────────────
  /** Status de negócio do VAC quando a versão foi gravada. */
  @Column({ type: "varchar", length: 30, nullable: true })
  status_no_momento!: string | null;

  /** Ator que originou este cálculo (usuário/sessão/agente). */
  @Column({ type: "text", nullable: true })
  ator!: string | null;

  /** Motivo do (re)cálculo. */
  @Column({ type: "text", nullable: true })
  motivo!: string | null;

  @CreateDateColumn()
  created_at!: Date;
}
