import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * NCM extraído do item `det/prod/NCM` da NF-e/NFC-e. É proveniência do XML, não uma regra manual
 * nem uma entrada no cálculo tributário: permanece nullable para linhas manuais, legadas e itens
 * sem código válido. Sem backfill deliberado; somente novas importações o preenchem.
 */
export class AddNcmToSimulacaoEntradas1786400000000 implements MigrationInterface {
  name = "AddNcmToSimulacaoEntradas1786400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "ncm" varchar(8)
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."ncm" IS
        'NCM de oito dígitos extraído do item det/prod/NCM da NF-e/NFC-e; null para linhas manuais, legadas ou XML sem NCM válido. Não afeta cálculo ou crédito e não recebe backfill.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "ncm"`);
  }
}
