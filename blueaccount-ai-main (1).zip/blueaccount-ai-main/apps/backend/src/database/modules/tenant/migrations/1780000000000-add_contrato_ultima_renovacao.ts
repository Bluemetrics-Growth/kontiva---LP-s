import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoUltimaRenovacao1780000000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "contratos"
      ADD COLUMN IF NOT EXISTS "ultima_renovacao" text
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "contratos"
      DROP COLUMN IF EXISTS "ultima_renovacao"
    `);
  }
}
