import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * `uf_override` em `simulacao_entradas`: UF manual da linha, para origem de ICMS/DIFAL. Vence
 * SEMPRE a UF do fornecedor vinculado (`fornecedores.uf`) — mesmo espírito de `cnae_override`
 * vencendo `fornecedores.cnae_principal`, mas para a localidade de origem em vez do CNAE. Não
 * cria um novo nível de precedência: só troca qual UF alimenta o nível `localidade` já existente
 * em `resolverLocalidadeDaEntrada` (`domain/simulacoes/simulacao.service.ts`).
 *
 * Não afeta ISS: ISS é chaveado só por `fornecedores.codigo_municipio_ibge`, sem noção de UF.
 *
 * `varchar(2)` nullable, sem default, sem backfill: nasce `NULL` para toda linha existente e o
 * deploy é bit-a-bit neutro, mesmo padrão de `cnae_override`/`transferencia_intragrupo`.
 */
export class AddUfOverrideToSimulacaoEntradas1786200000000 implements MigrationInterface {
  name = "AddUfOverrideToSimulacaoEntradas1786200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "uf_override" varchar(2)
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacao_entradas"."uf_override" IS
        'UF manual da linha para origem de ICMS/DIFAL; vence SEMPRE a UF do fornecedor vinculado; não afeta ISS (chaveado só por codigo_municipio_ibge); sem backfill, NULL para toda linha existente, deploy bit-a-bit neutro.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "uf_override"`,
    );
  }
}
