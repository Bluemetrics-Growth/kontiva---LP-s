import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreatePlataformasCobranca1780600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS plataformas_cobranca (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        plataforma TEXT NOT NULL,
        ambiente TEXT NOT NULL DEFAULT 'sandbox',
        api_key_encrypted TEXT NOT NULL,
        api_key_iv TEXT NOT NULL,
        api_key_tag TEXT NOT NULL,
        api_key_hint TEXT,
        webhook_auth_token TEXT NOT NULL,
        webhook_id_externo TEXT,
        ativo BOOLEAN NOT NULL DEFAULT true,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_plataformas_cobranca_ativa
        ON plataformas_cobranca (escritorio_id, plataforma)
        WHERE ativo = true;
    `);

    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_plataformas_cobranca_webhook_token
        ON plataformas_cobranca (webhook_auth_token);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_plataformas_cobranca_webhook_token;`);
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_plataformas_cobranca_ativa;`);
    await queryRunner.query(`DROP TABLE IF EXISTS plataformas_cobranca;`);
  }
}
