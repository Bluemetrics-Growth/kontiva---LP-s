import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Contrato } from "./contrato.entity.js";
import { Documento, type TipoDocumentoContratual } from "./documento.entity.js";

@Index("UQ_contrato_documentos_anexos_documento", ["documento_id"], { unique: true })
@Index("IDX_contrato_documentos_anexos_contrato", ["contrato_id"])
@Entity("contrato_documentos_anexos")
export class ContratoDocumentoAnexo {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Contrato, (c) => c.documentos_anexos, { nullable: false })
  @JoinColumn({ name: "contrato_id" })
  contrato!: Relation<Contrato>;

  @Column({ type: "uuid" })
  contrato_id!: string;

  @ManyToOne(() => Documento, { nullable: false })
  @JoinColumn({ name: "documento_id" })
  documento!: Relation<Documento>;

  @Column({ type: "uuid" })
  documento_id!: string;

  @Column({ type: "text" })
  tipo_documento_contratual!: TipoDocumentoContratual;

  @CreateDateColumn()
  created_at!: Date;
}
