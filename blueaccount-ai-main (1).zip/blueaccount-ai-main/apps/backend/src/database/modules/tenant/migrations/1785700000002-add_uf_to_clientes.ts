import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * UF do cliente. Preenchida pela consulta pública de CNPJ (`domain/fornecedores/consulta-cnpj.service.ts`)
 * quando o cliente é criado ou completado a partir de um contrato — a API vence quando tiver o dado,
 * o valor extraído/digitado só entra como fallback.
 *
 * **Sem backfill, deliberadamente.** `uf IS NULL` para todo cliente já cadastrado, e a próxima
 * criação/edição/confirmação de contrato é quem preenche. Mesmo mecanismo de
 * `1785700000001-add_uf_to_simulacoes`: nasce nula, ninguém migra dado retroativo.
 */
export class AddUfToClientes1785700000002 implements MigrationInterface {
  name = "AddUfToClientes1785700000002";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "clientes" ADD COLUMN IF NOT EXISTS "uf" varchar(2)
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "clientes"."uf" IS
        'UF do cliente, sugerida pela consulta pública de CNPJ. NULL para cadastros que nunca passaram por enriquecimento.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "clientes" DROP COLUMN IF EXISTS "uf"`);
  }
}
