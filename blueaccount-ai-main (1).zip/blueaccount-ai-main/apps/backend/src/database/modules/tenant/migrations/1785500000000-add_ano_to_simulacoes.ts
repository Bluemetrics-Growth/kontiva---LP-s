import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona `ano` à simulação e transforma as quatro `aliquota_*_padrao` em override opcional
 * (`NULL` = derivar do cronograma da reforma para o ano).
 *
 * O backfill é escrito para preservar bit a bit o resultado de toda simulação existente:
 *
 * - cenários que **não** modelam ICMS/ISS viram `ano = 2033` (regime pleno). 2033 devolve exatamente
 *   0,1770/0,0880 pelo cronograma, e o fator 0 de ICMS/ISS não muda nada porque já eram zero;
 * - cenários que **modelam** ICMS/ISS viram `ano = 2026`, cujo fator de retenção é 1,00 — a alíquota
 *   nominal gravada continua sendo a efetiva. O IBS/CBS desses cenários permanece gravado e passa a
 *   ser lido como override explícito, então o número também não muda.
 *
 * "Modelar ICMS/ISS" inclui os overrides **por entrada**, não só as colunas do cenário: a importação
 * de NF-e grava `aliquota_icms_override` na linha e deixa o cenário em zero. Sem checar as entradas, uma
 * simulação alimentada por NF-e cairia em 2033 e teria todo o ICMS zerado pelo fator — justamente a
 * mudança de resultado que este backfill existe para evitar.
 *
 * Só depois disso as alíquotas iguais ao default canônico são normalizadas para `NULL`, e apenas onde
 * isso é comprovadamente inócuo.
 */
export class AddAnoToSimulacoes1785500000000 implements MigrationInterface {
  name = "AddAnoToSimulacoes1785500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacoes" ADD COLUMN IF NOT EXISTS "ano" integer`);

    // Cenários sem ICMS/ISS em lugar nenhum — nem no cenário, nem em override de entrada — eram, na
    // prática, cenários de regime pleno.
    await queryRunner.query(`
      UPDATE "simulacoes" s
      SET "ano" = 2033
      WHERE s."ano" IS NULL
        AND COALESCE(s."aliquota_icms_padrao", 0) = 0
        AND COALESCE(s."aliquota_iss_padrao", 0) = 0
        AND NOT EXISTS (
          SELECT 1
          FROM "simulacao_entradas" e
          WHERE e."simulacao_id" = s."id"
            AND e."escritorio_id" = s."escritorio_id"
            AND (
              COALESCE(e."aliquota_icms_override", 0) <> 0
              OR COALESCE(e."aliquota_iss_override", 0) <> 0
            )
        )
    `);

    // Cenários com ICMS/ISS precisam de fator de retenção 1,00 para não mudar de resultado.
    await queryRunner.query(`UPDATE "simulacoes" SET "ano" = 2026 WHERE "ano" IS NULL`);

    await queryRunner.query(`ALTER TABLE "simulacoes" ALTER COLUMN "ano" SET NOT NULL`);

    for (const coluna of [
      "aliquota_ibs_padrao",
      "aliquota_cbs_padrao",
      "aliquota_icms_padrao",
      "aliquota_iss_padrao",
    ]) {
      await queryRunner.query(
        `ALTER TABLE "simulacoes" ALTER COLUMN "${coluna}" DROP DEFAULT`,
      );
      await queryRunner.query(
        `ALTER TABLE "simulacoes" ALTER COLUMN "${coluna}" DROP NOT NULL`,
      );
    }

    // IBS/CBS: só as linhas de regime pleno com o valor canônico podem passar a derivar do
    // cronograma. Qualquer outro valor continua gravado como override explícito.
    await queryRunner.query(`
      UPDATE "simulacoes"
      SET "aliquota_ibs_padrao" = NULL
      WHERE "ano" = 2033 AND "aliquota_ibs_padrao" = 0.1770
    `);
    await queryRunner.query(`
      UPDATE "simulacoes"
      SET "aliquota_cbs_padrao" = NULL
      WHERE "ano" = 2033 AND "aliquota_cbs_padrao" = 0.0880
    `);

    // ICMS/ISS: zero e null são equivalentes no motor (nenhuma alíquota nominal informada).
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_icms_padrao" = NULL WHERE "aliquota_icms_padrao" = 0`,
    );
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_iss_padrao" = NULL WHERE "aliquota_iss_padrao" = 0`,
    );

    await queryRunner.query(`
      COMMENT ON COLUMN "simulacoes"."ano" IS
        'Ano do cenário. Define IBS/CBS vigentes e o fator de retenção de ICMS/ISS (cronograma da reforma).'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Reconstitui os valores efetivos antes de voltar as colunas para NOT NULL. As linhas que
    // derivavam do cronograma recebem o default canônico de regime pleno.
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_ibs_padrao" = 0.1770 WHERE "aliquota_ibs_padrao" IS NULL`,
    );
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_cbs_padrao" = 0.0880 WHERE "aliquota_cbs_padrao" IS NULL`,
    );
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_icms_padrao" = 0 WHERE "aliquota_icms_padrao" IS NULL`,
    );
    await queryRunner.query(
      `UPDATE "simulacoes" SET "aliquota_iss_padrao" = 0 WHERE "aliquota_iss_padrao" IS NULL`,
    );

    const defaults: Array<[string, string]> = [
      ["aliquota_ibs_padrao", "0.1770"],
      ["aliquota_cbs_padrao", "0.0880"],
      ["aliquota_icms_padrao", "0"],
      ["aliquota_iss_padrao", "0"],
    ];
    for (const [coluna, valor] of defaults) {
      await queryRunner.query(
        `ALTER TABLE "simulacoes" ALTER COLUMN "${coluna}" SET DEFAULT ${valor}`,
      );
      await queryRunner.query(
        `ALTER TABLE "simulacoes" ALTER COLUMN "${coluna}" SET NOT NULL`,
      );
    }

    await queryRunner.query(`ALTER TABLE "simulacoes" DROP COLUMN IF EXISTS "ano"`);
  }
}
