import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

export type ConectorSharePointExecucaoStatus = "executando" | "concluida" | "concluida_com_erros" | "erro";

@Index("UQ_conector_sharepoint_exec_ativa", ["escritorio_id"], { unique: true, where: '"status" = \'executando\'' })
@Entity("conector_sharepoint_execucoes")
export class ConectorSharePointExecucao {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "text" }) status!: ConectorSharePointExecucaoStatus;
  @Column({ type: "text", nullable: true }) execution_arn!: string | null;
  @Column({ type: "int", default: 0 }) total_listados!: number;
  @Column({ type: "int", default: 0 }) sincronizados!: number;
  @Column({ type: "int", default: 0 }) ignorados!: number;
  @Column({ type: "int", default: 0 }) erros!: number;
  @Column({ type: "boolean", default: false }) truncada!: boolean;
  @Column({ type: "jsonb", nullable: true }) detalhes!: Record<string, unknown> | null;
  @Column({ type: "text", nullable: true }) erro!: string | null;
  @Column({ type: "uuid", nullable: true }) iniciada_por_usuario_id!: string | null;
  @Column({ type: "timestamptz", default: () => "now()" }) started_at!: Date;
  @Column({ type: "timestamptz", nullable: true }) finished_at!: Date | null;
}
