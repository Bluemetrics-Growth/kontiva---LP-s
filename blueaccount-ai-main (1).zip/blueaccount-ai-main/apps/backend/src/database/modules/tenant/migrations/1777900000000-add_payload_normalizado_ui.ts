import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddPayloadNormalizadoUi1777900000000 implements MigrationInterface {
  name = "AddPayloadNormalizadoUi1777900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "documentos" ADD COLUMN IF NOT EXISTS "payload_normalizado_ui" jsonb`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "payload_normalizado_ui" jsonb`,
    );
    await queryRunner.query(
      `ALTER TABLE "relatorios" ADD COLUMN IF NOT EXISTS "payload_normalizado_ui" jsonb`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "relatorios" DROP COLUMN IF EXISTS "payload_normalizado_ui"`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" DROP COLUMN IF EXISTS "payload_normalizado_ui"`,
    );
    await queryRunner.query(
      `ALTER TABLE "documentos" DROP COLUMN IF EXISTS "payload_normalizado_ui"`,
    );
  }
}
