import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateTables1776380047700 implements MigrationInterface {
    name = 'CreateTables1776380047700'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "servicos_contratados" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "contrato_id" uuid NOT NULL, "numero_de_documentos" integer, "numero_de_colaboradores" integer, "numero_de_prolabores" integer, "numero_de_estabelecimentos" integer, "base_de_calculo" text, "outros_servicos_contratados" jsonb, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_95b20856122d8c65a77779ea328" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "clausulas_excedentes" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "contrato_id" uuid NOT NULL, "referencia" text NOT NULL, "descricao" text, "tipo_cobranca" text, "valor" numeric(12,2), "quantidade_inicial" integer, "quantidade_final" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_f72ff1c4631538391db6ea55c1d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "contratos" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "cliente_id" uuid NOT NULL, "tipo_contrato" text, "data_emissao" text, "data_inicio" text, "dia_vencimento" integer, "inicio_faturamento" text, "mes_vencimento" text, "data_termino" text, "valor_original" numeric(12,2), "desconto_por_adimplencia" text, "multa_por_inadimplencia" text, "indice_reajuste" text, "adicional_anual" jsonb, "arquivo_origem" text, "extracao_bruta" jsonb, "contrato_ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_cfae35069d6f59da899c17ed397" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_contratos_cliente_ativo" ON "contratos" ("cliente_id") WHERE "contrato_ativo" = true`);
        await queryRunner.query(`CREATE TABLE "relatorios" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "cliente_id" uuid NOT NULL, "tipo_relatorio" text NOT NULL, "competencia" text, "razao_social" text, "colaboradores_ativos" integer, "prolabores_ativos" integer, "admissoes" integer, "rescisoes" integer, "afastados" integer, "total_notas_fiscais" integer, "notas_entrada" integer, "notas_saida" integer, "notas_servico" integer, "total_lancamentos" integer, "lancamentos_debito" integer, "lancamentos_credito" integer, "itens_excedentes" jsonb, "arquivo_origem" text, "extracao_bruta" jsonb, "relatorio_ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_45c4346cde9bc12a1ece0c95b1d" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_relatorios_ativos_cliente_tipo_competencia" ON "relatorios" ("cliente_id", "tipo_relatorio", "competencia") WHERE "relatorio_ativo" = true`);
        await queryRunner.query(`CREATE TABLE "clientes" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "cnpj" text NOT NULL, "razao_social" text NOT NULL, "nome_fantasia" text, "regime_tributario" text, "ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "UQ_bd9bd4df1ccf6f9d83a6f4b26cb" UNIQUE ("cnpj"), CONSTRAINT "PK_d76bf3571d906e4e86470482c08" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "documentos" ("id" uuid NOT NULL DEFAULT gen_random_uuid(), "escritorio_id" uuid NOT NULL, "cliente_id" uuid NOT NULL, "uploaded_by_usuario_id" uuid, "modulo" text NOT NULL, "filename_original" text NOT NULL, "storage_provider" text NOT NULL, "storage_bucket" text NOT NULL, "storage_key" text NOT NULL, "mime_type" text, "size_bytes" bigint, "competencia" text, "checksum" text, "status_upload" text NOT NULL DEFAULT 'pendente', "erro_upload" text, "status_extracao" text NOT NULL DEFAULT 'pendente', "erro_extracao" text, "processed_at" TIMESTAMP WITH TIME ZONE, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_30b7ee230a352e7582842d1dc02" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_documentos_cliente_modulo" ON "documentos" ("cliente_id", "modulo") `);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_documentos_storage_key" ON "documentos" ("storage_key") `);
        await queryRunner.query(`ALTER TABLE "servicos_contratados" ADD CONSTRAINT "FK_7ef317b5e3dc4b158a098fe5376" FOREIGN KEY ("contrato_id") REFERENCES "contratos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "clausulas_excedentes" ADD CONSTRAINT "FK_9b5165d2e0c81b1a552b2c3674a" FOREIGN KEY ("contrato_id") REFERENCES "contratos"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "contratos" ADD CONSTRAINT "FK_4b115ca6c2ed3a2d502b3fad059" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "relatorios" ADD CONSTRAINT "FK_fd206d307a112147c03122d0fec" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "documentos" ADD CONSTRAINT "FK_651b869b8703ee0c5e9527f420e" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "documentos" DROP CONSTRAINT "FK_651b869b8703ee0c5e9527f420e"`);
        await queryRunner.query(`ALTER TABLE "relatorios" DROP CONSTRAINT "FK_fd206d307a112147c03122d0fec"`);
        await queryRunner.query(`ALTER TABLE "contratos" DROP CONSTRAINT "FK_4b115ca6c2ed3a2d502b3fad059"`);
        await queryRunner.query(`ALTER TABLE "clausulas_excedentes" DROP CONSTRAINT "FK_9b5165d2e0c81b1a552b2c3674a"`);
        await queryRunner.query(`ALTER TABLE "servicos_contratados" DROP CONSTRAINT "FK_7ef317b5e3dc4b158a098fe5376"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_documentos_storage_key"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_documentos_cliente_modulo"`);
        await queryRunner.query(`DROP TABLE "documentos"`);
        await queryRunner.query(`DROP TABLE "clientes"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_relatorios_ativos_cliente_tipo_competencia"`);
        await queryRunner.query(`DROP TABLE "relatorios"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_contratos_cliente_ativo"`);
        await queryRunner.query(`DROP TABLE "contratos"`);
        await queryRunner.query(`DROP TABLE "clausulas_excedentes"`);
        await queryRunner.query(`DROP TABLE "servicos_contratados"`);
    }

}
