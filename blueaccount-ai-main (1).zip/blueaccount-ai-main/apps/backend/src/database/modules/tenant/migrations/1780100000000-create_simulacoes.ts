import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSimulacoes1780100000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "simulacoes" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "cliente_id" uuid NOT NULL,
        "nome" varchar(255) NOT NULL,
        "descricao" text,
        "aliquota_ibs_padrao" decimal(6,4) NOT NULL DEFAULT 0.1770,
        "aliquota_cbs_padrao" decimal(6,4) NOT NULL DEFAULT 0.0880,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT "fk_simulacoes_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id")
      );

      CREATE INDEX "idx_simulacoes_escritorio_id" ON "simulacoes"("escritorio_id");
      CREATE INDEX "idx_simulacoes_cliente_id" ON "simulacoes"("cliente_id");

      CREATE TABLE "simulacao_entradas" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "simulacao_id" uuid NOT NULL,
        "tipo" varchar(50) NOT NULL CHECK ("tipo" IN ('receita','custo_direto','outra_receita','outra_despesa')),
        "descricao" varchar(255) NOT NULL,
        "valor_bruto" decimal(14,2) NOT NULL,
        "categoria" varchar(100),
        "regra_credito" varchar(20) NOT NULL DEFAULT 'integral' CHECK ("regra_credito" IN ('integral','parcial','manual','sem_credito')),
        "regime_fornecedor" varchar(30) CHECK ("regime_fornecedor" IN ('padrao','simples_nacional','outro_sem_credito')),
        "aliquota_ibs_override" decimal(6,4),
        "aliquota_cbs_override" decimal(6,4),
        "credito_ibs_manual" decimal(14,2),
        "credito_cbs_manual" decimal(14,2),
        "percentual_credito" decimal(5,4),
        "ordem" int NOT NULL DEFAULT 0,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT "fk_simulacao_entradas_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE
      );

      CREATE INDEX "idx_simulacao_entradas_escritorio_id" ON "simulacao_entradas"("escritorio_id");
      CREATE INDEX "idx_simulacao_entradas_simulacao_id" ON "simulacao_entradas"("simulacao_id");
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS "simulacao_entradas";
      DROP TABLE IF EXISTS "simulacoes";
    `);
  }
}
