import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddCobrancaMitigacaoValoresACobrar1778600000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS cobranca_mitigacao JSONB;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS cobranca_mitigacao;
    `);
  }
}
