import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddS3OutputPathAcoesAi1779600000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE acoes_ai
      ADD COLUMN IF NOT EXISTS s3_output_path TEXT NULL;

      ALTER TABLE acoes_ai
      ALTER COLUMN titulo DROP NOT NULL,
      ALTER COLUMN descricao DROP NOT NULL,
      ALTER COLUMN tipo_acao DROP NOT NULL;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE acoes_ai
      DROP COLUMN IF EXISTS s3_output_path;

      ALTER TABLE acoes_ai
      ALTER COLUMN titulo SET NOT NULL,
      ALTER COLUMN descricao SET NOT NULL,
      ALTER COLUMN tipo_acao SET NOT NULL;
    `);
  }
}
