import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Permite fixar o montante de ICMS em entradas manuais.
 *
 * `NULL` preserva o cálculo pela alíquota. Qualquer valor não negativo, inclusive zero, é um
 * override monetário explícito. A restrição a entradas manuais fica no domínio, pois `nota_id`
 * também pode ser removido na duplicação de uma simulação importada.
 */
export class AddValorIcmsSimulacaoEntradas1787400000000 implements MigrationInterface {
  name = "AddValorIcmsSimulacaoEntradas1787400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "valor_icms" decimal(14,2),
        ADD CONSTRAINT "ck_simulacao_entrada_valor_icms"
          CHECK ("valor_icms" IS NULL OR "valor_icms" >= 0)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "ck_simulacao_entrada_valor_icms"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "valor_icms"`);
  }
}
