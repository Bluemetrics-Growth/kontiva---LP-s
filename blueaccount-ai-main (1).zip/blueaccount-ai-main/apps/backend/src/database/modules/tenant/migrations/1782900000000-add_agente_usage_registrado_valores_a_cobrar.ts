import type { MigrationInterface, QueryRunner } from "typeorm";

/** Evita duplicar o lançamento de tokens quando o callback é reenviado. */
export class AddAgenteUsageRegistradoValoresACobrar1782900000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS agente_usage_registrado_em TIMESTAMP NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS agente_usage_registrado_em
    `);
  }
}
