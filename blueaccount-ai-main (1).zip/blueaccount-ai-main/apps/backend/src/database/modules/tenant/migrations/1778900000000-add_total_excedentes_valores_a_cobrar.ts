import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddTotalExcedenteValoresACobrar1778900000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS total_excedentes NUMERIC(12, 2) NULL;
    `);

    await queryRunner.query(`
      UPDATE valores_a_cobrar
      SET total_excedentes = (
        SELECT COALESCE(SUM(
          COALESCE(
            (exc->>'valor_total')::numeric,
            (exc->>'quantidade')::numeric * (exc->>'valor_unitario')::numeric
          )
        ), 0)
        FROM jsonb_array_elements(valores_calculados->'excedentes') AS exc
      )
      WHERE valores_calculados->'excedentes' IS NOT NULL
        AND jsonb_array_length(valores_calculados->'excedentes') > 0;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS total_excedentes;
    `);
  }
}
