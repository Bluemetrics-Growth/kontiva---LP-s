import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSimulacaoNotasFiscais1780600000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "simulacao_notas_fiscais" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "simulacao_id" uuid NOT NULL,
        "entrada_id" uuid,
        "chave" varchar(44) NOT NULL,
        "modelo" int NOT NULL,
        "ambiente" int NOT NULL,
        "tipo_operacao" int NOT NULL,
        "numero" varchar(20),
        "serie" varchar(10),
        "data_emissao" varchar(40),
        "emitente_documento" varchar(14),
        "emitente_nome" varchar(255),
        "destinatario_documento" varchar(14),
        "destinatario_nome" varchar(255),
        "valor_total" decimal(14,2) NOT NULL,
        "classificacao" varchar(20) NOT NULL,
        "divergencia_tpnf" boolean NOT NULL DEFAULT false,
        "storage_provider" varchar(10),
        "storage_key" varchar(512),
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT "fk_simulacao_notas_fiscais_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE,
        CONSTRAINT "fk_simulacao_notas_fiscais_entrada" FOREIGN KEY ("entrada_id") REFERENCES "simulacao_entradas"("id") ON DELETE SET NULL,
        CONSTRAINT "uq_simulacao_notas_fiscais_chave" UNIQUE ("simulacao_id", "chave")
      );

      CREATE INDEX "idx_simulacao_notas_fiscais_escritorio_id" ON "simulacao_notas_fiscais"("escritorio_id");
      CREATE INDEX "idx_simulacao_notas_fiscais_simulacao_id" ON "simulacao_notas_fiscais"("simulacao_id");
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS "simulacao_notas_fiscais";
    `);
  }
}
