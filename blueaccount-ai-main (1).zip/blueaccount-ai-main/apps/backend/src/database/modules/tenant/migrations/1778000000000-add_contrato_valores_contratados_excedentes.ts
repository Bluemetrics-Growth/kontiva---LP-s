import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoValoresContratadosExcedentes1778000000000 implements MigrationInterface {
  name = "AddContratoValoresContratadosExcedentes1778000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "valores_contratados" jsonb`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "excedentes" jsonb`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contratos" DROP COLUMN IF EXISTS "excedentes"`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" DROP COLUMN IF EXISTS "valores_contratados"`,
    );
  }
}
