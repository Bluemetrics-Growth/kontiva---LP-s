import type { MigrationInterface, QueryRunner } from "typeorm";
import { computeBillingInputHash } from "../../../../domain/valores-a-cobrar/billing-snapshot-hash.js";

/**
 * Backfill do versionamento (complemento de 1781900000000).
 *
 * VACs já calculados ANTES da feature ficaram sem versão e sem `input_hash` — o
 * histórico aparecia vazio e a proteção de stale não os cobria. Esta migration
 * cria a versão 1 a partir do estado atual e fixa o `input_hash` usando a MESMA
 * função canônica do runtime (sem isso, um hash divergente marcaria stale falso).
 *
 * Idempotente: só age sobre VACs com cálculo não-vazio e que ainda não têm
 * nenhuma versão — seguro de re-rodar e no-op em instalações novas.
 */
export class BackfillBillingVersoes1782000000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const calculados: Array<{
      id: string;
      escritorio_id: string;
      valores_contratados: Record<string, unknown> | null;
      valores_observados: Record<string, unknown> | null;
      valores_calculados: Record<string, unknown> | null;
      linhagem: { contrato?: { versao_do_contrato?: number | null } | null } | null;
      outros_servicos_prestados: Array<{ descricao: string; valor: number | null }> | null;
      total: string | number | null;
      total_excedentes: string | number | null;
      status: string;
    }> = await queryRunner.query(`
      SELECT vac.id, vac.escritorio_id, vac.valores_contratados, vac.valores_observados,
             vac.valores_calculados, vac.linhagem, vac.outros_servicos_prestados,
             vac.total, vac.total_excedentes, vac.status
      FROM valores_a_cobrar vac
      WHERE vac.valores_calculados IS NOT NULL
        AND vac.valores_calculados <> '{}'::jsonb
        AND NOT EXISTS (
          SELECT 1 FROM valores_a_cobrar_versoes v WHERE v.valor_a_cobrar_id = vac.id
        )
    `);

    for (const vac of calculados) {
      const inputHash = computeBillingInputHash({
        contrato_versao: vac.linhagem?.contrato?.versao_do_contrato ?? null,
        valores_contratados: vac.valores_contratados ?? {},
        valores_observados: vac.valores_observados ?? {},
        outros_servicos_prestados: vac.outros_servicos_prestados ?? [],
      });

      const inserted: Array<{ id: string }> = await queryRunner.query(
        `
        INSERT INTO valores_a_cobrar_versoes
          (escritorio_id, valor_a_cobrar_id, versao, input_hash, valores_contratados,
           valores_observados, valores_calculados, linhagem, outros_servicos_prestados,
           total, total_excedentes, status_no_momento, ator, motivo)
        VALUES ($1, $2, 1, $3, $4::jsonb, $5::jsonb, $6::jsonb, $7::jsonb, $8::jsonb, $9, $10, $11,
                'sistema:backfill', 'versão inicial (backfill da migração)')
        RETURNING id
        `,
        [
          vac.escritorio_id,
          vac.id,
          inputHash,
          JSON.stringify(vac.valores_contratados ?? {}),
          JSON.stringify(vac.valores_observados ?? {}),
          JSON.stringify(vac.valores_calculados ?? {}),
          vac.linhagem === null ? null : JSON.stringify(vac.linhagem),
          JSON.stringify(vac.outros_servicos_prestados ?? []),
          vac.total,
          vac.total_excedentes,
          vac.status,
        ],
      );

      await queryRunner.query(
        `UPDATE valores_a_cobrar SET versao_ativa_id = $1, input_hash = $2 WHERE id = $3`,
        [inserted[0].id, inputHash, vac.id],
      );
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // Remove apenas as versões do backfill e desfaz a ponte/hash desses VACs.
    await queryRunner.query(`
      UPDATE valores_a_cobrar vac
      SET versao_ativa_id = NULL, input_hash = NULL
      WHERE versao_ativa_id IN (
        SELECT id FROM valores_a_cobrar_versoes WHERE ator = 'sistema:backfill'
      )
    `);
    await queryRunner.query(`DELETE FROM valores_a_cobrar_versoes WHERE ator = 'sistema:backfill';`);
  }
}
