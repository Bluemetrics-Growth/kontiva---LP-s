# `src/database/modules/tenant`

Schema isolado por escritório. Cada escritório recebe um schema dedicado (`escritorio_<uuid>`).

## Entidades

| Tabela | Entidade | Função |
|--------|----------|--------|
| `clientes` | `Cliente` | Clientes/empresas gerenciados pelo escritório |
| `documentos` | `Documento` | Arquivos enviados (contratos, relatórios, etc.) |
| `ocr_manifests` | `OcrManifest` | Manifestos de cada execução OCR por documento |
| `ocr_blocks` | `OcrBlock` | Blocos OCR indexados para lookup por documento/página |
| `ocr_extracted_field_sources` | `OcrExtractedFieldSource` | Liga campos extraídos aos blocos OCR citados |
| `contratos` | `Contrato` | Contratos de prestação de serviço — inclui `valores_contratados`, `excedentes` e a competência do último reajuste automático |
| `valores_a_cobrar` | `ValoresACobrar` | Cobrança consolidada por cliente e competência, incluindo flag e metadados do reajuste contratual aplicado |
| `clausulas_excedentes` | `ClausulasExcedentes` | Cláusulas de cobrança por excedente |
| `servicos_contratados` | `ServicosContratados` | Serviços inclusos em um contrato |
| `relatorios` | `Relatorio` | Relatórios gerados pelo sistema |
| `simulacoes` / `simulacao_entradas` | `Simulacao` / `SimulacaoEntrada` | Cenários tributários e linhas com tratamento explícito de ICMS |
| `acumuladores_simulacao` | `AcumuladorSimulacao` | Catálogo de códigos do Domínio, classificação e estado ativo por escritório |
| `simulacao_grupos` / `simulacao_grupo_itens` | `SimulacaoGrupo` / `SimulacaoGrupoItem` | Agrupamento N:N de simulações por cliente (escopo por `cliente_id`) |
| `conexoes_assinatura_eletronica` | `ConexaoAssinaturaEletronica` | Credenciais OAuth criptografadas e cursor da sincronização por escritório/provedor |
| `envelopes_assinatura_eletronica` | `EnvelopeAssinaturaEletronica` | Ledger do PDF/certificado sincronizado no S3 e vínculo ao documento somente após processamento explícito |

## Migrations

`1787900000000-add-origem-fatores-ncm-simulacao.ts` adiciona a proveniência independente de IBS e
CBS. No backfill, todo fator histórico não nulo é marcado `manual` e todo fator nulo,
`tratamento`; os valores numéricos não são alterados. As origens permitidas são `manual`, `ncm`,
`acumulador` e `tratamento`.

`1788900000000-reconciliar-fatores-ncm-simulacoes.ts` reaplica o catálogo público por longest-prefix
somente às linhas cuja origem já é `ncm`; fatores manuais, de acumulador e de tratamento não mudam.
`1789200000000-aplicar-heranca-fatores-ncm.ts` repete essa reconciliação após a nova invariante
global: toda raiz configurada é herdada e somente uma exceção filha de fator 1 restaura alíquota cheia.
`1789000000000-add-fundamento-credito-pis-cofins.ts` adiciona o fundamento auditável dos créditos
manuais de PIS/COFINS.

`1789600000000-add_nbs_to_simulacao_entradas.ts` adiciona `nbs` (varchar(9), nullable),
`credito_ibs_cbs_vedado` (boolean, default `false`) e `regime_especifico` (varchar(40), nullable) a
`simulacao_entradas`, com `CHECK` de exclusão mútua entre `ncm` e `nbs`. Sem backfill: toda linha
existente tem `nbs` nulo, então o `CHECK` valida sem migração de dados.
`1789700000000-add_origem_fator_nbs.ts` inclui `'nbs'` no domínio de `origem_fator_ibs`/
`origem_fator_cbs` (`DROP CONSTRAINT IF EXISTS` antes do `ADD`, para ser re-executável por tenant).

Migrations TypeORM em `migrations/`. Aplicadas automaticamente ao:

1. **Provisionar novo escritório:**
   ```bash
   POST /api/admin/escritorios/:id/schema
   ```
   Chama `provisionEscritorioSchema()` → `runTenantMigrations()` → aplica todas as migrations no novo schema.

2. **Sincronizar schemas existentes:**
   ```bash
   npm run migration:sync-tenants
   ```
   Aplica migrations pendentes em todos os schemas de tenant.

3. **Gerar nova migration:**
   ```bash
   npm run migration:generate:tenant \
     --schema=escritorio_<uuid> \
     --name=AddValorReajustado
   ```
   Gera arquivo em `migrations/` após detectar diff contra o schema.

A migration de dados `1788500000000-normalizar-fonte-editavel-series-simulacao` corrige séries
criadas durante a transição do vínculo: quando a simulação externa ficou fora do grupo e uma cópia do
mesmo ano foi incluída nele, essa cópia passa a ser a fonte editável. As simulações dos outros anos e
suas entradas são redirecionadas para a cópia-base. Séries em que a fonte já pertence ao grupo não
são alteradas, e o `down` é intencionalmente vazio porque não é seguro desfazer a autoria após novas
edições na cópia-base.

### Simulações e ICMS

- `1780400000000-add_tratamento_icms_to_entradas.ts` adiciona `tratamento_icms` às entradas do simulador.
- A migration faz backfill compatível: receitas usam `gera_debito`, despesas usam `gera_credito`, e despesas de fornecedores que anteriormente anulavam ICMS recebem `regra_credito_icms = sem_credito`.
- Novos writes definem o fallback por `tipo` no domínio; a coluna não possui default fixo no banco.

### Dados do Domínio

- `1787600000000-add-acumuladores-dados-simulacao.ts` cria o catálogo vazio em cada tenant e adiciona
  `acumulador_id`, fatores e documento de origem às entradas. Não há códigos globais ou carga inicial:
  cada escritório cadastra seus acumuladores ou permite que sua primeira importação os crie.
- `1787700000000-add-fatores-padrao-acumuladores-simulacao.ts` adiciona defaults nullable de IBS/CBS
  entre 0 e 1 ao catálogo, sem backfill nem alteração das entradas existentes.
- `documentos.simulacao_id` e `simulacao_entradas.documento_origem_id` usam cascade para que remover
  um documento de importação elimine somente seu lote. Acumuladores usam `ON DELETE RESTRICT` e não
  são apagados fisicamente.

### Índices de performance

- `1782400000000-add-performance-indexes.ts` adiciona índices compostos para as listagens e filtros
  operacionais, índices de relacionamento ausentes e índices trigram para busca parcial de clientes.
- `public.pg_trgm` é habilitado pela migration pública `1782310000000-enable-pg-trgm.ts`.
- O datasource tenant mantém `search_path=<schema>,public`, necessário para FKs públicas e
  operator classes de extensões.
- O sync processa um tenant por vez, com `lock_timeout` de 5 segundos e `statement_timeout` de
  120 segundos. Os limites podem ser ajustados por `DB_TENANT_MIGRATION_LOCK_TIMEOUT_MS` e
  `DB_TENANT_MIGRATION_STATEMENT_TIMEOUT_MS`.
- Antes de adicionar novos índices, valide o padrão de consulta com `EXPLAIN (ANALYZE, BUFFERS)` e
  verifique redundância em `pg_stat_user_indexes`.

## Isolamento

- Cada schema é independente: `escritorio_<uuid>`, `escritorio_<outro_uuid>`, etc.
- A tabela `_tenant_migrations` em cada schema rastreia o estado de migrations.
- FKs para `public.escritorios` e `public.usuarios` resolvem via `search_path`.

## Exemplo: Add Column in Tenant

```typescript
// 1. Edite a entidade
export class Contrato {
  @Column()
  valor_reajustado: number;  // ← nova coluna
}

// 2. Gere a migration
npm run migration:generate:tenant --schema=escritorio_dev --name=AddValorReajustado

// 3. Revise o arquivo gerado
// src/database/modules/tenant/migrations/<timestamp>-AddValorReajustado.ts

// 4. Sincronize todos os schemas
npm run migration:sync-tenants
```
