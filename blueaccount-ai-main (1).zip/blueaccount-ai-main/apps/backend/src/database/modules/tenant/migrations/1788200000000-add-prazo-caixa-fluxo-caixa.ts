import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddPrazoCaixaFluxoCaixa1788200000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacoes" ADD COLUMN IF NOT EXISTS "prazo_medio_caixa_dias" integer NOT NULL DEFAULT 0;
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "data_caixa_esperada" date;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "data_caixa_esperada";
    `);
    await queryRunner.query(`
      ALTER TABLE "simulacoes" DROP COLUMN IF EXISTS "prazo_medio_caixa_dias";
    `);
  }
}
