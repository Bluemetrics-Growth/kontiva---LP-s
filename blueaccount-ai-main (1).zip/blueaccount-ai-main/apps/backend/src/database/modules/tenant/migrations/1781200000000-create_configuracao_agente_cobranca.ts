import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateConfiguracaoAgenteCobranca1781200000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS configuracao_agente_cobranca (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        escritorio_id UUID NOT NULL,
        modo TEXT NOT NULL DEFAULT 'legado',
        inference_profile_id TEXT,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `);

    // Singleton por escritório.
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS UQ_configuracao_agente_cobranca_escritorio
        ON configuracao_agente_cobranca (escritorio_id);
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS UQ_configuracao_agente_cobranca_escritorio;`);
    await queryRunner.query(`DROP TABLE IF EXISTS configuracao_agente_cobranca;`);
  }
}
