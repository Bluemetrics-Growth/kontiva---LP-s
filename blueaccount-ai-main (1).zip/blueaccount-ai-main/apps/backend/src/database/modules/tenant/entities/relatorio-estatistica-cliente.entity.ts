import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";

@Index("UQ_relatorios_estatisticas_cliente_tipo_campo", ["cliente_id", "tipo_relatorio", "campo"], {
  unique: true,
})
@Index("IDX_relatorios_estatisticas_escritorio_cliente", ["escritorio_id", "cliente_id"])
@Entity("relatorios_estatisticas_cliente")
export class RelatorioEstatisticaCliente {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "text" })
  tipo_relatorio!: string;

  @Column({ type: "text" })
  campo!: string;

  @Column({ type: "int" })
  quantidade_amostras!: number;

  @Column({ type: "decimal", precision: 14, scale: 4, nullable: true })
  media!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 4, nullable: true })
  mediana!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 4, nullable: true })
  desvio_padrao!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 4, nullable: true })
  minimo!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 4, nullable: true })
  maximo!: number | null;

  @Column({ type: "text", nullable: true })
  competencia_inicial!: string | null;

  @Column({ type: "text", nullable: true })
  competencia_final!: string | null;

  @CreateDateColumn({ type: "timestamp with time zone" })
  calculado_em!: Date;

  @Column({ type: "jsonb", nullable: true })
  metadados!: Record<string, unknown> | null;
}
