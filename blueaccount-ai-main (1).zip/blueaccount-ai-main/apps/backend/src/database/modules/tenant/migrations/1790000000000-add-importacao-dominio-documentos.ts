import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddImportacaoDominioDocumentos1790000000000 implements MigrationInterface {
  name = "AddImportacaoDominioDocumentos1790000000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN "chave_importacao" text`);
    await queryRunner.query(`ALTER TABLE "documentos" ADD COLUMN "dados_simulacao_output_key" text`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_documentos_simulacao_chave_importacao"
      ON "documentos" ("simulacao_id", "chave_importacao")
      WHERE "chave_importacao" IS NOT NULL
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_documentos_simulacao_chave_importacao"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN "dados_simulacao_output_key"`);
    await queryRunner.query(`ALTER TABLE "documentos" DROP COLUMN "chave_importacao"`);
  }
}
