import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddRelatorioMetricasObservadas1777500000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE relatorios
        ADD COLUMN IF NOT EXISTS metricas_observadas jsonb;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE relatorios
        DROP COLUMN IF EXISTS metricas_observadas;
    `);
  }
}
