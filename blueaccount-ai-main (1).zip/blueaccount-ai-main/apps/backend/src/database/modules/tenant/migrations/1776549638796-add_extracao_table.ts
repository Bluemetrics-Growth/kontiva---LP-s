import { MigrationInterface, QueryRunner } from "typeorm";

export class AddExtracaoTable1776549638796 implements MigrationInterface {
    name = 'AddExtracaoTable1776549638796'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE IF NOT EXISTS "extracoes" (
          "id" uuid DEFAULT gen_random_uuid() NOT NULL,
          "documento_id" uuid NOT NULL,
          "tipo_extracao" text NOT NULL,
          "payload_json" jsonb NOT NULL,
          "confidence" numeric(5,4),
          "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
          "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
          CONSTRAINT "PK_extracoes_id" PRIMARY KEY ("id"),
          CONSTRAINT "FK_extracoes_documento_id" FOREIGN KEY ("documento_id")
            REFERENCES "documentos"("id") ON DELETE CASCADE ON UPDATE NO ACTION
        )`);
        await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_extracoes_documento_id" ON "extracoes" ("documento_id")`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX IF EXISTS "IDX_extracoes_documento_id"`);
        await queryRunner.query(`DROP TABLE IF EXISTS "extracoes"`);
    }
}
