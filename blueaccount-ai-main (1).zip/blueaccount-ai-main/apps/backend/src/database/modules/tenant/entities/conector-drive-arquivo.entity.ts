import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Index } from "typeorm";
import type { DocumentoModulo } from "./documento.entity.js";

export type ConectorDriveArquivoStatus = "sincronizado" | "erro";

/**
 * Ledger de arquivos sincronizados do Google Drive para o S3 por execução do
 * conector (uma linha por arquivo do inventário lido do manifesto). O índice
 * parcial único `(escritorio_id, modulo, md5_checksum) WHERE
 * status='sincronizado'` é a deduplicação: um mesmo conteúdo (mesmo checksum)
 * não é ressincronizado no mesmo módulo. `documento_id` fica `NULL` até que o
 * processamento (fora de escopo aqui) funile o arquivo pelo pipeline de
 * ingestão existente.
 */
@Index("UQ_conector_drive_arq_dedup", ["escritorio_id", "modulo", "md5_checksum"], {
  unique: true,
  where: '"status" = \'sincronizado\'',
})
@Index("IDX_conector_drive_arq_file", ["escritorio_id", "drive_file_id"])
@Entity("conector_drive_arquivos")
export class ConectorDriveArquivo {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "uuid" })
  execucao_id!: string;

  @Column({ type: "text" })
  drive_file_id!: string;

  @Column({ type: "text" })
  md5_checksum!: string;

  @Column({ type: "text" })
  nome_arquivo!: string;

  @Column({ type: "text", nullable: true })
  mime_type!: string | null;

  @Column({ type: "bigint", nullable: true })
  size_bytes!: string | null;

  @Column({ type: "timestamp with time zone", nullable: true })
  drive_modified_time!: Date | null;

  @Column({ type: "text" })
  modulo!: Exclude<DocumentoModulo, "simulation_data">;

  /** Chave do arquivo no bucket de input (`${escritorioId}/conector-drive/${runId}/${arquivoId}_${nome}`), gravada pela Lambda BaixarArquivo. */
  @Column({ type: "text" })
  s3_key!: string;

  /** Preenchido quando o processamento (fase futura) funilar este arquivo pelo pipeline existente. */
  @Column({ type: "uuid", nullable: true })
  documento_id!: string | null;

  @Column({ type: "text" })
  status!: ConectorDriveArquivoStatus;

  @Column({ type: "text", nullable: true })
  motivo!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
