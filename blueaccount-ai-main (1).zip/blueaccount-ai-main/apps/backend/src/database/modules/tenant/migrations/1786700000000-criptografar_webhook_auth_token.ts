import type { MigrationInterface, QueryRunner } from "typeorm";
import { CryptoService } from "../../../../infrastructure/security/crypto.service.js";

/**
 * Passa o `webhook_auth_token` da Asaas a ser guardado criptografado, como já eram a `api_key` e o
 * `webhook_secret` da Stripe na mesma tabela.
 *
 * O token é o segredo que a Asaas manda de volta no header `asaas-access-token` a cada webhook.
 * Estava em texto puro na tabela do tenant — quem lesse um dump, um snapshot do RDS ou explorasse
 * uma leitura indevida conseguiria forjar webhooks de pagamento (marcar cobrança como paga).
 *
 * Precisa ser **reversível**, não hash: `PlataformasCobrancaService.registrarWebhook()` reenvia o
 * token em texto puro para a Asaas ao registrar/renovar o webhook.
 *
 * A criptografia usa o mesmo `CryptoService` (AES-256-GCM com `SECRETS_ENCRYPTION_KEY`) do resto da
 * tabela. Se a chave não estiver configurada, `CryptoService` lança e a migration falha alto — que é
 * o comportamento certo: seguir em frente deixaria a coluna nova vazia e o webhook rejeitaria tudo.
 *
 * O índice único sobre o token é derrubado junto e **não** é recriado: com IV aleatório o mesmo
 * texto gera ciphertext diferente a cada escrita, então um índice único sobre o ciphertext não
 * garante nada. Nada consulta por token — o webhook acha a linha por `escritorio_id` + `plataforma`.
 */
export class CriptografarWebhookAuthToken1786700000000 implements MigrationInterface {
  name = "CriptografarWebhookAuthToken1786700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    const crypto = new CryptoService();

    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" ADD COLUMN IF NOT EXISTS "webhook_auth_token_encrypted" text`);
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" ADD COLUMN IF NOT EXISTS "webhook_auth_token_iv" text`);
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" ADD COLUMN IF NOT EXISTS "webhook_auth_token_tag" text`);

    const linhas: Array<{ id: string; webhook_auth_token: string | null }> = await queryRunner.query(
      `SELECT "id", "webhook_auth_token" FROM "plataformas_cobranca" WHERE "webhook_auth_token_encrypted" IS NULL`,
    );

    for (const linha of linhas) {
      // Token vazio/nulo não deveria existir (a coluna era NOT NULL), mas se existir, criptografar
      // string vazia produziria um segredo válido para "" — melhor deixar nulo e falhar na validação.
      if (!linha.webhook_auth_token) continue;

      const segredo = crypto.encrypt(linha.webhook_auth_token);
      await queryRunner.query(
        `UPDATE "plataformas_cobranca"
            SET "webhook_auth_token_encrypted" = $1,
                "webhook_auth_token_iv" = $2,
                "webhook_auth_token_tag" = $3
          WHERE "id" = $4`,
        [segredo.ciphertext, segredo.iv, segredo.tag, linha.id],
      );
    }

    await queryRunner.query(`DROP INDEX IF EXISTS "uq_plataformas_cobranca_webhook_token"`);
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" DROP COLUMN IF EXISTS "webhook_auth_token"`);
  }

  /**
   * Restaura a coluna em texto puro descriptografando o que foi gravado.
   *
   * O índice único volta com o nome original. Linhas sem token criptografado (não deveria haver)
   * receberiam texto puro nulo, então a coluna volta como NULL-able para o revert não travar.
   */
  public async down(queryRunner: QueryRunner): Promise<void> {
    const crypto = new CryptoService();

    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" ADD COLUMN IF NOT EXISTS "webhook_auth_token" text`);

    const linhas: Array<{
      id: string;
      webhook_auth_token_encrypted: string | null;
      webhook_auth_token_iv: string | null;
      webhook_auth_token_tag: string | null;
    }> = await queryRunner.query(
      `SELECT "id", "webhook_auth_token_encrypted", "webhook_auth_token_iv", "webhook_auth_token_tag"
         FROM "plataformas_cobranca"
        WHERE "webhook_auth_token_encrypted" IS NOT NULL`,
    );

    for (const linha of linhas) {
      if (!linha.webhook_auth_token_encrypted || !linha.webhook_auth_token_iv || !linha.webhook_auth_token_tag) continue;

      const texto = crypto.decrypt({
        ciphertext: linha.webhook_auth_token_encrypted,
        iv: linha.webhook_auth_token_iv,
        tag: linha.webhook_auth_token_tag,
      });
      await queryRunner.query(`UPDATE "plataformas_cobranca" SET "webhook_auth_token" = $1 WHERE "id" = $2`, [
        texto,
        linha.id,
      ]);
    }

    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS uq_plataformas_cobranca_webhook_token
         ON "plataformas_cobranca" ("webhook_auth_token")`,
    );
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" DROP COLUMN IF EXISTS "webhook_auth_token_tag"`);
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" DROP COLUMN IF EXISTS "webhook_auth_token_iv"`);
    await queryRunner.query(`ALTER TABLE "plataformas_cobranca" DROP COLUMN IF EXISTS "webhook_auth_token_encrypted"`);
  }
}
