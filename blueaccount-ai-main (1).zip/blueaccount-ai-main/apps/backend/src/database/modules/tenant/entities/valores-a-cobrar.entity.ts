import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { Contrato } from "./contrato.entity.js";

export type StatusValoresACobrar = "aberto" | "em_apuracao" | "revisado" | "pronto_para_revisao" | "enviado" | "pago" | "invalido";
export type StatusAuditoriaCobranca = "sem_dados" | "ok" | "subfaturado" | "superfaturado";
/**
 * Estado da execução assíncrona do agente de cobrança. Ortogonal ao `status` de
 * negócio: descreve só o ciclo de vida da geração via AgentCore (disparo → callback).
 *
 * `na_fila` é distinto de `em_processamento` de propósito: um VAC esperando vaga
 * na fila de cobrança não pode entrar na conta do teto de 5 min de
 * `reconcile-stale-agente.ts`, senão a cauda de um lote grande fica vermelha
 * antes mesmo de rodar. `agente_iniciado_em` só é preenchido no pop.
 */
export type StatusAgenteCobranca = "na_fila" | "em_processamento" | "concluido" | "erro";

export interface Excedente {
  tipo: string;
  referencia: string;
  valor_unitario: number;
  valor_observado: number;
  quantidade: number;
  faixa: {
    quantidade_inicial: number;
    quantidade_final: number | null;
  };
  explicacao: string;
}

export type ItemCobrado = Excedente;

export interface ValoresCalculados {
  valor_base: number;
  excedentes: Excedente[];
}

export interface QualidadeRelatorio {
  score: number | null;
  relatorio_id: string;
  erros: unknown[];
}

export interface OutroServicoPrestado {
  descricao: string;
  valor: number | null;
}

export interface CobrancaMitigacao {
  status: StatusAuditoriaCobranca;
  explicacao: string;
  ok: boolean;
  atualizado_em: string | null;
}

export interface ValoresACobrarLinhagem {
  contrato: {
    id: string;
    cliente_id: string;
    versao_do_contrato: number;
    arquivo_origem: string | null;
    contrato_ativo: boolean;
    created_at: string | Date | null;
    updated_at: string | Date | null;
  } | null;
  relatorios: Array<{
    id: string;
    tipo_relatorio: string;
    competencia: string | null;
    arquivo_origem: string | null;
    relatorio_ativo: boolean;
    created_at: string | Date | null;
    /** Origem em consolidação de grupo econômico (ausente em VACs antigos/isolados). */
    cliente_id?: string;
    cnpj?: string;
  }>;
  faturamento: Array<{
    id: string;
    competencia: string | null;
    valor_cobrado: number | null;
    discriminacao: string | null;
    arquivo_origem: string | null;
    faturamento_ativo: boolean;
    created_at: string | Date | null;
    /** Origem em consolidação de grupo econômico (ausente em VACs antigos/isolados). */
    cliente_id?: string;
    cnpj?: string;
  }>;
  /** Presente apenas em VACs consolidados por grupo econômico. */
  grupo?: {
    holding_id: string;
    membros_ids: string[];
    /**
     * Modo híbrido: snapshot das filhas com contrato ativo próprio no momento
     * da consolidação. Elas ficam fora da agregação de relatórios da holding;
     * o total calculado de cada uma entra como item da cobrança da holding
     * (ver `valores_calculados.cobrancas_membros`).
     */
    membros_com_contrato?: MembroComContratoSnapshot[];
    /**
     * Roster do grupo (holding + membros) no momento da consolidação, usado para
     * exibir os relatórios agrupados por empresa — inclusive as empresas que não
     * enviaram relatório na competência. Ausente em VACs antigos.
     */
    empresas?: EmpresaDoGrupo[];
  };
  gerado_em: string | null;
}

/** Empresa do grupo econômico (holding ou membro) no snapshot de consolidação. */
export interface EmpresaDoGrupo {
  cliente_id: string;
  cnpj: string | null;
  razao_social: string | null;
  papel: "holding" | "membro";
  /**
   * Filha com contrato ativo próprio (modo híbrido): fica fora da agregação de
   * relatórios da holding e é cobrada em VAC separado, então a ausência de
   * relatório aqui é esperada (não é lacuna de dados).
   */
  tem_contrato_proprio?: boolean;
}

/** Snapshot/item de filha com contrato próprio anexado ao VAC da holding. */
export interface MembroComContratoSnapshot {
  cliente_id: string;
  cnpj: string | null;
  razao_social: string | null;
  contrato_id: string;
  /** VAC da filha na competência (null se ainda não consolidado). */
  vac_id: string | null;
  total: number | null;
  /** true quando o VAC da filha já tem valores_calculados preenchidos. */
  calculado: boolean;
  status: string | null;
  /** VAC da filha já enviado/pago individualmente (legado pré-híbrido): fica fora da soma da holding. */
  ja_cobrado_individualmente?: boolean;
  /**
   * Desconto por adimplência do contrato da filha (texto livre, ex.: "5%"). Usado
   * na emissão para agregar o desconto condicional do grupo. Ausente em snapshots
   * antigos = sem desconto.
   */
  desconto_por_adimplencia?: string | null;
}

/**
 * Ajuste de grupo econômico (modo híbrido): desconto/acréscimo aplicado sobre o
 * total do grupo (holding + controladas), emitido pelo agente a partir de
 * `instrucoes_de_cobranca` e aplicado DETERMINISTICAMENTE pelo backend (o agente
 * não enxerga o total das controladas — ver contexto-cobranca.service.ts).
 *
 * Convenção de sinal: negativo = desconto, positivo = acréscimo.
 * Vive em `valores_calculados.ajuste_grupo`; o valor absoluto resultante é
 * persistido pelo backend em `valores_calculados.valor_ajuste_grupo`.
 */
export interface AjusteGrupo {
  /** "percentual": `valor` é % (ex.: -10 = -10%). "valor": `valor` é montante em R$. */
  tipo: "percentual" | "valor";
  /** Base do percentual: total do grupo (padrão) ou só a soma das controladas. */
  base?: "total_grupo" | "membros";
  valor: number;
  descricao?: string | null;
}

/**
 * Desconto manual da cobrança, aplicado DETERMINISTICAMENTE pelo backend como
 * ÚLTIMO passo do cálculo — depois do total próprio do agente, da soma das
 * filiais e das multas. Não passa pelo agente. Vive em coluna própria
 * (`desconto`) para sobreviver ao overwrite de `valores_calculados` quando o
 * agente recalcula; o valor absoluto resultante é persistido em
 * `valores_calculados.valor_desconto_total`. Ver `computeDesconto`.
 *
 * Convenção: `valor` é sempre uma REDUÇÃO (>= 0). "percentual": % sobre o
 * subtotal (próprio + filiais + ajuste de grupo − multas). "valor": montante R$.
 */
export interface Desconto {
  tipo: "percentual" | "valor";
  valor: number;
  descricao?: string | null;
}

@Index("UQ_valores_a_cobrar_cliente_competencia", ["cliente_id", "competencia"], { unique: true })
@Entity("valores_a_cobrar")
export class ValoresACobrar {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @ManyToOne(() => Contrato, { nullable: false })
  @JoinColumn({ name: "contrato_id" })
  contrato!: Relation<Contrato>;

  @Column({ type: "uuid" })
  contrato_id!: string;

  @Column({ type: "varchar", length: 7 })
  competencia!: string; // "MM/AAAA"

  @Column({ type: "date" })
  data_referencia!: string; // primeiro dia da competência

  @Column({ type: "jsonb" })
  valores_contratados!: Record<string, unknown>;

  @Column({ type: "jsonb" })
  valores_observados!: Record<string, unknown>;

  @Column({ type: "jsonb" })
  valores_calculados!: Record<string, unknown>;

  @Column({ type: "jsonb", default: () => "'[]'::jsonb" })
  outros_servicos_prestados!: OutroServicoPrestado[];

  @Column({ type: "jsonb", nullable: true })
  cobranca_mitigacao!: CobrancaMitigacao | null;

  /** Desconto manual aplicado por último no cálculo do total. Ver `Desconto`. */
  @Column({ type: "jsonb", nullable: true })
  desconto!: Desconto | null;

  @Column({ type: "jsonb", nullable: true })
  edicoes!: Record<string, unknown> | null;

  @Column({ type: "jsonb", default: () => `'{ "contrato": null, "relatorios": [], "faturamento": [], "gerado_em": null }'::jsonb` })
  linhagem!: ValoresACobrarLinhagem;

  @Column({ type: "text", nullable: true })
  explicacao_ia!: string | null;

  @Column({ type: "varchar", length: 30, default: "aberto" })
  status!: StatusValoresACobrar;

  /**
   * Status decidido pelo cálculo, mas retido enquanto a competência ainda está
   * em apuração. O pg_cron o restaura no mês seguinte.
   */
  @Column({ type: "varchar", length: 30, nullable: true })
  status_apos_apuracao!: "revisado" | "pronto_para_revisao" | null;

  @Column({ type: "decimal", precision: 12, scale: 2 })
  total!: number;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  total_cobrado!: number | null;

  @Column({ type: "decimal", precision: 12, scale: 2, nullable: true })
  total_excedentes!: number | null;

  @Column({ type: "uuid", array: true, default: "{}" })
  relatorios_ids!: string[];

  @Column({ type: "jsonb", nullable: true })
  qualidade_de_dados_relatorios!: Record<string, QualidadeRelatorio> | null;

  @Column({ type: "boolean", default: false })
  precisa_clarificacao!: boolean;

  /** Indica que o valor base do contrato foi reajustado nesta competência. */
  @Column({ type: "boolean", default: false })
  contrato_reajustado!: boolean;

  /** Snapshot do índice e dos valores usados no reajuste para comunicação ao cliente. */
  @Column({ type: "jsonb", nullable: true })
  reajuste_contrato!: {
    indice: string;
    competencia_inicio: string;
    competencia_fim: string;
    percentual_acumulado: number;
    valor_anterior: number;
    valor_reajustado: number;
  } | null;

  @Column({ type: "decimal", precision: 5, scale: 4, nullable: true })
  score_qualidade!: number | null;

  @Column({ type: "text", nullable: true })
  agente_cobranca_output_s3_path!: string | null;

  // ── Execução assíncrona do agente de cobrança (disparo → callback) ──────────
  @Column({ type: "varchar", length: 20, nullable: true })
  agente_status!: StatusAgenteCobranca | null;

  /** Correlação/idempotência: trace_id do disparo que está em curso. */
  @Column({ type: "text", nullable: true })
  agente_trace_id!: string | null;

  @Column({ type: "text", nullable: true })
  agente_erro!: string | null;

  @Column({ type: "timestamp", nullable: true })
  agente_iniciado_em!: Date | null;

  /** Marca idempotente do registro de tokens da execução atual do agente. */
  @Column({ type: "timestamp", nullable: true })
  agente_usage_registrado_em!: Date | null;

  @Column({ type: "uuid", nullable: true })
  cobranca_id!: string | null;

  // ── Lock de versão de contrato na renovação ─────────────────────────────────
  /**
   * VAC congelado numa versão específica do contrato (via `contrato_id`) por uma
   * renovação posterior. Enquanto true, a reconsolidação e `gerarCobranca` usam a
   * versão travada e pulam o gate de competência (o lock já a validou). Nunca é
   * setado em VAC pago. Ver `bloqueio-contrato-renovacao.ts`.
   */
  @Column({ type: "boolean", default: false })
  contrato_bloqueado!: boolean;

  /** Versão do contrato fixada no lock (auditoria/clareza; `contrato_id` é o pin efetivo). */
  @Column({ type: "int", nullable: true })
  contrato_versao_bloqueada!: number | null;

  @Column({ type: "timestamp", nullable: true })
  contrato_bloqueado_em!: Date | null;

  @Column({ type: "text", nullable: true })
  contrato_bloqueado_motivo!: string | null;

  // ── Versionamento e invalidação (stale) ─────────────────────────────────────
  /** Hash canônico dos insumos do cálculo ativo (ver billing-snapshot-hash.ts). */
  @Column({ type: "text", nullable: true })
  input_hash!: string | null;

  /** Ponte para a versão ativa válida em `valores_a_cobrar_versoes`. */
  @Column({ type: "uuid", nullable: true })
  versao_ativa_id!: string | null;

  /**
   * Insumos relevantes (contrato/relatório/faturamento/outros serviços) mudaram
   * após o cálculo ativo. Ortogonal ao `status`: enquanto true, a emissão é
   * bloqueada até um novo cálculo. Nunca é setado em VAC pago (registro imutável).
   */
  @Column({ type: "boolean", default: false })
  stale!: boolean;

  @Column({ type: "text", nullable: true })
  stale_motivo!: string | null;

  @Column({ type: "timestamp", nullable: true })
  stale_em!: Date | null;

  @Column({ type: "text", nullable: true })
  stale_por!: string | null;

  @Column({ type: "timestamp", nullable: true })
  recalculado_em!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
