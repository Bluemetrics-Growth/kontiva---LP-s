import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddOutrosServicosPrestadosValoresACobrar1778400000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      ADD COLUMN IF NOT EXISTS outros_servicos_prestados JSONB NOT NULL DEFAULT '[]'::jsonb;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
      DROP COLUMN IF EXISTS outros_servicos_prestados;
    `);
  }
}
