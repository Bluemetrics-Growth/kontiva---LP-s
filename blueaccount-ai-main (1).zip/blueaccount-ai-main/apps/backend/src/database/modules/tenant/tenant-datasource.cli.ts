/**
 * DataSource para uso com o TypeORM CLI (migration:generate, migration:revert).
 *
 * Uso:
 *   TENANT_SCHEMA=escritorio_abc npx typeorm migration:generate \
 *     -d src/database/modules/tenant/tenant-datasource.cli.ts \
 *     src/database/modules/tenant/migrations/002-NomeDaMigration
 */
import "reflect-metadata";
import { config } from "dotenv";
import { createTenantModuleDataSource } from "./tenant-datasource.js";

config();

const schema = process.env.TENANT_SCHEMA;
if (!schema) {
  throw new Error("TENANT_SCHEMA env var é obrigatória para o CLI de migration de tenant.");
}
if (schema.trim().toLowerCase() === "public") {
  throw new Error(
    "TENANT_SCHEMA=public é inválido para migration de tenant. Use um schema de tenant existente (ex.: escritorio_dev ou escritorio_<uuid>).",
  );
}

export default createTenantModuleDataSource(schema);
