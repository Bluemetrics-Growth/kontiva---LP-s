import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Guarda no cadastro do fornecedor a alíquota **nominal** de ICMS/ISS consolidada das NF-e
 * importadas, para as linhas de simulação daquele fornecedor não dependerem do padrão do cenário.
 *
 * As colunas `*_fonte` existem porque editabilidade é requisito: sem marcador, a próxima importação
 * apagaria silenciosamente a alíquota que o contador digitou. O marcador é por tributo — editar o
 * ICMS não deve congelar a derivação do ISS.
 *
 * Sem backfill possível: nenhuma nota já importada guardou tributos por item, então as colunas nascem
 * `NULL` e o comportamento no deploy é idêntico ao atual.
 */
export class AddAliquotasAtuaisToFornecedores1785600000000 implements MigrationInterface {
  name = "AddAliquotasAtuaisToFornecedores1785600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "fornecedores"
        ADD COLUMN IF NOT EXISTS "aliquota_icms_nominal" numeric(6,4),
        ADD COLUMN IF NOT EXISTS "aliquota_iss_nominal" numeric(6,4),
        ADD COLUMN IF NOT EXISTS "aliquota_icms_fonte" varchar(10),
        ADD COLUMN IF NOT EXISTS "aliquota_iss_fonte" varchar(10)
    `);

    for (const coluna of ["aliquota_icms_fonte", "aliquota_iss_fonte"]) {
      const constraint = `CHK_fornecedores_${coluna}`;
      await queryRunner.query(`DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_constraint c
            JOIN pg_class t ON t.oid = c.conrelid
            JOIN pg_namespace n ON n.oid = t.relnamespace
            WHERE c.conname = '${constraint}'
              AND t.relname = 'fornecedores'
              AND n.nspname = current_schema()
          ) THEN
            ALTER TABLE "fornecedores"
              ADD CONSTRAINT "${constraint}"
              CHECK ("${coluna}" IS NULL OR "${coluna}" IN ('nfe', 'manual'));
          END IF;
        END
      $$`);
    }

    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."aliquota_icms_nominal" IS
        'Alíquota nominal (cheia) de ICMS, pré-fator de retenção do cronograma da reforma.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."aliquota_icms_fonte" IS
        'nfe = derivada das notas importadas; manual = digitada pelo contador (nunca sobrescrita).'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."aliquota_iss_nominal" IS
        'Alíquota nominal (cheia) de ISS, pré-fator de retenção do cronograma da reforma.'
    `);
    await queryRunner.query(`
      COMMENT ON COLUMN "fornecedores"."aliquota_iss_fonte" IS
        'nfe = derivada das notas importadas; manual = digitada pelo contador (nunca sobrescrita).'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "fornecedores" DROP CONSTRAINT IF EXISTS "CHK_fornecedores_aliquota_icms_fonte"`,
    );
    await queryRunner.query(
      `ALTER TABLE "fornecedores" DROP CONSTRAINT IF EXISTS "CHK_fornecedores_aliquota_iss_fonte"`,
    );
    await queryRunner.query(`
      ALTER TABLE "fornecedores"
        DROP COLUMN IF EXISTS "aliquota_icms_nominal",
        DROP COLUMN IF EXISTS "aliquota_iss_nominal",
        DROP COLUMN IF EXISTS "aliquota_icms_fonte",
        DROP COLUMN IF EXISTS "aliquota_iss_fonte"
    `);
  }
}
