import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateSimulacaoGrupos1780500000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "simulacao_grupos" (
        "id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        "escritorio_id" uuid NOT NULL,
        "cliente_id" uuid NOT NULL,
        "nome" varchar(255) NOT NULL,
        "descricao" text,
        "cor" varchar(7),
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        CONSTRAINT "fk_simulacao_grupos_cliente" FOREIGN KEY ("cliente_id") REFERENCES "clientes"("id"),
        CONSTRAINT "uq_simulacao_grupos_cliente_nome" UNIQUE ("cliente_id", "nome")
      );

      CREATE INDEX "idx_simulacao_grupos_escritorio_id" ON "simulacao_grupos"("escritorio_id");
      CREATE INDEX "idx_simulacao_grupos_cliente_id" ON "simulacao_grupos"("cliente_id");

      CREATE TABLE "simulacao_grupo_itens" (
        "simulacao_grupo_id" uuid NOT NULL,
        "simulacao_id" uuid NOT NULL,
        "escritorio_id" uuid NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        PRIMARY KEY ("simulacao_grupo_id", "simulacao_id"),
        CONSTRAINT "fk_simulacao_grupo_itens_grupo" FOREIGN KEY ("simulacao_grupo_id") REFERENCES "simulacao_grupos"("id") ON DELETE CASCADE,
        CONSTRAINT "fk_simulacao_grupo_itens_simulacao" FOREIGN KEY ("simulacao_id") REFERENCES "simulacoes"("id") ON DELETE CASCADE
      );

      CREATE INDEX "idx_simulacao_grupo_itens_grupo_id" ON "simulacao_grupo_itens"("simulacao_grupo_id");
      CREATE INDEX "idx_simulacao_grupo_itens_simulacao_id" ON "simulacao_grupo_itens"("simulacao_id");
      CREATE INDEX "idx_simulacao_grupo_itens_escritorio_id" ON "simulacao_grupo_itens"("escritorio_id");
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DROP TABLE IF EXISTS "simulacao_grupo_itens";
      DROP TABLE IF EXISTS "simulacao_grupos";
    `);
  }
}
