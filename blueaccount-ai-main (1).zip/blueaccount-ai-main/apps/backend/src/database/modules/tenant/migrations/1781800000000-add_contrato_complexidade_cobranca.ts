import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoComplexidadeCobranca1781800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE contratos
        ADD COLUMN IF NOT EXISTS complexidade_cobranca INTEGER NOT NULL DEFAULT 1
    `);

    await queryRunner.query(`
      UPDATE contratos
      SET complexidade_cobranca = 1
      WHERE complexidade_cobranca IS NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE contratos
        DROP COLUMN IF EXISTS complexidade_cobranca
    `);
  }
}
