import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import type { DocumentoModulo } from "./documento.entity.js";

export type ConectorSharePointArquivoStatus = "sincronizado" | "erro";

@Index("UQ_conector_sharepoint_arq_dedup", ["escritorio_id", "modulo", "hash_algorithm", "hash_value"], { unique: true, where: '"status" = \'sincronizado\'' })
@Index("IDX_conector_sharepoint_arq_item", ["escritorio_id", "sharepoint_item_id"])
@Entity("conector_sharepoint_arquivos")
export class ConectorSharePointArquivo {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "uuid" }) escritorio_id!: string;
  @Column({ type: "uuid" }) execucao_id!: string;
  @Column({ type: "text" }) sharepoint_item_id!: string;
  @Column({ type: "text" }) hash_algorithm!: string;
  @Column({ type: "text" }) hash_value!: string;
  @Column({ type: "text" }) nome_arquivo!: string;
  @Column({ type: "text", nullable: true }) mime_type!: string | null;
  @Column({ type: "bigint", nullable: true }) size_bytes!: string | null;
  @Column({ type: "timestamptz", nullable: true }) sharepoint_modified_time!: Date | null;
  @Column({ type: "text" }) modulo!: Exclude<DocumentoModulo, "simulation_data">;
  @Column({ type: "text" }) s3_key!: string;
  @Column({ type: "uuid", nullable: true }) documento_id!: string | null;
  @Column({ type: "text" }) status!: ConectorSharePointArquivoStatus;
  @Column({ type: "text", nullable: true }) motivo!: string | null;
  @CreateDateColumn({ type: "timestamptz" }) created_at!: Date;
  @UpdateDateColumn({ type: "timestamptz" }) updated_at!: Date;
}
