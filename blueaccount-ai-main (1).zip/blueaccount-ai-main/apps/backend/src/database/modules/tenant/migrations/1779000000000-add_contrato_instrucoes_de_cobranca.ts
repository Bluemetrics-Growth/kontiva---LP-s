import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddContratoInstrucoesDeCobranca1779000000000 implements MigrationInterface {
  name = "AddContratoInstrucoesDeCobranca1779000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "instrucoes_de_cobranca" text`,
    );
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (
          SELECT 1
          FROM information_schema.columns
          WHERE table_name = 'contratos'
            AND column_name = 'forma_de_cobranca'
        ) THEN
          EXECUTE 'UPDATE "contratos"
            SET "instrucoes_de_cobranca" = "forma_de_cobranca"
            WHERE "instrucoes_de_cobranca" IS NULL
              AND "forma_de_cobranca" IS NOT NULL';
          EXECUTE 'ALTER TABLE "contratos" DROP COLUMN "forma_de_cobranca"';
        END IF;

        IF EXISTS (
          SELECT 1
          FROM information_schema.columns
          WHERE table_name = 'contratos'
            AND column_name = 'forma_cobranca'
        ) THEN
          EXECUTE 'UPDATE "contratos"
            SET "instrucoes_de_cobranca" = "forma_cobranca"
            WHERE "instrucoes_de_cobranca" IS NULL
              AND "forma_cobranca" IS NOT NULL';
          EXECUTE 'ALTER TABLE "contratos" DROP COLUMN "forma_cobranca"';
        END IF;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "contratos" ADD COLUMN IF NOT EXISTS "forma_de_cobranca" text`,
    );
    await queryRunner.query(
      `UPDATE "contratos"
        SET "forma_de_cobranca" = "instrucoes_de_cobranca"
        WHERE "forma_de_cobranca" IS NULL
          AND "instrucoes_de_cobranca" IS NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "contratos" DROP COLUMN IF EXISTS "instrucoes_de_cobranca"`,
    );
  }
}
