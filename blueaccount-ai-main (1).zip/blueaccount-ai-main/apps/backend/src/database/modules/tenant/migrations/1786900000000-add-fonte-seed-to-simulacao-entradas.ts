import type { MigrationInterface, QueryRunner } from "typeorm";

/** Vínculo opcional de entrada copiada à sua fonte; sem backfill para cenários existentes. */
export class AddFonteSeedToSimulacaoEntradas1786900000000 implements MigrationInterface {
  name = "AddFonteSeedToSimulacaoEntradas1786900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN IF NOT EXISTS "fonte_seed" uuid,
        ADD COLUMN IF NOT EXISTS "fonte_hash" varchar(64)
    `);
    await queryRunner.query(`COMMENT ON COLUMN "simulacao_entradas"."fonte_seed" IS 'Entrada-fonte de uma série vinculada; nulo para entradas independentes ou fonte.'`);
    await queryRunner.query(`COMMENT ON COLUMN "simulacao_entradas"."fonte_hash" IS 'SHA-256 do payload editável da entrada-fonte, sem backfill; cópias guardam o último hash aplicado.'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "fonte_hash"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "fonte_seed"`);
  }
}
