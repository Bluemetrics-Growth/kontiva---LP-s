import { Entity, PrimaryGeneratedColumn, Column, Index } from "typeorm";

export type ConectorDriveExecucaoStatus = "executando" | "concluida" | "concluida_com_erros" | "erro";

/**
 * Uma linha por execução do conector de Google Drive iniciada por usuário do escritório (sync
 * Drive→S3 via `apps/services/conector-drive`; o processamento do inventário
 * pelo pipeline existente é fase futura). O índice parcial único em
 * `(escritorio_id) WHERE status='executando'` é a guarda de execução única
 * por escritório.
 */
@Index("UQ_conector_drive_exec_ativa", ["escritorio_id"], {
  unique: true,
  where: '"status" = \'executando\'',
})
@Entity("conector_drive_execucoes")
export class ConectorDriveExecucao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  status!: ConectorDriveExecucaoStatus;

  @Column({ type: "text", nullable: true })
  execution_arn!: string | null;

  @Column({ type: "int", default: 0 })
  total_listados!: number;

  @Column({ type: "int", default: 0 })
  sincronizados!: number;

  @Column({ type: "int", default: 0 })
  ignorados!: number;

  @Column({ type: "int", default: 0 })
  erros!: number;

  @Column({ type: "boolean", default: false })
  truncada!: boolean;

  @Column({ type: "jsonb", nullable: true })
  detalhes!: Record<string, unknown> | null;

  @Column({ type: "text", nullable: true })
  erro!: string | null;

  @Column({ type: "uuid", nullable: true })
  iniciada_por_usuario_id!: string | null;

  @Column({ type: "timestamp with time zone", default: () => "now()" })
  started_at!: Date;

  @Column({ type: "timestamp with time zone", nullable: true })
  finished_at!: Date | null;
}
