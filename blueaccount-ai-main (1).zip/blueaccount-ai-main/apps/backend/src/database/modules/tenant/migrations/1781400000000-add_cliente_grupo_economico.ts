import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Grupo econômico via hierarquia de clientes (Plano 3):
 * - `holding_id`: FK auto-referente nullable; cliente com holding_id é membro de
 *   um grupo cuja holding é outro cliente. NULL = cliente isolado (comportamento
 *   atual preservado). ON DELETE SET NULL: remover a holding degrada os membros
 *   para isolados.
 * - `pagador_grupo`: só relevante na holding. No modo "contrato por empresa",
 *   decide se as cobranças individuais dos membros são emitidas no customer da
 *   holding ('holding') ou de cada empresa ('empresa', default quando NULL).
 *
 * O invariante "um nível só" (holding não pode ter holding) exige subquery e não
 * é expressável como CHECK no Postgres — fica na validação de serviço
 * (domain/clientes/grupo.service.ts). Aqui só impedimos auto-referência direta.
 */
export class AddClienteGrupoEconomico1781400000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE clientes
        ADD COLUMN IF NOT EXISTS holding_id UUID NULL,
        ADD COLUMN IF NOT EXISTS pagador_grupo TEXT NULL
    `);

    // ADD CONSTRAINT não suporta IF NOT EXISTS — DO-block idempotente.
    await queryRunner.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'FK_clientes_holding_id'
            AND t.relname = 'clientes'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE clientes
            ADD CONSTRAINT "FK_clientes_holding_id"
            FOREIGN KEY (holding_id) REFERENCES clientes(id) ON DELETE SET NULL;
        END IF;

        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_clientes_holding_nao_auto'
            AND t.relname = 'clientes'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE clientes
            ADD CONSTRAINT "CHK_clientes_holding_nao_auto"
            CHECK (holding_id IS NULL OR holding_id <> id);
        END IF;

        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_clientes_pagador_grupo'
            AND t.relname = 'clientes'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE clientes
            ADD CONSTRAINT "CHK_clientes_pagador_grupo"
            CHECK (pagador_grupo IS NULL OR pagador_grupo IN ('holding', 'empresa'));
        END IF;
      END
      $$;
    `);

    await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "IX_clientes_holding_id" ON clientes (holding_id)
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IX_clientes_holding_id"`);
    await queryRunner.query(`
      ALTER TABLE clientes
        DROP CONSTRAINT IF EXISTS "CHK_clientes_pagador_grupo",
        DROP CONSTRAINT IF EXISTS "CHK_clientes_holding_nao_auto",
        DROP CONSTRAINT IF EXISTS "FK_clientes_holding_id"
    `);
    await queryRunner.query(`
      ALTER TABLE clientes
        DROP COLUMN IF EXISTS pagador_grupo,
        DROP COLUMN IF EXISTS holding_id
    `);
  }
}
