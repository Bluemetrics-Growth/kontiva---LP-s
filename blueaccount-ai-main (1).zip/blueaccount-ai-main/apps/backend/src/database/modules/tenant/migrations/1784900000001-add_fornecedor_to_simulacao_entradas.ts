import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddFornecedorToSimulacaoEntradas1784900000001 implements MigrationInterface {
  name = "AddFornecedorToSimulacaoEntradas1784900000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" ADD COLUMN IF NOT EXISTS "fornecedor_id" uuid`);

    // SET NULL: desativar/apagar fornecedor não pode destruir a entrada da simulação. Sem o
    // fornecedor, a linha volta ao comportamento legado (regime_fornecedor + regra_credito).
    await queryRunner.query(`DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'FK_simulacao_entradas_fornecedor'
            AND t.relname = 'simulacao_entradas'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "simulacao_entradas"
            ADD CONSTRAINT "FK_simulacao_entradas_fornecedor"
            FOREIGN KEY ("fornecedor_id") REFERENCES "fornecedores"("id") ON DELETE SET NULL;
        END IF;
      END
    $$`);

    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_simulacao_entradas_fornecedor_id" ON "simulacao_entradas" ("fornecedor_id") WHERE "fornecedor_id" IS NOT NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_simulacao_entradas_fornecedor_id"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP CONSTRAINT IF EXISTS "FK_simulacao_entradas_fornecedor"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas" DROP COLUMN IF EXISTS "fornecedor_id"`);
  }
}
