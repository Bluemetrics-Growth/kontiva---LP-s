import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Lock de versão de contrato na renovação: quando um contrato é renovado, os VACs
 * de competências anteriores são congelados na versão que os gerou. Quarteto de
 * colunas espelhando a convenção `stale`/`stale_motivo`/`stale_em`.
 *
 * Idempotente (`ADD COLUMN IF NOT EXISTS`); sem re-pin histórico (lock só vale
 * daqui para frente, conforme decisão).
 */
export class AddBloqueioContratoValoresACobrar1784500000000 implements MigrationInterface {
  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        ADD COLUMN IF NOT EXISTS contrato_bloqueado BOOLEAN NOT NULL DEFAULT false,
        ADD COLUMN IF NOT EXISTS contrato_versao_bloqueada INT NULL,
        ADD COLUMN IF NOT EXISTS contrato_bloqueado_em TIMESTAMP NULL,
        ADD COLUMN IF NOT EXISTS contrato_bloqueado_motivo TEXT NULL;
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE valores_a_cobrar
        DROP COLUMN IF EXISTS contrato_bloqueado_motivo,
        DROP COLUMN IF EXISTS contrato_bloqueado_em,
        DROP COLUMN IF EXISTS contrato_versao_bloqueada,
        DROP COLUMN IF EXISTS contrato_bloqueado;
    `);
  }
}
