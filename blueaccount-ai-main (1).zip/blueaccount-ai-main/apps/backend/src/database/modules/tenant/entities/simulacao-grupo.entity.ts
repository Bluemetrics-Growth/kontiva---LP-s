import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  Index,
  Unique,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { SimulacaoGrupoItem } from "./simulacao-grupo-item.entity.js";

@Entity("simulacao_grupos")
@Unique("uq_simulacao_grupos_cliente_nome", ["cliente_id", "nome"])
@Index("idx_simulacao_grupos_escritorio_id", ["escritorio_id"])
@Index("idx_simulacao_grupos_cliente_id", ["cliente_id"])
export class SimulacaoGrupo {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @ManyToOne(() => Cliente, { nullable: false })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente>;

  @Column({ type: "uuid" })
  cliente_id!: string;

  @Column({ type: "varchar", length: 255 })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "varchar", length: 7, nullable: true })
  cor!: string | null;

  @OneToMany(() => SimulacaoGrupoItem, (i) => i.grupo)
  itens!: Relation<SimulacaoGrupoItem[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
