import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Inclui `'nbs'` no domínio de `origem_fator_ibs`/`origem_fator_cbs`, criado em
 * `1787900000000-add-origem-fatores-ncm-simulacao.ts` com apenas `('manual','ncm','acumulador','tratamento')`.
 * `DROP CONSTRAINT IF EXISTS` antes do `ADD` torna a migration re-executável (roda por tenant via
 * `migration:sync-tenants`).
 */
export class AddOrigemFatorNbs1789700000000 implements MigrationInterface {
  name = "AddOrigemFatorNbs1789700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      DROP CONSTRAINT IF EXISTS "CHK_simulacao_entradas_origem_fator_ibs",
      DROP CONSTRAINT IF EXISTS "CHK_simulacao_entradas_origem_fator_cbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_ibs" CHECK ("origem_fator_ibs" IN ('manual','ncm','nbs','acumulador','tratamento')),
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_cbs" CHECK ("origem_fator_cbs" IN ('manual','ncm','nbs','acumulador','tratamento'))`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      DROP CONSTRAINT IF EXISTS "CHK_simulacao_entradas_origem_fator_ibs",
      DROP CONSTRAINT IF EXISTS "CHK_simulacao_entradas_origem_fator_cbs"`);
    await queryRunner.query(`ALTER TABLE "simulacao_entradas"
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_ibs" CHECK ("origem_fator_ibs" IN ('manual','ncm','acumulador','tratamento')),
      ADD CONSTRAINT "CHK_simulacao_entradas_origem_fator_cbs" CHECK ("origem_fator_cbs" IN ('manual','ncm','acumulador','tratamento'))`);
  }
}
