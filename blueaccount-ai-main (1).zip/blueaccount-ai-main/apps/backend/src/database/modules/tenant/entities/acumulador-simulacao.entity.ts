import { Column, CreateDateColumn, Entity, Index, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn, type Relation } from "typeorm";
import { SimulacaoEntrada } from "./simulacao-entrada.entity.js";

export type AcumuladorSimulacaoTipo = "receita" | "custo";

@Index("UQ_acumuladores_simulacao_codigo", ["codigo"], { unique: true })
@Entity("acumuladores_simulacao")
export class AcumuladorSimulacao {
  @PrimaryGeneratedColumn("uuid") id!: string;
  @Column({ type: "varchar", length: 30 }) codigo!: string;
  @Column({ type: "varchar", length: 255 }) descricao!: string;
  @Column({ type: "varchar", length: 10 }) tipo!: AcumuladorSimulacaoTipo;
  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true }) fator_ibs_padrao!: number | null;
  @Column({ type: "decimal", precision: 7, scale: 6, nullable: true }) fator_cbs_padrao!: number | null;
  @Column({ type: "boolean", default: true }) ativo!: boolean;
  @OneToMany(() => SimulacaoEntrada, (entrada) => entrada.acumulador) entradas!: Relation<SimulacaoEntrada[]>;
  @CreateDateColumn() created_at!: Date;
  @UpdateDateColumn() updated_at!: Date;
}
