import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  type Relation,
} from "typeorm";
import { Cliente } from "./cliente.entity.js";
import { Agente } from "./agente.entity.js";

export type TipoAcaoAi = "cobranca" | "revisao_contrato" | "alerta" | "outro";
export type PrioridadeAcaoAi = "alta" | "media" | "baixa";
export type StatusAcaoAi = "processando" | "pendente" | "aceita" | "em_progresso" | "rejeitada" | "executada";
export type OrigemAcaoAi = "ai" | "rule" | "manual";

export type SubAcaoAi = {
  titulo: string;
  descricao?: string | null;
  tipo_acao: TipoAcaoAi;
  prioridade: PrioridadeAcaoAi;
  cliente_id?: string | null;
  payload?: Record<string, unknown>;
};

@Entity("acoes_ai")
export class AcaoAi {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Agente, (agente) => agente.acoes, { nullable: false })
  @JoinColumn({ name: "agente_id" })
  agente!: Relation<Agente>;

  @Column({ type: "uuid" })
  agente_id!: string;

  @ManyToOne(() => Cliente, { nullable: true })
  @JoinColumn({ name: "cliente_id" })
  cliente!: Relation<Cliente> | null;

  @Column({ type: "uuid", nullable: true })
  cliente_id!: string | null;

  @Column({ type: "text", nullable: true })
  titulo!: string | null;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text", nullable: true })
  tipo_acao!: TipoAcaoAi | null;

  @Column({ type: "text", default: "media" })
  prioridade!: PrioridadeAcaoAi;

  @Column({ type: "text", default: "pendente" })
  status!: StatusAcaoAi;

  @Column({ type: "text" })
  origem!: OrigemAcaoAi;

  @Column({ type: "jsonb", nullable: true })
  payload!: Record<string, unknown> | null;

  @Column({ type: "jsonb", nullable: true })
  acoes!: SubAcaoAi[] | null;

  @Column({ type: "text", nullable: true })
  resultado!: string | null;

  @Column({ type: "text", nullable: true })
  s3_output_path!: string | null;

  @Column({ type: "timestamp", nullable: true })
  executada_at!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
