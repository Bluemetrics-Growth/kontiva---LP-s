import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Fornecedores genéricos do escritório.
 *
 * O motor de simulação só reconhece crédito de IBS/CBS quando a linha tem `fornecedor_id` e o
 * cadastro daquele fornecedor comprova o regime (`domain/simulacoes/calculo.ts`, ramo
 * `perfilFornecedor !== null`). Sem isso a linha manual fica com crédito zerado, e não existia como
 * dizer "esta despesa veio de alguém no Lucro Presumido" sem inventar um CNPJ: `cnpj` era
 * `NOT NULL` e único.
 *
 * A resposta é um conjunto fechado de seis fornecedores sem documento, um por perfil de regime,
 * escondidos da tela de fornecedores. São do **escritório**, como todo fornecedor: o cadastro nunca
 * pertenceu a um cliente.
 *
 * Invariante gravada em `CHK_fornecedores_generico`: genérico nunca tem `cnpj`, e fornecedor real
 * sempre tem. É o que separa "fornecedor no Lucro Presumido" de "este fornecedor".
 *
 * `uf` fica NULL de propósito. `resolverLocalidadeDaEntrada` (`domain/simulacoes/simulacao.service.ts`)
 * trata origem desconhecida como operação interna para ICMS/ISS e devolve `null` no DIFAL, que é
 * exatamente a leitura correta de um fornecedor sem identidade: alíquota interna do estado do cenário
 * e nenhum DIFAL inventado.
 *
 * A lista de genéricos aparece duas vezes de propósito: aqui, congelada, porque é esta migration que
 * semeia as linhas, e em `domain/fornecedores/fornecedores-genericos.ts`, viva, como contrato legível
 * e base do teste que prova o perfil de crédito de cada uma. Migration não importa código de domínio
 * (o domínio muda, a migration já rodou). Ao adicionar um perfil, mexa no domínio e escreva uma
 * migration nova.
 */
export class AddFornecedoresGenericos1787200000000 implements MigrationInterface {
  name = "AddFornecedoresGenericos1787200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "fornecedores" ADD COLUMN IF NOT EXISTS "generico" boolean NOT NULL DEFAULT false`,
    );

    // Genérico não tem documento. Sem isto, a única forma de criá-lo seria um CNPJ sintético.
    await queryRunner.query(`ALTER TABLE "fornecedores" ALTER COLUMN "cnpj" DROP NOT NULL`);

    await queryRunner.query(`DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint c
          JOIN pg_class t ON t.oid = c.conrelid
          JOIN pg_namespace n ON n.oid = t.relnamespace
          WHERE c.conname = 'CHK_fornecedores_generico'
            AND t.relname = 'fornecedores'
            AND n.nspname = current_schema()
        ) THEN
          ALTER TABLE "fornecedores"
            ADD CONSTRAINT "CHK_fornecedores_generico"
            CHECK (("generico" AND "cnpj" IS NULL) OR (NOT "generico" AND "cnpj" IS NOT NULL));
        END IF;
      END
    $$`);

    // A UNIQUE de documento passa a ignorar quem não tem documento.
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_fornecedores_cnpj"`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "UQ_fornecedores_cnpj" ON "fornecedores" ("cnpj") WHERE "cnpj" IS NOT NULL`,
    );

    // Um genérico por perfil. Schema-per-escritório, então isto já é unicidade por escritório, igual
    // ao que `UQ_fornecedores_cnpj` faz com o documento. `opcao_ibs_cbs` entra na chave porque Simples
    // Nacional tem dois perfis distintos (regime único e a opção híbrida do art. 41), e `COALESCE` é
    // obrigatório: NULL em índice UNIQUE não colide com NULL, então sem ele o Lucro Presumido
    // duplicaria a cada execução.
    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "UQ_fornecedores_generico_perfil"
         ON "fornecedores" (COALESCE("regime_tributario", ''), COALESCE("opcao_ibs_cbs", ''))
         WHERE "generico"`,
    );

    // Semeia os seis perfis no schema em que esta migration está rodando.
    //
    // `escritorio_id` vem do NOME DO SCHEMA porque não há outra fonte confiável dentro de um tenant:
    // derivá-lo de `clientes`/`fornecedores` existentes falharia justamente no escritório recém-criado,
    // que ainda não tem linha nenhuma. O nome é `escritorio_<uuid com _ em vez de ->`, contrato de
    // `database/tenant-naming.ts` → `buildEscritorioSchemaName`.
    //
    // O `WHERE` é um guard, não um filtro: em qualquer schema fora desse formato a migration insere
    // zero linhas em vez de estourar num cast de uuid inválido.
    //
    // Cobre escritório existente e futuro pelo mesmo caminho: `provisionEscritorioSchema` roda as
    // migrations do tenant ao criar o escritório, e `migration:sync-tenants` roda nos que já existem.
    await queryRunner.query(`
      INSERT INTO "fornecedores" (
        "escritorio_id", "generico", "cnpj", "razao_social", "regime_tributario", "opcao_ibs_cbs", "ativo"
      )
      SELECT replace(regexp_replace(current_schema(), '^escritorio_', ''), '_', '-')::uuid,
             true, NULL, g.razao_social, g.regime_tributario, g.opcao_ibs_cbs, true
        FROM (VALUES
          ('Genérico - Lucro Real',                  'Lucro Real',       NULL::varchar(20)),
          ('Genérico - Lucro Presumido',             'Lucro Presumido',  NULL::varchar(20)),
          ('Genérico - Simples Nacional (DAS)',      'Simples Nacional', 'regime_unico'::varchar(20)),
          ('Genérico - Simples Nacional (híbrido)',  'Simples Nacional', 'regime_regular'::varchar(20)),
          ('Genérico - MEI',                         'MEI',              'regime_unico'::varchar(20)),
          ('Genérico - Pessoa Física',               'Pessoa Física',    NULL::varchar(20))
        ) AS g(razao_social, regime_tributario, opcao_ibs_cbs)
       WHERE current_schema() ~ '^escritorio_[0-9a-f]{8}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{4}_[0-9a-f]{12}$'
      ON CONFLICT DO NOTHING
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    // As entradas que apontavam para um genérico voltam a `fornecedor_id IS NULL` pela FK
    // `ON DELETE SET NULL` de `simulacao_entradas`, e o crédito delas volta a ser zerado por falta
    // de evidência. É a perda de informação inerente ao rollback, não um efeito colateral evitável.
    await queryRunner.query(`DELETE FROM "fornecedores" WHERE "generico"`);

    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_fornecedores_generico_perfil"`);
    await queryRunner.query(
      `ALTER TABLE "fornecedores" DROP CONSTRAINT IF EXISTS "CHK_fornecedores_generico"`,
    );

    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_fornecedores_cnpj"`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX IF NOT EXISTS "UQ_fornecedores_cnpj" ON "fornecedores" ("cnpj")`,
    );
    await queryRunner.query(`ALTER TABLE "fornecedores" ALTER COLUMN "cnpj" SET NOT NULL`);

    await queryRunner.query(`ALTER TABLE "fornecedores" DROP COLUMN IF EXISTS "generico"`);
  }
}
