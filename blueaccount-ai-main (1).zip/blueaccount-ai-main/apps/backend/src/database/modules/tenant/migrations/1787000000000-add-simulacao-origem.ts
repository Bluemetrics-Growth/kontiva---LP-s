import type { MigrationInterface, QueryRunner } from "typeorm";

/** Proveniência de cenário para séries vinculadas; sem backfill. */
export class AddSimulacaoOrigem1787000000000 implements MigrationInterface {
  name = "AddSimulacaoOrigem1787000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacoes" ADD COLUMN IF NOT EXISTS "simulacao_origem_id" uuid`);
    await queryRunner.query(`
      DO $$ BEGIN
        ALTER TABLE "simulacoes"
          ADD CONSTRAINT "fk_simulacoes_origem"
          FOREIGN KEY ("simulacao_origem_id") REFERENCES "simulacoes"("id") ON DELETE SET NULL;
      EXCEPTION WHEN duplicate_object THEN NULL;
      END $$;
    `);
    await queryRunner.query(`COMMENT ON COLUMN "simulacoes"."simulacao_origem_id" IS 'Cenário-base de uma série vinculada; nulo para cenário independente/fonte e sem backfill.'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP CONSTRAINT IF EXISTS "fk_simulacoes_origem"`);
    await queryRunner.query(`ALTER TABLE "simulacoes" DROP COLUMN IF EXISTS "simulacao_origem_id"`);
  }
}
