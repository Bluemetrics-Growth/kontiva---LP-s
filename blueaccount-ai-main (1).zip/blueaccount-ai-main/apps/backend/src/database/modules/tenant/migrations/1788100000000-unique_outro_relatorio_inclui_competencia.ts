import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * A ingestão em lote via planilha (Excel/CSV) usa o mesmo `arquivo_origem`
 * (o documento) para todos os clientes/competências do arquivo. O índice
 * anterior, escopado só por (arquivo_origem, cliente_id), tratava o 2º
 * período do mesmo cliente no mesmo upload como duplicata do 1º — o
 * relatório "outro" daquele período nunca era inserido, nem no app-level
 * guard (`garantirOutroIneditoPorDocumento`) nem no banco.
 */
export class UniqueOutroRelatorioInclueCompetencia1788100000000 implements MigrationInterface {
  name = "UniqueOutroRelatorioInclueCompetencia1788100000000";

  async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_outro_ativo_arquivo_origem_cliente"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_outro_ativo_arquivo_origem_cliente_competencia"
      ON "relatorios" ("arquivo_origem", "cliente_id", "competencia")
      WHERE "relatorio_ativo" = true
        AND "tipo_relatorio" = 'outro'
        AND "arquivo_origem" IS NOT NULL
        AND "arquivo_origem" <> 'Cadastro manual'
    `);
  }

  async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "UQ_relatorios_outro_ativo_arquivo_origem_cliente_competencia"`);
    await queryRunner.query(`
      CREATE UNIQUE INDEX "UQ_relatorios_outro_ativo_arquivo_origem_cliente"
      ON "relatorios" ("arquivo_origem", "cliente_id")
      WHERE "relatorio_ativo" = true
        AND "tipo_relatorio" = 'outro'
        AND "arquivo_origem" IS NOT NULL
        AND "arquivo_origem" <> 'Cadastro manual'
    `);
  }
}
