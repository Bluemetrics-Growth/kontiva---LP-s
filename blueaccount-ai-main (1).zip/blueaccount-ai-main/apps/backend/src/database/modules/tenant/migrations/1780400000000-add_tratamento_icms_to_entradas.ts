import type { MigrationInterface, QueryRunner } from "typeorm";

export class AddTratamentoIcmsToEntradas1780400000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        ADD COLUMN "tratamento_icms" VARCHAR(32);

      UPDATE "simulacao_entradas"
      SET "tratamento_icms" = CASE
        WHEN "tipo" IN ('receita', 'outra_receita') THEN 'gera_debito'
        ELSE 'gera_credito'
      END;

      UPDATE "simulacao_entradas"
      SET "regra_credito_icms" = 'sem_credito'
      WHERE "tipo" IN ('custo_direto', 'outra_despesa')
        AND "regime_fornecedor" IN ('simples_nacional', 'outro_sem_credito');

      ALTER TABLE "simulacao_entradas"
        ALTER COLUMN "tratamento_icms" SET NOT NULL,
        ADD CONSTRAINT "chk_simulacao_entradas_tratamento_icms"
          CHECK ("tratamento_icms" IN ('gera_debito', 'gera_credito', 'credito_transferido_manual', 'sem_efeito')),
        ADD CONSTRAINT "chk_simulacao_entradas_tratamento_icms_tipo"
          CHECK (
            ("tipo" IN ('receita', 'outra_receita') AND "tratamento_icms" IN ('gera_debito', 'sem_efeito'))
            OR
            ("tipo" IN ('custo_direto', 'outra_despesa') AND "tratamento_icms" IN ('gera_credito', 'credito_transferido_manual', 'sem_efeito'))
          );
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simulacao_entradas"
        DROP CONSTRAINT IF EXISTS "chk_simulacao_entradas_tratamento_icms_tipo",
        DROP CONSTRAINT IF EXISTS "chk_simulacao_entradas_tratamento_icms",
        DROP COLUMN IF EXISTS "tratamento_icms";
    `);
  }
}
