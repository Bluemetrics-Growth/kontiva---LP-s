import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

export type AnexoSimples = "I" | "II" | "III" | "IV" | "V";

/**
 * Por que um CNAE não tem anexo.
 *
 * - `enquadrado`: tem anexo (ou depende do Fator R). É o caso normal.
 * - `vedado`: a atividade exclui a empresa do tratamento diferenciado. Só para o que casa com termo
 *   LITERALMENTE enumerado na lei, nunca por inferência: esta é a única situação em que o produto
 *   afirma inelegibilidade, e uma afirmação forte e errada faz o contador trocar o regime do cenário.
 * - `nao_optante`: a atividade não é exercida por ME/EPP (administração pública, organização
 *   associativa, serviço doméstico, organismo internacional). Não é vedação, é inaplicabilidade.
 *
 * Ausência do código no catálogo é coisa diferente das três: é lacuna nossa, e o diagnóstico
 * `cnae_nao_mapeado` existe para não confundir lacuna com veredito.
 */
export type SituacaoSimplesCnae = "enquadrado" | "vedado" | "nao_optante";

@Index("UQ_simples_cnaes_codigo", ["codigo"], { unique: true })
@Entity("simples_cnaes")
export class SimplesCnae {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 7 })
  codigo!: string;

  @Column({ type: "text" })
  descricao!: string;

  /** Null somente quando o anexo depende do Fator R. */
  @Column({ type: "varchar", length: 3, nullable: true })
  anexo!: AnexoSimples | null;

  @Column({ type: "boolean", default: false })
  fator_r!: boolean;

  /** Ver `SituacaoSimplesCnae`. `anexo` só é obrigatório quando `enquadrado` e sem Fator R. */
  @Column({ type: "varchar", length: 20, default: "enquadrado" })
  situacao!: SituacaoSimplesCnae;
  @Column({ type: "varchar", length: 100 })
  fonte!: string;
}
