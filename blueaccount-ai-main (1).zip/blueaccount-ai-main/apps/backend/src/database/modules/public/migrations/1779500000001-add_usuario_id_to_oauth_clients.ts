import { MigrationInterface, QueryRunner } from "typeorm";

export class AddUsuarioIdToOauthClients1779500000001 implements MigrationInterface {
  name = "AddUsuarioIdToOauthClients1779500000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "oauth_clients" ADD COLUMN IF NOT EXISTS "usuario_id" uuid`);
    await queryRunner.query(`ALTER TABLE "oauth_clients" ADD COLUMN IF NOT EXISTS "escritorio_id" uuid`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_oauth_clients_usuario_id" ON "oauth_clients" ("usuario_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_oauth_clients_escritorio_id" ON "oauth_clients" ("escritorio_id")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_oauth_clients_escritorio_id"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_oauth_clients_usuario_id"`);
    await queryRunner.query(`ALTER TABLE "oauth_clients" DROP COLUMN IF EXISTS "escritorio_id"`);
    await queryRunner.query(`ALTER TABLE "oauth_clients" DROP COLUMN IF EXISTS "usuario_id"`);
  }
}
