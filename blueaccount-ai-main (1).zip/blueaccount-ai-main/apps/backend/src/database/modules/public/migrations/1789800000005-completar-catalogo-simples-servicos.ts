import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Serviços do residual do art. 18, §5º-F, mais os de previsão expressa e as vedações do art. 17 que
 * casam literalmente com um inciso. 52 códigos.
 *
 * Migration própria em vez de crescer o seed e confiar nas anteriores: `1789800000004` insere com
 * `ON CONFLICT DO NOTHING` e roda UMA vez, então num banco que já a aplicou o arquivo maior seria
 * invisível. É a mesma armadilha do seeding inline que já mordeu duas vezes neste catálogo, e a regra
 * vale para todo crescimento futuro.
 *
 * Idempotente e neutra nas duas direções. Nenhum código existente muda de classificação: os 52 são
 * todos novos, então não há `UPDATE` a fazer - se um dia uma reclassificação for necessária, ela pede
 * migration própria com `UPDATE` explícito, porque `ON CONFLICT DO NOTHING` não a aplicaria.
 */
export class CompletarCatalogoSimplesServicos1789800000005 implements MigrationInterface {
  name = "CompletarCatalogoSimplesServicos1789800000005";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte", "situacao")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte, item.situacao
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  /** Remove só o que esta leva traz. As fontes identificam a procedência linha a linha. */
  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes"
        WHERE "fonte" LIKE 'LC 123/2006, art. 18, §5º-F%'
           OR "fonte" LIKE 'LC 123/2006, art. 18, §5º-C%'
           OR "fonte" LIKE 'LC 123/2006, art. 18, §5º-B%'
           OR "fonte" LIKE 'LC 123/2006, art. 18, §4º, II%'
           OR "fonte" LIKE 'LC 123/2006, Anexo III%'
           OR "fonte" LIKE 'LC 123/2006, art. 17%'`,
    );
  }
}
