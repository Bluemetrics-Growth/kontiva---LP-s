import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, Unique } from "typeorm";

/**
 * Registro idempotente das transições ALARM do CloudWatch para degradações de
 * runtimes AgentCore. Não armazena documento, prompt ou conteúdo do log.
 */
@Entity("alertas_agentcore")
@Unique("UQ_alertas_agentcore_arn_transicao", ["alarm_arn", "transition_at"])
export class AlertaAgentcore {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Index()
  @Column({ type: "text" })
  alarm_arn!: string;

  @Column({ type: "text" })
  alarm_name!: string;

  @Index()
  @Column({ type: "text" })
  agent_name!: string;

  @Index()
  @Column({ type: "text" })
  condicao!: "timeout_ou_erro" | "retentativas" | "execucoes_lentas";

  @Column({ type: "text", nullable: true })
  ambiente!: string | null;

  @Column({ type: "text", nullable: true })
  motivo!: string | null;

  @Column({ type: "timestamp with time zone" })
  transition_at!: Date;

  @CreateDateColumn()
  created_at!: Date;
}
