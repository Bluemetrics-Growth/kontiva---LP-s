import { Column, Entity, Index, OneToMany, PrimaryGeneratedColumn, type Relation } from "typeorm";
import type { AnexoSimples } from "./simples-cnae.entity.js";
import { SimplesAnexoReparticao } from "./simples-anexo-reparticao.entity.js";

@Index("UQ_simples_anexos_vigencia_faixa", ["anexo", "faixa", "vigencia_inicio"], { unique: true })
@Entity("simples_anexos")
export class SimplesAnexo {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 3 })
  anexo!: AnexoSimples;

  @Column({ type: "smallint" })
  faixa!: number;

  @Column({ type: "int" })
  vigencia_inicio!: number;

  @Column({ type: "int", nullable: true })
  vigencia_fim!: number | null;

  @Column({ type: "decimal", precision: 14, scale: 2 })
  rbt12_minimo!: number;

  @Column({ type: "decimal", precision: 14, scale: 2 })
  rbt12_maximo!: number;

  @Column({ type: "decimal", precision: 8, scale: 6 })
  aliquota_nominal!: number;

  @Column({ type: "decimal", precision: 14, scale: 2 })
  parcela_deduzir!: number;

  @Column({ type: "text" })
  fundamento_legal!: string;

  @OneToMany(() => SimplesAnexoReparticao, (reparticao) => reparticao.faixa_anexo)
  reparticoes!: Relation<SimplesAnexoReparticao[]>;
}
