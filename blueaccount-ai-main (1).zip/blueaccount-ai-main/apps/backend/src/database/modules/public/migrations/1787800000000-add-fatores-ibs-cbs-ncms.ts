import type { MigrationInterface, QueryRunner } from "typeorm";

type RegraLegalNcm = {
  codigo: string;
  descricao: string;
  fator: number;
  fundamento: string;
  condicoes: string | null;
  automatica: boolean;
};

/**
 * Manifesto das classificações NCM/SH expressamente alcançadas pelos anexos vigentes da LC 214/2025,
 * consolidada pela LC 227/2026. Prefixos preservam exatamente o nível publicado pelo legislador;
 * requisitos de descrição, registro, adquirente, destino ou uso tornam a regra apenas sugestiva.
 */
const REGRAS_LEGAIS: RegraLegalNcm[] = [
  { codigo: "100620", descricao: "Arroz descascado", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "100630", descricao: "Arroz semibranqueado ou branqueado", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "10064000", descricao: "Arroz quebrado", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "0401", descricao: "Leite fluido pasteurizado ou industrializado", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana e abrangido pela descrição legal.", automatica: false },
  { codigo: "0402", descricao: "Leite em pó", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana e abrangido pela descrição legal.", automatica: false },
  { codigo: "04051000", descricao: "Manteiga", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: null, automatica: true },
  { codigo: "15171000", descricao: "Margarina", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: null, automatica: true },
  { codigo: "19011010", descricao: "Fórmulas infantis acondicionadas para venda a retalho", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Fórmula infantil conforme os requisitos da legislação específica.", automatica: false },
  { codigo: "19011090", descricao: "Outras fórmulas infantis", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Fórmula infantil conforme os requisitos da legislação específica.", automatica: false },
  { codigo: "21069090", descricao: "Fórmulas infantis ou dietoterápicas abrangidas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente fórmula infantil ou dietoterápica para erro inato do metabolismo expressamente abrangida.", automatica: false },
  { codigo: "19019090", descricao: "Farinha com baixo teor de proteína", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente produto destinado às condições metabólicas descritas na lei.", automatica: false },
  { codigo: "19021900", descricao: "Massa com baixo teor de proteína", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente produto destinado às condições metabólicas descritas na lei.", automatica: false },
  { codigo: "0407", descricao: "Ovos de aves", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Ovo abrangido pela descrição legal, sem preparação excluída.", automatica: false },
  { codigo: "0701", descricao: "Batatas frescas ou refrigeradas", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0702", descricao: "Tomates frescos ou refrigerados", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0703", descricao: "Cebolas, alhos e produtos hortícolas semelhantes", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0704", descricao: "Couves, couve-flor e produtos semelhantes", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0705", descricao: "Alfaces e chicórias", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0706", descricao: "Cenouras, nabos e raízes semelhantes", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0707", descricao: "Pepinos e pepininhos", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0708", descricao: "Legumes de vagem frescos ou refrigerados", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola no estado descrito na lei.", automatica: false },
  { codigo: "0709", descricao: "Outros produtos hortícolas frescos ou refrigerados", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Produto hortícola abrangido pela descrição legal.", automatica: false },
  { codigo: "0713", descricao: "Legumes de vagem secos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Feijões e demais produtos expressamente abrangidos pela descrição legal.", automatica: false },
  { codigo: "07133319", descricao: "Feijões comuns, outros", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Feijão abrangido pela descrição legal.", automatica: false },
  { codigo: "07133329", descricao: "Feijão-preto, outros", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Feijão abrangido pela descrição legal.", automatica: false },
  { codigo: "07133399", descricao: "Outros feijões", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Feijão abrangido pela descrição legal.", automatica: false },
  { codigo: "07133590", descricao: "Feijão-fradinho, outros", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Feijão abrangido pela descrição legal.", automatica: false },
  { codigo: "0801", descricao: "Cocos e castanhas", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Somente frutas e produtos abrangidos; observar exclusões de frutas de casca rija.", automatica: false },
  { codigo: "0802", descricao: "Outras frutas de casca rija", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Somente espécies regionais expressamente abrangidas.", automatica: false },
  { codigo: "0803", descricao: "Bananas", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0804", descricao: "Tâmaras, figos, abacaxis, abacates, goiabas, mangas e mangostões", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0805", descricao: "Cítricos", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0806", descricao: "Uvas", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0807", descricao: "Melões, melancias e mamões", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0808", descricao: "Maçãs, peras e marmelos", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0809", descricao: "Damascos, cerejas, pêssegos, ameixas e abrunhos", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta no estado descrito na lei.", automatica: false },
  { codigo: "0810", descricao: "Outras frutas frescas", fator: 0, fundamento: "LC 214/2025, arts. 143 e 147 e Anexo XV", condicoes: "Fruta abrangida pela descrição legal.", automatica: false },
  { codigo: "0901", descricao: "Café", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Café abrangido pela apresentação e descrição legal.", automatica: false },
  { codigo: "21011", descricao: "Extratos, essências e concentrados de café", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto de café abrangido pela descrição legal.", automatica: false },
  { codigo: "0903", descricao: "Mate", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Mate abrangido pela descrição legal.", automatica: false },
  { codigo: "1006", descricao: "Arroz", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Arroz abrangido pela descrição legal.", automatica: false },
  { codigo: "1101", descricao: "Farinha de trigo ou de mistura de trigo com centeio", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana e abrangido pela descrição legal.", automatica: false },
  { codigo: "11062000", descricao: "Farinha de mandioca", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "19030000", descricao: "Tapioca e seus sucedâneos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "11022000", descricao: "Farinha de milho", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "11031300", descricao: "Grumos e sêmolas de milho", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto destinado à alimentação humana conforme a descrição legal.", automatica: false },
  { codigo: "11041900", descricao: "Outros grãos de cereais trabalhados", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente grãos de milho abrangidos pela descrição legal.", automatica: false },
  { codigo: "11042300", descricao: "Outros grãos de milho trabalhados", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto abrangido pela descrição legal.", automatica: false },
  { codigo: "11041200", descricao: "Grãos de aveia esmagados ou em flocos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto abrangido pela descrição legal.", automatica: false },
  { codigo: "11042200", descricao: "Outros grãos de aveia trabalhados", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto abrangido pela descrição legal.", automatica: false },
  { codigo: "11029000", descricao: "Outras farinhas de cereais", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente farinha de aveia abrangida pela descrição legal.", automatica: false },
  { codigo: "1507", descricao: "Óleo de soja", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Óleo destinado à alimentação humana e na apresentação abrangida.", automatica: false },
  { codigo: "1701", descricao: "Açúcares de cana ou beterraba", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Açúcar abrangido pela descrição legal.", automatica: false },
  { codigo: "15132120", descricao: "Óleo de babaçu", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Atender à legislação específica para consumo como alimento.", automatica: false },
  { codigo: "19021", descricao: "Massas alimentícias não cozidas nem recheadas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Produto abrangido pela descrição legal; conferir fórmula especial quando aplicável.", automatica: false },
  { codigo: "19059090", descricao: "Pão francês", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente pão francês com formato, composição e requisitos descritos na lei.", automatica: false },
  { codigo: "19012010", descricao: "Pré-mistura para pão francês", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente pré-mistura ou massa destinada ao pão francês descrito na lei.", automatica: false },
  { codigo: "19012090", descricao: "Massa para pão francês", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente pré-mistura ou massa destinada ao pão francês descrito na lei.", automatica: false },
  { codigo: "04061010", descricao: "Queijo muçarela", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipo de queijo expressamente abrangido.", automatica: false },
  { codigo: "04061090", descricao: "Outros queijos frescos abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipos de queijo expressamente abrangidos.", automatica: false },
  { codigo: "04062000", descricao: "Queijos ralados ou em pó", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipos de queijo expressamente abrangidos.", automatica: false },
  { codigo: "04069010", descricao: "Outros queijos abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipos de queijo expressamente abrangidos.", automatica: false },
  { codigo: "04069020", descricao: "Outros queijos abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipos de queijo expressamente abrangidos.", automatica: false },
  { codigo: "04069030", descricao: "Outros queijos abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente tipos de queijo expressamente abrangidos.", automatica: false },
  { codigo: "25010020", descricao: "Sal para consumo humano", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Atender ao teor de iodo e demais requisitos da legislação específica.", automatica: false },
  { codigo: "25010090", descricao: "Outro sal para consumo humano", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Atender ao teor de iodo e demais requisitos da legislação específica.", automatica: false },
  { codigo: "0201", descricao: "Carnes bovinas frescas ou refrigeradas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Carne ou produto animal expressamente abrangido, exceto exclusões legais.", automatica: false },
  { codigo: "0202", descricao: "Carnes bovinas congeladas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Carne ou produto animal expressamente abrangido, exceto exclusões legais.", automatica: false },
  { codigo: "0203", descricao: "Carnes suínas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Carne ou produto animal expressamente abrangido, exceto exclusões legais.", automatica: false },
  { codigo: "0204", descricao: "Carnes ovinas ou caprinas", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Carne ou produto animal expressamente abrangido, exceto exclusões legais.", automatica: false },
  { codigo: "0207", descricao: "Carnes e miudezas de aves", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Carne ou produto animal expressamente abrangido, exceto os códigos 0207.43.00 e 0207.53.00.", automatica: false },
  { codigo: "02074300", descricao: "Exceção: fígados de patos", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão expressa da alíquota zero da cesta básica.", automatica: true },
  { codigo: "02075300", descricao: "Exceção: fígados de gansos", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão expressa da alíquota zero da cesta básica.", automatica: true },
  { codigo: "0302", descricao: "Peixes frescos ou refrigerados abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.", automatica: false },
  { codigo: "0303", descricao: "Peixes congelados abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.", automatica: false },
  { codigo: "0304", descricao: "Filés e outras carnes de peixes abrangidos", fator: 0, fundamento: "LC 214/2025, art. 125 e Anexo I", condicoes: "Somente peixes abrangidos; observar todas as exclusões por espécie e apresentação.", automatica: false },
  { codigo: "03021", descricao: "Exceção: salmonídeos frescos ou refrigerados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica; conferir outro enquadramento aplicável.", automatica: true },
  { codigo: "03023", descricao: "Exceção: atuns frescos ou refrigerados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica; conferir outro enquadramento aplicável.", automatica: true },
  { codigo: "03029", descricao: "Exceção: outros peixes frescos ou refrigerados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica conforme espécie/apresentação.", automatica: true },
  { codigo: "03031", descricao: "Exceção: salmonídeos congelados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica; conferir outro enquadramento aplicável.", automatica: true },
  { codigo: "03034", descricao: "Exceção: atuns congelados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica; conferir outro enquadramento aplicável.", automatica: true },
  { codigo: "03039", descricao: "Exceção: outros peixes congelados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício da cesta básica conforme espécie/apresentação.", automatica: true },
  { codigo: "03044", descricao: "Exceção: filés frescos ou refrigerados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício conforme espécie/apresentação expressamente indicada.", automatica: true },
  { codigo: "03045", descricao: "Exceção: outros filés frescos ou refrigerados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício conforme espécie/apresentação expressamente indicada.", automatica: true },
  { codigo: "03047", descricao: "Exceção: filés congelados", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício conforme espécie/apresentação expressamente indicada.", automatica: true },
  { codigo: "03048", descricao: "Exceção: outra carne de peixe congelada", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício conforme espécie/apresentação expressamente indicada.", automatica: true },
  { codigo: "03049", descricao: "Exceção: outra carne de peixe", fator: 1, fundamento: "LC 214/2025, Anexo I, exclusão expressa", condicoes: "Exclusão do benefício conforme espécie/apresentação expressamente indicada.", automatica: true },
  { codigo: "1902", descricao: "Massas alimentícias", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: "Somente códigos, apresentações e composição abrangidos; itens do Anexo I permanecem com alíquota zero.", automatica: false },
  { codigo: "1905", descricao: "Produtos de padaria", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: "Somente produtos expressamente descritos no Anexo VII; pão comum abrangido pelo Anexo I permanece com alíquota zero.", automatica: false },
  { codigo: "2009", descricao: "Sucos de frutas ou produtos hortícolas", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: "Natural, sem adição de açúcar, edulcorantes ou conservantes, conforme a descrição legal.", automatica: false },
  { codigo: "04090000", descricao: "Mel natural", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "11081200", descricao: "Amido de milho", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "19022000", descricao: "Massas alimentícias recheadas", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "19023000", descricao: "Outras massas alimentícias", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "19059010", descricao: "Pão de forma", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "20029000", descricao: "Extrato de tomate", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 135 e Anexo VII", condicoes: null, automatica: true },
  { codigo: "04032000", descricao: "Leite fermentado", fator: 0.4, fundamento: "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026", condicoes: "Atender à descrição e aos requisitos da legislação específica; conferir eventual enquadramento mais benéfico.", automatica: false },
  { codigo: "04039000", descricao: "Outros leites fermentados e compostos lácteos", fator: 0.4, fundamento: "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026", condicoes: "Atender à descrição e aos requisitos da legislação específica; conferir eventual enquadramento mais benéfico.", automatica: false },
  { codigo: "22029900", descricao: "Alimentos líquidos naturais de base vegetal", fator: 0.4, fundamento: "LC 214/2025, art. 135 e Anexo VII, texto consolidado pela LC 227/2026", condicoes: "Somente bebidas naturais com bases e composição expressamente abrangidas pela descrição legal.", automatica: false },
  { codigo: "1901", descricao: "Preparações alimentícias e fórmulas nutricionais especiais", fator: 0.4, fundamento: "LC 214/2025, arts. 133 e 134 e Anexo VI", condicoes: "Composição para nutrição enteral/parenteral ou fórmula especial listada, conforme indicação e registro aplicáveis.", automatica: false },
  { codigo: "2106", descricao: "Preparações alimentícias e fórmulas nutricionais especiais", fator: 0.4, fundamento: "LC 214/2025, arts. 133 e 134 e Anexo VI", condicoes: "Composição para nutrição enteral/parenteral ou fórmula especial listada, conforme indicação e registro aplicáveis.", automatica: false },
  { codigo: "3003", descricao: "Medicamentos não acondicionados para venda a retalho", fator: 0.4, fundamento: "LC 214/2025, art. 133", condicoes: "Medicamento registrado na Anvisa ou produzido por farmácia de manipulação; conferir hipóteses de alíquota zero do art. 146.", automatica: false },
  { codigo: "3004", descricao: "Medicamentos acondicionados para venda a retalho", fator: 0.4, fundamento: "LC 214/2025, art. 133", condicoes: "Medicamento registrado na Anvisa ou produzido por farmácia de manipulação; conferir hipóteses de alíquota zero do art. 146.", automatica: false },
  { codigo: "3306", descricao: "Produtos de higiene bucal", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 136 e Anexo VIII", condicoes: "Produto e apresentação majoritariamente consumidos por famílias de baixa renda, conforme o Anexo VIII.", automatica: false },
  { codigo: "3401", descricao: "Sabões e produtos de higiene/limpeza", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 136 e Anexo VIII", condicoes: "Somente produtos e apresentações expressamente relacionados no Anexo VIII.", automatica: false },
  { codigo: "3808", descricao: "Inseticidas e produtos semelhantes", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 137 e Anexo IX", condicoes: "Somente insumo agropecuário ou aquícola registrado e na finalidade prevista em lei.", automatica: false },
  { codigo: "4901", descricao: "Livros, brochuras e impressos semelhantes", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 139 e Anexo X", condicoes: "Produção nacional artística, cultural, jornalística ou audiovisual enquadrada nas condições do art. 139.", automatica: false },
  { codigo: "9021", descricao: "Dispositivos ortopédicos e de acessibilidade", fator: 0.4, fundamento: "LC 214/2025, arts. 128, 131 e 132 e Anexos IV e V", condicoes: "Dispositivo listado e regularizado perante a Anvisa ou órgão competente; observar adquirente e finalidade quando exigidos.", automatica: false },
  { codigo: "9022", descricao: "Aparelhos de raios X e outros dispositivos médicos", fator: 0.4, fundamento: "LC 214/2025, arts. 128 e 131 e Anexo IV", condicoes: "Dispositivo listado e regularizado perante a Anvisa.", automatica: false },
  { codigo: "9018", descricao: "Instrumentos e aparelhos para medicina, cirurgia e odontologia", fator: 0.4, fundamento: "LC 214/2025, arts. 131 e 144 e Anexos IV e XII", condicoes: "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.", automatica: false },
  { codigo: "9019", descricao: "Aparelhos de mecanoterapia, massagem e terapia respiratória", fator: 0.4, fundamento: "LC 214/2025, arts. 131 e 144 e Anexos IV e XII", condicoes: "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.", automatica: false },
  { codigo: "9020", descricao: "Outros aparelhos respiratórios e máscaras contra gases", fator: 0.4, fundamento: "LC 214/2025, arts. 131 e 144 e Anexos IV e XII", condicoes: "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.", automatica: false },
  { codigo: "9402", descricao: "Mobiliário médico, cirúrgico, odontológico ou veterinário", fator: 0.4, fundamento: "LC 214/2025, arts. 131 e 144 e Anexos IV e XII", condicoes: "Somente dispositivo expressamente listado e regularizado na Anvisa; alíquota zero pode depender do item ou adquirente.", automatica: false },
  { codigo: "8713", descricao: "Cadeiras de rodas e outros veículos para pessoas com deficiência", fator: 0.4, fundamento: "LC 214/2025, arts. 132 e 145 e Anexos V e XIII", condicoes: "Dispositivo de acessibilidade expressamente listado e conforme norma competente; alíquota zero pode depender do item ou adquirente.", automatica: false },
  { codigo: "8714", descricao: "Partes e acessórios de veículos para pessoas com deficiência", fator: 0.4, fundamento: "LC 214/2025, arts. 132 e 145 e Anexos V e XIII", condicoes: "Somente partes e acessórios expressamente listados e conforme norma competente.", automatica: false },
  { codigo: "96190000", descricao: "Absorventes, tampões, calcinhas absorventes e coletores menstruais", fator: 0, fundamento: "LC 214/2025, art. 147", condicoes: "Produto de cuidado básico à saúde menstrual que atenda aos requisitos da Anvisa.", automatica: false },
];

export class AddFatoresIbsCbsNcms1787800000000 implements MigrationInterface {
  name = "AddFatoresIbsCbsNcms1787800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ncms_referencia"
      ADD COLUMN IF NOT EXISTS "fator_ibs" decimal(7,6) NOT NULL DEFAULT 1,
      ADD COLUMN IF NOT EXISTS "fator_cbs" decimal(7,6) NOT NULL DEFAULT 1,
      ADD COLUMN IF NOT EXISTS "fatores_configurados" boolean NOT NULL DEFAULT false,
      ADD COLUMN IF NOT EXISTS "aplicacao_automatica" boolean NOT NULL DEFAULT true,
      ADD COLUMN IF NOT EXISTS "fundamento_legal_fatores" text,
      ADD COLUMN IF NOT EXISTS "condicoes_aplicacao_fatores" text,
      ADD COLUMN IF NOT EXISTS "origem_configuracao_fatores" varchar(80)`);
    await queryRunner.query(`DO $$ BEGIN
      ALTER TABLE "ncms_referencia" ADD CONSTRAINT "CHK_ncms_referencia_fator_ibs" CHECK ("fator_ibs" BETWEEN 0 AND 1);
    EXCEPTION WHEN duplicate_object THEN NULL; END $$`);
    await queryRunner.query(`DO $$ BEGIN
      ALTER TABLE "ncms_referencia" ADD CONSTRAINT "CHK_ncms_referencia_fator_cbs" CHECK ("fator_cbs" BETWEEN 0 AND 1);
    EXCEPTION WHEN duplicate_object THEN NULL; END $$`);
    await queryRunner.query(`DO $$ BEGIN
      ALTER TABLE "ncms_referencia" ADD CONSTRAINT "CHK_ncms_referencia_codigo_escopo" CHECK ("codigo" ~ '^[0-9]{2,8}$');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$`);

    for (const regra of REGRAS_LEGAIS) {
      await queryRunner.query(`INSERT INTO "ncms_referencia" (
        "codigo", "descricao", "descricoes_hierarquia", "resposta_brasilapi",
        "fator_ibs", "fator_cbs", "fatores_configurados", "aplicacao_automatica",
        "fundamento_legal_fatores", "condicoes_aplicacao_fatores", "origem_configuracao_fatores"
      ) VALUES ($1, $2, NULL, $3::jsonb, $4, $4, true, $5, $6, $7, 'LC214-227-2026')
      ON CONFLICT ("codigo") DO UPDATE SET
        "fator_ibs" = EXCLUDED."fator_ibs",
        "fator_cbs" = EXCLUDED."fator_cbs",
        "fatores_configurados" = true,
        "aplicacao_automatica" = EXCLUDED."aplicacao_automatica",
        "fundamento_legal_fatores" = EXCLUDED."fundamento_legal_fatores",
        "condicoes_aplicacao_fatores" = EXCLUDED."condicoes_aplicacao_fatores",
        "origem_configuracao_fatores" = EXCLUDED."origem_configuracao_fatores"`, [
        regra.codigo,
        regra.descricao,
        JSON.stringify({ origem: "migration:LC214-227-2026", codigo: regra.codigo }),
        regra.fator,
        regra.automatica,
        regra.fundamento,
        regra.condicoes,
      ]);
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM "ncms_referencia"
      WHERE "origem_configuracao_fatores" = 'LC214-227-2026'
        AND "resposta_brasilapi"->>'origem' = 'migration:LC214-227-2026'`);
    await queryRunner.query(`ALTER TABLE "ncms_referencia"
      DROP CONSTRAINT "CHK_ncms_referencia_codigo_escopo",
      DROP CONSTRAINT "CHK_ncms_referencia_fator_cbs",
      DROP CONSTRAINT "CHK_ncms_referencia_fator_ibs",
      DROP COLUMN "origem_configuracao_fatores",
      DROP COLUMN "condicoes_aplicacao_fatores",
      DROP COLUMN "fundamento_legal_fatores",
      DROP COLUMN "aplicacao_automatica",
      DROP COLUMN "fatores_configurados",
      DROP COLUMN "fator_cbs",
      DROP COLUMN "fator_ibs"`);
  }
}
