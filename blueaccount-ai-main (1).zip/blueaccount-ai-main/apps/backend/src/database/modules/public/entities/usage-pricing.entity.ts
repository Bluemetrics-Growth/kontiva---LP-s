import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn } from "typeorm";

/** Converte numeric do Postgres (string) <-> number no domínio. */
const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/**
 * Tabela de tarifas globais de billing por uso (singleton).
 * Há no máximo uma linha vigente; valores iniciais vêm de `settings.ts`.
 */
@Entity("usage_pricing")
export class UsagePricing {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "numeric", transformer: numericToNumber })
  price_per_ocr_page!: number;

  @Column({ type: "numeric", transformer: numericToNumber })
  price_per_1k_input_tokens!: number;

  @Column({ type: "numeric", transformer: numericToNumber })
  price_per_1k_output_tokens!: number;

  @Column({ type: "numeric", transformer: numericToNumber })
  platform_monthly_fee!: number;

  @UpdateDateColumn()
  updated_at!: Date;
}
