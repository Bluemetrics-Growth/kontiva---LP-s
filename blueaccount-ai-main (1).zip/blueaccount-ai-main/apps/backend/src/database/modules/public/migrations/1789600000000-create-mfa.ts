import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateMfa1789600000000 implements MigrationInterface {
  name = "CreateMfa1789600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "fatores_mfa_usuario" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "usuario_id" uuid NOT NULL,
        "segredo_encrypted" text NOT NULL,
        "segredo_iv" text NOT NULL,
        "segredo_tag" text NOT NULL,
        "ultimo_passo_aceito" bigint,
        "ativado_em" TIMESTAMP NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_fatores_mfa_usuario" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_fatores_mfa_usuario_usuario_id" UNIQUE ("usuario_id"),
        CONSTRAINT "FK_fatores_mfa_usuario_usuario" FOREIGN KEY ("usuario_id") REFERENCES "usuarios"("id") ON DELETE CASCADE
      )
    `);
    await queryRunner.query(`
      CREATE TABLE "fator_mfa_admin_plataforma" (
        "username" text NOT NULL,
        "segredo_encrypted" text NOT NULL,
        "segredo_iv" text NOT NULL,
        "segredo_tag" text NOT NULL,
        "ultimo_passo_aceito" bigint,
        "ativado_em" TIMESTAMP NOT NULL,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_fator_mfa_admin_plataforma" PRIMARY KEY ("username"),
        CONSTRAINT "CK_fator_mfa_admin_username" CHECK ("username" = 'admin')
      )
    `);
    await queryRunner.query(`
      CREATE UNLOGGED TABLE "desafios_mfa" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "token_hash" text NOT NULL,
        "usuario_id" uuid,
        "admin_username" text,
        "finalidade" text NOT NULL,
        "origem" text NOT NULL,
        "segredo_pendente_encrypted" text,
        "segredo_pendente_iv" text,
        "segredo_pendente_tag" text,
        "return_to" text,
        "tentativas" integer NOT NULL DEFAULT 0,
        "expires_at" TIMESTAMP NOT NULL,
        "consumido_em" TIMESTAMP,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_desafios_mfa" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_desafios_mfa_token_hash" UNIQUE ("token_hash"),
        CONSTRAINT "CK_desafios_mfa_identidade" CHECK (("usuario_id" IS NOT NULL AND "admin_username" IS NULL) OR ("usuario_id" IS NULL AND "admin_username" = 'admin')),
        CONSTRAINT "CK_desafios_mfa_finalidade" CHECK ("finalidade" IN ('cadastro', 'verificacao')),
        CONSTRAINT "CK_desafios_mfa_origem" CHECK ("origem" IN ('senha', 'google', 'admin')),
        CONSTRAINT "CK_desafios_mfa_segredo_pendente" CHECK (("finalidade" = 'cadastro' AND "segredo_pendente_encrypted" IS NOT NULL AND "segredo_pendente_iv" IS NOT NULL AND "segredo_pendente_tag" IS NOT NULL) OR ("finalidade" = 'verificacao' AND "segredo_pendente_encrypted" IS NULL AND "segredo_pendente_iv" IS NULL AND "segredo_pendente_tag" IS NULL))
      )
    `);
    await queryRunner.query(`CREATE INDEX "IDX_desafios_mfa_expires_at" ON "desafios_mfa" ("expires_at")`);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_desafios_mfa_usuario_ativo" ON "desafios_mfa" ("usuario_id") WHERE "usuario_id" IS NOT NULL AND "consumido_em" IS NULL`);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_desafios_mfa_admin_ativo" ON "desafios_mfa" ("admin_username") WHERE "admin_username" IS NOT NULL AND "consumido_em" IS NULL`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "desafios_mfa"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "fator_mfa_admin_plataforma"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "fatores_mfa_usuario"`);
  }
}
