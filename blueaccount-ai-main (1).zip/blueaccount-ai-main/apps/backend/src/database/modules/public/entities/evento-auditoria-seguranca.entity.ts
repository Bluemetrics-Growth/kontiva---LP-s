import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Check("CK_eventos_auditoria_identidade", `"identidade_tipo" IN ('usuario', 'admin_plataforma')`)
@Check("CK_eventos_auditoria_resultado", `"resultado" IN ('sucesso', 'falha')`)
@Entity({ name: "eventos_auditoria_seguranca", schema: "public" })
export class EventoAuditoriaSeguranca {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Index()
  @Column({ type: "text" })
  evento!: string;

  @Column({ type: "text" })
  identidade_tipo!: "usuario" | "admin_plataforma";

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  @Column({ type: "text" })
  resultado!: "sucesso" | "falha";

  @Column({ type: "jsonb", nullable: true })
  metadados!: Record<string, string | number | boolean | null> | null;

  @Index()
  @CreateDateColumn()
  created_at!: Date;
}
