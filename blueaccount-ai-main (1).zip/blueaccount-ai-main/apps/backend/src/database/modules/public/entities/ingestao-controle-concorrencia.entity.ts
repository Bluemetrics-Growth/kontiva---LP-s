import { Check, Entity, PrimaryColumn } from "typeorm";

@Entity("ingestao_controle_concorrencia")
@Check("CHK_ingestao_controle_concorrencia_singleton", `"id" = 1`)
export class IngestaoControleConcorrencia {
  @PrimaryColumn({ type: "smallint" })
  id!: number;
}
