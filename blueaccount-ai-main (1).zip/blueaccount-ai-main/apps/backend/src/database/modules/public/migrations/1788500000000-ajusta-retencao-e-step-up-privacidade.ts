import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Follow-up de `1788400000000-create-operacao-privacidade`.
 *
 * Existe porque aquela migration pode já ter rodado em ambientes de desenvolvimento
 * antes destes ajustes: editar o arquivo aplicado corrige quem ainda não rodou (prd),
 * mas não converge quem já rodou. Tudo aqui é idempotente, então serve aos dois casos.
 *
 * O que converge:
 * 1. `reautenticado_em` em `sessoes` e `admin_session` — coluna do step-up auth. Sem
 *    ela o gate de ação crítica cai em `created_at`, que só o logout renova, e o
 *    usuário fica sem caminho para excluir documento ou mexer em integração.
 * 2. Reagenda a retenção diária com prazo separado para a trilha de auditoria
 *    administrativa (`agent_name = 'admin-usuarios'`): 1 ano, contra 30 dias da
 *    telemetria. O job anterior levava a trilha de controle de acesso junto com a
 *    telemetria. `cron.schedule` faz upsert pelo nome do job.
 */
export class AjustaRetencaoEStepUpPrivacidade1788500000000 implements MigrationInterface {
  name = "AjustaRetencaoEStepUpPrivacidade1788500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "sessoes" ADD COLUMN IF NOT EXISTS "reautenticado_em" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "admin_session" ADD COLUMN IF NOT EXISTS "reautenticado_em" TIMESTAMP`);

    // Prazos espelhados em `domain/privacidade/privacidade.service.ts`
    // (RETENCAO_TELEMETRIA_DIAS / RETENCAO_AUDITORIA_DIAS): mudar um exige mudar o
    // outro. Falha de agendamento não derruba o deploy — a purga também roda por
    // `POST /api/admin/privacidade/retencao/executar`.
    await queryRunner.query(`
      DO $$
      BEGIN
        IF current_setting('shared_preload_libraries', true) LIKE '%pg_cron%' THEN
          CREATE EXTENSION IF NOT EXISTS pg_cron;
          PERFORM cron.schedule(
            'lgpd-retencao-operacional-diaria', '17 3 * * *',
            $q$
              DELETE FROM public.contexto WHERE created_at < now() - interval '30 days';
              DELETE FROM public.agent_logs
                WHERE created_at < now() - interval '30 days'
                  AND agent_name <> 'admin-usuarios';
              DELETE FROM public.agent_logs
                WHERE created_at < now() - interval '365 days'
                  AND agent_name = 'admin-usuarios';
            $q$
          );
        ELSE
          RAISE NOTICE 'pg_cron não carregado; purge de retenção LGPD não agendado.';
        END IF;
      EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'pg_cron indisponível para agendar a retenção LGPD (%); use POST /api/admin/privacidade/retencao/executar.', SQLERRM;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "admin_session" DROP COLUMN IF EXISTS "reautenticado_em"`);
    await queryRunner.query(`ALTER TABLE "sessoes" DROP COLUMN IF EXISTS "reautenticado_em"`);
    // O job volta ao corpo de prazo único da migration anterior.
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
          PERFORM cron.schedule(
            'lgpd-retencao-operacional-diaria', '17 3 * * *',
            $q$
              DELETE FROM public.contexto WHERE created_at < now() - interval '30 days';
              DELETE FROM public.agent_logs WHERE created_at < now() - interval '30 days';
            $q$
          );
        END IF;
      EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'pg_cron indisponível para reverter o agendamento (%).', SQLERRM;
      END $$;
    `);
  }
}
