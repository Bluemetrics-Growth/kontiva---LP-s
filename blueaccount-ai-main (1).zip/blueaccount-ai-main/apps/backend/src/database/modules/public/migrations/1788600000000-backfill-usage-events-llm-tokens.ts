import type { MigrationInterface, QueryRunner } from "typeorm";

export class BackfillUsageEventsLlmTokens1788600000000 implements MigrationInterface {
  name = "BackfillUsageEventsLlmTokens1788600000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // A partir de agora o AgentLogger espelha tokens em usage_events (survive ao
    // purge de 30 dias de agent_logs — ver domain/privacidade). Sem este backfill,
    // a janela de agent_logs ainda viva no momento do deploy (até 30 dias) some do
    // billing assim que o próximo ciclo do pg_cron rodar. Um único INSERT...SELECT
    // basta aqui (ao contrário do UPDATE em lote de 1788400000000): a retenção LGPD
    // já limita o universo de origem a, no máximo, 30 dias de linhas.
    await queryRunner.query(`
      INSERT INTO public.usage_events (escritorio_id, event_type, quantity, metadata, created_at)
      SELECT
        escritorio_id,
        'llm_tokens',
        COALESCE(total_tokens, COALESCE(input_tokens, 0) + COALESCE(output_tokens, 0)),
        jsonb_build_object(
          'agent_name', agent_name,
          'model_id', model_id,
          'input_tokens', input_tokens,
          'output_tokens', output_tokens,
          'backfilled', true
        ),
        created_at
      FROM public.agent_logs
      WHERE COALESCE(total_tokens, COALESCE(input_tokens, 0) + COALESCE(output_tokens, 0)) > 0
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DELETE FROM public.usage_events
      WHERE event_type = 'llm_tokens' AND metadata->>'backfilled' = 'true'
    `);
  }
}
