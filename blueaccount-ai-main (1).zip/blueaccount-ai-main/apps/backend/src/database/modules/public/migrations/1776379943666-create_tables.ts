import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateTables1776379943666 implements MigrationInterface {
    name = 'CreateTables1776379943666'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "admin_session" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "session_id_hash" text NOT NULL, "username" text NOT NULL, "expires_at" TIMESTAMP NOT NULL, "revoked_at" TIMESTAMP, "last_seen_at" TIMESTAMP, "user_agent" text, "ip_address" text, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_031b46c28b79cc8e17984c9f1a2" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_admin_session_expires_at" ON "admin_session" ("expires_at") `);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_admin_session_session_id_hash" ON "admin_session" ("session_id_hash") `);
        await queryRunner.query(`CREATE TABLE "usuarios" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "escritorio_id" uuid NOT NULL, "nome" text NOT NULL, "email" text NOT NULL, "cognito_sub" text, "admin_escritorio" boolean NOT NULL DEFAULT false, "ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_d7281c63c176e152e4c531594a8" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_usuarios_escritorio_id" ON "usuarios" ("escritorio_id") `);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_usuarios_cognito_sub" ON "usuarios" ("cognito_sub") `);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_usuarios_email" ON "usuarios" ("email") `);
        await queryRunner.query(`CREATE TABLE "escritorios" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "nome" text NOT NULL, "ativo" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_5f0a6586ca926a1a84d56c40b00" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "agent_logs" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "escritorio_id" uuid NOT NULL, "agent_name" text NOT NULL, "level" text NOT NULL, "event" text NOT NULL, "context" jsonb, "model_id" text, "input_tokens" integer, "output_tokens" integer, "total_tokens" integer, "latency_ms" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_2cc52efab0f963454d7006a6981" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_dd40236664974a6f631808901f" ON "agent_logs" ("agent_name") `);
        await queryRunner.query(`CREATE INDEX "IDX_797608d0f2c0e7135266c4a138" ON "agent_logs" ("created_at") `);
        await queryRunner.query(`CREATE TABLE "sessoes" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "session_id_hash" text NOT NULL, "usuario_id" uuid NOT NULL, "escritorio_id" uuid NOT NULL, "expires_at" TIMESTAMP NOT NULL, "revoked_at" TIMESTAMP, "last_seen_at" TIMESTAMP, "user_agent" text, "ip_address" text, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_c2a5880f0d471e675eacc8e5714" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_sessoes_expires_at" ON "sessoes" ("expires_at") `);
        await queryRunner.query(`CREATE INDEX "IDX_sessoes_escritorio_id" ON "sessoes" ("escritorio_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_sessoes_usuario_id" ON "sessoes" ("usuario_id") `);
        await queryRunner.query(`CREATE UNIQUE INDEX "UQ_sessoes_session_id_hash" ON "sessoes" ("session_id_hash") `);
        await queryRunner.query(`CREATE TABLE "contexto" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "trace_id" text NOT NULL, "escritorio_id" uuid, "usuario_id" uuid, "sessao_id" uuid, "rota" text NOT NULL, "metodo" text NOT NULL, "pagina" text, "status_code" integer, "sucesso" boolean NOT NULL DEFAULT false, "request_payload" jsonb, "response_payload" jsonb, "error_payload" jsonb, "latency_ms" integer, "created_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_668c31e0a285941aab771f69268" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_created_at" ON "contexto" ("created_at") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_sucesso" ON "contexto" ("sucesso") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_pagina" ON "contexto" ("pagina") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_metodo" ON "contexto" ("metodo") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_rota" ON "contexto" ("rota") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_sessao_id" ON "contexto" ("sessao_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_usuario_id" ON "contexto" ("usuario_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_escritorio_id" ON "contexto" ("escritorio_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_contexto_trace_id" ON "contexto" ("trace_id") `);
        await queryRunner.query(`ALTER TABLE "usuarios" ADD CONSTRAINT "FK_2b0b0d5b48967881ec444174a71" FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "agent_logs" ADD CONSTRAINT "FK_db1eece6c40eb5fc35faa1b0544" FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sessoes" ADD CONSTRAINT "FK_61dbcb4cfdf4aaca8067f368128" FOREIGN KEY ("usuario_id") REFERENCES "usuarios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "sessoes" ADD CONSTRAINT "FK_bf95fdd714ce01e7e9bdf12ff6b" FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "contexto" ADD CONSTRAINT "FK_e45d7c7e50204c9fea4db0fc52d" FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "contexto" ADD CONSTRAINT "FK_a409f04494924e120beac2001c4" FOREIGN KEY ("usuario_id") REFERENCES "usuarios"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "contexto" ADD CONSTRAINT "FK_f2c35d02ce83d3f3963b2bfb3bf" FOREIGN KEY ("sessao_id") REFERENCES "sessoes"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "contexto" DROP CONSTRAINT "FK_f2c35d02ce83d3f3963b2bfb3bf"`);
        await queryRunner.query(`ALTER TABLE "contexto" DROP CONSTRAINT "FK_a409f04494924e120beac2001c4"`);
        await queryRunner.query(`ALTER TABLE "contexto" DROP CONSTRAINT "FK_e45d7c7e50204c9fea4db0fc52d"`);
        await queryRunner.query(`ALTER TABLE "sessoes" DROP CONSTRAINT "FK_bf95fdd714ce01e7e9bdf12ff6b"`);
        await queryRunner.query(`ALTER TABLE "sessoes" DROP CONSTRAINT "FK_61dbcb4cfdf4aaca8067f368128"`);
        await queryRunner.query(`ALTER TABLE "agent_logs" DROP CONSTRAINT "FK_db1eece6c40eb5fc35faa1b0544"`);
        await queryRunner.query(`ALTER TABLE "usuarios" DROP CONSTRAINT "FK_2b0b0d5b48967881ec444174a71"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_trace_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_escritorio_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_usuario_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_sessao_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_rota"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_metodo"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_pagina"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_sucesso"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_contexto_created_at"`);
        await queryRunner.query(`DROP TABLE "contexto"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_sessoes_session_id_hash"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_sessoes_usuario_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_sessoes_escritorio_id"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_sessoes_expires_at"`);
        await queryRunner.query(`DROP TABLE "sessoes"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_797608d0f2c0e7135266c4a138"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_dd40236664974a6f631808901f"`);
        await queryRunner.query(`DROP TABLE "agent_logs"`);
        await queryRunner.query(`DROP TABLE "escritorios"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_usuarios_email"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_usuarios_cognito_sub"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_usuarios_escritorio_id"`);
        await queryRunner.query(`DROP TABLE "usuarios"`);
        await queryRunner.query(`DROP INDEX "public"."UQ_admin_session_session_id_hash"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_admin_session_expires_at"`);
        await queryRunner.query(`DROP TABLE "admin_session"`);
    }

}
