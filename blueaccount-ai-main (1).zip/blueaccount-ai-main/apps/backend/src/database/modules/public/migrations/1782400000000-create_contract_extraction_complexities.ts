import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateContractExtractionComplexities1782400000000 implements MigrationInterface {
  name = "CreateContractExtractionComplexities1782400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "contract_extraction_complexities" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"nivel" integer NOT NULL, ` +
        `"nome" text NOT NULL, ` +
        `"descricao" text, ` +
        `"inference_profile_id" text, ` +
        `"ativo" boolean NOT NULL DEFAULT true, ` +
        `"created_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_contract_extraction_complexities" PRIMARY KEY ("id"), ` +
        `CONSTRAINT "UQ_contract_extraction_complexities_nivel" UNIQUE ("nivel"))`,
    );

    await queryRunner.query(`
      INSERT INTO "contract_extraction_complexities" ("nivel", "nome", "descricao", "inference_profile_id", "ativo")
      VALUES
        (1, 'Standard', 'Modelo padrao de extracao de contrato (default global quando inference_profile_id nulo).', NULL, true),
        (2, 'High accuracy', 'Modelo de maior capacidade para contratos complexos.', NULL, true)
      ON CONFLICT ("nivel") DO NOTHING
    `);

    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "contract_extraction_engine" text NOT NULL DEFAULT 'converse'`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "contract_extraction_complexity" integer NOT NULL DEFAULT 1`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "contract_extraction_complexity"`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "contract_extraction_engine"`,
    );
    await queryRunner.query(`DROP TABLE IF EXISTS "contract_extraction_complexities"`);
  }
}
