import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona a configuração do conector de Google Drive em `escritorios`:
 * `conector_drive_folder_id` (pasta compartilhada raiz no Drive do cliente) e
 * `conector_drive_ativo` (opt-in do admin; default `false` preserva o
 * comportamento atual para todas as linhas existentes).
 */
export class AddConectorDriveToEscritorios1783400000000 implements MigrationInterface {
  name = "AddConectorDriveToEscritorios1783400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "conector_drive_folder_id" text NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "conector_drive_ativo" boolean NOT NULL DEFAULT false`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "conector_drive_ativo"`);
    await queryRunner.query(`ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "conector_drive_folder_id"`);
  }
}
