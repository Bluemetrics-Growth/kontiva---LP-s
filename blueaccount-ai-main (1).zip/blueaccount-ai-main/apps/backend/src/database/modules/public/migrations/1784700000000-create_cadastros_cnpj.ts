import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCadastrosCnpj1784700000000 implements MigrationInterface {
  name = "CreateCadastrosCnpj1784700000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Cache do cadastro público de CNPJ (dados abertos da RFB). Público de propósito: é dado
    // público e compartilhar deduplica consulta entre escritórios, como em indices_inflacao.
    // `payload` guarda a resposta HIGIENIZADA — sem qsa/email/telefone (PII de terceiro).
    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "cadastros_cnpj" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(),
      "cnpj" varchar(14) NOT NULL,
      "razao_social" text,
      "nome_fantasia" text,
      "uf" varchar(2),
      "municipio" text,
      "cnae_principal" varchar(7),
      "cnae_principal_descricao" text,
      "cnaes_secundarios" jsonb,
      "porte" text,
      "natureza_juridica" text,
      "situacao_cadastral" text,
      "descricao_situacao_cadastral" text,
      "optante_simples" boolean,
      "optante_mei" boolean,
      "fonte" text NOT NULL DEFAULT 'BrasilAPI',
      "payload" jsonb,
      "consultado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_cadastros_cnpj" PRIMARY KEY ("id")
    )`);

    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_cadastros_cnpj_cnpj" ON "cadastros_cnpj" ("cnpj")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "cadastros_cnpj"`);
  }
}
