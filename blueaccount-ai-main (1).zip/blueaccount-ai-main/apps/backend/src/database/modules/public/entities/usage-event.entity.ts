import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
  ManyToOne,
  JoinColumn,
  type Relation,
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";

/**
 * Tipos de evento de uso faturável por escritório.
 * - `ocr_pages`: páginas processadas pelo pipeline de OCR (Textract).
 * - `llm_tokens`: tokens de uma chamada de modelo (`quantity` = total_tokens,
 *   `metadata.model_id`/`input_tokens`/`output_tokens`/`agent_name`).
 *
 * `llm_tokens` existe porque `agent_logs` (fonte original de tokens) é purgado
 * aos 30 dias pela retenção LGPD (`domain/privacidade`), e billing precisa do
 * total histórico. Só o agregado sem PII é duplicado aqui; prompt/context/
 * trace_id continuam só em `agent_logs` e saem no purge normalmente.
 */
export type UsageEventType = "ocr_pages" | "llm_tokens";

@Entity("usage_events")
export class UsageEvent {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Escritorio, { nullable: false })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio>;

  @Index()
  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Index()
  @Column({ type: "text" })
  event_type!: UsageEventType;

  /** Quantidade consumida no evento (ex.: nº de páginas OCR). */
  @Column({ type: "int" })
  quantity!: number;

  /** Documento de origem, quando aplicável. */
  @Column({ type: "uuid", nullable: true })
  documento_id!: string | null;

  @Column({ type: "jsonb", nullable: true })
  metadata!: Record<string, unknown> | null;

  @Index()
  @CreateDateColumn()
  created_at!: Date;
}
