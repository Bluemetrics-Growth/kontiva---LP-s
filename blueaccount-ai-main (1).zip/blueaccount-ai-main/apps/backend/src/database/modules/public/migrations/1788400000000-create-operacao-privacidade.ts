import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateOperacaoPrivacidade1788400000000 implements MigrationInterface {
  name = "CreateOperacaoPrivacidade1788400000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Step-up auth: marco da última confirmação de senha dentro da sessão. Sem esta
    // coluna o gate de ação crítica cairia em `created_at`, que só o logout renova.
    await queryRunner.query(`ALTER TABLE "sessoes" ADD COLUMN "reautenticado_em" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "admin_session" ADD COLUMN "reautenticado_em" TIMESTAMP`);
    await queryRunner.query(`ALTER TABLE "usuarios" ADD COLUMN "papel" text NOT NULL DEFAULT 'operador'`);
    await queryRunner.query(`UPDATE "usuarios" SET "papel" = CASE WHEN "admin_escritorio" THEN 'administrador' ELSE 'operador' END`);
    await queryRunner.query(`ALTER TABLE "usuarios" ADD CONSTRAINT "CK_usuarios_papel" CHECK ("papel" IN ('administrador','operador','consulta'))`);
    // Limpa prompt/contexto já gravados (o código novo não grava mais). Em lotes de
    // 10 mil por `ctid`: `agent_logs` é a tabela mais quente do schema public e um
    // UPDATE de tabela inteira dentro do passo de migration do deploy seguraria lock
    // de escrita e inflaria a tabela pelo tempo todo do rewrite.
    await queryRunner.query(`
      DO $$
      DECLARE afetadas integer;
      BEGIN
        LOOP
          WITH alvo AS (
            SELECT ctid FROM public.agent_logs
            WHERE prompt IS NOT NULL OR context IS NOT NULL
            LIMIT 10000
          )
          UPDATE public.agent_logs SET prompt = NULL, context = NULL
          WHERE ctid IN (SELECT ctid FROM alvo);
          GET DIAGNOSTICS afetadas = ROW_COUNT;
          EXIT WHEN afetadas = 0;
        END LOOP;
      END $$;
    `);
    await queryRunner.query(`
      CREATE TABLE "solicitacoes_privacidade" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "protocolo" text NOT NULL,
        "token_acesso_hash" text NOT NULL,
        "tipo" text NOT NULL,
        "status" text NOT NULL DEFAULT 'identidade_pendente',
        "nome_titular" text NOT NULL,
        "email_titular" text NOT NULL,
        "email_hash" text NOT NULL,
        "descricao" text,
        "escritorio_id" uuid,
        "usuario_id" uuid,
        "identidade_verificada_em" timestamptz,
        "responsavel" text,
        "prazo_resposta_em" timestamptz NOT NULL,
        "decisao" text,
        "fundamento" text,
        "evidencias" jsonb NOT NULL DEFAULT '[]'::jsonb,
        "concluida_em" timestamptz,
        "created_at" timestamptz NOT NULL DEFAULT now(),
        "updated_at" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "PK_solicitacoes_privacidade" PRIMARY KEY ("id"),
        CONSTRAINT "CK_solicitacoes_privacidade_tipo" CHECK ("tipo" IN ('confirmacao','acesso','correcao','portabilidade','bloqueio','anonimizacao','eliminacao','oposicao','revisao_decisao_automatizada')),
        CONSTRAINT "CK_solicitacoes_privacidade_status" CHECK ("status" IN ('recebida','identidade_pendente','em_analise','em_execucao','concluida','negada'))
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_solicitacoes_privacidade_protocolo" ON "solicitacoes_privacidade" ("protocolo")`);
    await queryRunner.query(`CREATE INDEX "IDX_solicitacoes_privacidade_status_prazo" ON "solicitacoes_privacidade" ("status", "prazo_resposta_em")`);
    await queryRunner.query(`CREATE INDEX "IDX_solicitacoes_privacidade_email_hash" ON "solicitacoes_privacidade" ("email_hash")`);

    await queryRunner.query(`
      CREATE TABLE "incidentes_dados_pessoais" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "titulo" text NOT NULL,
        "status" text NOT NULL DEFAULT 'triagem',
        "descricao_resumida" text NOT NULL,
        "categorias_dados" text,
        "titulares_afetados_estimativa" text,
        "avaliacao_risco" text,
        "medidas_contencao" text,
        "responsavel" text,
        "detectado_em" timestamptz NOT NULL,
        "comunicado_controlador_em" timestamptz,
        "comunicado_anpd_em" timestamptz,
        "comunicado_titulares_em" timestamptz,
        "encerrado_em" timestamptz,
        "evidencias" jsonb NOT NULL DEFAULT '[]'::jsonb,
        "created_at" timestamptz NOT NULL DEFAULT now(),
        "updated_at" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "PK_incidentes_dados_pessoais" PRIMARY KEY ("id"),
        CONSTRAINT "CK_incidentes_dados_pessoais_status" CHECK ("status" IN ('triagem','contencao','avaliacao_risco','comunicacao','encerrado'))
      )
    `);
    await queryRunner.query(`CREATE INDEX "IDX_incidentes_dados_pessoais_status" ON "incidentes_dados_pessoais" ("status")`);
    await queryRunner.query(`CREATE INDEX "IDX_incidentes_dados_pessoais_detectado_em" ON "incidentes_dados_pessoais" ("detectado_em")`);
    await queryRunner.query(`
      CREATE FUNCTION proteger_retencao_incidente_dados_pessoais() RETURNS trigger AS $$
      BEGIN
        IF OLD.detectado_em > now() - interval '5 years' THEN
          RAISE EXCEPTION 'Incidente com dados pessoais deve ser mantido por no minimo 5 anos.';
        END IF;
        RETURN OLD;
      END;
      $$ LANGUAGE plpgsql
    `);
    await queryRunner.query(`
      CREATE TRIGGER "TRG_incidentes_dados_pessoais_retencao"
      BEFORE DELETE ON "incidentes_dados_pessoais"
      FOR EACH ROW EXECUTE FUNCTION proteger_retencao_incidente_dados_pessoais()
    `);

    await queryRunner.query(`
      CREATE TABLE "tombstones_privacidade" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "escopo" text NOT NULL,
        "identificador_hash" text NOT NULL,
        "escritorio_id" uuid,
        "manifesto" jsonb NOT NULL DEFAULT '{}'::jsonb,
        "motivo" text NOT NULL,
        "tentativas" integer NOT NULL DEFAULT 0,
        "ultimo_erro" text,
        "proxima_tentativa_em" timestamptz,
        "concluido_em" timestamptz,
        "created_at" timestamptz NOT NULL DEFAULT now(),
        "updated_at" timestamptz NOT NULL DEFAULT now(),
        CONSTRAINT "PK_tombstones_privacidade" PRIMARY KEY ("id"),
        CONSTRAINT "CK_tombstones_privacidade_escopo" CHECK ("escopo" IN ('documento','escritorio','titular'))
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_tombstones_privacidade_escopo_hash" ON "tombstones_privacidade" ("escopo", "identificador_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_tombstones_privacidade_pendente" ON "tombstones_privacidade" ("concluido_em", "proxima_tentativa_em")`);

    // Retenção operacional: o payload já passa a ser mínimo no código; este job
    // garante que a telemetria identificável não ultrapasse 30 dias em produção.
    //
    // A trilha de auditoria administrativa (`agent_name = 'admin-usuarios'`) tem
    // prazo próprio de 1 ano: ela registra quem criou/promoveu/removeu usuário e não
    // pode sair junto com a telemetria. Prazos espelhados em
    // `domain/privacidade/privacidade.service.ts` (RETENCAO_*_DIAS) — mudar um exige
    // mudar o outro.
    //
    // O guard segue o mesmo padrão de `1784112210638-set_sessoes_unlogged` (que já
    // criou a extensão em prod). O EXCEPTION extra é deliberado: agendamento é
    // conveniência operacional e `POST /api/admin/privacidade/retencao/executar` faz
    // o mesmo trabalho sob demanda — nada disso justifica derrubar o deploy.
    await queryRunner.query(`
      DO $$
      BEGIN
        IF current_setting('shared_preload_libraries', true) LIKE '%pg_cron%' THEN
          CREATE EXTENSION IF NOT EXISTS pg_cron;
          PERFORM cron.schedule(
            'lgpd-retencao-operacional-diaria', '17 3 * * *',
            $q$
              DELETE FROM public.contexto WHERE created_at < now() - interval '30 days';
              DELETE FROM public.agent_logs
                WHERE created_at < now() - interval '30 days'
                  AND agent_name <> 'admin-usuarios';
              DELETE FROM public.agent_logs
                WHERE created_at < now() - interval '365 days'
                  AND agent_name = 'admin-usuarios';
            $q$
          );
        ELSE
          RAISE NOTICE 'pg_cron não carregado; purge de retenção LGPD não agendado.';
        END IF;
      EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'pg_cron indisponível para agendar a retenção LGPD (%); use POST /api/admin/privacidade/retencao/executar.', SQLERRM;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
          PERFORM cron.unschedule(jobname) FROM cron.job WHERE jobname = 'lgpd-retencao-operacional-diaria';
        END IF;
      END $$;
    `);
    await queryRunner.query(`DROP TABLE "tombstones_privacidade"`);
    await queryRunner.query(`DROP TRIGGER "TRG_incidentes_dados_pessoais_retencao" ON "incidentes_dados_pessoais"`);
    await queryRunner.query(`DROP FUNCTION proteger_retencao_incidente_dados_pessoais`);
    await queryRunner.query(`DROP TABLE "incidentes_dados_pessoais"`);
    await queryRunner.query(`DROP TABLE "solicitacoes_privacidade"`);
    await queryRunner.query(`ALTER TABLE "usuarios" DROP CONSTRAINT "CK_usuarios_papel"`);
    await queryRunner.query(`ALTER TABLE "usuarios" DROP COLUMN "papel"`);
    await queryRunner.query(`ALTER TABLE "admin_session" DROP COLUMN "reautenticado_em"`);
    await queryRunner.query(`ALTER TABLE "sessoes" DROP COLUMN "reautenticado_em"`);
  }
}
