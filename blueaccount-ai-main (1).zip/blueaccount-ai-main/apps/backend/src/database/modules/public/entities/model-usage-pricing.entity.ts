import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/** Converte numeric do Postgres (string) <-> number no domínio. */
const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/**
 * Tarifas de uso de tokens por modelo.
 * Quando um model_id não tiver tarifa ativa, o cálculo usa `usage_pricing`.
 */
@Entity("model_usage_pricing")
export class ModelUsagePricing {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text", unique: true })
  model_id!: string;

  @Column({ type: "text", nullable: true })
  label!: string | null;

  @Column({ type: "numeric", transformer: numericToNumber })
  price_per_1k_input_tokens!: number;

  @Column({ type: "numeric", transformer: numericToNumber })
  price_per_1k_output_tokens!: number;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
