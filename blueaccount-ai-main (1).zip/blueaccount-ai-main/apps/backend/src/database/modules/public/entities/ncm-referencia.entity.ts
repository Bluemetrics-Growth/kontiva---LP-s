import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/** Cache compartilhado, lazy e sem TTL do cadastro público de NCM da BrasilAPI. */
@Index("UQ_ncms_referencia_codigo", ["codigo"], { unique: true })
// Resolução de fatores (`resolverFatoresPorNcm`) filtra por fatores_configurados antes do LIKE de
// prefixo; sem este índice parcial, o LIKE (construído a partir da coluna, não indexável) força
// varredura sequencial da tabela inteira — que cresce sem limite como cache da BrasilAPI.
@Index("IDX_ncms_referencia_fatores_configurados_codigo", ["codigo"], { where: `"fatores_configurados" = true` })
@Entity("ncms_referencia")
export class NcmReferencia {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /** Código NCM/SH sem pontuação. Folhas têm 8 dígitos; regras legais podem usar prefixos de 2 a 8. */
  @Column({ type: "varchar", length: 8 })
  codigo!: string;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_ibs!: number;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_cbs!: number;

  /** Distingue uma regra explícita do default de 100% aplicado a todo NCM apenas cacheado. */
  @Column({ type: "boolean", default: false })
  fatores_configurados!: boolean;

  /** Compatibilidade de leitura; toda regra com `fatores_configurados=true` é obrigada a ser automática. */
  @Column({ type: "boolean", default: true })
  aplicacao_automatica!: boolean;

  @Column({ type: "text", nullable: true })
  fundamento_legal_fatores!: string | null;

  @Column({ type: "text", nullable: true })
  condicoes_aplicacao_fatores!: string | null;

  @Column({ type: "varchar", length: 80, nullable: true })
  origem_configuracao_fatores!: string | null;

  @Column({ type: "text" })
  descricao!: string;

  /** Descrições dos nós-pai, da posição mais ampla para a mais específica. */
  @Column({ type: "text", array: true, nullable: true })
  descricoes_hierarquia!: string[] | null;

  @Column({ type: "date", nullable: true })
  data_inicio!: string | null;

  @Column({ type: "date", nullable: true })
  data_fim!: string | null;

  @Column({ type: "text", nullable: true })
  tipo_ato!: string | null;

  @Column({ type: "varchar", length: 20, nullable: true })
  numero_ato!: string | null;

  @Column({ type: "varchar", length: 4, nullable: true })
  ano_ato!: string | null;

  /** Snapshot fiel da resposta da BrasilAPI, preservado para futuros usos sem ampliar o contrato público. */
  @Column({ type: "jsonb" })
  resposta_brasilapi!: Record<string, unknown>;

  /** Snapshot dos nós devolvidos pela busca de árvore da BrasilAPI. */
  @Column({ type: "jsonb", nullable: true })
  resposta_arvore_brasilapi!: Record<string, unknown>[] | null;

  @UpdateDateColumn({ type: "timestamptz" })
  atualizado_em!: Date;
}
