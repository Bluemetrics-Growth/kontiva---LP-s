import { MigrationInterface, QueryRunner } from "typeorm";

export class AddDeletedAtToUsuarios1776706729000 implements MigrationInterface {
    name = 'AddDeletedAtToUsuarios1776706729000'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "usuarios" ADD "deleted_at" TIMESTAMP`);
        await queryRunner.query(`CREATE INDEX "IDX_usuarios_deleted_at" ON "usuarios" ("deleted_at")`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP INDEX "public"."IDX_usuarios_deleted_at"`);
        await queryRunner.query(`ALTER TABLE "usuarios" DROP COLUMN "deleted_at"`);
    }
}
