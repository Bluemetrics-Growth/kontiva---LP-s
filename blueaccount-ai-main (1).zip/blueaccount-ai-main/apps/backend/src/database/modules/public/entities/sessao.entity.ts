import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Usuario } from "./usuario.entity.js";
import { Escritorio } from "./escritorio.entity.js";

@Index("UQ_sessoes_session_id_hash", ["session_id_hash"], { unique: true })
@Index("IDX_sessoes_usuario_id", ["usuario_id"])
@Index("IDX_sessoes_escritorio_id", ["escritorio_id"])
@Index("IDX_sessoes_expires_at", ["expires_at"])
// Tabela UNLOGGED (migration 1784112210638-set_sessoes_unlogged): escrita não gera
// WAL. Trunca em parada suja (crash/reboot) → usuário reautentica. TypeORM não
// gerencia LOGGED/UNLOGGED, então o estado vive só na migration.
@Entity("sessoes")
export class Sessao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  session_id_hash!: string;

  // createForeignKeyConstraints: false — `sessoes` é UNLOGGED (migration
  // 1784112210638) e não pode ter FK para tabela LOGGED; mantém navegação ORM
  // sem gerar a constraint no migration:generate.
  @ManyToOne(() => Usuario, { nullable: false, createForeignKeyConstraints: false })
  @JoinColumn({ name: "usuario_id" })
  usuario!: Relation<Usuario>;

  @Column({ type: "uuid" })
  usuario_id!: string;

  @ManyToOne(() => Escritorio, { nullable: false, createForeignKeyConstraints: false })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio>;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "timestamp" })
  expires_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  revoked_at!: Date | null;

  @Column({ type: "timestamp", nullable: true })
  last_seen_at!: Date | null;

  // Step-up auth: instante da última confirmação de senha dentro desta sessão.
  // As ações críticas (ver AuthGuard) exigem confirmação recente; `null` significa
  // que só o login inicial vale, e aí o marco é `created_at`.
  @Column({ type: "timestamp", nullable: true })
  reautenticado_em!: Date | null;

  @Column({ type: "text", nullable: true })
  user_agent!: string | null;

  @Column({ type: "text", nullable: true })
  ip_address!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
