import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateNcmsReferencia1786100000000 implements MigrationInterface {
  name = "CreateNcmsReferencia1786100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE "ncms_referencia" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(),
      "codigo" varchar(8) NOT NULL,
      "descricao" text NOT NULL,
      "data_inicio" date,
      "data_fim" date,
      "tipo_ato" text,
      "numero_ato" varchar(20),
      "ano_ato" varchar(4),
      "resposta_brasilapi" jsonb NOT NULL,
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_ncms_referencia" PRIMARY KEY ("id")
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_ncms_referencia_codigo" ON "ncms_referencia" ("codigo")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "ncms_referencia"`);
  }
}
