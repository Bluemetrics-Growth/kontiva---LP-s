import type { MigrationInterface, QueryRunner } from "typeorm";

export class EnriquecerNcmsReferenciaComArvore1786101000000 implements MigrationInterface {
  name = "EnriquecerNcmsReferenciaComArvore1786101000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ncms_referencia"
      ADD "descricoes_hierarquia" text[],
      ADD "resposta_arvore_brasilapi" jsonb`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "ncms_referencia"
      DROP COLUMN "resposta_arvore_brasilapi",
      DROP COLUMN "descricoes_hierarquia"`);
  }
}
