import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateCnaesReferencia1785000000000 implements MigrationInterface {
  name = "CreateCnaesReferencia1785000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // Cache lazy do cadastro público de CNAE (classificação oficial do IBGE). Público de propósito:
    // é dado público e compartilhar deduplica consulta entre escritórios, como em cadastros_cnpj e
    // indices_inflacao. Sem TTL: classificação de CNAE é dado governamental quase estático.
    await queryRunner.query(`CREATE TABLE IF NOT EXISTS "cnaes_referencia" (
      "id" uuid NOT NULL DEFAULT gen_random_uuid(),
      "codigo" varchar(7) NOT NULL,
      "descricao" text NOT NULL,
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_cnaes_referencia" PRIMARY KEY ("id")
    )`);

    await queryRunner.query(`CREATE UNIQUE INDEX IF NOT EXISTS "UQ_cnaes_referencia_codigo" ON "cnaes_referencia" ("codigo")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "cnaes_referencia"`);
  }
}
