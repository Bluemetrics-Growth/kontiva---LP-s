import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona o modo de input enviado ao agente de extração de contrato
 * (`contract_agent_input_mode`) em `escritorios`. Espelha
 * `1783200000000-add_report_agent_input_mode_to_escritorios`: default `'ocr'`
 * preserva o comportamento atual (Textract + markdown anotado) para todas as
 * linhas existentes; `'pdf'` é opt-in do admin para enviar o PDF/imagem
 * diretamente ao ContractAgent, pulando o OCR.
 */
export class AddContractAgentInputModeToEscritorios1783300000000 implements MigrationInterface {
  name = "AddContractAgentInputModeToEscritorios1783300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "contract_agent_input_mode" text NOT NULL DEFAULT 'ocr'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "contract_agent_input_mode"`,
    );
  }
}
