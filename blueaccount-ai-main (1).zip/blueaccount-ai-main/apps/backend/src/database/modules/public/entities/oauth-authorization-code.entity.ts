import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
} from "typeorm";

@Index("UQ_oauth_authorization_codes_code_hash", ["code_hash"], { unique: true })
@Index("IDX_oauth_authorization_codes_client_id", ["client_id"])
@Index("IDX_oauth_authorization_codes_expires_at", ["expires_at"])
@Entity("oauth_authorization_codes")
export class OAuthAuthorizationCode {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  code_hash!: string;

  @Column({ type: "text" })
  client_id!: string;

  @Column({ type: "uuid" })
  usuario_id!: string;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  session_id_hash!: string;

  @Column({ type: "text" })
  redirect_uri!: string;

  @Column({ type: "text" })
  code_challenge!: string;

  @Column({ type: "text", default: "S256" })
  code_challenge_method!: string;

  @Column({ type: "text", nullable: true })
  scope!: string | null;

  @Column({ type: "text", nullable: true })
  resource!: string | null;

  @Column({ type: "timestamp" })
  expires_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  consumed_at!: Date | null;

  @CreateDateColumn()
  created_at!: Date;
}
