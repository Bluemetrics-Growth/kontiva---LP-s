import { Check, Column, Entity, Index, PrimaryColumn } from "typeorm";

export type ModuloIngestaoConcorrencia = "contratos" | "relatorios_periodicos";
export type StatusTerminalIngestao = "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "ABORTED";

@Entity("ingestao_permissoes_processamento")
@Index("IDX_ingestao_permissoes_ativas_modulo", ["modulo"], {
  where: `"liberada_em" IS NULL`,
})
@Check("CHK_ingestao_permissoes_modulo", `"modulo" IN ('contratos', 'relatorios_periodicos')`)
@Check(
  "CHK_ingestao_permissoes_status_terminal",
  `"status_terminal" IS NULL OR "status_terminal" IN ('SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED')`,
)
@Check(
  "CHK_ingestao_permissoes_liberacao",
  `("liberada_em" IS NULL AND "status_terminal" IS NULL) OR ("liberada_em" IS NOT NULL AND "status_terminal" IS NOT NULL)`,
)
export class IngestaoPermissaoProcessamento {
  @PrimaryColumn({ type: "text" })
  execution_arn!: string;

  @Column({ type: "varchar", length: 128 })
  documento_id!: string;

  @Column({ type: "varchar", length: 32 })
  modulo!: ModuloIngestaoConcorrencia;

  @Column({ type: "timestamptz", default: () => "CURRENT_TIMESTAMP" })
  adquirida_em!: Date;

  @Column({ type: "timestamptz", nullable: true })
  liberada_em!: Date | null;

  @Column({ type: "varchar", length: 16, nullable: true })
  status_terminal!: StatusTerminalIngestao | null;
}
