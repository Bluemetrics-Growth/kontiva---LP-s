import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Adiciona o modo de input enviado ao agente de extração de relatório
 * (`report_agent_input_mode`) em `escritorios`. Espelha o estilo de
 * `1783100000000-add_report_extraction_to_escritorios`: default `'ocr'`
 * preserva o comportamento atual (Textract + markdown anotado) para todas as
 * linhas existentes; `'pdf'` é opt-in do admin para enviar o PDF/imagem
 * diretamente ao RelatorioExtracaoAgent, pulando o OCR.
 */
export class AddReportAgentInputModeToEscritorios1783200000000 implements MigrationInterface {
  name = "AddReportAgentInputModeToEscritorios1783200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_agent_input_mode" text NOT NULL DEFAULT 'ocr'`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_agent_input_mode"`,
    );
  }
}
