import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Altera somente os defaults usados na criacao de novos escritorios. Linhas
 * existentes mantem sua configuracao explicita, inclusive os caminhos
 * legados Converse/OCR.
 */
export class SetAgentcorePdfDefaultsForNewEscritorios1784500000000 implements MigrationInterface {
  name = "SetAgentcorePdfDefaultsForNewEscritorios1784500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "contract_extraction_engine" SET DEFAULT 'agent'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "contract_agent_input_mode" SET DEFAULT 'pdf'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "report_extraction_engine" SET DEFAULT 'agent'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "report_agent_input_mode" SET DEFAULT 'pdf'`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "contract_extraction_engine" SET DEFAULT 'converse'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "contract_agent_input_mode" SET DEFAULT 'ocr'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "report_extraction_engine" SET DEFAULT 'converse'`);
    await queryRunner.query(`ALTER TABLE "escritorios" ALTER COLUMN "report_agent_input_mode" SET DEFAULT 'ocr'`);
  }
}
