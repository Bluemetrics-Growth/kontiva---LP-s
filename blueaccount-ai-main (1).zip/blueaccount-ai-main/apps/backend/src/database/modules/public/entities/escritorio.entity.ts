import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  type Relation,
} from "typeorm";
import { Usuario } from "./usuario.entity.js";

@Entity("escritorios")
export class Escritorio {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  nome!: string;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  /**
   * Marca o escritório como ambiente de teste de cobrança. Quando true, toda
   * geração de cobrança força a avaliação (eval_enabled) com um eval_reason
   * padronizado e marcador de dataset, sem depender de seleção manual.
   */
  @Column({ type: "boolean", default: false })
  ambiente_teste_cobranca!: boolean;

  /**
   * Nivel de complexidade de extracao de contrato (catalogo
   * contract_extraction_complexities → inference_profile_id).
   */
  @Column({ type: "int", default: 1 })
  contract_extraction_complexity!: number;

  /**
   * Modo de input enviado ao agente de extracao de contrato. `pdf` (default
   * para novos escritórios) pula OCR e envia os bytes do PDF/imagem diretamente
   * ao ContractAgent (AgentCore); `ocr` preserva o Textract + markdown anotado.
   * O backend so ativa o modo `pdf` no payload quando o mime type e o tamanho do arquivo
   * tambem sao compativeis (ver `DocumentosService.podeEnviarPdfDiretoAoAgente`).
   * Espelha `report_agent_input_mode`. Sem markdown anotado a rastreabilidade
   * por bloco de OCR (`id`) nao existe — o agente usa `fonte` (trecho verbatim).
   */
  @Column({ type: "text", default: "pdf" })
  contract_agent_input_mode!: "ocr" | "pdf";

  /**
   * Nivel de complexidade de extracao de relatorio (reaproveita o catalogo
   * contract_extraction_complexities → inference_profile_id, compartilhado entre
   * contratos e relatorios).
   */
  @Column({ type: "int", default: 1 })
  report_extraction_complexity!: number;

  /**
   * Modo de input enviado ao agente de extracao de relatorio. `pdf` (default
   * para novos escritórios) pula OCR e envia os bytes do PDF/imagem diretamente
   * ao RelatorioExtracaoAgent (AgentCore); `ocr` preserva o Textract + markdown
   * anotado. O backend so ativa o modo `pdf` no payload de enfileiramento quando o mime type
   * e o tamanho do arquivo tambem sao compativeis (ver
   * `DocumentosService.podeEnviarPdfDiretoAoAgente`).
   */
  @Column({ type: "text", default: "pdf" })
  report_agent_input_mode!: "ocr" | "pdf";

  /**
   * Orientacao opcional, definida pelo admin da plataforma, anexada somente as
   * execucoes do RelatorioExtracaoAgent.
   */
  @Column({ type: "text", nullable: true })
  report_agent_instructions!: string | null;

  /**
   * Marca o escritorio como conta trial. Quando true, aplicam-se os limites
   * configuraveis abaixo (documentos, execucoes de cobranca, paginas por
   * documento) e o reprocessamento de OCR fica bloqueado.
   */
  @Column({ type: "boolean", default: false })
  is_trial!: boolean;

  /** Trial: maximo de documentos enviados (lifetime). */
  @Column({ type: "int", default: 20 })
  trial_max_documentos!: number;

  /** Trial: maximo de execucoes do agente de cobranca (lifetime). */
  @Column({ type: "int", default: 20 })
  trial_max_cobranca_execucoes!: number;

  /** Trial: maximo de paginas por documento. */
  @Column({ type: "int", default: 10 })
  trial_max_paginas_por_documento!: number;

  /** Trial: contador de execucoes de cobranca ja consumidas. */
  @Column({ type: "int", default: 0 })
  trial_cobranca_execucoes_usadas!: number;

  /**
   * Provedor de IA externo que o escritório usa. Define para qual assistente o
   * atalho "Perguntar ao ChatGPT/Claude" da aplicação aponta. Definido pelo
   * próprio escritório (admin do escritório) em /configuracoes. Espelha o estilo
   * dos campos texto-enum com default.
   */
  @Column({ type: "text", default: "chatgpt" })
  provedor_ia!: "chatgpt" | "claude";

  /**
   * Idioma preferido do escritório (`'pt' | 'en'`). Base da internacionalização
   * da plataforma. Default `'pt'` preserva o comportamento atual. Primeiro uso:
   * define o idioma da `explicacao` gerada pelo CobrancaAgent. Espelha o estilo
   * dos campos texto-enum com default (ex.: `provedor_ia`).
   */
  @Column({ type: "text", default: "pt" })
  locale!: "pt" | "en";

  /**
   * ID da pasta raiz compartilhada no Google Drive do cliente (compartilhada
   * com a service account do conector). `null` = conector não configurado.
   */
  @Column({ type: "text", nullable: true })
  conector_drive_folder_id!: string | null;

  /** Habilita o conector de Google Drive (disparo admin-only) para o escritório. */
  @Column({ type: "boolean", default: false })
  conector_drive_ativo!: boolean;

  @ManyToOne(() => Usuario, { nullable: true })
  @JoinColumn({ name: "ai_user_id" })
  ai_user!: Relation<Usuario> | null;

  /**
   * Usuario tecnico usado por agentes internos para criar sessoes curtas com
   * escopo do escritorio, sem personificar um usuario humano.
   */
  @Column({ type: "uuid", nullable: true })
  ai_user_id!: string | null;

  @OneToMany(() => Usuario, (usuario) => usuario.escritorio)
  usuarios!: Relation<Usuario[]>;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
