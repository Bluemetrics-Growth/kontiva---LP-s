import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Padroniza o formato do CNPJ no cache para o **mascarado**, igual a `clientes.cnpj` e
 * `fornecedores.cnpj`.
 *
 * Motivo: esta era a única coluna de CNPJ do banco guardada só com dígitos, e a divergência não
 * dava erro — dava resultado vazio. Um `JOIN` entre `cadastros_cnpj` e `fornecedores` comparando as
 * colunas cruas casa **zero linhas** e falha em silêncio, que é o pior modo de falha possível para
 * um backfill. Com as três tabelas no mesmo formato, a igualdade direta volta a funcionar.
 *
 * O contra-argumento ("é cache de uma API que fala dígitos") não se sustenta: a URL da BrasilAPI já
 * é montada a partir de `somenteDigitos(...)` de qualquer forma, então isto não acrescenta
 * conversão, só muda em qual ponta ela acontece.
 */
export class MascararCnpjEmCadastrosCnpj1784800000001 implements MigrationInterface {
  name = "MascararCnpjEmCadastrosCnpj1784800000001";

  public async up(queryRunner: QueryRunner): Promise<void> {
    // 18 = 14 dígitos + 4 separadores (`00.000.000/0000-00`).
    await queryRunner.query(`ALTER TABLE "cadastros_cnpj" ALTER COLUMN "cnpj" TYPE varchar(18)`);

    // Só converte o que ainda está em dígitos puros: a migration precisa ser idempotente, porque um
    // ambiente já migrado tem linhas mascaradas que este UPDATE não pode tocar.
    await queryRunner.query(`
      UPDATE "cadastros_cnpj"
      SET "cnpj" =
        substr("cnpj", 1, 2) || '.' ||
        substr("cnpj", 3, 3) || '.' ||
        substr("cnpj", 6, 3) || '/' ||
        substr("cnpj", 9, 4) || '-' ||
        substr("cnpj", 13, 2)
      WHERE "cnpj" ~ '^[0-9]{14}$'
    `);

    await queryRunner.query(`
      COMMENT ON COLUMN "cadastros_cnpj"."cnpj" IS
        'CNPJ MASCARADO (00.000.000/0000-00), mesmo formato de clientes.cnpj e fornecedores.cnpj. Chave de consulta do cache.'
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE "cadastros_cnpj"
      SET "cnpj" = regexp_replace("cnpj", '\\D', '', 'g')
      WHERE "cnpj" !~ '^[0-9]{14}$'
    `);
    await queryRunner.query(`ALTER TABLE "cadastros_cnpj" ALTER COLUMN "cnpj" TYPE varchar(14)`);
  }
}
