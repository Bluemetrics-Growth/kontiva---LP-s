import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";

@Index("UQ_usuarios_email", ["email"], { unique: true })
@Index("UQ_usuarios_cognito_sub", ["cognito_sub"], { unique: true })
@Index("IDX_usuarios_escritorio_id", ["escritorio_id"])
@Entity("usuarios")
export class Usuario {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Escritorio, (escritorio) => escritorio.usuarios, { nullable: false })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio>;

  @Column({ type: "uuid" })
  escritorio_id!: string;

  @Column({ type: "text" })
  nome!: string;

  @Column({ type: "text" })
  email!: string;

  @Column({ type: "text", nullable: true })
  cognito_sub!: string | null;

  @Column({ type: "boolean", default: false })
  admin_escritorio!: boolean;

  @Column({ type: "text", default: "operador" })
  papel!: "administrador" | "operador" | "consulta";

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  deleted_at!: Date | null;
}
