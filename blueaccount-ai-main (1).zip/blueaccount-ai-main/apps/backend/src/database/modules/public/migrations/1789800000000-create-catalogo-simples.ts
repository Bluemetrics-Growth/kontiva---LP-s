import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";
import { FUNDAMENTO_SIMPLES, SIMPLES_ANEXOS_SEED } from "./dados/simples-anexos.js";

export class CreateCatalogoSimples1789800000000 implements MigrationInterface {
  name = "CreateCatalogoSimples1789800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "simples_cnaes" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "codigo" varchar(7) NOT NULL,
        "descricao" text NOT NULL,
        "anexo" varchar(3),
        "fator_r" boolean NOT NULL DEFAULT false,
        "fonte" varchar(100) NOT NULL,
        CONSTRAINT "PK_simples_cnaes" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_simples_cnaes_codigo" UNIQUE ("codigo"),
        CONSTRAINT "CK_simples_cnaes_codigo" CHECK ("codigo" ~ '^[0-9]{7}$'),
        CONSTRAINT "CK_simples_cnaes_anexo" CHECK ("anexo" IS NULL OR "anexo" IN ('I','II','III','IV','V')),
        CONSTRAINT "CK_simples_cnaes_fator_r" CHECK (("fator_r" AND "anexo" IS NULL) OR (NOT "fator_r" AND "anexo" IS NOT NULL))
      )
    `);
    await queryRunner.query(`
      CREATE TABLE "simples_anexos" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "anexo" varchar(3) NOT NULL,
        "faixa" smallint NOT NULL,
        "vigencia_inicio" int NOT NULL,
        "vigencia_fim" int,
        "rbt12_minimo" numeric(14,2) NOT NULL,
        "rbt12_maximo" numeric(14,2) NOT NULL,
        "aliquota_nominal" numeric(8,6) NOT NULL,
        "parcela_deduzir" numeric(14,2) NOT NULL,
        "fundamento_legal" text NOT NULL,
        CONSTRAINT "PK_simples_anexos" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_simples_anexos_vigencia_faixa" UNIQUE ("anexo", "faixa", "vigencia_inicio"),
        CONSTRAINT "CK_simples_anexos_anexo" CHECK ("anexo" IN ('I','II','III','IV','V')),
        CONSTRAINT "CK_simples_anexos_faixa" CHECK ("faixa" BETWEEN 1 AND 6),
        CONSTRAINT "CK_simples_anexos_vigencia" CHECK ("vigencia_fim" IS NULL OR "vigencia_fim" >= "vigencia_inicio"),
        CONSTRAINT "CK_simples_anexos_rbt12" CHECK ("rbt12_minimo" >= 0 AND "rbt12_maximo" > "rbt12_minimo"),
        CONSTRAINT "CK_simples_anexos_aliquota" CHECK ("aliquota_nominal" >= 0 AND "aliquota_nominal" <= 1),
        CONSTRAINT "CK_simples_anexos_deducao" CHECK ("parcela_deduzir" >= 0)
      )
    `);
    await queryRunner.query(`
      CREATE TABLE "simples_anexo_reparticoes" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
        "simples_anexo_id" uuid NOT NULL,
        "componente" varchar(3) NOT NULL,
        "percentual" numeric(8,6) NOT NULL,
        CONSTRAINT "PK_simples_anexo_reparticoes" PRIMARY KEY ("id"),
        CONSTRAINT "UQ_simples_anexo_reparticoes_componente" UNIQUE ("simples_anexo_id", "componente"),
        CONSTRAINT "CK_simples_anexo_reparticoes_componente" CHECK ("componente" IN ('IBS','CBS')),
        CONSTRAINT "CK_simples_anexo_reparticoes_percentual" CHECK ("percentual" >= 0 AND "percentual" <= 1),
        CONSTRAINT "FK_simples_anexo_reparticoes_faixa" FOREIGN KEY ("simples_anexo_id") REFERENCES "simples_anexos"("id") ON DELETE CASCADE
      )
    `);

    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       -- Só os enquadrados. A tabela nasce sem a coluna situacao, e o CHECK criado acima exige anexo
       -- em toda linha sem Fator R; vedado e não-optante entram em 1789800000004, que relaxa o CHECK.
       -- O filtro tem de existir aqui porque o seed é uma constante compartilhada e mutável: sem ele,
       -- crescer o arquivo quebra a criação do zero em banco novo, mesmo sem ninguém tocar nesta migration.
       WHERE item.situacao = 'enquadrado'`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
    await queryRunner.query(
      `WITH faixas AS (
         INSERT INTO "simples_anexos" (
           "anexo", "faixa", "vigencia_inicio", "vigencia_fim", "rbt12_minimo", "rbt12_maximo",
           "aliquota_nominal", "parcela_deduzir", "fundamento_legal"
         )
         SELECT item.anexo, item.faixa, item.vigencia_inicio, item.vigencia_fim,
                item.rbt12_minimo, item.rbt12_maximo, item.aliquota_nominal,
                item.parcela_deduzir, $2
         FROM jsonb_to_recordset($1::jsonb) AS item(
           anexo varchar, faixa smallint, vigencia_inicio int, vigencia_fim int,
           rbt12_minimo numeric, rbt12_maximo numeric, aliquota_nominal numeric,
           parcela_deduzir numeric, percentual_cbs numeric, percentual_ibs numeric
         )
         RETURNING id, anexo, faixa, vigencia_inicio
       ), dados AS (
         SELECT * FROM jsonb_to_recordset($1::jsonb) AS item(
           anexo varchar, faixa smallint, vigencia_inicio int, vigencia_fim int,
           rbt12_minimo numeric, rbt12_maximo numeric, aliquota_nominal numeric,
           parcela_deduzir numeric, percentual_cbs numeric, percentual_ibs numeric
         )
       )
       INSERT INTO "simples_anexo_reparticoes" ("simples_anexo_id", "componente", "percentual")
       SELECT faixas.id, componente.nome, componente.percentual
       FROM faixas
       JOIN dados USING (anexo, faixa, vigencia_inicio)
       CROSS JOIN LATERAL (VALUES ('CBS', dados.percentual_cbs), ('IBS', dados.percentual_ibs)) componente(nome, percentual)`,
      [JSON.stringify(SIMPLES_ANEXOS_SEED), FUNDAMENTO_SIMPLES],
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "simples_anexo_reparticoes"`);
    await queryRunner.query(`DROP TABLE "simples_anexos"`);
    await queryRunner.query(`DROP TABLE "simples_cnaes"`);
  }
}
