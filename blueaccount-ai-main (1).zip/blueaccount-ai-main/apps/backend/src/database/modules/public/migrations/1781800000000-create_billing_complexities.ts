import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateBillingComplexities1781800000000 implements MigrationInterface {
  name = "CreateBillingComplexities1781800000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "billing_complexities" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"nivel" integer NOT NULL, ` +
        `"nome" text NOT NULL, ` +
        `"descricao" text, ` +
        `"inference_profile_id" text, ` +
        `"preco_mensal_por_contrato" numeric NOT NULL DEFAULT 0, ` +
        `"ativo" boolean NOT NULL DEFAULT true, ` +
        `"created_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `"updated_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_billing_complexities" PRIMARY KEY ("id"), ` +
        `CONSTRAINT "UQ_billing_complexities_nivel" UNIQUE ("nivel"))`,
    );

    await queryRunner.query(`
      INSERT INTO "billing_complexities" ("nivel", "nome", "descricao", "inference_profile_id", "preco_mensal_por_contrato", "ativo")
      VALUES
        (1, 'Standard billing', 'Modelo padrao para contratos com regras simples de cobranca.', NULL, 0, true),
        (2, 'Level 2 billing complexity', 'Modelo para contratos com estruturas mais complexas de cobranca.', NULL, 0, true)
      ON CONFLICT ("nivel") DO NOTHING
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE IF EXISTS "billing_complexities"`);
  }
}
