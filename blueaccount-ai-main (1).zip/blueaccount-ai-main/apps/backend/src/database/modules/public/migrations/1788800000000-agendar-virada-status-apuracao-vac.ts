import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Conclui a apuração mensal diretamente no banco. Os schemas de tenant são
 * dinâmicos, por isso a função percorre os escritórios ativos com identificador
 * seguro e não depende de a API estar online na virada.
 */
export class AgendarViradaStatusApuracaoVac1788800000000 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE OR REPLACE FUNCTION public.atualizar_status_vacs_apos_apuracao()
      RETURNS void
      LANGUAGE plpgsql
      SECURITY DEFINER
      SET search_path = pg_catalog, public
      AS $$
      DECLARE
        escritorio record;
        schema_tenant text;
      BEGIN
        FOR escritorio IN SELECT id FROM public.escritorios WHERE ativo = true LOOP
          schema_tenant := 'escritorio_' || replace(lower(escritorio.id::text), '-', '_');
          BEGIN
            EXECUTE format($sql$
              UPDATE %I.valores_a_cobrar
              SET status = CASE
                    WHEN valores_calculados IS NOT NULL AND valores_calculados <> '{}'::jsonb
                      THEN COALESCE(status_apos_apuracao, 'revisado')
                    ELSE 'aberto'
                  END,
                  status_apos_apuracao = NULL,
                  updated_at = now()
              WHERE status = 'em_apuracao'
                AND competencia ~ '^(0[1-9]|1[0-2])/[0-9]{4}$'
                AND to_date(competencia, 'MM/YYYY') < date_trunc('month', now() AT TIME ZONE 'America/Sao_Paulo')::date
            $sql$, schema_tenant);
          EXCEPTION
            WHEN undefined_table OR undefined_column THEN
              RAISE WARNING 'VAC apuração ignorado no schema %: migration de tenant pendente', schema_tenant;
          END;
        END LOOP;
      END;
      $$;
    `);

    await queryRunner.query(`
      DO $$
      BEGIN
        IF current_setting('shared_preload_libraries', true) LIKE '%pg_cron%' THEN
          CREATE EXTENSION IF NOT EXISTS pg_cron;
          PERFORM cron.schedule(
            'virada-status-vacs-apos-apuracao',
            '5 3 * * *',
            $q$SELECT public.atualizar_status_vacs_apos_apuracao()$q$
          );
        ELSE
          RAISE NOTICE 'pg_cron não carregado; virada de status dos VACs não agendada.';
        END IF;
      EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'pg_cron indisponível para a virada de status dos VACs (%).', SQLERRM;
      END $$;
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      DO $$
      BEGIN
        IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_cron') THEN
          PERFORM cron.unschedule(jobid)
          FROM cron.job
          WHERE jobname = 'virada-status-vacs-apos-apuracao';
        END IF;
      END $$;
    `);
    await queryRunner.query(`DROP FUNCTION IF EXISTS public.atualizar_status_vacs_apos_apuracao();`);
  }
}
