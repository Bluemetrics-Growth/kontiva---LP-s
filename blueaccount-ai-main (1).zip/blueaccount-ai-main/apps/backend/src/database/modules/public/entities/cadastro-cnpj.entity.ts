import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import type { CnaeSecundario } from "../../tenant/entities/fornecedor.entity.js";

/**
 * Cache do cadastro público de CNPJ (dados abertos da Receita Federal, hoje via BrasilAPI).
 *
 * Vive no schema público e é compartilhado por todos os escritórios de propósito: é dado público, e
 * compartilhar deduplica consulta entre tenants. Mesmo racional de `indices_inflacao`.
 *
 * ATENÇÃO: `payload` guarda a resposta **higienizada**. `qsa` (nomes e documentos de sócios), `email`
 * e telefones são removidos antes de gravar — é PII de terceiro sem necessidade funcional aqui.
 * Ver `higienizarPayloadCnpj` em `domain/fornecedores/consulta-cnpj.service.ts`.
 */
@Index("UQ_cadastros_cnpj_cnpj", ["cnpj"], { unique: true })
@Entity("cadastros_cnpj")
export class CadastroCnpj {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /**
   * CNPJ **mascarado** (`00.000.000/0000-00`) — é a chave de consulta do cache.
   *
   * Mesmo formato de `clientes.cnpj` e `fornecedores.cnpj`, de propósito: enquanto esta coluna
   * guardava só dígitos, qualquer `JOIN` com aquelas tabelas comparando as colunas cruas casava zero
   * linhas e falhava em silêncio. Normalize com `normalizarCnpj` antes de consultar.
   */
  @Column({ type: "varchar", length: 18 })
  cnpj!: string;

  @Column({ type: "text", nullable: true })
  razao_social!: string | null;

  @Column({ type: "text", nullable: true })
  nome_fantasia!: string | null;

  @Column({ type: "varchar", length: 2, nullable: true })
  uf!: string | null;

  @Column({ type: "text", nullable: true })
  municipio!: string | null;

  /**
   * Código IBGE do município, 7 dígitos. NÃO confundir com `codigo_municipio` do payload, que é o
   * código TOM/SIAFI da Receita (4 dígitos) e nunca deve ser usado como chave de município.
   */
  @Column({ type: "varchar", length: 7, nullable: true })
  codigo_municipio_ibge!: string | null;

  @Column({ type: "varchar", length: 7, nullable: true })
  cnae_principal!: string | null;

  @Column({ type: "text", nullable: true })
  cnae_principal_descricao!: string | null;

  @Column({ type: "jsonb", nullable: true })
  cnaes_secundarios!: CnaeSecundario[] | null;

  @Column({ type: "text", nullable: true })
  porte!: string | null;

  @Column({ type: "text", nullable: true })
  natureza_juridica!: string | null;

  @Column({ type: "text", nullable: true })
  situacao_cadastral!: string | null;

  @Column({ type: "text", nullable: true })
  descricao_situacao_cadastral!: string | null;

  /** Null = a fonte não informou (BrasilAPI devolve null, não false, para não optante). */
  @Column({ type: "boolean", nullable: true })
  optante_simples!: boolean | null;

  @Column({ type: "boolean", nullable: true })
  optante_mei!: boolean | null;

  @Column({ type: "text", default: "BrasilAPI" })
  fonte!: string;

  /** Resposta higienizada da fonte, para auditoria e para campos que ainda não viraram coluna. */
  @Column({ type: "jsonb", nullable: true })
  payload!: Record<string, unknown> | null;

  @UpdateDateColumn({ type: "timestamptz" })
  consultado_em!: Date;
}
