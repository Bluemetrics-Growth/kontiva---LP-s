import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

@Index("UQ_oauth_clients_client_id", ["client_id"], { unique: true })
@Entity("oauth_clients")
export class OAuthClient {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  client_id!: string;

  @Column({ type: "text", nullable: true })
  client_secret_hash!: string | null;

  @Column({ type: "text", nullable: true })
  client_name!: string | null;

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  @Column({ type: "uuid", nullable: true })
  escritorio_id!: string | null;

  @Column({ type: "jsonb" })
  redirect_uris!: string[];

  @Column({ type: "text", default: "none" })
  token_endpoint_auth_method!: string;

  @Column({ type: "text", nullable: true })
  scope!: string | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
