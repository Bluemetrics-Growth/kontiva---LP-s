import type { MigrationInterface, QueryRunner } from "typeorm";

export class EnablePgTrgm1782310000000 implements MigrationInterface {
  name = "EnablePgTrgm1782310000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE EXTENSION IF NOT EXISTS pg_trgm`);
  }

  public async down(): Promise<void> {
    // Shared database capability: do not remove it while tenant indexes may depend on it.
  }
}
