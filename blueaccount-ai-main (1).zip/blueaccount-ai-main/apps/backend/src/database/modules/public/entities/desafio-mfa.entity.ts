import { Check, Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

export type FinalidadeDesafioMfa = "cadastro" | "verificacao";
export type OrigemDesafioMfa = "senha" | "google" | "admin";

@Index("UQ_desafios_mfa_token_hash", ["token_hash"], { unique: true })
@Index("IDX_desafios_mfa_expires_at", ["expires_at"])
@Index("UQ_desafios_mfa_usuario_ativo", ["usuario_id"], { unique: true, where: `"usuario_id" IS NOT NULL AND "consumido_em" IS NULL` })
@Index("UQ_desafios_mfa_admin_ativo", ["admin_username"], { unique: true, where: `"admin_username" IS NOT NULL AND "consumido_em" IS NULL` })
@Check(
  "CK_desafios_mfa_identidade",
  `("usuario_id" IS NOT NULL AND "admin_username" IS NULL) OR ("usuario_id" IS NULL AND "admin_username" = 'admin')`,
)
@Check("CK_desafios_mfa_finalidade", `"finalidade" IN ('cadastro', 'verificacao')`)
@Check("CK_desafios_mfa_origem", `"origem" IN ('senha', 'google', 'admin')`)
@Check(
  "CK_desafios_mfa_segredo_pendente",
  `("finalidade" = 'cadastro' AND "segredo_pendente_encrypted" IS NOT NULL AND "segredo_pendente_iv" IS NOT NULL AND "segredo_pendente_tag" IS NOT NULL) OR ("finalidade" = 'verificacao' AND "segredo_pendente_encrypted" IS NULL AND "segredo_pendente_iv" IS NULL AND "segredo_pendente_tag" IS NULL)`,
)
@Entity({ name: "desafios_mfa", schema: "public" })
export class DesafioMfa {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  token_hash!: string;

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  @Column({ type: "text", nullable: true })
  admin_username!: "admin" | null;

  @Column({ type: "text" })
  finalidade!: FinalidadeDesafioMfa;

  @Column({ type: "text" })
  origem!: OrigemDesafioMfa;

  @Column({ type: "text", nullable: true })
  segredo_pendente_encrypted!: string | null;

  @Column({ type: "text", nullable: true })
  segredo_pendente_iv!: string | null;

  @Column({ type: "text", nullable: true })
  segredo_pendente_tag!: string | null;

  @Column({ type: "text", nullable: true })
  return_to!: string | null;

  @Column({ type: "integer", default: 0 })
  tentativas!: number;

  @Column({ type: "timestamp" })
  expires_at!: Date;

  @Column({ type: "timestamp", nullable: true })
  consumido_em!: Date | null;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
