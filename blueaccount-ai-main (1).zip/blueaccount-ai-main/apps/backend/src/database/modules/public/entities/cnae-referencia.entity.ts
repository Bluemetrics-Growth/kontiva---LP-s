import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/**
 * Cache lazy do cadastro público de CNAE (classificação oficial do IBGE, subclasses, hoje via
 * `servicodados.ibge.gov.br`).
 *
 * Vive no schema público e é compartilhado por todos os escritórios de propósito: é dado público, e
 * compartilhar deduplica consulta entre tenants. Mesmo racional de `cadastros_cnpj` e
 * `indices_inflacao`.
 *
 * Diferente de `cadastros_cnpj`, esta tabela NÃO tem TTL/expiração: a classificação de CNAE é dado
 * governamental quase estático (o IBGE revisa a estrutura raramente, em ciclos de anos), então uma
 * vez resolvido um código ele é considerado válido indefinidamente. Se o IBGE algum dia revisar a
 * classificação, um job de refresh manual poderia revisitar esta tabela — não é necessário construir
 * isso agora.
 */
@Index("UQ_cnaes_referencia_codigo", ["codigo"], { unique: true })
@Entity("cnaes_referencia")
export class CnaeReferencia {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /** Código CNAE (subclasse), 7 dígitos — chave de consulta do cache. */
  @Column({ type: "varchar", length: 7 })
  codigo!: string;

  @Column({ type: "text" })
  descricao!: string;

  @Column({ type: "varchar", length: 5, nullable: true })
  classe_codigo!: string | null;

  @Column({ type: "text", nullable: true })
  classe_descricao!: string | null;

  @Column({ type: "varchar", length: 3, nullable: true })
  grupo_codigo!: string | null;

  @Column({ type: "text", nullable: true })
  grupo_descricao!: string | null;

  @Column({ type: "varchar", length: 2, nullable: true })
  divisao_codigo!: string | null;

  @Column({ type: "text", nullable: true })
  divisao_descricao!: string | null;

  @Column({ type: "varchar", length: 1, nullable: true })
  secao_codigo!: string | null;

  @Column({ type: "text", nullable: true })
  secao_descricao!: string | null;

  /** Termos de atividade da subclasse, úteis para classificação futura. */
  @Column({ type: "text", array: true, default: () => "'{}'" })
  atividades!: string[];

  /** Notas de inclusão/exclusão da subclasse. */
  @Column({ type: "text", array: true, default: () => "'{}'" })
  observacoes!: string[];

  /** Notas de inclusão/exclusão da classe pai. */
  @Column({ type: "text", array: true, default: () => "'{}'" })
  observacoes_classe!: string[];

  /** Snapshot fiel do objeto devolvido pelo IBGE para suportar campos futuros sem perda. */
  @Column({ type: "jsonb", nullable: true })
  resposta_ibge!: Record<string, unknown> | null;

  @UpdateDateColumn({ type: "timestamptz" })
  atualizado_em!: Date;
}
