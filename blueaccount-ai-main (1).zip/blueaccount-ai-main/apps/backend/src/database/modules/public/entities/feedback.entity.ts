import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  type Relation,
} from "typeorm";
import { Escritorio } from "./escritorio.entity.js";
import { Usuario } from "./usuario.entity.js";

export type FeedbackStatus = "aberto" | "resolvido";

@Index("IDX_feedback_escritorio_id", ["escritorio_id"])
@Index("IDX_feedback_usuario_id", ["usuario_id"])
@Index("IDX_feedback_status", ["status"])
@Index("IDX_feedback_created_at", ["created_at"])
@Entity("feedback")
export class Feedback {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Escritorio, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "escritorio_id" })
  escritorio!: Relation<Escritorio> | null;

  @Column({ type: "uuid", nullable: true })
  escritorio_id!: string | null;

  @ManyToOne(() => Usuario, { nullable: true, onDelete: "SET NULL" })
  @JoinColumn({ name: "usuario_id" })
  usuario!: Relation<Usuario> | null;

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  /** Snapshot do e-mail do autor; sobrevive à remoção do usuário. */
  @Column({ type: "text", nullable: true })
  email!: string | null;

  /** Texto livre descrevendo o problema/feedback. */
  @Column({ type: "text" })
  mensagem!: string;

  /** Rota em que o usuário estava ao enviar o feedback. */
  @Column({ type: "text", nullable: true })
  pagina!: string | null;

  @Column({ type: "text", default: "aberto" })
  status!: FeedbackStatus;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
