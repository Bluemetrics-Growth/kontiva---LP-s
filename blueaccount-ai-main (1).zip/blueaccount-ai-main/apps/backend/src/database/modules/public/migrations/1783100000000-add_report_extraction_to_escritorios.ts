import { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Espelha `1782400000000-create_contract_extraction_complexities` para
 * relatórios: adiciona só as colunas de engine/complexidade em `escritorios`.
 * Reaproveita o catálogo `contract_extraction_complexities` já existente
 * (compartilhado entre contratos e relatórios) — sem nova tabela.
 */
export class AddReportExtractionToEscritorios1783100000000 implements MigrationInterface {
  name = "AddReportExtractionToEscritorios1783100000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_extraction_engine" text NOT NULL DEFAULT 'converse'`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "report_extraction_complexity" integer NOT NULL DEFAULT 1`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_extraction_complexity"`,
    );
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "report_extraction_engine"`,
    );
  }
}
