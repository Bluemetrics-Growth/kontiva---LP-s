import type { MigrationInterface, QueryRunner } from "typeorm";

export class EnriquecerCnaesReferencia1785784564556 implements MigrationInterface {
  name = "EnriquecerCnaesReferencia1785784564556";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "cnaes_referencia"
      ADD "classe_codigo" varchar(5),
      ADD "classe_descricao" text,
      ADD "grupo_codigo" varchar(3),
      ADD "grupo_descricao" text,
      ADD "divisao_codigo" varchar(2),
      ADD "divisao_descricao" text,
      ADD "secao_codigo" varchar(1),
      ADD "secao_descricao" text,
      ADD "atividades" text[] NOT NULL DEFAULT '{}',
      ADD "observacoes" text[] NOT NULL DEFAULT '{}',
      ADD "observacoes_classe" text[] NOT NULL DEFAULT '{}',
      ADD "resposta_ibge" jsonb`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "cnaes_referencia"
      DROP COLUMN "resposta_ibge",
      DROP COLUMN "observacoes_classe",
      DROP COLUMN "observacoes",
      DROP COLUMN "atividades",
      DROP COLUMN "secao_descricao",
      DROP COLUMN "secao_codigo",
      DROP COLUMN "divisao_descricao",
      DROP COLUMN "divisao_codigo",
      DROP COLUMN "grupo_descricao",
      DROP COLUMN "grupo_codigo",
      DROP COLUMN "classe_descricao",
      DROP COLUMN "classe_codigo"`);
  }
}
