import { MigrationInterface, QueryRunner } from "typeorm";

export class AddAmbienteTesteCobrancaToEscritorios1782000000000 implements MigrationInterface {
  name = "AddAmbienteTesteCobrancaToEscritorios1782000000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" ADD COLUMN IF NOT EXISTS "ambiente_teste_cobranca" boolean NOT NULL DEFAULT false`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "escritorios" DROP COLUMN IF EXISTS "ambiente_teste_cobranca"`,
    );
  }
}
