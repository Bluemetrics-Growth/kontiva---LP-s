import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

export const TIPOS_SOLICITACAO_PRIVACIDADE = [
  "confirmacao",
  "acesso",
  "correcao",
  "portabilidade",
  "bloqueio",
  "anonimizacao",
  "eliminacao",
  "oposicao",
  "revisao_decisao_automatizada",
] as const;

export type TipoSolicitacaoPrivacidade = typeof TIPOS_SOLICITACAO_PRIVACIDADE[number];
export type StatusSolicitacaoPrivacidade =
  | "recebida"
  | "identidade_pendente"
  | "em_analise"
  | "em_execucao"
  | "concluida"
  | "negada";

/**
 * Fila operacional de direitos dos titulares. Evidências guardam somente
 * metadados de execução (tipo, data, responsável e checksum), nunca o conteúdo
 * exportado ou uma cópia dos dados pessoais localizados.
 */
@Entity("solicitacoes_privacidade")
@Index("UQ_solicitacoes_privacidade_protocolo", ["protocolo"], { unique: true })
@Index("IDX_solicitacoes_privacidade_status_prazo", ["status", "prazo_resposta_em"])
@Index("IDX_solicitacoes_privacidade_email_hash", ["email_hash"])
export class SolicitacaoPrivacidade {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text" })
  protocolo!: string;

  @Column({ type: "text" })
  token_acesso_hash!: string;

  @Column({ type: "text" })
  tipo!: TipoSolicitacaoPrivacidade;

  @Column({ type: "text", default: "identidade_pendente" })
  status!: StatusSolicitacaoPrivacidade;

  @Column({ type: "text" })
  nome_titular!: string;

  @Column({ type: "text" })
  email_titular!: string;

  @Column({ type: "text" })
  email_hash!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "uuid", nullable: true })
  escritorio_id!: string | null;

  @Column({ type: "uuid", nullable: true })
  usuario_id!: string | null;

  @Column({ type: "timestamp with time zone", nullable: true })
  identidade_verificada_em!: Date | null;

  @Column({ type: "text", nullable: true })
  responsavel!: string | null;

  @Column({ type: "timestamp with time zone" })
  prazo_resposta_em!: Date;

  @Column({ type: "text", nullable: true })
  decisao!: string | null;

  @Column({ type: "text", nullable: true })
  fundamento!: string | null;

  @Column({ type: "jsonb", default: [] })
  evidencias!: Array<Record<string, unknown>>;

  @Column({ type: "timestamp with time zone", nullable: true })
  concluida_em!: Date | null;

  @CreateDateColumn({ type: "timestamp with time zone" })
  created_at!: Date;

  @UpdateDateColumn({ type: "timestamp with time zone" })
  updated_at!: Date;
}
