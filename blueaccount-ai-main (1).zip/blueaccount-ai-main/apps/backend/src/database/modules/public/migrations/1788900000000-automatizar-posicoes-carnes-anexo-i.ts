import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * As posições abaixo são citadas integralmente no item 19 do Anexo I. A resolução continua
 * hierárquica: exceções mais específicas (por exemplo, foie gras em 0207) vencem o prefixo-pai.
 */
export class AutomatizarPosicoesCarnesAnexoI1788900000000 implements MigrationInterface {
  name = "AutomatizarPosicoesCarnesAnexoI1788900000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE "ncms_referencia"
      SET "aplicacao_automatica" = true,
          "condicoes_aplicacao_fatores" =
            'Posição integralmente relacionada no item 19 do Anexo I; exceções expressas usam regra mais específica.',
          "origem_configuracao_fatores" = 'LC214-227-2026:anexo-I-item-19'
      WHERE "codigo" IN ('0201', '0202', '0203', '0204', '0207')
        AND "fatores_configurados" = true
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      UPDATE "ncms_referencia"
      SET "aplicacao_automatica" = false,
          "condicoes_aplicacao_fatores" =
            'Carne ou produto animal expressamente abrangido, exceto exclusões legais.',
          "origem_configuracao_fatores" = 'LC214-227-2026'
      WHERE "codigo" IN ('0201', '0202', '0203', '0204', '0207')
        AND "origem_configuracao_fatores" = 'LC214-227-2026:anexo-I-item-19'
    `);
  }
}
