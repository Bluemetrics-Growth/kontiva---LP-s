import { Entity, PrimaryGeneratedColumn, Column, UpdateDateColumn } from "typeorm";

/**
 * Configuração global dos modelos usados pelas state machines de extração
 * com OCR (singleton). `null` significa usar o default do stack (env vars
 * dos templates SAM de contratos/relatórios).
 */
@Entity("extraction_model_config")
export class ExtractionModelConfig {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "text", nullable: true })
  contratos_inference_profile_id!: string | null;

  @Column({ type: "text", nullable: true })
  relatorios_inference_profile_id!: string | null;

  @UpdateDateColumn()
  updated_at!: Date;
}
