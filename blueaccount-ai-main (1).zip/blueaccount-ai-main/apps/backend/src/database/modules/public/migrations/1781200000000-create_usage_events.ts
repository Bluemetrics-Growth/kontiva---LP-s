import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateUsageEvents1781200000000 implements MigrationInterface {
  name = "CreateUsageEvents1781200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE IF NOT EXISTS "usage_events" (` +
        `"id" uuid NOT NULL DEFAULT uuid_generate_v4(), ` +
        `"escritorio_id" uuid NOT NULL, ` +
        `"event_type" text NOT NULL, ` +
        `"quantity" integer NOT NULL, ` +
        `"documento_id" uuid, ` +
        `"metadata" jsonb, ` +
        `"created_at" TIMESTAMP NOT NULL DEFAULT now(), ` +
        `CONSTRAINT "PK_usage_events" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_usage_events_escritorio_id" ON "usage_events" ("escritorio_id")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_usage_events_event_type" ON "usage_events" ("event_type")`);
    await queryRunner.query(`CREATE INDEX IF NOT EXISTS "IDX_usage_events_created_at" ON "usage_events" ("created_at")`);
    await queryRunner.query(
      `ALTER TABLE "usage_events" ADD CONSTRAINT "FK_usage_events_escritorio_id" ` +
        `FOREIGN KEY ("escritorio_id") REFERENCES "escritorios"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "usage_events" DROP CONSTRAINT IF EXISTS "FK_usage_events_escritorio_id"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_usage_events_created_at"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_usage_events_event_type"`);
    await queryRunner.query(`DROP INDEX IF EXISTS "IDX_usage_events_escritorio_id"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "usage_events"`);
  }
}
