import type { MigrationInterface, QueryRunner } from "typeorm";
import { SIMPLES_CNAES_SEED } from "./dados/simples-cnaes.js";

/**
 * Separa "não tem anexo porque a lei não admite a atividade" de "não tem anexo porque nosso catálogo
 * não cobre o código".
 *
 * Sem esta coluna as duas situações caíam no mesmo `cnae_nao_mapeado`, com a mesma frase, e elas pedem
 * respostas opostas: numa o regime do cenário está errado, na outra a falha é nossa e o contador não
 * deve mexer no regime por causa dela.
 *
 * `enquadrado` é o default, então a coluna é neutra em deploy para tudo que já está na tabela.
 */
export class AddSituacaoSimplesCnaes1789800000004 implements MigrationInterface {
  name = "AddSituacaoSimplesCnaes1789800000004";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      ALTER TABLE "simples_cnaes"
        ADD COLUMN "situacao" varchar(20) NOT NULL DEFAULT 'enquadrado',
        ADD CONSTRAINT "CK_simples_cnaes_situacao"
          CHECK ("situacao" IN ('enquadrado', 'vedado', 'nao_optante'))
    `);
    // O CHECK antigo exigia anexo em toda linha sem Fator R. Vedado e não-optante não têm anexo por
    // definição, então a regra passa a valer só dentro de `enquadrado`.
    await queryRunner.query(`ALTER TABLE "simples_cnaes" DROP CONSTRAINT "CK_simples_cnaes_fator_r"`);
    await queryRunner.query(`
      ALTER TABLE "simples_cnaes"
        ADD CONSTRAINT "CK_simples_cnaes_fator_r" CHECK (
          CASE WHEN "situacao" = 'enquadrado'
            THEN ("fator_r" AND "anexo" IS NULL) OR (NOT "fator_r" AND "anexo" IS NOT NULL)
            ELSE "anexo" IS NULL AND NOT "fator_r"
          END
        )
    `);
    await queryRunner.query(
      `INSERT INTO "simples_cnaes" ("codigo", "descricao", "anexo", "fator_r", "fonte", "situacao")
       SELECT item.codigo, item.descricao, item.anexo, item.fator_r, item.fonte, item.situacao
       FROM jsonb_to_recordset($1::jsonb) AS item(
         codigo varchar, descricao text, anexo varchar, fator_r boolean, fonte varchar, situacao varchar
       )
       ON CONFLICT ("codigo") DO NOTHING`,
      [JSON.stringify(SIMPLES_CNAES_SEED)],
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DELETE FROM "simples_cnaes" WHERE "situacao" <> 'enquadrado'`,
    );
    await queryRunner.query(`ALTER TABLE "simples_cnaes" DROP CONSTRAINT "CK_simples_cnaes_fator_r"`);
    await queryRunner.query(`
      ALTER TABLE "simples_cnaes"
        ADD CONSTRAINT "CK_simples_cnaes_fator_r" CHECK (
          ("fator_r" AND "anexo" IS NULL) OR (NOT "fator_r" AND "anexo" IS NOT NULL)
        )
    `);
    await queryRunner.query(`
      ALTER TABLE "simples_cnaes"
        DROP CONSTRAINT "CK_simples_cnaes_situacao",
        DROP COLUMN "situacao"
    `);
  }
}
