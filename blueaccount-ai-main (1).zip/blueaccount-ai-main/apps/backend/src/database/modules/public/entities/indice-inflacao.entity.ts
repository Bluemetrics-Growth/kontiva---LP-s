import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

const numericToNumber = {
  to: (value?: number | null) => value,
  from: (value?: string | null) => (value == null ? value : Number(value)),
};

/** Série mensal oficial consultada no BCB/SGS e reutilizada por todos os escritórios. */
@Index("UQ_indices_inflacao_indice_competencia", ["indice", "competencia"], { unique: true })
@Entity("indices_inflacao")
export class IndiceInflacao {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "varchar", length: 20 })
  indice!: "IPCA" | "INPC" | "IGP-M";

  /** Competência da variação, no formato MM/AAAA. */
  @Column({ type: "varchar", length: 7 })
  competencia!: string;

  @Column({ type: "numeric", precision: 10, scale: 6, transformer: numericToNumber })
  percentual_mensal!: number;

  @Column({ type: "text", default: "BCB/SGS" })
  fonte!: string;

  @CreateDateColumn()
  coletado_em!: Date;
}
