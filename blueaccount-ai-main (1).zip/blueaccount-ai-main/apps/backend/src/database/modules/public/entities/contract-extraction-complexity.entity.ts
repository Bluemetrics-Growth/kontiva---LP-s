import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from "typeorm";

/**
 * Catalogo global de complexidades de extracao de contrato (engine AgentCore).
 *
 * Define o modelo/inference profile usado pelo ContractAgent por nivel. Espelha
 * `billing_complexities`, mas sem preco — extracao != cobranca.
 */
@Entity("contract_extraction_complexities")
export class ContractExtractionComplexity {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ type: "int", unique: true })
  nivel!: number;

  @Column({ type: "text" })
  nome!: string;

  @Column({ type: "text", nullable: true })
  descricao!: string | null;

  @Column({ type: "text", nullable: true })
  inference_profile_id!: string | null;

  @Column({ type: "boolean", default: true })
  ativo!: boolean;

  @CreateDateColumn()
  created_at!: Date;

  @UpdateDateColumn()
  updated_at!: Date;
}
