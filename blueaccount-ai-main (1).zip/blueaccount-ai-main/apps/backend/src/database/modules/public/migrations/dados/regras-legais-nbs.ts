/**
 * Regras legais de IBS/CBS aplicadas por código NBS, no mesmo espírito do manifesto de NCM em
 * `1787800000000-add-fatores-ibs-cbs-ncms.ts`: dado curado, versionado em migration, com fundamento
 * legal ao lado de cada linha.
 *
 * Casamento é por PREFIXO mais longo, porque os anexos da LC 214/2025 referenciam serviços por
 * prefixos de tamanho variável (o Anexo II cita tanto `1.2203` quanto `1.2201.20.00`). Uma exceção
 * legal dentro de um prefixo beneficiado deve ser cadastrada como regra filha mais específica.
 *
 * `fator` é o multiplicador da alíquota nominal: `0.4` = redução de 60%, `0.6` = redução de 40%,
 * `0.7` = redução de 30%, `0` = alíquota zero/isenção, `1` = alíquota cheia (usado quando a regra
 * existe apenas para sinalizar regime específico).
 *
 * `aplicacao_automatica: false` é o caso em que o código NBS **não é** o fato que dispara o
 * benefício — a redução do art. 127, por exemplo, depende da habilitação do profissional e da
 * composição societária, não do serviço prestado. Nesses casos o fator automático continua sendo 1 e
 * a plataforma apenas sugere o benefício, cabendo ao contador confirmar (o fator confirmado é
 * gravado como `manual`, que vence toda a precedência).
 */
export type RegraLegalNbs = {
  /** Prefixo NBS sem pontuação, de 3 a 9 dígitos. */
  codigo: string;
  /** Rótulo curto da regra, para auditoria do manifesto. */
  descricao: string;
  /** Multiplicador da alíquota nominal de IBS e CBS, entre 0 e 1. */
  fator: number;
  /** `false` quando o benefício depende de fato externo ao código; a plataforma só sugere. */
  aplicacao_automatica: boolean;
  /** `false` quando a lei veda ao adquirente apropriar crédito ainda que a operação seja tributada. */
  gera_credito_adquirente: boolean;
  /** Regime específico da LC 214/2025 que a plataforma ainda não modela; serve de alerta. */
  regime_especifico: string | null;
  fundamento: string;
  condicoes: string | null;
};

export const REGRAS_LEGAIS_NBS: RegraLegalNbs[] = [
  // ── Anexo II — serviços de educação, redução de 60% (art. 129) ────────────────────────────────
  {
    codigo: "122011",
    descricao: "Serviços de educação infantil, inclusive creche e pré-escola",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 1",
    condicoes: null,
  },
  {
    codigo: "122012000",
    descricao: "Serviços de ensino fundamental",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 2",
    condicoes: null,
  },
  {
    codigo: "122013000",
    descricao: "Serviços de ensino médio",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 3",
    condicoes: null,
  },
  {
    codigo: "122020000",
    descricao: "Serviços de educação técnica de nível médio",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 4",
    condicoes: null,
  },
  {
    codigo: "12203",
    descricao: "Serviços de educação de jovens e adultos",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 5",
    condicoes: null,
  },
  {
    codigo: "12204",
    descricao: "Serviços de educação superior",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, item 6",
    condicoes: null,
  },
  {
    codigo: "122051300",
    descricao: "Ensino de línguas de sinais, escrita tátil e línguas nativas de povos originários",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 129 e Anexo II, itens 7 e 8",
    condicoes:
      "O Anexo II beneficia apenas o ensino de sistemas linguísticos visomotores, de escrita tátil e de línguas nativas de povos originários. Ensino de outras línguas estrangeiras compartilha a mesma subposição e NÃO tem redução.",
  },

  // ── Anexo III — serviços de saúde, redução de 60% (art. 130) ──────────────────────────────────
  {
    codigo: "12301",
    descricao: "Serviços de saúde humana",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 130 e Anexo III, itens 1 a 26, 28 e 29",
    condicoes:
      "O Anexo III lista todas as subposições de 1.2301, do serviço cirúrgico ao residual 1.2301.99.00.",
  },
  {
    codigo: "12302",
    descricao: "Cuidado e assistência a idosos e pessoas com deficiência em unidades de acolhimento",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 130 e Anexo III, item 27",
    condicoes: null,
  },
  {
    codigo: "126030000",
    descricao: "Serviços funerários, de cremação e de embalsamamento",
    fator: 0.4,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 130 e Anexo III, item 30",
    condicoes: null,
  },

  // ── Art. 157 — isenção do transporte público coletivo urbano/semiurbano/metropolitano ─────────
  {
    codigo: "1040111",
    descricao: "Transporte público coletivo rodoviário local regular de passageiros",
    fator: 0,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 157",
    condicoes:
      "A isenção exige serviço acessível a toda a população, com itinerário e preço fixados pelo poder público, sob autorização, permissão ou concessão. Fretamento e transporte escolar ficam de fora.",
  },
  {
    codigo: "104011620",
    descricao: "Transporte metroviário local de passageiros",
    fator: 0,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 157",
    condicoes:
      "Abrange trens urbanos, metrôs, veículos leves sobre trilhos e monotrilhos sob concessão pública.",
  },

  // ── Art. 285 — redução de 100% do transporte ferroviário e hidroviário urbano ─────────────────
  {
    codigo: "104011610",
    descricao: "Transporte ferroviário local de passageiros",
    fator: 0,
    aplicacao_automatica: true,
    gera_credito_adquirente: false,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 285, I e III",
    condicoes:
      "O inciso III veda expressamente ao adquirente apropriar crédito de IBS e CBS sobre esses serviços.",
  },
  {
    codigo: "104012110",
    descricao: "Transporte hidroviário local de passageiros por travessia",
    fator: 0,
    aplicacao_automatica: true,
    gera_credito_adquirente: false,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 285, I e III",
    condicoes:
      "Aplicável ao caráter urbano, semiurbano e metropolitano. O inciso III veda o crédito ao adquirente.",
  },

  // ── Art. 286 — redução de 40% do transporte coletivo intermunicipal e interestadual ───────────
  {
    codigo: "1040211",
    descricao: "Transporte coletivo rodoviário intermunicipal e interestadual de passageiros",
    fator: 0.6,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 286",
    condicoes: null,
  },
  {
    codigo: "104021400",
    descricao: "Transporte coletivo ferroviário intermunicipal e interestadual de passageiros",
    fator: 0.6,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 286",
    condicoes: null,
  },
  {
    codigo: "1040221",
    descricao: "Transporte coletivo hidroviário interior intermunicipal e interestadual de passageiros",
    fator: 0.6,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 286",
    condicoes: null,
  },
  {
    codigo: "104022200",
    descricao: "Transporte coletivo hidroviário costeiro de passageiros",
    fator: 0.6,
    aplicacao_automatica: true,
    gera_credito_adquirente: true,
    regime_especifico: "transporte_coletivo_passageiros",
    fundamento: "LC 214/2025, art. 286",
    condicoes: null,
  },

  // ── Art. 57 — bens e serviços de uso ou consumo pessoal: sem crédito para o adquirente ────────
  {
    codigo: "12505",
    descricao: "Serviços desportivos e recreacionais desportivos",
    fator: 1,
    aplicacao_automatica: true,
    gera_credito_adquirente: false,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 57, I, f",
    condicoes:
      "Presunção de uso pessoal. Quando o serviço for utilizado preponderantemente na atividade econômica do adquirente, o contador registra o crédito como manual, que vence a vedação.",
  },
  {
    codigo: "12507",
    descricao: "Serviços de parques de diversão e atrações similares",
    fator: 1,
    aplicacao_automatica: true,
    gera_credito_adquirente: false,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 57, I, f",
    condicoes:
      "Presunção de uso pessoal. Crédito manual continua disponível para uso preponderantemente econômico.",
  },
  {
    codigo: "12602",
    descricao: "Serviços de tratamento de beleza e bem-estar físico",
    fator: 1,
    aplicacao_automatica: true,
    gera_credito_adquirente: false,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 57, I, f",
    condicoes:
      "Presunção de uso pessoal (serviços estéticos). Crédito manual continua disponível para uso preponderantemente econômico.",
  },

  // ── Art. 127 — profissões intelectuais regulamentadas, redução de 30% (condicionada) ──────────
  {
    codigo: "11301",
    descricao: "Serviços jurídicos",
    fator: 0.7,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 127, caput e inciso I",
    condicoes:
      "A redução não decorre do serviço, e sim do prestador: pessoa física habilitada, ou pessoa jurídica cujos sócios tenham habilitação ligada ao objeto social e estejam sob fiscalização de conselho profissional. Confirme antes de aplicar.",
  },
  {
    codigo: "11302",
    descricao: "Serviços de auditoria, contabilidade e escrituração mercantil",
    fator: 0.7,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 127, caput e inciso V",
    condicoes:
      "Depende de habilitação e fiscalização por conselho profissional (CRC) e da composição societária. Confirme antes de aplicar.",
  },
  {
    codigo: "11402",
    descricao: "Serviços de arquitetura, urbanismo e paisagismo",
    fator: 0.7,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 127, caput e inciso II",
    condicoes:
      "Depende de habilitação e fiscalização por conselho profissional (CAU) e da composição societária. Confirme antes de aplicar.",
  },
  {
    codigo: "11403",
    descricao: "Serviços de engenharia",
    fator: 0.7,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 127, caput e inciso IX",
    condicoes:
      "Depende de habilitação e fiscalização por conselho profissional (CREA) e da composição societária. Confirme antes de aplicar.",
  },
  {
    codigo: "11405",
    descricao: "Serviços veterinários",
    fator: 0.7,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: null,
    fundamento: "LC 214/2025, art. 127, caput e inciso XIV",
    condicoes:
      "Depende de habilitação e fiscalização por conselho profissional (CRMV) e da composição societária. Confirme antes de aplicar.",
  },

  // ── Regimes específicos ainda não modelados pelo motor: sinalizar, não calcular ───────────────
  {
    codigo: "10901",
    descricao: "Serviços financeiros",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 182 a 209",
    condicoes:
      "Regime específico de serviços financeiros: base de cálculo, alíquotas e crédito seguem regras próprias que a simulação ainda não reproduz. Revise a linha manualmente.",
  },
  {
    codigo: "10902",
    descricao: "Serviços de banco de investimento",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 182 a 209",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10903",
    descricao: "Serviços de seguro e previdência complementar",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 210 a 230",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10904",
    descricao: "Serviços de resseguro",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 210 a 230",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10905",
    descricao: "Serviços auxiliares aos serviços financeiros",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 182 a 209",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10906",
    descricao: "Serviços auxiliares a seguros, resseguros e previdência complementar",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 210 a 230",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10909",
    descricao: "Serviços de holding de ativos financeiros",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "financeiro",
    fundamento: "LC 214/2025, arts. 182 a 209",
    condicoes: "Regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10910",
    descricao: "Planos privados de assistência à saúde",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "planos_assistencia_saude",
    fundamento: "LC 214/2025, arts. 231 a 236",
    condicoes:
      "Regime específico de planos de assistência à saúde: base e crédito próprios, não modelados pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "11001",
    descricao: "Serviços imobiliários sob comissão ou contrato",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "bens_imoveis",
    fundamento: "LC 214/2025, arts. 251 a 260",
    condicoes:
      "Regime específico de bens imóveis, com redutores de base próprios não modelados pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "11002",
    descricao: "Locação de imóveis",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "bens_imoveis",
    fundamento: "LC 214/2025, arts. 251 a 260",
    condicoes:
      "Regime específico de bens imóveis, com redutores de base próprios não modelados pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "10301",
    descricao: "Fornecimento de alimentação, incluindo refeições",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "hotelaria_alimentacao_turismo",
    fundamento: "LC 214/2025, arts. 274 a 283",
    condicoes:
      "Bares e restaurantes têm regime específico com base reduzida e vedação parcial de crédito, ainda não modelados. Revise a linha manualmente.",
  },
  {
    codigo: "10303",
    descricao: "Serviços de hospedagem para visitantes",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "hotelaria_alimentacao_turismo",
    fundamento: "LC 214/2025, arts. 274 a 283",
    condicoes:
      "Hotelaria tem regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
  {
    codigo: "11805",
    descricao: "Serviços de planejamento de viagens e serviços relacionados",
    fator: 1,
    aplicacao_automatica: false,
    gera_credito_adquirente: true,
    regime_especifico: "hotelaria_alimentacao_turismo",
    fundamento: "LC 214/2025, arts. 274 a 283",
    condicoes:
      "Agências de turismo têm regime específico não modelado pela simulação. Revise a linha manualmente.",
  },
];
