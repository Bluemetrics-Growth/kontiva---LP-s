import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateOauthTables1779500000000 implements MigrationInterface {
  name = "CreateOauthTables1779500000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "oauth_clients" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "client_id" text NOT NULL,
        "client_secret_hash" text,
        "client_name" text,
        "usuario_id" uuid,
        "escritorio_id" uuid,
        "redirect_uris" jsonb NOT NULL,
        "token_endpoint_auth_method" text NOT NULL DEFAULT 'none',
        "scope" text,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_oauth_clients_id" PRIMARY KEY ("id")
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_oauth_clients_client_id" ON "oauth_clients" ("client_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_clients_usuario_id" ON "oauth_clients" ("usuario_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_clients_escritorio_id" ON "oauth_clients" ("escritorio_id")`);

    await queryRunner.query(`
      CREATE TABLE "oauth_authorization_codes" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "code_hash" text NOT NULL,
        "client_id" text NOT NULL,
        "usuario_id" uuid NOT NULL,
        "escritorio_id" uuid NOT NULL,
        "session_id_hash" text NOT NULL,
        "redirect_uri" text NOT NULL,
        "code_challenge" text NOT NULL,
        "code_challenge_method" text NOT NULL DEFAULT 'S256',
        "scope" text,
        "resource" text,
        "expires_at" TIMESTAMP NOT NULL,
        "consumed_at" TIMESTAMP,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_oauth_authorization_codes_id" PRIMARY KEY ("id")
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_oauth_authorization_codes_code_hash" ON "oauth_authorization_codes" ("code_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_authorization_codes_client_id" ON "oauth_authorization_codes" ("client_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_authorization_codes_expires_at" ON "oauth_authorization_codes" ("expires_at")`);

    await queryRunner.query(`
      CREATE TABLE "oauth_access_tokens" (
        "id" uuid NOT NULL DEFAULT uuid_generate_v4(),
        "token_hash" text NOT NULL,
        "client_id" text NOT NULL,
        "usuario_id" uuid NOT NULL,
        "escritorio_id" uuid NOT NULL,
        "session_id_hash" text NOT NULL,
        "scope" text,
        "resource" text,
        "expires_at" TIMESTAMP NOT NULL,
        "revoked_at" TIMESTAMP,
        "last_seen_at" TIMESTAMP,
        "created_at" TIMESTAMP NOT NULL DEFAULT now(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
        CONSTRAINT "PK_oauth_access_tokens_id" PRIMARY KEY ("id")
      )
    `);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_oauth_access_tokens_token_hash" ON "oauth_access_tokens" ("token_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_access_tokens_client_id" ON "oauth_access_tokens" ("client_id")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_access_tokens_session_id_hash" ON "oauth_access_tokens" ("session_id_hash")`);
    await queryRunner.query(`CREATE INDEX "IDX_oauth_access_tokens_expires_at" ON "oauth_access_tokens" ("expires_at")`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_access_tokens_expires_at"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_access_tokens_session_id_hash"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_access_tokens_client_id"`);
    await queryRunner.query(`DROP INDEX "public"."UQ_oauth_access_tokens_token_hash"`);
    await queryRunner.query(`DROP TABLE "oauth_access_tokens"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_authorization_codes_expires_at"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_authorization_codes_client_id"`);
    await queryRunner.query(`DROP INDEX "public"."UQ_oauth_authorization_codes_code_hash"`);
    await queryRunner.query(`DROP TABLE "oauth_authorization_codes"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_clients_escritorio_id"`);
    await queryRunner.query(`DROP INDEX "public"."IDX_oauth_clients_usuario_id"`);
    await queryRunner.query(`DROP INDEX "public"."UQ_oauth_clients_client_id"`);
    await queryRunner.query(`DROP TABLE "oauth_clients"`);
  }
}
