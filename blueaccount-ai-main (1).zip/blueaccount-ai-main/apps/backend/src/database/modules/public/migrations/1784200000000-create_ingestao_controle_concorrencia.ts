import type { MigrationInterface, QueryRunner } from "typeorm";

export class CreateIngestaoControleConcorrencia1784200000000 implements MigrationInterface {
  name = "CreateIngestaoControleConcorrencia1784200000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE "ingestao_controle_concorrencia" (
        "id" smallint NOT NULL,
        CONSTRAINT "PK_ingestao_controle_concorrencia" PRIMARY KEY ("id"),
        CONSTRAINT "CHK_ingestao_controle_concorrencia_singleton" CHECK ("id" = 1)
      )
    `);
    await queryRunner.query(`INSERT INTO "ingestao_controle_concorrencia" ("id") VALUES (1)`);

    await queryRunner.query(`
      CREATE TABLE "ingestao_permissoes_processamento" (
        "execution_arn" text NOT NULL,
        "documento_id" varchar(128) NOT NULL,
        "modulo" varchar(32) NOT NULL,
        "adquirida_em" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
        "liberada_em" TIMESTAMP WITH TIME ZONE,
        "status_terminal" varchar(16),
        CONSTRAINT "PK_ingestao_permissoes_processamento" PRIMARY KEY ("execution_arn"),
        CONSTRAINT "CHK_ingestao_permissoes_modulo" CHECK ("modulo" IN ('contratos', 'relatorios_periodicos')),
        CONSTRAINT "CHK_ingestao_permissoes_status_terminal" CHECK (
          "status_terminal" IS NULL OR "status_terminal" IN ('SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED')
        ),
        CONSTRAINT "CHK_ingestao_permissoes_liberacao" CHECK (
          ("liberada_em" IS NULL AND "status_terminal" IS NULL)
          OR ("liberada_em" IS NOT NULL AND "status_terminal" IS NOT NULL)
        )
      )
    `);
    await queryRunner.query(`
      CREATE INDEX "IDX_ingestao_permissoes_ativas_modulo"
      ON "ingestao_permissoes_processamento" ("modulo")
      WHERE "liberada_em" IS NULL
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS "public"."IDX_ingestao_permissoes_ativas_modulo"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "ingestao_permissoes_processamento"`);
    await queryRunner.query(`DROP TABLE IF EXISTS "ingestao_controle_concorrencia"`);
  }
}
