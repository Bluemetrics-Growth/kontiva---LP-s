import { Column, Entity, Index, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

/**
 * Catálogo local da NBS 2.0 (Nomenclatura Brasileira de Serviços), semeado a partir do Anexo B da
 * NFS-e Nacional (`scripts/gerar-catalogo-nbs.mjs`) — não existe API pública equivalente à BrasilAPI
 * para NBS, então este cache não é lazy: nasce cheio pela migration de seed e cresce só por
 * atualização manual do catálogo oficial (`origem_configuracao_fatores = "nbs-2.0-anexo-b"`).
 */
@Index("UQ_nbs_referencia_codigo", ["codigo"], { unique: true })
// Resolução de regras (`resolverRegrasPorNbs`) filtra por fatores_configurados antes do LIKE de
// prefixo; sem este índice parcial, o LIKE (construído a partir da coluna, não indexável) força
// varredura sequencial da tabela inteira — que tem ~1200 linhas do catálogo, das quais só as
// dezenas com regra legal curada (`fatores_configurados = true`) importam para o LIKE.
@Index("IDX_nbs_referencia_fatores_configurados_codigo", ["codigo"], { where: `"fatores_configurados" = true` })
@Entity("nbs_referencia")
export class NbsReferencia {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  /** Código NBS sem pontuação, de 3 a 9 dígitos (capítulo a subitem). */
  @Column({ type: "varchar", length: 9 })
  codigo!: string;

  @Column({ type: "text" })
  descricao!: string;

  /** Descrições dos nós-pai presentes no catálogo, do mais amplo para o mais específico. */
  @Column({ type: "text", array: true, nullable: true })
  descricoes_hierarquia!: string[] | null;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_ibs!: number;

  @Column({ type: "decimal", precision: 7, scale: 6, default: 1 })
  fator_cbs!: number;

  /** Distingue uma regra legal curada do registro só catalogado pelo seed do Anexo B. */
  @Column({ type: "boolean", default: false })
  fatores_configurados!: boolean;

  /**
   * `false` quando o código NBS não é, por si só, o fato que dispara o benefício (ex.: art. 127,
   * profissões intelectuais regulamentadas — depende de habilitação e composição societária). Nesse
   * caso `resolverRegrasPorNbs` mantém o fator automático em 1 e só sugere o benefício.
   */
  @Column({ type: "boolean", default: true })
  aplicacao_automatica!: boolean;

  /** `false` quando a lei veda ao adquirente apropriar crédito de IBS/CBS sobre esta operação (art. 57). */
  @Column({ type: "boolean", default: true })
  gera_credito_adquirente!: boolean;

  /** Regime específico da LC 214/2025 (financeiro, saúde suplementar, imóveis, ...) ainda não modelado. */
  @Column({ type: "varchar", length: 40, nullable: true })
  regime_especifico!: string | null;

  @Column({ type: "text", nullable: true })
  fundamento_legal_fatores!: string | null;

  @Column({ type: "text", nullable: true })
  condicoes_aplicacao_fatores!: string | null;

  @Column({ type: "varchar", length: 80, nullable: true })
  origem_configuracao_fatores!: string | null;

  @UpdateDateColumn({ type: "timestamptz" })
  atualizado_em!: Date;
}
