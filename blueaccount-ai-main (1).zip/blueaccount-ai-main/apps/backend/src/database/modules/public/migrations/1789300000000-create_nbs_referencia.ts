import type { MigrationInterface, QueryRunner } from "typeorm";

/**
 * Cria a tabela `nbs_referencia`, catálogo local da NBS 2.0 (não existe fonte externa gratuita
 * equivalente à BrasilAPI para NBS — ver `database/modules/public/entities/nbs-referencia.entity.ts`).
 */
export class CreateNbsReferencia1789300000000 implements MigrationInterface {
  name = "CreateNbsReferencia1789300000000";

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`CREATE TABLE "nbs_referencia" (
      "id" uuid NOT NULL DEFAULT uuid_generate_v7(),
      "codigo" varchar(9) NOT NULL,
      "descricao" text NOT NULL,
      "descricoes_hierarquia" text[],
      "fator_ibs" decimal(7,6) NOT NULL DEFAULT 1,
      "fator_cbs" decimal(7,6) NOT NULL DEFAULT 1,
      "fatores_configurados" boolean NOT NULL DEFAULT false,
      "aplicacao_automatica" boolean NOT NULL DEFAULT true,
      "gera_credito_adquirente" boolean NOT NULL DEFAULT true,
      "regime_especifico" varchar(40),
      "fundamento_legal_fatores" text,
      "condicoes_aplicacao_fatores" text,
      "origem_configuracao_fatores" varchar(80),
      "atualizado_em" timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT "PK_nbs_referencia" PRIMARY KEY ("id"),
      CONSTRAINT "CHK_nbs_referencia_codigo_escopo" CHECK ("codigo" ~ '^[0-9]{3,9}$'),
      CONSTRAINT "CHK_nbs_referencia_fator_ibs" CHECK ("fator_ibs" BETWEEN 0 AND 1),
      CONSTRAINT "CHK_nbs_referencia_fator_cbs" CHECK ("fator_cbs" BETWEEN 0 AND 1)
    )`);
    await queryRunner.query(`CREATE UNIQUE INDEX "UQ_nbs_referencia_codigo" ON "nbs_referencia" ("codigo")`);
    // Ver o comentário da entidade: sem este índice parcial, o LIKE de prefixo de
    // `resolverRegrasPorNbs` varre a tabela inteira (~1200 linhas do catálogo) a cada resolução.
    await queryRunner.query(`CREATE INDEX "IDX_nbs_referencia_fatores_configurados_codigo"
      ON "nbs_referencia" ("codigo") WHERE "fatores_configurados" = true`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP TABLE "nbs_referencia"`);
  }
}
