#!/usr/bin/env node
/**
 * Housekeeping OPCIONAL, não pré-requisito de deploy.
 *
 * Quem substitui o contrato de simulações é a migration `1787100000000-substituir-contrato-simulacoes`,
 * que apaga as linhas ela mesma, em transação, por tenant. O que ela não alcança é o S3: os XMLs de
 * NF-e importados ficam órfãos sob `<escritorio>/simulacoes-nfe/`. Este comando existe para varrê-los.
 *
 * Roda depois da migration sem problema: encontra zero linha no banco e ainda assim limpa o S3 por
 * prefixo. **Irreversível** — exige `--confirmar-exclusao-irreversivel`. Apaga por prefixo além das
 * `storage_key` conhecidas, então confirme que nenhuma outra feature escreve sob esse infixo.
 */
import { pathToFileURL } from "node:url";
import type { DataSource } from "typeorm";
import { AppDataSource } from "./data-source.js";
import { buildEscritorioSchemaName } from "./tenant-naming.js";
import { createDocumentStorage, type DocumentStorage } from "../infrastructure/document-storage.js";

function identificador(valor: string): string {
  return `"${valor.replaceAll('"', '""')}"`;
}

export type ResumoLimpezaSimulacoes = {
  tenants: number;
  xmlsRemovidos: number;
  simulacoesRemovidas: number;
  gruposRemovidos: number;
};

export async function limparSimulacoesAntigas(
  dataSource: Pick<DataSource, "query" | "createQueryRunner">,
  storage: DocumentStorage,
): Promise<ResumoLimpezaSimulacoes> {
  const escritorios = await dataSource.query(`SELECT id FROM public.escritorios ORDER BY id`);
  const resumo: ResumoLimpezaSimulacoes = {
    tenants: escritorios.length,
    xmlsRemovidos: 0,
    simulacoesRemovidas: 0,
    gruposRemovidos: 0,
  };

  for (const escritorio of escritorios as Array<{ id: string }>) {
    const escritorioId = String(escritorio.id);
    const schema = identificador(buildEscritorioSchemaName(escritorioId));
    const notas = await dataSource.query(
      `SELECT storage_key FROM ${schema}.simulacao_notas_fiscais WHERE storage_key IS NOT NULL`,
    );
    const objetosDoPrefixo = await storage.list(`${escritorioId}/`);
    const chaves = new Set<string>([
      ...notas.map((nota: { storage_key: string }) => nota.storage_key),
      ...objetosDoPrefixo
        .map((objeto) => objeto.key)
        .filter((key) => key.includes("/simulacoes-nfe/")),
    ]);
    for (const key of chaves) {
      await storage.delete(key);
      resumo.xmlsRemovidos += 1;
    }

    const [contagens] = await dataSource.query(`
      SELECT
        (SELECT COUNT(*)::int FROM ${schema}.simulacoes) AS simulacoes,
        (SELECT COUNT(*)::int FROM ${schema}.simulacao_grupos) AS grupos
    `);
    const queryRunner = dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      await queryRunner.query(`DELETE FROM ${schema}.simulacao_grupo_itens`);
      await queryRunner.query(`DELETE FROM ${schema}.simulacao_grupos`);
      await queryRunner.query(`DELETE FROM ${schema}.simulacoes`);
      await queryRunner.commitTransaction();
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
    resumo.simulacoesRemovidas += Number(contagens.simulacoes);
    resumo.gruposRemovidos += Number(contagens.grupos);

    const [restante] = await dataSource.query(`
      SELECT
        (SELECT COUNT(*) FROM ${schema}.simulacoes) +
        (SELECT COUNT(*) FROM ${schema}.simulacao_entradas) +
        (SELECT COUNT(*) FROM ${schema}.simulacao_notas_fiscais) +
        (SELECT COUNT(*) FROM ${schema}.simulacao_grupos) +
        (SELECT COUNT(*) FROM ${schema}.simulacao_grupo_itens) AS total
    `);
    if (Number(restante.total) !== 0) {
      throw new Error(`Limpeza incompleta no schema ${schema}: ${restante.total} registro(s).`);
    }
  }
  return resumo;
}

async function main(): Promise<void> {
  if (!process.argv.includes("--confirmar-exclusao-irreversivel")) {
    throw new Error("Confirme a operação com --confirmar-exclusao-irreversivel.");
  }
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  try {
    const resumo = await limparSimulacoesAntigas(AppDataSource, createDocumentStorage());
    console.log(JSON.stringify(resumo, null, 2));
  } finally {
    if (AppDataSource.isInitialized) await AppDataSource.destroy();
  }
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? "").href) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  });
}
