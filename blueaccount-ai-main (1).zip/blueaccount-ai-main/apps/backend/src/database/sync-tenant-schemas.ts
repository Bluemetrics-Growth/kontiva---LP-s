#!/usr/bin/env node
import { AppDataSource } from "./data-source.js";
import { Escritorio } from "./modules/public/entities/escritorio.entity.js";
import { buildEscritorioSchemaName } from "./tenant-naming.js";
import { runTenantMigrations, runModuleMigrations, MODULE_FACTORIES } from "./tenant-module-runner.js";
import type { ModuleName } from "./tenant-module-runner.js";
import {
  buildTenantPrivilegeTarget,
  grantTenantRoleToRuntimeRoles,
  reconcileTenantPrivileges,
  revokePublicTablePrivilegesFromTenantRole,
} from "./tenant-privileges.js";

const MODULE_NAMES: ModuleName[] = ["tenant"];
const MIGRATION_STATE_TABLE = "tenant_migration_state";

type TenantMigrationState = {
  timestamp: number;
  name: string;
} | null;

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, "\"\"")}"`;
}

async function ensureTenantMigrationStateTable(): Promise<void> {
  await AppDataSource.query(`
    CREATE TABLE IF NOT EXISTS public.${quoteIdentifier(MIGRATION_STATE_TABLE)} (
      schema_name text NOT NULL,
      module_name text NOT NULL,
      last_migration_timestamp bigint,
      last_migration_name text,
      updated_at timestamptz NOT NULL DEFAULT now(),
      CONSTRAINT pk_tenant_migration_state PRIMARY KEY (schema_name, module_name)
    )
  `);
}

async function readLatestTenantMigrationFromSchema(schemaName: string): Promise<TenantMigrationState> {
  const schemaRef = quoteIdentifier(schemaName);

  try {
    const rows = await AppDataSource.query(
      `SELECT timestamp, name FROM ${schemaRef}."_tenant_migrations" ORDER BY timestamp DESC LIMIT 1`,
    );

    if (!Array.isArray(rows) || rows.length === 0) {
      return null;
    }

    const row = rows[0] as { timestamp?: unknown; name?: unknown };
    const timestamp = Number(row.timestamp);
    const name = String(row.name ?? "");
    if (!Number.isFinite(timestamp) || !name) {
      return null;
    }

    return { timestamp, name };
  } catch (error: unknown) {
    const pgCode = error && typeof error === "object" && "code" in error
      ? String((error as { code?: unknown }).code)
      : "";
    if (pgCode === "42P01") {
      return null;
    }
    throw error;
  }
}

async function persistTenantMigrationState(
  schemaName: string,
  moduleName: ModuleName,
  state: TenantMigrationState,
): Promise<void> {
  await AppDataSource.query(
    `
      INSERT INTO public.${quoteIdentifier(MIGRATION_STATE_TABLE)}
        (schema_name, module_name, last_migration_timestamp, last_migration_name, updated_at)
      VALUES ($1, $2, $3, $4, now())
      ON CONFLICT (schema_name, module_name)
      DO UPDATE SET
        last_migration_timestamp = EXCLUDED.last_migration_timestamp,
        last_migration_name = EXCLUDED.last_migration_name,
        updated_at = now()
    `,
    [schemaName, moduleName, state?.timestamp ?? null, state?.name ?? null],
  );
}

async function main() {
  const targetModule = process.argv
    .find((a) => a.startsWith("--module="))
    ?.split("=")[1] as ModuleName | undefined;

  if (targetModule && !MODULE_NAMES.includes(targetModule)) {
    console.error(`Módulo inválido: "${targetModule}". Use: ${MODULE_NAMES.join(", ")}`);
    process.exit(1);
  }

  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
  }

  try {
    await ensureTenantMigrationStateTable();

    const escritorios = await AppDataSource.getRepository(Escritorio).find({ select: { id: true } });

    console.log(`Sincronizando ${escritorios.length} schema(s)${targetModule ? ` [módulo: ${targetModule}]` : ""}...`);

    for (const escritorio of escritorios) {
      const schema = buildEscritorioSchemaName(escritorio.id);
      await AppDataSource.query(`CREATE SCHEMA IF NOT EXISTS "${schema}"`);
      const target = buildTenantPrivilegeTarget(escritorio.id);
      await reconcileTenantPrivileges(AppDataSource.manager, target);
      await revokePublicTablePrivilegesFromTenantRole(AppDataSource.manager, target.roleName);

      console.log(`  → ${schema}`);

      if (targetModule) {
        await runModuleMigrations(schema, MODULE_FACTORIES[targetModule], targetModule);
      } else {
        await runTenantMigrations(schema);
      }

      const effectiveModule = targetModule ?? "tenant";
      const latest = await readLatestTenantMigrationFromSchema(schema);
      await persistTenantMigrationState(schema, effectiveModule, latest);
      await reconcileTenantPrivileges(AppDataSource.manager, target);
      await revokePublicTablePrivilegesFromTenantRole(AppDataSource.manager, target.roleName);
      await grantTenantRoleToRuntimeRoles(AppDataSource.manager, target.roleName);
    }
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
    }
  }
  console.log("Schemas sincronizados.");
}

main().catch((error) => {
  console.error("Falha ao sincronizar schemas:", error);

  process.exit(1);
});
