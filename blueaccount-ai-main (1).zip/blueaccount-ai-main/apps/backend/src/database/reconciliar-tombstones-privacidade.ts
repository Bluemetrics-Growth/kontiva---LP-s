#!/usr/bin/env node
import { AppDataSource } from "./data-source.js";
import { hashPrivacidade } from "../domain/privacidade/privacidade.service.js";
import { listEscritorios } from "../domain/escritorios/escritorio.service.js";
import { listAllDocumentos } from "../domain/documentos/documentos.service.js";
import { listarTombstonesPrivacidadeExternos } from "../infrastructure/privacy-tombstone-storage.js";
import { DocumentosService } from "../modules/documentos/documentos.service.js";
import { EscritoriosService } from "../modules/escritorios/escritorios.service.js";

type DocumentoRestaurado = { escritorioId: string; documentoId: string };

async function main(): Promise<void> {
  const executar = process.argv.includes("--executar");
  const confirmado = process.argv.includes("--confirmar-reaplicacao");
  if (executar && !confirmado) {
    throw new Error("Use --executar --confirmar-reaplicacao para autorizar a reaplicação destrutiva.");
  }

  const externos = await listarTombstonesPrivacidadeExternos();
  const hashesEscritorio = new Set(externos.filter((item) => item.escopo === "escritorio").map((item) => item.identificador_hash));
  const hashesDocumento = new Set(externos.filter((item) => item.escopo === "documento").map((item) => item.identificador_hash));
  const escritorios = await listEscritorios({ includeInactive: true });
  const escritoriosRestaurados = escritorios.filter((item) => hashesEscritorio.has(hashPrivacidade(`escritorio:${item.id}`)));
  const idsEscritoriosRestaurados = new Set(escritoriosRestaurados.map((item) => item.id));
  const documentosRestaurados: DocumentoRestaurado[] = [];

  for (const escritorio of escritorios) {
    if (idsEscritoriosRestaurados.has(escritorio.id)) continue;
    for (const documento of await listAllDocumentos(escritorio.id)) {
      if (hashesDocumento.has(hashPrivacidade(`documento:${escritorio.id}:${documento.id}`))) {
        documentosRestaurados.push({ escritorioId: escritorio.id, documentoId: documento.id });
      }
    }
  }

  process.stdout.write(`${JSON.stringify({
    modo: executar ? "execucao" : "dry-run",
    tombstones_externos: externos.length,
    escritorios_restaurados: escritoriosRestaurados.length,
    documentos_restaurados: documentosRestaurados.length,
  })}\n`);
  if (!executar) return;

  const documentosService = new DocumentosService();
  for (const item of documentosRestaurados) {
    const ok = await documentosService.deleteDocumento(item.escritorioId, item.documentoId);
    if (!ok) throw new Error("Falha ao reaplicar tombstone de documento.");
  }
  const escritoriosService = new EscritoriosService();
  for (const item of escritoriosRestaurados) {
    const result = await escritoriosService.deleteEscritorio(item.id);
    if (!result.ok) throw new Error("Falha ao reaplicar tombstone de escritório.");
  }
}

main()
  .catch((error: unknown) => {
    process.stderr.write(`Falha ao reconciliar tombstones: ${error instanceof Error ? error.name : "erro_desconhecido"}\n`);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (AppDataSource.isInitialized) await AppDataSource.destroy();
  });
