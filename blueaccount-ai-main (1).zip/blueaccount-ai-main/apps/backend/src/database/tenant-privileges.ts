import type { EntityManager } from "typeorm";
import { buildEscritorioRoleName, buildEscritorioSchemaName } from "./tenant-naming.js";

export type TenantPrivilegeTarget = {
  schemaName: string;
  roleName: string;
};

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

function uniqueValues(values: Array<string | null | undefined>): string[] {
  return [...new Set(
    values
      .map((value) => value?.trim())
      .filter((value): value is string => Boolean(value)),
  )];
}

export function resolveTenantObjectOwnerRole(): string {
  const envRole = process.env.DB_USERNAME?.trim()
    || process.env.DB_AI_USERNAME?.trim();
  if (envRole) {
    return envRole;
  }
  return "postgres";
}

export function resolveRuntimeRoles(): string[] {
  return uniqueValues([
    process.env.DB_AI_USERNAME,
    process.env.DB_USERNAME,
  ]);
}

export function buildTenantPrivilegeTarget(escritorioId: string): TenantPrivilegeTarget {
  return {
    schemaName: buildEscritorioSchemaName(escritorioId),
    roleName: buildEscritorioRoleName(escritorioId),
  };
}

export async function ensureTenantRole(
  manager: Pick<EntityManager, "query">,
  roleName: string,
): Promise<void> {
  const existingRole = await manager.query("SELECT 1 FROM pg_roles WHERE rolname = $1 LIMIT 1", [roleName]);
  if (!Array.isArray(existingRole) || existingRole.length === 0) {
    await manager.query(`CREATE ROLE ${quoteIdentifier(roleName)} NOLOGIN`);
  }
}

export async function grantTenantRoleToRuntimeRoles(
  manager: Pick<EntityManager, "query">,
  roleName: string,
  runtimeRoles = resolveRuntimeRoles(),
): Promise<void> {
  if (runtimeRoles.length === 0) {
    return;
  }

  const existingRoles = await manager.query(
    "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
    [runtimeRoles],
  );
  const existingRoleSet = new Set(
    Array.isArray(existingRoles) ? existingRoles.map((row) => String(row.rolname)) : [],
  );

  for (const runtimeRole of runtimeRoles) {
    if (!existingRoleSet.has(runtimeRole)) {
      continue;
    }
    await manager.query(`GRANT ${quoteIdentifier(roleName)} TO ${quoteIdentifier(runtimeRole)}`);
  }
}

export async function reconcileTenantPrivileges(
  manager: Pick<EntityManager, "query">,
  { schemaName, roleName }: TenantPrivilegeTarget,
  ownerRole = resolveTenantObjectOwnerRole(),
): Promise<void> {
  const quotedSchemaName = quoteIdentifier(schemaName);
  const quotedRoleName = quoteIdentifier(roleName);
  const quotedOwnerRole = quoteIdentifier(ownerRole);

  await ensureTenantRole(manager, roleName);
  await manager.query(`GRANT USAGE ON SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(`GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(`GRANT USAGE ON ALL SEQUENCES IN SCHEMA ${quotedSchemaName} TO ${quotedRoleName}`);
  await manager.query(
    `ALTER DEFAULT PRIVILEGES FOR ROLE ${quotedOwnerRole} IN SCHEMA ${quotedSchemaName} ` +
    `GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO ${quotedRoleName}`,
  );
  await manager.query(
    `ALTER DEFAULT PRIVILEGES FOR ROLE ${quotedOwnerRole} IN SCHEMA ${quotedSchemaName} ` +
    `GRANT USAGE ON SEQUENCES TO ${quotedRoleName}`,
  );
}

export async function revokePublicTablePrivilegesFromTenantRole(
  manager: Pick<EntityManager, "query">,
  roleName: string,
): Promise<void> {
  const quotedRoleName = quoteIdentifier(roleName);

  await manager.query(`REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM ${quotedRoleName}`);
}
