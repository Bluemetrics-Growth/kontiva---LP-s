# Gaps de Testes — Database Layer

Data de referência: 2026-04-20

## Situação Atual

Já coberto por testes automatizados:

- `create-tenant-schemas.ts` (unitário)
- `sync-tenant-schemas.ts` (unitário)
- naming/factory/runner/provisioning de tenant
- smoke tests de integração (`*.integration.test.ts`)

## Lacunas Reais em Aberto

## Gap 1: Integração real com PostgreSQL de teste

Hoje os testes de integração não validam:

- criação real de schema/tabelas via migration;
- grants/permissões efetivas de role;
- idempotência completa de provisioning com banco real.

Mínimo recomendado:

1. Adicionar ambiente de banco dedicado para teste (docker compose de teste).
2. Criar casos que validem tabelas efetivamente criadas por schema.
3. Validar grants de role e operações CRUD com role de tenant.

## Gap 2: Cobertura de regressão para falhas transacionais

Faltam cenários de erro com rollback verificável quando uma etapa de provisioning falha após criação parcial.

Mínimo recomendado:

1. Simular erro após criação de schema/role.
2. Verificar compensação/consistência final.
3. Registrar comportamento esperado para falhas não recuperáveis.

## Gap 3: Integração em CI separada do deploy

Atualmente o workflow de deploy valida unitários, mas não executa uma pipeline dedicada de integração de database.

Mínimo recomendado:

1. Job separado para `test:integration`.
2. Ambiente efêmero de banco.
3. Gate opcional por branch (ao menos em `main`).

## Prioridade

1. Gap 1 (alta)
2. Gap 3 (alta)
3. Gap 2 (média)
