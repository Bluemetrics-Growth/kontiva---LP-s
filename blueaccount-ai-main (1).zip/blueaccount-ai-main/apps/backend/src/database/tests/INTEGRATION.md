# Integration Tests — Database Layer

Data de referência: 2026-04-20

## Estado Atual

A suíte de integração desta pasta está configurada em `apps/backend/vitest.integration.config.ts` e executa arquivos `*.integration.test.ts`.

Arquivos atuais:

- `escritorio.integration.test.ts`
- `simple.integration.test.ts`

Observação: no estado atual, esses testes funcionam como smoke tests e não exercitam provisioning real em PostgreSQL de teste.

## Como Rodar

Na raiz do monorepo:

```bash
npm run test:integration
npm run test:integration:watch
```

No workspace backend:

```bash
npm run test:integration
npm run test:integration:watch
```

## Objetivo de Evolução (Próxima Iteração)

1. Adicionar ambiente de PostgreSQL dedicado para integração.
2. Validar criação de schema e aplicação de migrations reais.
3. Validar grants/permissões por role de tenant.
4. Incluir job de integração no CI.

## Checklist para Novos Testes de Integração

- Usar `*.integration.test.ts`.
- Isolar dados por schema/namespace de teste.
- Garantir cleanup no final de cada teste.
- Evitar dependências externas além do banco de teste.
