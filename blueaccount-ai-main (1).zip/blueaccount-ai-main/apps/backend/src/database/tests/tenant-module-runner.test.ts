import { beforeEach, describe, expect, it, vi } from "vitest";

const runnerMocks = vi.hoisted(() => {
  const createTenantModuleDataSource = vi.fn();
  const initialize = vi.fn();
  const destroy = vi.fn();
  const query = vi.fn();
  const runMigrations = vi.fn();

  class MockDataSource {
    initialize = initialize;
    destroy = destroy;
    query = query;
    runMigrations = runMigrations;
  }

  createTenantModuleDataSource.mockReturnValue(new MockDataSource());

  return {
    createTenantModuleDataSource,
    initialize,
    destroy,
    query,
    runMigrations,
  };
});

vi.mock("../modules/tenant/tenant-datasource.js", () => ({
  createTenantModuleDataSource: runnerMocks.createTenantModuleDataSource,
}));

const { runTenantMigrations, runModuleMigrations } = await import(
  "../tenant-module-runner.js"
);

describe("tenant-module-runner", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    runnerMocks.initialize.mockResolvedValue(undefined);
    runnerMocks.destroy.mockResolvedValue(undefined);
    runnerMocks.query.mockResolvedValue(undefined);
    runnerMocks.runMigrations.mockResolvedValue(undefined);
  });

  describe("runTenantMigrations", () => {
    it("initializes datasource for schema", async () => {
      await runTenantMigrations("escritorio_abc");

      expect(runnerMocks.initialize).toHaveBeenCalled();
    });

    it("creates schema if not exists", async () => {
      await runTenantMigrations("escritorio_abc");

      expect(runnerMocks.query).toHaveBeenCalledWith(
        expect.stringContaining("CREATE SCHEMA IF NOT EXISTS")
      );
    });

    it("runs migrations after creating schema", async () => {
      await runTenantMigrations("escritorio_xyz");

      expect(runnerMocks.runMigrations).toHaveBeenCalled();
    });

    it("destroys datasource after migrations", async () => {
      await runTenantMigrations("escritorio_abc");

      expect(runnerMocks.destroy).toHaveBeenCalled();
    });

    it("destroys datasource on migration error", async () => {
      runnerMocks.runMigrations.mockRejectedValueOnce(
        new Error("migration failed")
      );

      await expect(runTenantMigrations("escritorio_abc")).rejects.toThrow(
        "migration failed"
      );

      expect(runnerMocks.destroy).toHaveBeenCalled();
    });
  });

  describe("runModuleMigrations", () => {
    it("calls factory with schema name", async () => {
      const factory = vi.fn().mockReturnValue({
        initialize: runnerMocks.initialize,
        destroy: runnerMocks.destroy,
        query: runnerMocks.query,
        runMigrations: runnerMocks.runMigrations,
      });

      await runModuleMigrations("escritorio_abc", factory);

      expect(factory).toHaveBeenCalledWith("escritorio_abc");
    });

    it("handles migration errors gracefully", async () => {
      runnerMocks.runMigrations.mockRejectedValueOnce(
        new Error("migration failed")
      );

      await expect(
        runModuleMigrations("escritorio_abc", () => ({
          initialize: runnerMocks.initialize,
          destroy: runnerMocks.destroy,
          query: runnerMocks.query,
          runMigrations: runnerMocks.runMigrations,
        }))
      ).rejects.toThrow("migration failed");

      expect(runnerMocks.destroy).toHaveBeenCalled();
    });
  });
});
