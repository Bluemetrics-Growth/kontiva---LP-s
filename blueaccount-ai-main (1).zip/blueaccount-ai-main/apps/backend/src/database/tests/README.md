# `src/database/tests`

Documentação dos testes da camada de database (unitários e integração).

## Escopo

A pasta cobre:

- nomenclatura de schemas/roles de tenant;
- criação de datasource por tenant;
- execução de migrations por tenant;
- provisioning de schema/role de escritório;
- CLIs de provisioning e sync (`create-tenant-schemas`, `sync-tenant-schemas`);
- smoke tests de integração (`*.integration.test.ts`).

## Arquivos de Teste Atuais

### Unitários

- `data-source.test.ts`
- `tenant-naming.test.ts`
- `tenant-datasource-factory.test.ts`
- `tenant-module-runner.test.ts`
- `escritorio-schema.test.ts`
- `create-tenant-schemas.test.ts`
- `sync-tenant-schemas.test.ts`

### Integração

- `escritorio.integration.test.ts`
- `simple.integration.test.ts`

## Comandos

Na raiz:

```bash
npm run test --workspace apps/backend
npm run test:integration --workspace apps/backend
```

Na pasta backend:

```bash
npm run test
npm run test:integration
```

## Convenções

- Unitários: `*.test.ts`
- Integração: `*.integration.test.ts`
- Evitar dependência de rede externa.
- Para novos testes de migration/provisioning, priorizar asserts de comportamento observável (queries executadas, chamadas a runner, erros tratados).

## Observação Importante

A suíte de integração atual é smoke e ainda não valida provisioning real em PostgreSQL dedicado de teste. O backlog está em `GAPS.md`.
