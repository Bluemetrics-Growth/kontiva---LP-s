import { describe, expect, it, vi } from "vitest";
import type { DataSource } from "typeorm";
import type { DocumentStorage } from "../../infrastructure/document-storage.js";
import { limparSimulacoesAntigas } from "../limpar-simulacoes-antigas.js";

describe("limparSimulacoesAntigas", () => {
  it("limpa simulações e XMLs de todos os tenants sem tocar cadastros", async () => {
    const sqlExecutado: string[] = [];
    const query = vi.fn(async (sql: string) => {
      sqlExecutado.push(sql);
      if (sql.includes("public.escritorios")) return [{ id: "office-1" }, { id: "office-2" }];
      if (sql.includes("SELECT storage_key")) {
        return sql.includes("office_1")
          ? [{ storage_key: "office-1/simulacoes-nfe/nota.xml" }]
          : [];
      }
      if (sql.includes("AS simulacoes")) return [{ simulacoes: 2, grupos: 1 }];
      if (sql.includes("AS total")) return [{ total: 0 }];
      throw new Error(`SQL inesperado: ${sql}`);
    });
    const queryRunner = {
      connect: vi.fn(),
      startTransaction: vi.fn(),
      query: vi.fn(async (sql: string) => { sqlExecutado.push(sql); }),
      commitTransaction: vi.fn(),
      rollbackTransaction: vi.fn(),
      release: vi.fn(),
    };
    const dataSource = {
      query,
      createQueryRunner: vi.fn(() => queryRunner),
    } as unknown as Pick<DataSource, "query" | "createQueryRunner">;
    const storage = {
      put: vi.fn(),
      get: vi.fn(),
      delete: vi.fn(),
      list: vi.fn(async (prefix: string) => [
        { key: `${prefix}simulacoes-nfe/orfa.xml` },
        { key: `${prefix}documentos/preservar.pdf` },
      ]),
    } as unknown as DocumentStorage;

    const resumo = await limparSimulacoesAntigas(dataSource, storage);

    expect(resumo).toEqual({ tenants: 2, xmlsRemovidos: 3, simulacoesRemovidas: 4, gruposRemovidos: 2 });
    expect(storage.delete).toHaveBeenCalledWith("office-1/simulacoes-nfe/nota.xml");
    expect(storage.delete).toHaveBeenCalledWith("office-1/simulacoes-nfe/orfa.xml");
    expect(storage.delete).toHaveBeenCalledWith("office-2/simulacoes-nfe/orfa.xml");
    expect(storage.delete).not.toHaveBeenCalledWith(expect.stringContaining("documentos/preservar.pdf"));
    expect(sqlExecutado.join("\n")).not.toMatch(/DELETE FROM .*clientes|DELETE FROM .*fornecedores/i);
    expect(queryRunner.commitTransaction).toHaveBeenCalledTimes(2);
    expect(queryRunner.release).toHaveBeenCalledTimes(2);
  });

  it("faz rollback e libera a conexão quando uma exclusão falha", async () => {
    const queryRunner = {
      connect: vi.fn(),
      startTransaction: vi.fn(),
      query: vi.fn().mockRejectedValue(new Error("falha no banco")),
      commitTransaction: vi.fn(),
      rollbackTransaction: vi.fn(),
      release: vi.fn(),
    };
    const dataSource = {
      query: vi.fn(async (sql: string) => {
        if (sql.includes("public.escritorios")) return [{ id: "office-1" }];
        if (sql.includes("storage_key")) return [];
        return [{ simulacoes: 1, grupos: 0 }];
      }),
      createQueryRunner: vi.fn(() => queryRunner),
    } as unknown as Pick<DataSource, "query" | "createQueryRunner">;
    const storage = {
      put: vi.fn(), get: vi.fn(), delete: vi.fn(), list: vi.fn(async () => []),
    } as unknown as DocumentStorage;

    await expect(limparSimulacoesAntigas(dataSource, storage)).rejects.toThrow("falha no banco");
    expect(queryRunner.rollbackTransaction).toHaveBeenCalledOnce();
    expect(queryRunner.release).toHaveBeenCalledOnce();
  });
});
