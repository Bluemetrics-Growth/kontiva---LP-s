import { describe, expect, it, vi } from "vitest";
import { SetAgentcorePdfDefaultsForNewEscritorios1784500000000 } from "../modules/public/migrations/1784500000000-set_agentcore_pdf_defaults_for_new_escritorios.js";

describe("SetAgentcorePdfDefaultsForNewEscritorios1784500000000", () => {
  it("altera somente os defaults dos novos escritorios", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    const migration = new SetAgentcorePdfDefaultsForNewEscritorios1784500000000();

    await migration.up({ query } as never);

    const statements = query.mock.calls.map(([statement]) => statement as string);
    expect(statements).toEqual([
      `ALTER TABLE "escritorios" ALTER COLUMN "contract_extraction_engine" SET DEFAULT 'agent'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "contract_agent_input_mode" SET DEFAULT 'pdf'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "report_extraction_engine" SET DEFAULT 'agent'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "report_agent_input_mode" SET DEFAULT 'pdf'`,
    ]);
    expect(statements.join(" ")).not.toMatch(/\bUPDATE\b/i);
  });

  it("restaura apenas os defaults legados ao reverter", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    const migration = new SetAgentcorePdfDefaultsForNewEscritorios1784500000000();

    await migration.down({ query } as never);

    expect(query.mock.calls.map(([statement]) => statement)).toEqual([
      `ALTER TABLE "escritorios" ALTER COLUMN "contract_extraction_engine" SET DEFAULT 'converse'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "contract_agent_input_mode" SET DEFAULT 'ocr'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "report_extraction_engine" SET DEFAULT 'converse'`,
      `ALTER TABLE "escritorios" ALTER COLUMN "report_agent_input_mode" SET DEFAULT 'ocr'`,
    ]);
  });
});
