import { beforeEach, describe, expect, it, vi } from "vitest";

const provisoningMocks = vi.hoisted(() => {
  const runTenantMigrations = vi.fn();
  const managerQuery = vi.fn();

  return {
    runTenantMigrations,
    managerQuery,
  };
});

vi.mock("../tenant-module-runner.js", () => ({
  runTenantMigrations: provisoningMocks.runTenantMigrations,
}));

const { provisionEscritorioSchema } = await import("../escritorio-schema.js");

describe("provisionEscritorioSchema", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    provisoningMocks.runTenantMigrations.mockResolvedValue(undefined);
    provisoningMocks.managerQuery.mockResolvedValue([]);
  });

  it("creates schema with UUID", async () => {
    const manager = {
      query: provisoningMocks.managerQuery,
    };

    await provisionEscritorioSchema(
      manager as any,
      "550e8400-e29b-41d4-a716-446655440000"
    );

    expect(provisoningMocks.managerQuery).toHaveBeenCalledWith(
      expect.stringContaining("CREATE SCHEMA IF NOT EXISTS")
    );
  });

  it("creates NOLOGIN role", async () => {
    provisoningMocks.managerQuery.mockImplementation((sql: string) => {
      if (sql.includes("pg_roles")) {
        return [];
      }
      return undefined;
    });

    const manager = {
      query: provisoningMocks.managerQuery,
    };

    await provisionEscritorioSchema(manager as any, "office-1");

    const createRoleCalls = provisoningMocks.managerQuery.mock.calls.filter(
      (call: any[]) => call[0]?.includes("CREATE ROLE")
    );

    expect(createRoleCalls.length).toBeGreaterThan(0);
  });

  it("does not grant public table access", async () => {
    const manager = {
      query: provisoningMocks.managerQuery,
    };

    await provisionEscritorioSchema(manager as any, "office-123");

    const publicGrantCalls = provisoningMocks.managerQuery.mock.calls.filter(
      (call: any[]) => String(call[0]).includes("GRANT") && String(call[0]).includes("public")
    );

    expect(publicGrantCalls).toHaveLength(0);
    expect(provisoningMocks.managerQuery).toHaveBeenCalledWith(
      'REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM "user_escritorio_office_123"'
    );
  });

  it("applies tenant migrations", async () => {
    const manager = {
      query: provisoningMocks.managerQuery,
    };

    await provisionEscritorioSchema(manager as any, "office-456");

    expect(provisoningMocks.runTenantMigrations).toHaveBeenCalledWith(
      expect.stringContaining("escritorio_")
    );
  });

  it("grants CRUD permissions after migrations", async () => {
    const manager = {
      query: provisoningMocks.managerQuery,
    };

    await provisionEscritorioSchema(manager as any, "office-789");

    const grantCalls = provisoningMocks.managerQuery.mock.calls.filter(
      (call: any[]) =>
        call[0]?.includes("GRANT SELECT, INSERT, UPDATE, DELETE")
    );

    expect(grantCalls.length).toBeGreaterThan(0);
  });

  it("returns schema name on success", async () => {
    const manager = {
      query: provisoningMocks.managerQuery,
    };

    const result = await provisionEscritorioSchema(manager as any, "office-xyz");

    expect(result.schemaName).toMatch(/^escritorio_/);
  });
});
