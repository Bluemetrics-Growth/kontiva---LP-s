import { describe, expect, it } from "vitest";
import { buildEscritorioSchemaName, buildEscritorioRoleName } from "../tenant-naming.js";

describe("tenant naming", () => {
  it("builds schema name from UUID", () => {
    const id = "550e8400-e29b-41d4-a716-446655440000";
    const schema = buildEscritorioSchemaName(id);
    expect(schema).toBe("escritorio_550e8400_e29b_41d4_a716_446655440000");
  });

  it("normalizes hyphens to underscores", () => {
    const id = "my-office-123";
    const schema = buildEscritorioSchemaName(id);
    expect(schema).toBe("escritorio_my_office_123");
  });

  it("converts to lowercase", () => {
    const id = "MyOffice-ABC";
    const schema = buildEscritorioSchemaName(id);
    expect(schema).toBe("escritorio_myoffice_abc");
  });

  it("trims whitespace", () => {
    const id = "  office-123  ";
    const schema = buildEscritorioSchemaName(id);
    expect(schema).toBe("escritorio_office_123");
  });

  it("throws on empty id", () => {
    expect(() => buildEscritorioSchemaName("   ")).toThrow(
      "escritorio_id é obrigatório."
    );
  });

  it("builds role name from UUID", () => {
    const id = "550e8400-e29b-41d4-a716-446655440000";
    const role = buildEscritorioRoleName(id);
    expect(role).toBe("user_escritorio_550e8400_e29b_41d4_a716_446655440000");
  });

  it("normalizes role name hyphens", () => {
    const id = "my-office-123";
    const role = buildEscritorioRoleName(id);
    expect(role).toBe("user_escritorio_my_office_123");
  });

  it("throws on empty role id", () => {
    expect(() => buildEscritorioRoleName("")).toThrow(
      "escritorio_id é obrigatório."
    );
  });
});
