import { describe, expect, it, vi } from "vitest";
import { SeedRegrasLegaisNbs1789500000000 } from "../modules/public/migrations/1789500000000-seed_regras_legais_nbs.js";
import { REGRAS_LEGAIS_NBS } from "../modules/public/migrations/dados/regras-legais-nbs.js";

describe("REGRAS_LEGAIS_NBS (manifesto)", () => {
  it("não tem prefixo duplicado", () => {
    const codigos = REGRAS_LEGAIS_NBS.map((regra) => regra.codigo);
    expect(new Set(codigos).size).toBe(codigos.length);
  });

  it("todo código tem entre 3 e 9 dígitos, só numérico", () => {
    for (const regra of REGRAS_LEGAIS_NBS) {
      expect(regra.codigo).toMatch(/^[0-9]{3,9}$/);
    }
  });

  it("todo fator está entre 0 e 1", () => {
    for (const regra of REGRAS_LEGAIS_NBS) {
      expect(regra.fator).toBeGreaterThanOrEqual(0);
      expect(regra.fator).toBeLessThanOrEqual(1);
    }
  });

  it("tem mais de 30 regras curadas", () => {
    expect(REGRAS_LEGAIS_NBS.length).toBeGreaterThan(30);
  });
});

describe("SeedRegrasLegaisNbs1789500000000", () => {
  it("aplica UPDATE por código, sem INSERT, para cada regra do manifesto", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new SeedRegrasLegaisNbs1789500000000().up({ query } as never);

    expect(query).toHaveBeenCalledTimes(REGRAS_LEGAIS_NBS.length);
    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain('UPDATE "nbs_referencia"');
    expect(sql).not.toContain("INSERT INTO");
    expect(sql).toContain('"fatores_configurados" = true');
    expect(sql).toContain("'lc214'");

    const codigosAtualizados = query.mock.calls.map(([, parametros]) => (parametros as unknown[])[0]);
    expect(codigosAtualizados).toEqual(REGRAS_LEGAIS_NBS.map((regra) => regra.codigo));

    const parametrosArt127 = query.mock.calls.find(
      ([, parametros]) => (parametros as unknown[])[0] === "11301",
    )?.[1] as unknown[];
    expect(parametrosArt127).toEqual(["11301", 0.7, false, true, null, expect.any(String), expect.any(String)]);
  });

  it("down() reverte somente os códigos do manifesto, e só quando a origem ainda é lc214", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new SeedRegrasLegaisNbs1789500000000().down({ query } as never);

    expect(query).toHaveBeenCalledTimes(1);
    const [sql, parametros] = query.mock.calls[0] as [string, unknown[]];
    expect(sql).toContain('"fatores_configurados" = false');
    expect(sql).toContain("'nbs-2.0-anexo-b'");
    expect(sql).toContain('"origem_configuracao_fatores" = \'lc214\'');
    expect(parametros[0]).toEqual(REGRAS_LEGAIS_NBS.map((regra) => regra.codigo));
  });
});
