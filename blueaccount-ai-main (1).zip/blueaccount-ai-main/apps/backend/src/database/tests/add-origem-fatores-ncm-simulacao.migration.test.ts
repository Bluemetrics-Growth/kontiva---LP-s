import { describe, expect, it, vi } from "vitest";
import { AddOrigemFatoresNcmSimulacao1787900000000 } from "../modules/tenant/migrations/1787900000000-add-origem-fatores-ncm-simulacao.js";

describe("AddOrigemFatoresNcmSimulacao1787900000000", () => {
  it("marca fator histórico não nulo como manual sem alterar seu valor", async () => {
    const query = vi.fn().mockResolvedValue(undefined);
    await new AddOrigemFatoresNcmSimulacao1787900000000().up({ query } as never);

    const sql = query.mock.calls.map(([statement]) => statement as string).join(" ");
    expect(sql).toContain("CASE WHEN \"fator_ibs\" IS NULL THEN 'tratamento' ELSE 'manual' END");
    expect(sql).toContain("CASE WHEN \"fator_cbs\" IS NULL THEN 'tratamento' ELSE 'manual' END");
    expect(sql).not.toMatch(/SET\s+"fator_(?:ibs|cbs)"\s*=/i);
    expect(sql).toContain("('manual','ncm','acumulador','tratamento')");
  });
});
