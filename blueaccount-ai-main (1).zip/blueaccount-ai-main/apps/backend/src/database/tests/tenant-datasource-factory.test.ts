import { beforeEach, describe, expect, it, vi } from "vitest";

vi.stubEnv("DB_HOST", "localhost");
vi.stubEnv("DB_PORT", "5432");
vi.stubEnv("DB_USERNAME", "testuser");
vi.stubEnv("DB_PASSWORD", "testpass");
vi.stubEnv("DB_DATABASE", "testdb");
vi.stubEnv("DB_SSL", "false");
vi.stubEnv("DB_LOGGING", "false");

const { createTenantDataSource } = await import("../tenant-datasource-factory.js");

describe("createTenantDataSource", () => {
  beforeEach(() => {
    vi.stubEnv("DB_HOST", "localhost");
    vi.stubEnv("DB_PORT", "5432");
    vi.stubEnv("DB_USERNAME", "testuser");
    vi.stubEnv("DB_PASSWORD", "testpass");
    vi.stubEnv("DB_DATABASE", "testdb");
    vi.stubEnv("DB_SSL", "false");
  });

  it("creates datasource with tenant schema", () => {
    const ds = createTenantDataSource({
      schemaName: "escritorio_abc",
      entities: [],
      migrationsDir: "migrations",
    });

    expect(ds).toBeDefined();
    expect(ds.options.schema).toBe("escritorio_abc");
    expect(ds.options.database).toBe("testdb");
    expect(ds.options.username).toBe("testuser");
  });

  it("uses environment defaults", () => {
    const ds = createTenantDataSource({
      schemaName: "escritorio_test",
      entities: [],
      migrationsDir: "migrations",
    });

    expect(ds.options.host).toBe("localhost");
    expect(ds.options.port).toBe(5432);
    expect(ds.options.database).toBe("testdb");
  });

  it("configures migrations table name", () => {
    const ds = createTenantDataSource({
      schemaName: "escritorio_abc",
      entities: [],
      migrationsDir: "migrations",
    });

    expect(ds.options.migrationsTableName).toBe("_tenant_migrations");
  });

  it("sets search_path in connection extras", () => {
    const ds = createTenantDataSource({
      schemaName: "escritorio_xyz",
      entities: [],
      migrationsDir: "migrations",
    });

    expect(ds.options.extra?.options).toContain("escritorio_xyz");
  });

  it("respects DB_SSL environment variable", () => {
    vi.stubEnv("DB_SSL", "true");
    const ds = createTenantDataSource({
      schemaName: "escritorio_ssl",
      entities: [],
      migrationsDir: "migrations",
    });

    expect(ds.options.ssl).not.toBe(false);
    expect(ds.options.ssl).toBeTruthy();
  });
});
