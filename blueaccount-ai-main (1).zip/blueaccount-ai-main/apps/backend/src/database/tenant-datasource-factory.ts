import "reflect-metadata";
import { DataSource } from "typeorm";
import { config } from "dotenv";

config();

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (typeof value !== "string") return fallback;
  const n = value.trim().toLowerCase();
  if (["1", "true", "yes", "y", "on"].includes(n)) return true;
  if (["0", "false", "no", "n", "off"].includes(n)) return false;
  return fallback;
}

function parsePositiveInteger(value: string | undefined, fallback: number): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

export interface TenantDataSourceOptions {
  schemaName: string;
  entities: unknown[];
  migrationsDir: string;
}

/**
 * Cria um DataSource TypeORM apontado para o schema de um escritório específico.
 *
 * O TypeORM usa `schema` para definir o search_path da conexão:
 *   search_path = <schemaName>, public
 *
 * Isso garante que:
 *  - Todas as queries de migration operam no schema do tenant
 *  - FKs para public.escritorios / public.usuarios resolvem via search_path
 *  - A tabela _tenant_migrations é criada dentro do schema do tenant
 */
export function createTenantDataSource({ schemaName, entities, migrationsDir }: TenantDataSourceOptions): DataSource {
  const sslEnabled = parseBoolean(process.env.DB_SSL, false);
  const sslRejectUnauthorized = parseBoolean(process.env.DB_SSL_REJECT_UNAUTHORIZED, true);
  const lockTimeoutMs = parsePositiveInteger(process.env.DB_TENANT_MIGRATION_LOCK_TIMEOUT_MS, 5_000);
  const statementTimeoutMs = parsePositiveInteger(process.env.DB_TENANT_MIGRATION_STATEMENT_TIMEOUT_MS, 120_000);

  return new DataSource({
    type: "postgres",
    host: process.env.DB_HOST ?? "localhost",
    port: Number(process.env.DB_PORT ?? 5432),
    username: process.env.DB_USERNAME ?? "blueaccount",
    password: process.env.DB_PASSWORD ?? "blueaccount",
    database: process.env.DB_DATABASE ?? "blueaccount",
    schema: schemaName,
    synchronize: false,
    logging: process.env.DB_LOGGING === "true",
    ssl: sslEnabled ? { rejectUnauthorized: sslRejectUnauthorized } : false,
    extra: {
      options:
        `-c search_path=${schemaName},public ` +
        `-c lock_timeout=${lockTimeoutMs} ` +
        `-c statement_timeout=${statementTimeoutMs}`,
    },
    entities: entities as Parameters<DataSource["setOptions"]>[0]["entities"],
    migrations: [migrationsDir],
    migrationsTableName: "_tenant_migrations",
  });
}
