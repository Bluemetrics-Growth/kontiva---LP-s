import "reflect-metadata";
import { DataSource } from "typeorm";
import { config } from "dotenv";

config({ path: ".env.test" });

export const TestDataSource = new DataSource({
  type: "postgres",
  host: process.env.DB_HOST ?? "localhost",
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USERNAME ?? "testuser",
  password: process.env.DB_PASSWORD ?? "testpass",
  database: process.env.DB_DATABASE ?? "testdb",
  synchronize: false,
  logging: false,
  entities: ["src/database/modules/**/entities/*.entity.ts"],
  migrations: [
    "src/database/modules/public/migrations/*.ts",
    "src/database/modules/tenant/migrations/*.ts",
  ],
  migrationsTableName: "_migrations",
});
