#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { AppDataSource } from "./data-source.js";
import { provisionEscritorioSchema } from "./escritorio-schema.js";
import { buildEscritorioRoleName } from "./tenant-naming.js";

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

function uniqueValues(values: Array<string | null | undefined>): string[] {
  return [...new Set(values.filter((value): value is string => Boolean(value && value.trim())))]
    .map((value) => value.trim());
}

function resolveRuntimeRoles(): string[] {
  return uniqueValues([
    process.env.DB_AI_USERNAME,
    process.env.DB_USERNAME,
  ]);
}

async function grantTenantRoleMemberships(): Promise<void> {
  const escritorios = await AppDataSource.query('SELECT id FROM public.escritorios ORDER BY id ASC');
  const runtimeRoles = resolveRuntimeRoles();
  const existingRoles = await AppDataSource.query(
    "SELECT rolname FROM pg_roles WHERE rolname = ANY($1::text[])",
    [runtimeRoles],
  );
  const grantedRoles = new Set(
    Array.isArray(existingRoles) ? existingRoles.map((row) => String(row.rolname)) : [],
  );

  for (const escritorio of Array.isArray(escritorios) ? escritorios : []) {
    const roleName = buildEscritorioRoleName(String(escritorio.id));
    for (const runtimeRole of runtimeRoles) {
      if (!grantedRoles.has(runtimeRole)) {
        continue;
      }
      await AppDataSource.query(`GRANT ${quoteIdentifier(roleName)} TO ${quoteIdentifier(runtimeRole)}`);
    }
  }
}

async function reconcileTenantProvisioning(): Promise<void> {
  const escritorios = await AppDataSource.query("SELECT id FROM public.escritorios ORDER BY created_at ASC");
  for (const escritorio of Array.isArray(escritorios) ? escritorios : []) {
    const escritorioId = String(escritorio.id);
    await provisionEscritorioSchema(AppDataSource.manager, escritorioId);
  }
}

async function main() {
  const sqlPath = resolve(fileURLToPath(new URL("../../../../scripts/create-tenant-schemas.sql", import.meta.url)));
  const sql = await readFile(sqlPath, "utf8");

  if (!AppDataSource.isInitialized) {
    console.log("Initializing AppDataSource...");
    await AppDataSource.initialize();
    console.log("AppDataSource initialized.");
  }

  try {
    console.log("Creating tenant schemas from project datasource...");
    await AppDataSource.query(sql);
    console.log("SQL script done. Granting role memberships...");
    await grantTenantRoleMemberships();
    console.log("Role memberships done. Reconciling tenant provisioning...");
    await reconcileTenantProvisioning();
    console.log("Tenant schemas created.");
  } finally {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
    }
  }
}

main().catch((error) => {
  console.error("Failed to create tenant schemas:", error);
  process.exit(1);
});
