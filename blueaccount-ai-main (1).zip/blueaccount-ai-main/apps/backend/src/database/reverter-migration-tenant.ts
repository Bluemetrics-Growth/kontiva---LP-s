#!/usr/bin/env node
import "reflect-metadata";
import { config } from "dotenv";
import { createTenantModuleDataSource } from "./modules/tenant/tenant-datasource.js";

config();

function obterSchema(): string {
  const argumento = process.argv.find((item) => item.startsWith("--schema="));
  const schema = argumento?.slice("--schema=".length).trim() ?? "";
  if (!/^escritorio_[a-z0-9_]+$/i.test(schema)) {
    throw new Error("Informe um schema tenant válido com --schema=escritorio_<uuid>.");
  }
  return schema;
}

async function main(): Promise<void> {
  const schema = obterSchema();
  const dataSource = createTenantModuleDataSource(schema);
  await dataSource.initialize();
  try {
    await dataSource.undoLastMigration();
  } finally {
    await dataSource.destroy();
  }
}

main().catch((error) => {
  console.error("Falha ao reverter migration tenant:", error);
  process.exit(1);
});
