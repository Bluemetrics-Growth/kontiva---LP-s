import { runQueryWithRls } from "../database/data-source.js";

/**
 * Executes the excedentes_funcionarios resumo folha query and returns the results.
 * @returns {Promise<Array<any>>} Array of result rows
 */
export async function getExcedentesFuncionariosResumoFolha(escritorioId: string, { limit = 20, offset = 0, competencia }: { limit?: number; offset?: number; competencia?: string } = {}): Promise<{ data: any[]; total: number }> {
	// Build query with optional competencia filter
	const paginatedCompetenciaFilter = competencia ? `AND resumo_folha.competencia = $3` : '';
	const countCompetenciaFilter = competencia ? `AND resumo_folha.competencia = $1` : '';
	const paginatedQuery = `
		WITH excedentes_funcionarios AS (
			SELECT DISTINCT
				clientes.razao_social,
				clientes.cnpj AS cnpj_cliente,
				contratos.valor_original,
				clausulas_excedentes.referencia,
				COALESCE(clausulas_excedentes.quantidade_inicial, 1) AS quantidade_inicial,
				COALESCE(clausulas_excedentes.quantidade_final, 1.0e12) AS quantidade_final,
				clausulas_excedentes.valor,
				resumo_folha.colaboradores_ativos - COALESCE(clausulas_excedentes.quantidade_inicial, 1) AS quantidade_excedente,
				(resumo_folha.colaboradores_ativos - COALESCE(clausulas_excedentes.quantidade_inicial, 1))*clausulas_excedentes.valor AS valor_excedente,
				resumo_folha.competencia AS  "data",
				resumo_folha.colaboradores_ativos
			FROM clientes
			INNER JOIN contratos
				ON clientes.id = contratos.cliente_id
			INNER JOIN clausulas_excedentes
				ON contratos.id = clausulas_excedentes.contrato_id
			LEFT JOIN relatorios resumo_folha
				ON resumo_folha.cliente_id = clientes.id
				AND resumo_folha.relatorio_ativo
				AND resumo_folha.tipo_relatorio = 'resumo_folha'
				AND resumo_folha.colaboradores_ativos BETWEEN COALESCE(quantidade_inicial, 2) AND  COALESCE(quantidade_final, 1.0e12)
				${paginatedCompetenciaFilter}
			WHERE
				contratos.contrato_ativo
				AND clausulas_excedentes.referencia = 'empregados_ativos'
		)
		SELECT
			razao_social,
			cnpj_cliente,
			"data",
			sum(quantidade_excedente) AS quantidade_excedente_folha,
			sum(valor_excedente) AS valor_excedente_folha
		FROM excedentes_funcionarios
		GROUP BY
			razao_social,
			cnpj_cliente,
			"data"
		ORDER BY razao_social, cnpj_cliente, "data"
		LIMIT $1 OFFSET $2
	`;

	// Count query for total
	const countQuery = `
		WITH excedentes_funcionarios AS (
			SELECT DISTINCT
				clientes.razao_social,
				clientes.cnpj AS cnpj_cliente,
				contratos.valor_original,
				clausulas_excedentes.referencia,
				COALESCE(clausulas_excedentes.quantidade_inicial, 1) AS quantidade_inicial,
				COALESCE(clausulas_excedentes.quantidade_final, 1.0e12) AS quantidade_final,
				clausulas_excedentes.valor,
				resumo_folha.colaboradores_ativos - COALESCE(clausulas_excedentes.quantidade_inicial, 1) AS quantidade_excedente,
				(resumo_folha.colaboradores_ativos - COALESCE(clausulas_excedentes.quantidade_inicial, 1))*clausulas_excedentes.valor AS valor_excedente,
				resumo_folha.competencia AS  "data",
				resumo_folha.colaboradores_ativos
			FROM clientes
			INNER JOIN contratos 
				ON clientes.id = contratos.cliente_id 
			INNER JOIN clausulas_excedentes 
				ON contratos.id = clausulas_excedentes.contrato_id 
			LEFT JOIN relatorios resumo_folha
				ON resumo_folha.cliente_id = clientes.id
				AND resumo_folha.relatorio_ativo
				AND resumo_folha.tipo_relatorio = 'resumo_folha'
				AND resumo_folha.colaboradores_ativos BETWEEN COALESCE(quantidade_inicial, 2) AND  COALESCE(quantidade_final, 1.0e12)
				${countCompetenciaFilter}
			WHERE
				contratos.contrato_ativo
				AND clausulas_excedentes.referencia = 'empregados_ativos'
		)
		SELECT COUNT(*) FROM (
			SELECT 1
			FROM excedentes_funcionarios
			GROUP BY razao_social, cnpj_cliente, "data"
		) AS sub
	`;

	const paginationParams = competencia ? [limit, offset, competencia] : [limit, offset];
	const countParams = competencia ? [competencia] : [];

	const data = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
		return await manager.query(paginatedQuery, paginationParams);
	});

	const countResult = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
		return await manager.query(countQuery, countParams);
	});
	const total = parseInt(countResult[0]?.count || "0", 10);
	return { data, total };
}
