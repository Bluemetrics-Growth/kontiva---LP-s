import { AppDataSource } from "../../database/data-source.js";
import { Feedback, type FeedbackStatus } from "../../database/modules/public/entities/feedback.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";

export type FeedbackResumo = {
  id: string;
  escritorio_id: string | null;
  escritorio_nome: string | null;
  usuario_id: string | null;
  usuario_nome: string | null;
  usuario_email: string | null;
  email: string | null;
  mensagem: string;
  pagina: string | null;
  status: FeedbackStatus;
  created_at: Date | string;
  updated_at: Date | string;
};

export type CreateFeedbackInput = {
  escritorio_id?: string | null;
  usuario_id?: string | null;
  email?: string | null;
  mensagem: string;
  pagina?: string | null;
};

export type ListFeedbackInput = {
  page?: number;
  pageSize?: number;
  status?: FeedbackStatus;
  escritorio_id?: string;
  date_from?: string;
  date_to?: string;
};

export type ListFeedbackResult = {
  data: FeedbackResumo[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

export function isFeedbackStatus(value: unknown): value is FeedbackStatus {
  return value === "aberto" || value === "resolvido";
}

export async function createFeedback(input: CreateFeedbackInput): Promise<FeedbackResumo> {
  await ensureDatabase();

  const mensagem = input.mensagem?.trim();
  if (!mensagem) {
    throw new FeedbackValidationError("O campo 'mensagem' é obrigatório.");
  }

  const repo = AppDataSource.getRepository(Feedback);
  const feedback = repo.create({
    escritorio_id: input.escritorio_id?.trim() || null,
    usuario_id: input.usuario_id?.trim() || null,
    email: input.email?.trim() || null,
    mensagem,
    pagina: input.pagina?.trim() || null,
    status: "aberto",
  });

  const saved = await repo.save(feedback);
  const reloaded = await repo.findOne({
    where: { id: saved.id },
    relations: ["escritorio", "usuario"],
  });

  return mapFeedback(reloaded ?? saved);
}

export async function listFeedback(input: ListFeedbackInput = {}): Promise<ListFeedbackResult> {
  await ensureDatabase();

  const page = normalizePage(input.page);
  const pageSize = clampPageSize(input.pageSize);
  const repo = AppDataSource.getRepository(Feedback);
  const qb = repo
    .createQueryBuilder("feedback")
    .leftJoinAndSelect("feedback.escritorio", "escritorio")
    .leftJoinAndSelect("feedback.usuario", "usuario")
    .orderBy("feedback.created_at", "DESC")
    .skip((page - 1) * pageSize)
    .take(pageSize);

  if (input.status) {
    qb.andWhere("feedback.status = :status", { status: input.status });
  }

  if (input.escritorio_id?.trim()) {
    qb.andWhere("feedback.escritorio_id = :escritorio_id", { escritorio_id: input.escritorio_id.trim() });
  }

  if (input.date_from?.trim()) {
    qb.andWhere("feedback.created_at >= :date_from", { date_from: input.date_from.trim() });
  }

  if (input.date_to?.trim()) {
    qb.andWhere("feedback.created_at <= :date_to", { date_to: input.date_to.trim() });
  }

  const [rows, total] = await qb.getManyAndCount();
  return {
    data: rows.map(mapFeedback),
    total,
    page,
    pageSize,
    totalPages: Math.max(Math.ceil(total / pageSize), 1),
  };
}

export async function updateFeedbackStatus(
  id: string,
  status: FeedbackStatus,
): Promise<FeedbackResumo | null> {
  await ensureDatabase();

  const repo = AppDataSource.getRepository(Feedback);
  const feedback = await repo.findOne({ where: { id }, relations: ["escritorio", "usuario"] });
  if (!feedback) {
    return null;
  }

  feedback.status = status;
  await repo.save(feedback);
  return mapFeedback(feedback);
}

export class FeedbackValidationError extends Error {}

function mapFeedback(feedback: Feedback): FeedbackResumo {
  return {
    id: feedback.id,
    escritorio_id: feedback.escritorio_id,
    escritorio_nome: feedback.escritorio?.nome ?? null,
    usuario_id: feedback.usuario_id,
    usuario_nome: feedback.usuario?.nome ?? null,
    usuario_email: feedback.usuario?.email ?? null,
    email: feedback.email,
    mensagem: feedback.mensagem,
    pagina: feedback.pagina,
    status: feedback.status,
    created_at: feedback.created_at,
    updated_at: feedback.updated_at,
  };
}

function clampPageSize(value: number | undefined): number {
  if (!value || Number.isNaN(value)) return 25;
  return Math.min(Math.max(Math.trunc(value), 10), 100);
}

function normalizePage(value: number | undefined): number {
  if (!value || Number.isNaN(value)) return 1;
  return Math.max(Math.trunc(value), 1);
}
