# `src/domain/feedback`

Lógica de negócio para o feedback aberto enviado por usuários do produto.

## Responsabilidades

- validar e persistir feedback (`createFeedback`)
- listar feedback de forma paginada/filtrável para o painel admin (`listFeedback`)
- atualizar o status de triagem (`updateFeedbackStatus`)

## Persistência

O feedback vive no **schema público** (tabela `feedback`), pois é consumido apenas por administradores da plataforma — mesmo modelo de `contexto`/`agent_logs`. As funções usam `AppDataSource.getRepository(Feedback)` diretamente, **sem RLS**.

## Dependências

- `src/database/modules/public/entities/feedback.entity.ts` — entidade
- `src/domain/autenticacao` — `ensureDatabase`
- consumido por `src/modules/feedback`
