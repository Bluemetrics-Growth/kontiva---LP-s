import { beforeEach, describe, expect, it, vi } from "vitest";

const feedbackMocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();

  const queryBuilder = {
    leftJoinAndSelect: vi.fn(),
    orderBy: vi.fn(),
    skip: vi.fn(),
    take: vi.fn(),
    andWhere: vi.fn(),
    getManyAndCount: vi.fn(),
  };
  const feedbackRepo = {
    create: vi.fn((value) => value),
    save: vi.fn(),
    findOne: vi.fn(),
    createQueryBuilder: vi.fn(() => queryBuilder),
  };

  const AppDataSource = {
    isInitialized: true,
    initialize: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Feedback") return feedbackRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
  };

  return { ensureDatabase, queryBuilder, feedbackRepo, AppDataSource };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: feedbackMocks.ensureDatabase,
}));

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: feedbackMocks.AppDataSource,
}));

const { createFeedback, listFeedback, updateFeedbackStatus, FeedbackValidationError } = await import(
  "../feedback.service.js"
);

describe("feedback service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Builder methods are chainable.
    feedbackMocks.queryBuilder.leftJoinAndSelect.mockReturnValue(feedbackMocks.queryBuilder);
    feedbackMocks.queryBuilder.orderBy.mockReturnValue(feedbackMocks.queryBuilder);
    feedbackMocks.queryBuilder.skip.mockReturnValue(feedbackMocks.queryBuilder);
    feedbackMocks.queryBuilder.take.mockReturnValue(feedbackMocks.queryBuilder);
    feedbackMocks.queryBuilder.andWhere.mockReturnValue(feedbackMocks.queryBuilder);
  });

  it("rejects empty message", async () => {
    await expect(createFeedback({ mensagem: "   " })).rejects.toBeInstanceOf(FeedbackValidationError);
    expect(feedbackMocks.feedbackRepo.save).not.toHaveBeenCalled();
  });

  it("persists feedback derived from session identity and returns mapped row", async () => {
    feedbackMocks.feedbackRepo.save.mockResolvedValue({ id: "fb-1" });
    feedbackMocks.feedbackRepo.findOne.mockResolvedValue({
      id: "fb-1",
      escritorio_id: "esc-1",
      escritorio: { nome: "Escritório X" },
      usuario_id: "user-1",
      usuario: { nome: "João", email: "joao@example.com" },
      email: "joao@example.com",
      mensagem: "Tela travou",
      pagina: "/contratos/1",
      status: "aberto",
      created_at: "2026-06-15T10:00:00Z",
      updated_at: "2026-06-15T10:00:00Z",
    });

    const result = await createFeedback({
      escritorio_id: "esc-1",
      usuario_id: "user-1",
      email: "joao@example.com",
      mensagem: "Tela travou",
      pagina: "/contratos/1",
    });

    expect(feedbackMocks.feedbackRepo.create).toHaveBeenCalledWith(
      expect.objectContaining({ escritorio_id: "esc-1", usuario_id: "user-1", mensagem: "Tela travou", status: "aberto" }),
    );
    expect(result.escritorio_nome).toBe("Escritório X");
    expect(result.usuario_email).toBe("joao@example.com");
    expect(result.status).toBe("aberto");
  });

  it("lists feedback with pagination metadata", async () => {
    feedbackMocks.queryBuilder.getManyAndCount.mockResolvedValue([
      [
        {
          id: "fb-1",
          escritorio_id: null,
          escritorio: null,
          usuario_id: null,
          usuario: null,
          email: null,
          mensagem: "msg",
          pagina: null,
          status: "aberto",
          created_at: "2026-06-15T10:00:00Z",
          updated_at: "2026-06-15T10:00:00Z",
        },
      ],
      1,
    ]);

    const result = await listFeedback({ status: "aberto" });

    expect(feedbackMocks.queryBuilder.andWhere).toHaveBeenCalledWith("feedback.status = :status", { status: "aberto" });
    expect(result.total).toBe(1);
    expect(result.data).toHaveLength(1);
    expect(result.totalPages).toBe(1);
  });

  it("returns null when updating a missing feedback", async () => {
    feedbackMocks.feedbackRepo.findOne.mockResolvedValue(null);
    const result = await updateFeedbackStatus("missing", "resolvido");
    expect(result).toBeNull();
    expect(feedbackMocks.feedbackRepo.save).not.toHaveBeenCalled();
  });
});
