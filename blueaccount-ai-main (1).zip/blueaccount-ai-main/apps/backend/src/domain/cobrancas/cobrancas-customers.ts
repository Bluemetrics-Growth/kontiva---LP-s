import type { EntityManager } from "typeorm";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { ClientePlataformaCobranca } from "../../database/modules/tenant/entities/cliente-plataforma-cobranca.entity.js";
import type { PlataformaCobranca } from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";
import { buildProvedor } from "./provedor.factory.js";
import type { CobrancasServiceDeps } from "./cobrancas-context.js";

/** Resolve ou cria o customer externo e persiste o vínculo local para emissões futuras. */
export async function garantirCustomerExterno(
  deps: CobrancasServiceDeps,
  manager: EntityManager,
  plataforma: PlataformaCobranca,
  cliente: Cliente,
): Promise<string> {
  const mapRepo = manager.getRepository(ClientePlataformaCobranca);
  const existing = await mapRepo.findOne({
    where: { cliente_id: cliente.id, plataforma_id: plataforma.id },
  });

  const provedor = buildProvedor(plataforma, deps.crypto);
  const customerInput = {
    nome: cliente.razao_social,
    cpfCnpj: cliente.cnpj,
    email: cliente.email ?? null,
  };
  if (existing) {
    await provedor.atualizarCustomer?.(existing.id_externo_cliente, customerInput);
    return existing.id_externo_cliente;
  }

  const created = await provedor.criarCustomer({ ...customerInput });
  const row = mapRepo.create({
    escritorio_id: plataforma.escritorio_id,
    cliente_id: cliente.id,
    plataforma_id: plataforma.id,
    id_externo_cliente: created.idExterno,
  });
  await mapRepo.save(row);
  return created.idExterno;
}

/** Resolve um customer externo existente sem criar registros novos no provedor. */
export async function resolverCustomerExterno(
  deps: CobrancasServiceDeps,
  manager: EntityManager,
  plataforma: PlataformaCobranca,
  cliente: Cliente,
): Promise<string | null> {
  const mapRepo = manager.getRepository(ClientePlataformaCobranca);
  const existing = await mapRepo.findOne({
    where: { cliente_id: cliente.id, plataforma_id: plataforma.id },
  });
  if (existing) return existing.id_externo_cliente;

  const provedor = buildProvedor(plataforma, deps.crypto);
  const encontrado = await provedor.buscarCustomerPorDocumento(cliente.cnpj);
  if (!encontrado) return null;

  const row = mapRepo.create({
    escritorio_id: plataforma.escritorio_id,
    cliente_id: cliente.id,
    plataforma_id: plataforma.id,
    id_externo_cliente: encontrado.idExterno,
  });
  await mapRepo.save(row);
  return encontrado.idExterno;
}
