import type { CryptoService } from "../../infrastructure/security/crypto.service.js";
import type { PlataformasCobrancaService } from "./plataformas-cobranca.service.js";

export interface CobrancasServiceDeps {
  crypto: CryptoService;
  plataformas: PlataformasCobrancaService;
}
