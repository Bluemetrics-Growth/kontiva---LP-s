// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
import type { StatusCobranca } from "../../database/modules/tenant/entities/cobranca.entity.js";
import type { MembroPendente } from "./cobrancas-errors.js";

export interface EnviarCobrancaInput {
  valorACobrarId: string;
  escritorioId: string;
  approvalHash: string;
  idempotencyKey: string;
  vencimento?: string;
  billingType?: "BOLETO" | "PIX";
  edicoes?: unknown;
  usuarioNome?: string | null;
}

export interface PreviewCobrancaResult {
  emissivel: boolean;
  approval_hash: string | null;
  preview: Record<string, unknown>;
  /** Presente quando o registro não é emissível por regra de grupo econômico. */
  motivo_nao_emissivel?: "membro_grupo_consolidado" | "membros_pendentes" | "faturamento_existente" | "desatualizado";
  /** Filhas com contrato próprio sem cálculo/desatualizadas (VAC de holding). */
  membros_pendentes?: MembroPendente[];
}

export interface SincronizarFaturamentoInput {
  escritorioId: string;
  clienteId: string;
  /** Competência no formato MM/AAAA. */
  competencia: string;
}

export interface SincronizarFaturamentoResult {
  encontrado: boolean;
  competencia: string;
  total: number;
  quantidade: number;
  itens: Array<{
    id_externo: string;
    valor: number;
    vencimento: string;
    status: StatusCobranca;
    status_externo: string;
  }>;
}
