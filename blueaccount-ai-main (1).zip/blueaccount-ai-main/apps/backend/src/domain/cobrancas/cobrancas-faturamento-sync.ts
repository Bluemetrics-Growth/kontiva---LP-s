import { runQueryWithRls } from "../../database/data-source.js";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import { ValoresACobrar } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { resolverClientePagador } from "../clientes/grupo.service.js";
import { consolidarCompetencia } from "../valores-a-cobrar/consolidar.service.js";
import { PlataformaCobrancaAusenteError } from "./cobrancas-errors.js";
import { resolverCustomerExterno } from "./cobrancas-customers.js";
import type { CobrancasServiceDeps } from "./cobrancas-context.js";
import type { SincronizarFaturamentoInput, SincronizarFaturamentoResult } from "./cobrancas-types.js";
import { buildProvedor } from "./provedor.factory.js";
import { competenciaParaIntervaloVencimento, plataformaLabel } from "./cobrancas-utils.js";

/** Busca cobranças do provedor por competência e grava o faturamento observado correspondente. */
export async function sincronizarFaturamentoDoProvedor(
  deps: CobrancasServiceDeps,
  input: SincronizarFaturamentoInput,
): Promise<SincronizarFaturamentoResult> {
  const { de, ate } = competenciaParaIntervaloVencimento(input.competencia);

  const result = await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const plataforma = await deps.plataformas.getAtivaParaEscritorio(manager, input.escritorioId);
    if (!plataforma) throw new PlataformaCobrancaAusenteError();

    const cliente = await manager.getRepository(Cliente).findOne({
      where: { id: input.clienteId, escritorio_id: input.escritorioId },
    });
    if (!cliente) throw new Error("Cliente não encontrado.");

    const pagador = await resolverClientePagador(manager, input.escritorioId, cliente);
    const customerId = await resolverCustomerExterno(deps, manager, plataforma, pagador);
    if (!customerId) {
      return {
        encontrado: false,
        competencia: input.competencia,
        total: 0,
        quantidade: 0,
        itens: [],
      } satisfies SincronizarFaturamentoResult;
    }

    const provedor = buildProvedor(plataforma, deps.crypto);
    let cobrancas = (await provedor.listarCobrancas({
      customerExternoId: customerId,
      vencimentoDe: de,
      vencimentoAte: ate,
    })).filter((c) => !c.deletado);

    if (pagador.id !== cliente.id) {
      const vacsDoCliente = await manager.getRepository(ValoresACobrar).find({
        where: { cliente_id: cliente.id, escritorio_id: input.escritorioId },
        select: ["id"],
      });
      const vacIds = new Set(vacsDoCliente.map((v) => v.id));
      cobrancas = cobrancas.filter((c) => c.externalReference !== null && vacIds.has(c.externalReference));
    }

    const total = Number(cobrancas.reduce((sum, c) => sum + Number(c.valor ?? 0), 0).toFixed(2));
    const itens = cobrancas.map((c) => ({
      id_externo: c.idExterno,
      valor: c.valor,
      vencimento: c.vencimento,
      status: c.status,
      status_externo: c.statusExterno,
    }));

    const faturamentoRepo = manager.getRepository(Faturamento);
    const label = plataformaLabel(plataforma);
    const discriminacao = `${label} — ${cobrancas.length} cobrança(s) com vencimento em ${input.competencia}`;
    const payloadUi = {
      origem: "plataforma_cobranca",
      plataforma: plataforma.plataforma,
      intervalo_vencimento: { de, ate },
      itens,
    };
    const existente = await faturamentoRepo.findOne({
      where: {
        cliente_id: cliente.id,
        competencia: input.competencia,
        faturamento_ativo: true,
      },
    });
    if (existente) {
      existente.valor_cobrado = total;
      existente.razao_social = existente.razao_social ?? cliente.razao_social;
      existente.discriminacao = discriminacao;
      existente.arquivo_origem = `${label} (consulta)`;
      existente.payload_normalizado_ui = payloadUi;
      await faturamentoRepo.save(existente);
    } else {
      const novo = faturamentoRepo.create({
        escritorio_id: input.escritorioId,
        cliente_id: cliente.id,
        competencia: input.competencia,
        razao_social: cliente.razao_social,
        valor_cobrado: total,
        discriminacao,
        arquivo_origem: `${label} (consulta)`,
        payload_normalizado_ui: payloadUi,
        faturamento_ativo: true,
      });
      await faturamentoRepo.save(novo);
    }

    return {
      encontrado: true,
      competencia: input.competencia,
      total,
      quantidade: cobrancas.length,
      itens,
    } satisfies SincronizarFaturamentoResult;
  });

  if (result.encontrado) {
    setImmediate(() => {
      consolidarCompetencia(input.escritorioId, input.clienteId, input.competencia).catch((err) => {
        console.error("[sincronizarFaturamentoDoProvedor] consolidarCompetencia falhou:", err);
      });
    });
  }

  return result;
}
