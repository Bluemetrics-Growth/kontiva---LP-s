import { Inject, Injectable } from "@nestjs/common";
import type { EntityManager } from "typeorm";
import type Stripe from "stripe";
import type { Cobranca } from "../../database/modules/tenant/entities/cobranca.entity.js";
import type { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import type { PlataformaCobranca } from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";
import type { CryptoService } from "../../infrastructure/security/crypto.service.js";
import { CryptoService as CryptoServiceToken } from "../../infrastructure/security/crypto.service.js";
import { PlataformasCobrancaService } from "./plataformas-cobranca.service.js";
import type { CobrancasServiceDeps } from "./cobrancas-context.js";
import { garantirCustomerExterno as garantirCustomerExternoUseCase } from "./cobrancas-customers.js";
import { sincronizarFaturamentoDoProvedor as sincronizarFaturamentoDoProvedorUseCase } from "./cobrancas-faturamento-sync.js";
import { previewCobranca as previewCobrancaUseCase, enviarCobrancaParaValorACobrar as enviarCobrancaParaValorACobrarUseCase } from "./cobrancas-emissao.js";
import {
  aplicarStatusStripeWebhook as aplicarStatusStripeWebhookUseCase,
  aplicarStatusViaToken as aplicarStatusViaTokenUseCase,
  cancelar as cancelarUseCase,
  list as listUseCase,
  listPaginated as listPaginatedUseCase,
  retificar as retificarUseCase,
  sincronizar as sincronizarUseCase,
} from "./cobrancas-lifecycle.js";
import type {
  EnviarCobrancaInput,
  PreviewCobrancaResult,
  SincronizarFaturamentoInput,
  SincronizarFaturamentoResult,
} from "./cobrancas-types.js";

export { computeApprovalHash } from "./cobrancas-approval.js";
export { computeDescontoAdimplencia, parseDescontoAdimplencia } from "./cobrancas-desconto.js";
export {
  ApprovalHashMismatchError,
  CobrancaStaleError,
  FaturamentoExistenteError,
  MembroGrupoConsolidadoError,
  MembrosPendentesError,
  PlataformaCobrancaAusenteError,
  StatusNaoElegivelError,
  type MembroPendente,
} from "./cobrancas-errors.js";
export type {
  EnviarCobrancaInput,
  PreviewCobrancaResult,
  SincronizarFaturamentoInput,
  SincronizarFaturamentoResult,
} from "./cobrancas-types.js";

@Injectable()
export class CobrancasService {
  /** Recebe adaptadores compartilhados pela fachada e pelos casos de uso extraídos. */
  constructor(
    @Inject(CryptoServiceToken)
    private readonly crypto: CryptoService,
    @Inject(PlataformasCobrancaService)
    private readonly plataformas: PlataformasCobrancaService,
  ) {}

  /** Centraliza as dependências que os casos de uso transacionais recebem sem acoplar em Nest. */
  private get deps(): CobrancasServiceDeps {
    return { crypto: this.crypto, plataformas: this.plataformas };
  }

  /** Garante que o cliente tenha um customer externo reutilizável na plataforma ativa. */
  garantirCustomerExterno(
    manager: EntityManager,
    plataforma: PlataformaCobranca,
    cliente: Cliente,
  ): Promise<string> {
    return garantirCustomerExternoUseCase(this.deps, manager, plataforma, cliente);
  }

  /** Consulta cobranças existentes no provedor e grava o faturamento observado da competência. */
  sincronizarFaturamentoDoProvedor(
    input: SincronizarFaturamentoInput,
  ): Promise<SincronizarFaturamentoResult> {
    return sincronizarFaturamentoDoProvedorUseCase(this.deps, input);
  }

  /** Monta um preview sem efeito financeiro e devolve hash apenas quando o VAC é emissível. */
  previewCobranca(id: string, escritorioId: string): Promise<PreviewCobrancaResult | null> {
    return previewCobrancaUseCase(id, escritorioId);
  }

  /** Emite a cobrança no provedor após validar status, versão e approval hash. */
  enviarCobrancaParaValorACobrar(input: EnviarCobrancaInput): Promise<Cobranca> {
    return enviarCobrancaParaValorACobrarUseCase(this.deps, input);
  }

  /** Cancela a cobrança no provedor e persiste o status interno cancelado. */
  cancelar(id: string, escritorioId: string): Promise<Cobranca> {
    return cancelarUseCase(this.deps, id, escritorioId);
  }

  /** Atualiza valor, vencimento ou tipo de cobrança enquanto o status ainda permite retificação. */
  retificar(
    id: string,
    escritorioId: string,
    patch: { valor?: number; vencimento?: string; billing_type?: "BOLETO" | "PIX" },
  ): Promise<Cobranca> {
    return retificarUseCase(this.deps, id, escritorioId, patch);
  }

  /** Consulta o provedor e reaplica localmente o status externo mais recente. */
  sincronizar(id: string, escritorioId: string): Promise<Cobranca> {
    return sincronizarUseCase(this.deps, id, escritorioId);
  }

  /** Lista cobranças do escritório com filtros simples para compatibilidade do endpoint legado. */
  list(escritorioId: string, filtros: { status?: string; cliente_id?: string }): Promise<Cobranca[]> {
    return listUseCase(escritorioId, filtros);
  }

  /** Lista cobranças em modo paginado para telas operacionais com busca incremental. */
  listPaginated(
    escritorioId: string,
    filtros: { status?: string; cliente_id?: string; page?: number; pageSize?: number },
  ) {
    return listPaginatedUseCase(escritorioId, filtros);
  }

  /** Aplica um evento Asaas já autenticado pelo token salvo na plataforma. */
  aplicarStatusViaToken(payload: {
    payment?: { id?: string; status?: string; paymentDate?: string };
  }, plataforma: PlataformaCobranca): Promise<void> {
    return aplicarStatusViaTokenUseCase(payload, plataforma);
  }

  /** Valida e aplica um evento Stripe já reconstruído pelo controller a partir do raw body. */
  aplicarStatusStripeWebhook(event: Stripe.Event, plataforma: PlataformaCobranca): Promise<void> {
    return aplicarStatusStripeWebhookUseCase(event, plataforma);
  }
}
