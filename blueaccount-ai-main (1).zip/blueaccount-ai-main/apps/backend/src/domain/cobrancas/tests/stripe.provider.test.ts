import { describe, expect, it, vi } from "vitest";
import type { StripeClient } from "../../../infrastructure/external-services/stripe/stripe.client.js";
import { mapStripeInvoiceStatus, mapStripeWebhookEventStatus, StripeProvider } from "../provedores/stripe.provider.js";

function makeClient() {
  return {
    ping: vi.fn(),
    findCustomerByCpfCnpj: vi.fn(),
    createCustomer: vi.fn(),
    updateCustomer: vi.fn(),
    createInvoice: vi.fn(),
    retrieveInvoice: vi.fn(),
    listInvoices: vi.fn(),
    updateInvoice: vi.fn(),
    voidInvoice: vi.fn(),
  } as unknown as StripeClient & {
    findCustomerByCpfCnpj: ReturnType<typeof vi.fn>;
    createCustomer: ReturnType<typeof vi.fn>;
    updateCustomer: ReturnType<typeof vi.fn>;
    createInvoice: ReturnType<typeof vi.fn>;
    listInvoices: ReturnType<typeof vi.fn>;
  };
}

describe("StripeProvider", () => {
  it("maps invoice statuses to internal statuses", () => {
    expect(mapStripeInvoiceStatus("paid")).toBe("paga");
    expect(mapStripeInvoiceStatus("void")).toBe("cancelada");
    expect(mapStripeInvoiceStatus("uncollectible")).toBe("estornada");
    expect(mapStripeInvoiceStatus("open")).toBe("pendente");
    expect(mapStripeWebhookEventStatus("invoice.paid", "open")).toBe("paga");
  });

  it("reuses an existing customer by CNPJ before creating a new one", async () => {
    const client = makeClient();
    client.findCustomerByCpfCnpj.mockResolvedValue({ id: "cus_existing" });
    const provider = new StripeProvider(client);

    const result = await provider.criarCustomer({
      nome: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: null,
    });

    expect(result).toEqual({ idExterno: "cus_existing" });
    expect(client.findCustomerByCpfCnpj).toHaveBeenCalledWith("12.345.678/0001-90");
    expect(client.createCustomer).not.toHaveBeenCalled();
  });

  it("updates an existing customer with email when reusing it", async () => {
    const client = makeClient();
    client.findCustomerByCpfCnpj.mockResolvedValue({ id: "cus_existing" });
    const provider = new StripeProvider(client);

    const result = await provider.criarCustomer({
      nome: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: "financeiro@cliente.com.br",
    });

    expect(result).toEqual({ idExterno: "cus_existing" });
    expect(client.updateCustomer).toHaveBeenCalledWith("cus_existing", {
      name: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: "financeiro@cliente.com.br",
    });
    expect(client.createCustomer).not.toHaveBeenCalled();
  });

  it("creates an invoice in BRL cents and exposes the hosted URL as urlBoleto", async () => {
    const client = makeClient();
    client.createInvoice.mockResolvedValue({
      id: "in_123",
      status: "open",
      hosted_invoice_url: "https://invoice.stripe.com/i/test",
      amount_due: 12345,
      total: 12345,
      due_date: 1781568000,
      created: 1781568000,
      metadata: { valor_a_cobrar_id: "vac_1" },
    });
    const provider = new StripeProvider(client);

    const result = await provider.criarCobranca({
      customerExternoId: "cus_1",
      valor: 123.45,
      vencimento: "2026-06-15",
      billingType: "BOLETO",
      externalReference: "vac_1",
      descricao: "Kontiva",
      metadata: { escritorio_id: "esc_1", cliente_id: "cli_1" },
    });

    expect(client.createInvoice).toHaveBeenCalledWith({
      customer: "cus_1",
      amountCents: 12345,
      dueDate: "2026-06-15",
      description: "Kontiva",
      externalReference: "vac_1",
      metadata: {
        escritorio_id: "esc_1",
        cliente_id: "cli_1",
        valor_a_cobrar_id: "vac_1",
      },
    });
    expect(result).toMatchObject({
      idExterno: "in_123",
      statusExterno: "open",
      status: "pendente",
      urlBoleto: "https://invoice.stripe.com/i/test",
    });
  });

  it("filters listed invoices by due date and maps externalReference from metadata", async () => {
    const client = makeClient();
    client.listInvoices.mockResolvedValue([
      {
        id: "in_1",
        status: "paid",
        amount_due: 10000,
        due_date: 1781524800,
        created: 1781524800,
        metadata: { valor_a_cobrar_id: "vac_1" },
      },
      {
        id: "in_old",
        status: "open",
        amount_due: 5000,
        due_date: 1778846400,
        created: 1778846400,
        metadata: {},
      },
    ]);
    const provider = new StripeProvider(client);

    const result = await provider.listarCobrancas({
      customerExternoId: "cus_1",
      vencimentoDe: "2026-06-01",
      vencimentoAte: "2026-06-30",
    });

    expect(result).toEqual([
      {
        idExterno: "in_1",
        valor: 100,
        vencimento: "2026-06-15",
        statusExterno: "paid",
        status: "paga",
        deletado: false,
        externalReference: "vac_1",
      },
    ]);
  });
});
