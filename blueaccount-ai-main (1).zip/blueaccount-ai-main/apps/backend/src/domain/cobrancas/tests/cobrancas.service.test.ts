import { describe, expect, it, vi, beforeEach } from "vitest";

const cobrancaRepo = {
  findOne: vi.fn(),
  create: vi.fn((data: Record<string, unknown>) => ({ ...data })),
  save: vi.fn(),
};
const vacRepo = {
  find: vi.fn(),
  findOne: vi.fn(),
  save: vi.fn((v: unknown) => v),
};
const clienteMapRepo = {
  findOne: vi.fn(),
  create: vi.fn((data: Record<string, unknown>) => ({ ...data })),
  save: vi.fn(),
};
const clienteRepo = {
  find: vi.fn(),
  findOne: vi.fn(),
};
const contratoRepo = {
  find: vi.fn(),
  findOne: vi.fn(),
};

const reposByName: Record<string, unknown> = {
  Cobranca: cobrancaRepo,
  ValoresACobrar: vacRepo,
  ClientePlataformaCobranca: clienteMapRepo,
  Cliente: clienteRepo,
  Contrato: contratoRepo,
};

const mockManager = {
  getRepository: vi.fn((entity: { name: string }) => reposByName[entity.name]),
};

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: vi.fn((_ctx: unknown, fn: (m: typeof mockManager) => unknown) => fn(mockManager)),
}));

vi.mock("../provedor.factory.js", () => ({
  buildProvedor: vi.fn(),
}));

import { buildProvedor } from "../provedor.factory.js";
import {
  CobrancasService,
  computeApprovalHash,
  computeDescontoAdimplencia,
  parseDescontoAdimplencia,
  StatusNaoElegivelError,
  ApprovalHashMismatchError,
  CobrancaStaleError,
  FaturamentoExistenteError,
  MembroGrupoConsolidadoError,
  MembrosPendentesError,
} from "../cobrancas.service.js";

const buildProvedorMock = vi.mocked(buildProvedor);

const ESC = "esc_1";

function makeVac(overrides: Record<string, unknown> = {}) {
  return {
    id: "vac_1",
    escritorio_id: ESC,
    cliente_id: "cli_1",
    competencia: "08/2025",
    valores_calculados: { valor_base: 5180, excedentes: [{ valor_total: 358 }], total_excedentes: 358 },
    total: 5538,
    total_excedentes: 358,
    status: "pronto_para_revisao",
    cobranca_id: null,
    outros_servicos_prestados: [],
    explicacao_ia: "Base + excedentes.",
    cobranca_mitigacao: null,
    cliente: { id: "cli_1", cnpj: "24.606.870/0001-77", razao_social: "QUANTUM" },
    edicoes: null,
    ...overrides,
  };
}

function makeService() {
  const crypto = {} as never;
  const plataformas = {
    getAtivaParaEscritorio: vi.fn().mockResolvedValue({ id: "plat_1", escritorio_id: ESC }),
  } as never;
  return new CobrancasService(crypto, plataformas);
}

function makeProvedor() {
  return {
    criarCobranca: vi.fn().mockResolvedValue({
      idExterno: "pay_new",
      status: "pendente",
      statusExterno: "PENDING",
      urlBoleto: "https://b/x",
      urlPix: null,
      payload: {},
    }),
    criarCustomer: vi.fn(),
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  cobrancaRepo.create.mockImplementation((data: Record<string, unknown>) => ({ ...data }));
  vacRepo.save.mockImplementation((v: unknown) => v);
  vacRepo.find.mockResolvedValue([]);
  clienteRepo.find.mockResolvedValue([]);
  clienteRepo.findOne.mockResolvedValue(null);
  contratoRepo.find.mockResolvedValue([]);
  contratoRepo.findOne.mockResolvedValue(null);
  // Cliente já mapeado no provedor → evita criação de customer externo.
  clienteMapRepo.findOne.mockResolvedValue({ id_externo_cliente: "cust_1" });
});

describe("CobrancasService.enviarCobrancaParaValorACobrar (invariantes de servidor)", () => {
  it("emite quando pronto_para_revisao com hash válido + idempotency_key", async () => {
    const service = makeService();
    const vac = makeVac();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null); // sem replay anterior
    vacRepo.findOne.mockResolvedValue(vac);
    cobrancaRepo.save.mockImplementation((c: Record<string, unknown>) => ({ ...c, id: "cob_new" }));

    const result = await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_1",
      escritorioId: ESC,
      approvalHash: computeApprovalHash(vac),
      idempotencyKey: "idem_1",
    });

    expect(provedor.criarCobranca).toHaveBeenCalledTimes(1);
    expect(result.id).toBe("cob_new");
    expect(cobrancaRepo.create).toHaveBeenCalledWith(expect.objectContaining({ idempotency_key: "idem_1" }));
    expect(vac.status).toBe("enviado");
  });

  it("emite vac.total (honra desconto) em vez de recomputar base+excedentes", async () => {
    const service = makeService();
    // Desconto: vac.total (5000) < valor_base + excedentes (5538). A emissão deve
    // sair com 5000, não com o valor cheio recomputado das partes.
    const vac = makeVac({
      valores_calculados: {
        valor_base: 5180,
        excedentes: [{ valor_total: 358 }],
        total_excedentes: 358,
        valor_total_cobranca: 5000,
      },
      total: 5000,
    });
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    cobrancaRepo.save.mockImplementation((c: Record<string, unknown>) => ({ ...c, id: "cob_new" }));

    await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_1",
      escritorioId: ESC,
      approvalHash: computeApprovalHash(vac),
      idempotencyKey: "idem_desc",
    });

    expect(provedor.criarCobranca).toHaveBeenCalledWith(expect.objectContaining({ valor: 5000 }));
  });

  it.each(["aberto", "revisado", "enviado", "pago", "invalido"])(
    "rejeita emissão quando status=%s (StatusNaoElegivelError, sem tocar o provedor)",
    async (status) => {
      const service = makeService();
      const vac = makeVac({ status });
      const provedor = makeProvedor();
      buildProvedorMock.mockReturnValue(provedor as never);
      cobrancaRepo.findOne.mockResolvedValue(null);
      vacRepo.findOne.mockResolvedValue(vac);

      await expect(
        service.enviarCobrancaParaValorACobrar({
          valorACobrarId: "vac_1",
          escritorioId: ESC,
          approvalHash: computeApprovalHash(vac),
          idempotencyKey: "idem_x",
        }),
      ).rejects.toBeInstanceOf(StatusNaoElegivelError);
      expect(provedor.criarCobranca).not.toHaveBeenCalled();
    },
  );

  it("rejeita hash divergente (ApprovalHashMismatchError, sem tocar o provedor)", async () => {
    const service = makeService();
    const vac = makeVac();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_1",
        escritorioId: ESC,
        approvalHash: "hash_errado",
        idempotencyKey: "idem_x",
      }),
    ).rejects.toBeInstanceOf(ApprovalHashMismatchError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("rejeita emissão quando já existe faturamento observado no valor a cobrar", async () => {
    const service = makeService();
    const vac = makeVac({
      total_cobrado: 5538,
      linhagem: {
        contrato: null,
        relatorios: [],
        faturamento: [{ id: "fat_1", valor_cobrado: 5538, faturamento_ativo: true }],
        gerado_em: null,
      },
    });
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_1",
        escritorioId: ESC,
        approvalHash: computeApprovalHash(vac),
        idempotencyKey: "idem_fat",
      }),
    ).rejects.toBeInstanceOf(FaturamentoExistenteError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("rejeita emissão quando os insumos mudaram desde o último cálculo (CobrancaStaleError)", async () => {
    const service = makeService();
    const vac = makeVac({ stale: true, stale_motivo: "contrato reajustado" });
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_1",
        escritorioId: ESC,
        approvalHash: computeApprovalHash(vac),
        idempotencyKey: "idem_stale",
      }),
    ).rejects.toBeInstanceOf(CobrancaStaleError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("replay idempotente: mesma idempotency_key retorna a cobrança existente sem chamar o provedor", async () => {
    const service = makeService();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    const existente = { id: "cob_ja", idempotency_key: "idem_1" };
    cobrancaRepo.findOne.mockResolvedValue(existente); // achou emissão anterior

    const result = await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_1",
      escritorioId: ESC,
      approvalHash: "qualquer",
      idempotencyKey: "idem_1",
    });

    expect(result).toBe(existente);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
    expect(vacRepo.findOne).not.toHaveBeenCalled();
  });
});

describe("CobrancasService.previewCobranca (sem efeito financeiro)", () => {
  it("registro pronto_para_revisao → emissivel:true + approval_hash", async () => {
    const service = makeService();
    const vac = makeVac();
    vacRepo.findOne.mockResolvedValue(vac);

    const result = await service.previewCobranca("vac_1", ESC);

    expect(result?.emissivel).toBe(true);
    expect(result?.approval_hash).toBe(computeApprovalHash(vac));
  });

  it("registro pago → emissivel:false sem approval_hash", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(makeVac({ status: "pago" }));

    const result = await service.previewCobranca("vac_1", ESC);

    expect(result?.emissivel).toBe(false);
    expect(result?.approval_hash).toBeNull();
  });

  it("registro desatualizado (stale) → emissivel:false, motivo desatualizado, sem approval_hash", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(makeVac({ stale: true, stale_motivo: "contrato reajustado" }));

    const result = await service.previewCobranca("vac_1", ESC);

    expect(result?.emissivel).toBe(false);
    expect(result?.approval_hash).toBeNull();
    expect(result?.motivo_nao_emissivel).toBe("desatualizado");
  });

  it("registro com faturamento observado → emissivel:false sem approval_hash", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(makeVac({
      linhagem: {
        contrato: null,
        relatorios: [],
        faturamento: [{ id: "fat_1", valor_cobrado: 5538, faturamento_ativo: true }],
        gerado_em: null,
      },
    }));

    const result = await service.previewCobranca("vac_1", ESC);

    expect(result?.emissivel).toBe(false);
    expect(result?.approval_hash).toBeNull();
    expect(result?.motivo_nao_emissivel).toBe("faturamento_existente");
  });

  it("registro inexistente → null", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(null);
    expect(await service.previewCobranca("nope", ESC)).toBeNull();
  });
});

describe("grupo econômico híbrido (filha com contrato próprio)", () => {
  const FILHA = { id: "cli_f", cnpj: "11.111.111/0001-11", razao_social: "FILHA LTDA", holding_id: "cli_h" };
  const ITEM_FILHA = {
    cliente_id: "cli_f",
    cnpj: "11.111.111/0001-11",
    razao_social: "FILHA LTDA",
    contrato_id: "ctr_f",
    vac_id: "vac_f",
    total: 800,
    calculado: true,
    status: "revisado",
  };

  function makeVacHolding(overrides: Record<string, unknown> = {}) {
    return makeVac({
      id: "vac_h",
      cliente_id: "cli_h",
      cliente: { id: "cli_h", cnpj: "22.222.222/0001-22", razao_social: "HOLDING SA", holding_id: null },
      valores_calculados: {
        valor_base: 5180,
        excedentes: [{ valor_total: 358 }],
        total_excedentes: 358,
        cobrancas_membros: [ITEM_FILHA],
        valor_membros_total: 800,
      },
      total: 6338,
      linhagem: { contrato: null, relatorios: [], faturamento: [], grupo: { holding_id: "cli_h", membros_ids: ["cli_f"] } },
      ...overrides,
    });
  }

  function mockEstadoVivoDaFilha(vacFilha: Record<string, unknown> | null) {
    clienteRepo.find.mockResolvedValue([FILHA]);
    contratoRepo.find.mockResolvedValue([{ id: "ctr_f", cliente_id: "cli_f", contrato_ativo: true }]);
    vacRepo.find.mockResolvedValue(vacFilha ? [vacFilha] : []);
  }

  it("filha de grupo consolidado não emite (MembroGrupoConsolidadoError, sem tocar o provedor)", async () => {
    const service = makeService();
    const vac = makeVac({ cliente: { id: "cli_1", cnpj: "x", razao_social: "FILHA", holding_id: "cli_h" } });
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    // Holding do grupo tem contrato ativo → modo consolidado
    contratoRepo.findOne.mockResolvedValue({ id: "ctr_h", cliente_id: "cli_h", contrato_ativo: true });

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_1",
        escritorioId: ESC,
        approvalHash: computeApprovalHash(vac),
        idempotencyKey: "idem_f",
      }),
    ).rejects.toBeInstanceOf(MembroGrupoConsolidadoError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("preview de filha de grupo consolidado → emissivel:false com motivo membro_grupo_consolidado", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(
      makeVac({ cliente: { id: "cli_1", cnpj: "x", razao_social: "FILHA", holding_id: "cli_h" } }),
    );
    contratoRepo.findOne.mockResolvedValue({ id: "ctr_h", cliente_id: "cli_h", contrato_ativo: true });

    const result = await service.previewCobranca("vac_1", ESC);

    expect(result?.emissivel).toBe(false);
    expect(result?.approval_hash).toBeNull();
    expect(result?.motivo_nao_emissivel).toBe("membro_grupo_consolidado");
  });

  it("holding com filha sem cálculo → preview emissivel:false com membros_pendentes", async () => {
    const service = makeService();
    vacRepo.findOne.mockResolvedValue(makeVacHolding());
    mockEstadoVivoDaFilha(null); // filha não tem VAC na competência

    const result = await service.previewCobranca("vac_h", ESC);

    expect(result?.emissivel).toBe(false);
    expect(result?.motivo_nao_emissivel).toBe("membros_pendentes");
    expect(result?.membros_pendentes).toEqual([
      expect.objectContaining({ cliente_id: "cli_f", motivo: "sem_calculo" }),
    ]);
  });

  it("holding com filha pendente → emissão rejeitada (MembrosPendentesError)", async () => {
    const service = makeService();
    const vac = makeVacHolding();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    mockEstadoVivoDaFilha(null);

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_h",
        escritorioId: ESC,
        approvalHash: computeApprovalHash(vac),
        idempotencyKey: "idem_h",
      }),
    ).rejects.toBeInstanceOf(MembrosPendentesError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("holding com item desatualizado (total da filha mudou) → emissão rejeitada", async () => {
    const service = makeService();
    const vac = makeVacHolding();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    // Ao vivo a filha está em 900, mas o snapshot aprovado tem 800.
    mockEstadoVivoDaFilha({ id: "vac_f", cliente_id: "cli_f", total: 900, valores_calculados: { valor_base: 900 }, status: "revisado" });

    await expect(
      service.enviarCobrancaParaValorACobrar({
        valorACobrarId: "vac_h",
        escritorioId: ESC,
        approvalHash: computeApprovalHash(vac),
        idempotencyKey: "idem_h2",
      }),
    ).rejects.toBeInstanceOf(MembrosPendentesError);
    expect(provedor.criarCobranca).not.toHaveBeenCalled();
  });

  it("holding emissível: valor soma itens das filhas e descrição lista as empresas", async () => {
    const service = makeService();
    const vac = makeVacHolding();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    cobrancaRepo.save.mockImplementation((c: Record<string, unknown>) => ({ ...c, id: "cob_h" }));
    // Estado vivo bate com o snapshot aprovado.
    mockEstadoVivoDaFilha({ id: "vac_f", cliente_id: "cli_f", total: 800, valores_calculados: { valor_base: 800 }, status: "revisado" });

    await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_h",
      escritorioId: ESC,
      approvalHash: computeApprovalHash(vac),
      idempotencyKey: "idem_h3",
    });

    expect(provedor.criarCobranca).toHaveBeenCalledWith(
      expect.objectContaining({
        // 5180 (base) + 358 (excedentes) + 800 (filha)
        valor: 6338,
        descricao: expect.stringContaining("FILHA LTDA"),
      }),
    );
  });

  it("holding com desconto de adimplência do membro: envia discount FIXO condicional", async () => {
    const service = makeService();
    // Membro com 5% de adimplência sobre seu total (800) → R$ 40 de desconto agregado.
    const vac = makeVacHolding({
      valores_calculados: {
        valor_base: 5180,
        excedentes: [{ valor_total: 358 }],
        total_excedentes: 358,
        cobrancas_membros: [{ ...ITEM_FILHA, desconto_por_adimplencia: "5%" }],
        valor_membros_total: 800,
      },
    });
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    cobrancaRepo.save.mockImplementation((c: Record<string, unknown>) => ({ ...c, id: "cob_h" }));
    mockEstadoVivoDaFilha({ id: "vac_f", cliente_id: "cli_f", total: 800, valores_calculados: { valor_base: 800 }, status: "revisado" });

    await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_h",
      escritorioId: ESC,
      approvalHash: computeApprovalHash(vac),
      idempotencyKey: "idem_desc_grupo",
    });

    expect(provedor.criarCobranca).toHaveBeenCalledWith(
      expect.objectContaining({
        valor: 6338,
        desconto: { valor: 40, tipo: "FIXED", diasLimite: 0 },
      }),
    );
  });

  it("sem desconto de adimplência: não envia objeto desconto", async () => {
    const service = makeService();
    const vac = makeVacHolding();
    const provedor = makeProvedor();
    buildProvedorMock.mockReturnValue(provedor as never);
    cobrancaRepo.findOne.mockResolvedValue(null);
    vacRepo.findOne.mockResolvedValue(vac);
    cobrancaRepo.save.mockImplementation((c: Record<string, unknown>) => ({ ...c, id: "cob_h" }));
    mockEstadoVivoDaFilha({ id: "vac_f", cliente_id: "cli_f", total: 800, valores_calculados: { valor_base: 800 }, status: "revisado" });

    await service.enviarCobrancaParaValorACobrar({
      valorACobrarId: "vac_h",
      escritorioId: ESC,
      approvalHash: computeApprovalHash(vac),
      idempotencyKey: "idem_sem_desc",
    });

    expect(provedor.criarCobranca).toHaveBeenCalledWith(expect.not.objectContaining({ desconto: expect.anything() }));
  });
});

describe("parseDescontoAdimplencia", () => {
  it("interpreta percentual", () => {
    expect(parseDescontoAdimplencia("5%")).toEqual({ tipo: "PERCENTAGE", valor: 5 });
    expect(parseDescontoAdimplencia("17,5%")).toEqual({ tipo: "PERCENTAGE", valor: 17.5 });
  });
  it("interpreta valor fixo em R$", () => {
    expect(parseDescontoAdimplencia("R$ 100")).toEqual({ tipo: "FIXED", valor: 100 });
    expect(parseDescontoAdimplencia("R$ 1.250,50")).toEqual({ tipo: "FIXED", valor: 1250.5 });
  });
  it("número puro ≤ 100 é percentual; > 100 é fixo", () => {
    expect(parseDescontoAdimplencia("5")).toEqual({ tipo: "PERCENTAGE", valor: 5 });
    expect(parseDescontoAdimplencia("250")).toEqual({ tipo: "FIXED", valor: 250 });
  });
  it("vazio/inválido → null", () => {
    expect(parseDescontoAdimplencia(null)).toBeNull();
    expect(parseDescontoAdimplencia("")).toBeNull();
    expect(parseDescontoAdimplencia("isento")).toBeNull();
  });
});

describe("computeDescontoAdimplencia", () => {
  it("agrega próprio (percentual sobre base+excedentes) + membros", () => {
    const vac = {
      valores_contratados: { desconto_por_adimplencia: "10%" },
      valores_calculados: {
        valor_base: 1000,
        cobrancas_membros: [
          { total: 4800, calculado: true, desconto_por_adimplencia: "5%" },
          { total: 2000, calculado: true, ja_cobrado_individualmente: true, desconto_por_adimplencia: "5%" },
        ],
      },
      total_excedentes: 200,
    };
    // próprio: 10% de (1000+200)=120; membro cobrável: 5% de 4800=240; membro já cobrado: ignorado.
    expect(computeDescontoAdimplencia(vac)).toBe(360);
  });

  it("holding sem desconto + membro 5%: só o do membro", () => {
    const vac = {
      valores_contratados: { desconto_por_adimplencia: null },
      valores_calculados: { valor_base: 0, cobrancas_membros: [{ total: 4800, calculado: true, desconto_por_adimplencia: "5%" }] },
      total_excedentes: 0,
    };
    expect(computeDescontoAdimplencia(vac)).toBe(240);
  });

  it("sem desconto em lugar nenhum → 0", () => {
    const vac = {
      valores_contratados: {},
      valores_calculados: { valor_base: 3000, cobrancas_membros: [] },
      total_excedentes: 0,
    };
    expect(computeDescontoAdimplencia(vac)).toBe(0);
  });
});
