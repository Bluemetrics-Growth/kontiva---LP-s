import { describe, expect, it } from "vitest";
import { buildComparacaoItems } from "../cobranca.service.js";

describe("cobranca service", () => {
  it("builds comparison items from the latest supported reports", () => {
    const items = buildComparacaoItems({
      servicos: {
        numero_de_documentos: 100,
        numero_de_colaboradores: 10,
        numero_de_prolabores: 2,
      } as never,
      relatorios: [
        {
          tipo_relatorio: "resumo_folha",
          colaboradores_ativos: 12,
          prolabores_ativos: 3,
          admissoes: 1,
          rescisoes: 0,
        } as never,
        {
          tipo_relatorio: "numero_de_documentos",
          total_notas_fiscais: 140,
          total_lancamentos: 9,
        } as never,
        {
          tipo_relatorio: "numero_notas_fiscais",
          total_notas_fiscais: 130,
        } as never,
        {
          tipo_relatorio: "lancamentos_contabeis",
          total_lancamentos: 8,
        } as never,
      ],
    });

    expect(items).toEqual([
      {
        label: "Colaboradores",
        contratado: 10,
        realizado: 12,
        excedente: 2,
      },
      {
        label: "Pró-labores",
        contratado: 2,
        realizado: 3,
        excedente: 1,
      },
      {
        label: "Documentos (NFs)",
        contratado: 100,
        realizado: 140,
        excedente: 40,
      },
      {
        label: "Lançamentos contábeis",
        contratado: null,
        realizado: 8,
        excedente: null,
      },
      {
        label: "Admissões",
        contratado: null,
        realizado: 1,
        excedente: null,
      },
      {
        label: "Rescisões",
        contratado: null,
        realizado: 0,
        excedente: null,
      },
    ]);
  });
});
