import { describe, expect, it, vi, beforeEach } from "vitest";
import { PlataformasCobrancaService } from "../plataformas-cobranca.service.js";

const mockRepo = {
  find: vi.fn(),
  findOne: vi.fn(),
  create: vi.fn(),
  save: vi.fn(),
  delete: vi.fn().mockResolvedValue({}),
  createQueryBuilder: vi.fn(),
};

const mockManager = {
  getRepository: vi.fn().mockReturnValue(mockRepo),
};

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: vi.fn((_ctx: unknown, fn: (m: typeof mockManager) => unknown) => fn(mockManager)),
}));

vi.mock("../provedor.factory.js", () => ({
  buildProvedor: vi.fn(),
}));

vi.mock("../../../settings.js", () => ({
  settings: { PUBLIC_BASE_URL: "https://app.kontiva.com.br" },
}));

import { buildProvedor } from "../provedor.factory.js";

const buildProvedorMock = vi.mocked(buildProvedor);

function makeCrypto() {
  return {
    encrypt: vi.fn().mockReturnValue({ ciphertext: "c", iv: "i", tag: "t" }),
    decrypt: vi.fn().mockReturnValue("api_key_decrypted"),
    mask: vi.fn().mockReturnValue("****key"),
  } as never;
}

function makePlataformaEntity(overrides = {}) {
  return {
    id: "plat_123",
    escritorio_id: "esc_1",
    plataforma: "asaas",
    ambiente: "sandbox",
    api_key_encrypted: "c",
    api_key_iv: "i",
    api_key_tag: "t",
    api_key_hint: "****key",
    webhook_secret_encrypted: null,
    webhook_secret_iv: null,
    webhook_secret_tag: null,
    webhook_secret_hint: null,
    webhook_auth_token: "tok_abc",
    webhook_id_externo: null,
    ativo: true,
    created_at: new Date("2026-01-01"),
    updated_at: new Date("2026-01-01"),
    ...overrides,
  };
}

describe("PlataformasCobrancaService.create", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    const qb = {
      update: vi.fn().mockReturnThis(),
      set: vi.fn().mockReturnThis(),
      where: vi.fn().mockReturnThis(),
      execute: vi.fn().mockResolvedValue({}),
    };
    mockRepo.createQueryBuilder.mockReturnValue(qb);
    mockRepo.create.mockImplementation((data: object) => ({ ...makePlataformaEntity(), ...data }));
    mockRepo.save.mockImplementation((entity: object) => Promise.resolve(entity));
  });

  it("registra o webhook na Asaas e salva webhook_id_externo quando criação tem sucesso", async () => {
    const provedor = { registrarWebhook: vi.fn().mockResolvedValue({ idExterno: "wbh_456" }) };
    buildProvedorMock.mockReturnValue(provedor as never);

    const service = new PlataformasCobrancaService(makeCrypto());
    const result = await service.create(
      "esc_1",
      { plataforma: "asaas", ambiente: "sandbox", api_key: "key_test_123" },
      "contato@escritorio.com",
    );

    expect(provedor.registrarWebhook).toHaveBeenCalledWith(
      expect.objectContaining({
        url: "https://app.kontiva.com.br/api/webhooks/cobrancas/asaas/esc_1",
        email: "contato@escritorio.com",
      }),
    );
    expect(result.webhook_id_externo).toBe("wbh_456");
  });

  it("lança erro e deleta a plataforma quando o registro do webhook falha", async () => {
    const provedor = { registrarWebhook: vi.fn().mockRejectedValue(new Error("Asaas indisponível")) };
    buildProvedorMock.mockReturnValue(provedor as never);

    const service = new PlataformasCobrancaService(makeCrypto());
    await expect(
      service.create(
        "esc_1",
        { plataforma: "asaas", ambiente: "sandbox", api_key: "key_test_123" },
        "contato@escritorio.com",
      ),
    ).rejects.toThrow("Falha ao registrar webhook na Asaas");

    expect(mockRepo.delete).toHaveBeenCalledWith("plat_123");
  });

  it("não tenta registrar webhook quando registrar_webhook é false", async () => {
    const provedor = { registrarWebhook: vi.fn() };
    buildProvedorMock.mockReturnValue(provedor as never);

    const service = new PlataformasCobrancaService(makeCrypto());
    await service.create(
      "esc_1",
      { plataforma: "asaas", ambiente: "sandbox", api_key: "key_test_123", registrar_webhook: false },
      "contato@escritorio.com",
    );

    expect(provedor.registrarWebhook).not.toHaveBeenCalled();
  });

  it("cadastra Stripe com webhook secret encriptado e não tenta registrar webhook remoto", async () => {
    const provedor = { registrarWebhook: vi.fn() };
    buildProvedorMock.mockReturnValue(provedor as never);
    const crypto = makeCrypto();

    const service = new PlataformasCobrancaService(crypto);
    const result = await service.create(
      "esc_1",
      {
        plataforma: "stripe",
        ambiente: "sandbox",
        api_key: "sk_test_123",
        webhook_secret: "whsec_123",
        registrar_webhook: true,
      },
      "contato@escritorio.com",
    );

    expect(crypto.encrypt).toHaveBeenCalledWith("sk_test_123");
    expect(crypto.encrypt).toHaveBeenCalledWith("whsec_123");
    expect(provedor.registrarWebhook).not.toHaveBeenCalled();
    expect(result.plataforma).toBe("stripe");
    expect(result.webhook_secret_hint).toBe("****key");
  });
});
