import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const cobrancaTests: any[] = [];
  const cobrancaTestRepo = {
    create: vi.fn((input) => input),
    save: vi.fn(async (input) => {
      const saved = {
        ...input,
        id: input.id ?? "test-1",
        created_at: input.created_at ?? new Date("2026-06-01T00:00:00Z"),
        updated_at: new Date("2026-06-01T00:00:00Z"),
      };
      const index = cobrancaTests.findIndex((item) => item.id === saved.id);
      if (index >= 0) cobrancaTests[index] = saved;
      else cobrancaTests.push(saved);
      return saved;
    }),
    findOne: vi.fn(async ({ where }) => cobrancaTests.find((item) => item.id === where.id) ?? null),
    find: vi.fn(async () => cobrancaTests),
  };
  const valoresRepo = {
    findOne: vi.fn(),
  };
  const versaoRepo = {
    findOne: vi.fn(async () => ({
      id: "versao-1",
      versao: 1,
      input_hash: "hash",
      total: 150,
      total_excedentes: 50,
      valores_calculados: { valor_total_cobranca: 150 },
      created_at: new Date("2026-06-01T00:00:00Z"),
    })),
  };
  const runQueryWithRls = vi.fn(async (_ctx, callback) => {
    const manager = {
      getRepository: vi.fn((entity: { name?: string }) => {
        if (entity?.name === "CobrancaTest") return cobrancaTestRepo;
        if (entity?.name === "ValoresACobrar") return valoresRepo;
        if (entity?.name === "ValoresACobrarVersao") return versaoRepo;
        throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
      }),
    };
    return callback(manager);
  });
  const isEscritorioTeste = vi.fn(async () => true);
  const gerarCobranca = vi.fn();
  const readS3ObjectText = vi.fn();
  const agentInvokeJsonText = vi.fn();
  const settings = {
    REGION: "us-east-1",
    COBRANCA_TEST_SYNC_TIMEOUT_MS: 20,
    GRADER_AGENT_RUNTIME_ARN: "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/GraderAgent",
    GRADER_AGENT_RUNTIME_QUALIFIER: "",
  };
  return {
    cobrancaTests,
    cobrancaTestRepo,
    valoresRepo,
    versaoRepo,
    runQueryWithRls,
    isEscritorioTeste,
    gerarCobranca,
    readS3ObjectText,
    agentInvokeJsonText,
    settings,
  };
});

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: mocks.runQueryWithRls,
}));

vi.mock("../../escritorios/escritorio.service.js", () => ({
  isEscritorioAmbienteTesteCobranca: mocks.isEscritorioTeste,
}));

vi.mock("../../valores-a-cobrar/gerar-cobranca.service.js", () => ({
  gerarCobranca: mocks.gerarCobranca,
}));

vi.mock("../../../settings.js", () => ({
  settings: mocks.settings,
}));

vi.mock("../../../infrastructure/external-services/agentcore-runtime.client.js", () => ({
  AgentCoreRuntimeClient: vi.fn(function AgentCoreRuntimeClient() {
    return {
      readS3ObjectText: mocks.readS3ObjectText,
      invokeJsonText: mocks.agentInvokeJsonText,
    };
  }),
}));

const {
  runCobrancaTest,
  CobrancaEvalForbiddenError,
} = await import("../cobranca-tests.service.js");

const VAC_CONCLUIDO = {
  id: "vac-1",
  escritorio_id: "office-1",
  cliente_id: "cliente-1",
  contrato_id: "contrato-1",
  competencia: "05/2026",
  valores_contratados: { valor_mensal: 100 },
  valores_observados: { resumo_folha: { colaboradores: 11 } },
  valores_calculados: { valor_total_cobranca: 150 },
  outros_servicos_prestados: [{ descricao: "Extra", valor: 50 }],
  linhagem: { contrato: { id: "contrato-1" }, relatorios: [], faturamento: [], gerado_em: null },
  total: 150,
  total_excedentes: 50,
  versao_ativa_id: "versao-1",
  agente_status: "concluido",
  agente_trace_id: "billing-trace-1",
  agente_erro: null,
  agente_cobranca_output_s3_path: "s3://bucket/cobranca/output.json",
};

function resetSuccessMocks() {
  mocks.cobrancaTests.length = 0;
  mocks.valoresRepo.findOne.mockResolvedValue(VAC_CONCLUIDO);
  mocks.gerarCobranca.mockResolvedValue(VAC_CONCLUIDO);
  mocks.readS3ObjectText.mockResolvedValue(JSON.stringify({ result: { valor_total_cobranca: 150 } }));
  mocks.agentInvokeJsonText.mockResolvedValue(JSON.stringify({ grade: 92, explanation: "Cobrança correta." }));
}

describe("cobranca-tests.service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.settings.COBRANCA_TEST_SYNC_TIMEOUT_MS = 20;
    mocks.isEscritorioTeste.mockResolvedValue(true);
    resetSuccessMocks();
  });

  it("bloqueia escritório que não é ambiente de teste", async () => {
    mocks.isEscritorioTeste.mockResolvedValue(false);

    await expect(runCobrancaTest("office-1", { valor_a_cobrar_id: "vac-1" }, { sessionId: "session" }))
      .rejects.toBeInstanceOf(CobrancaEvalForbiddenError);
    expect(mocks.gerarCobranca).not.toHaveBeenCalled();
  });

  it("reusa cobrança já concluída, lê output S3, chama GraderAgent e salva aprovado", async () => {
    const result = await runCobrancaTest("office-1", { valor_a_cobrar_id: "vac-1" }, { sessionId: "session" });

    expect(mocks.gerarCobranca).not.toHaveBeenCalled();
    const graderPayload = mocks.agentInvokeJsonText.mock.calls[0][0].payload;
    expect(graderPayload.prompt).toContain("valor_total_cobranca");
    expect(graderPayload.target).toContain("valores_contratados");
    expect(graderPayload.grading_instructions).toContain("Valores certos");
    expect(result.status).toBe("aprovado");
    expect(result.grade).toBe(92);
    expect(result.agent_response).toContain("valor_total_cobranca");
  });

  it("salva erro e não chama agente de cobrança quando não há output avaliável", async () => {
    const vacAberto = {
      ...VAC_CONCLUIDO,
      agente_status: null,
      agente_trace_id: null,
      agente_cobranca_output_s3_path: null,
    };
    mocks.valoresRepo.findOne.mockResolvedValue(vacAberto);

    const result = await runCobrancaTest("office-1", { valor_a_cobrar_id: "vac-1" }, { sessionId: "session" });

    expect(mocks.gerarCobranca).not.toHaveBeenCalled();
    expect(mocks.agentInvokeJsonText).not.toHaveBeenCalled();
    expect(result.status).toBe("erro");
    expect(result.erro).toContain("não possui output avaliável");
  });

  it("salva erro quando cobrança não conclui antes do timeout", async () => {
    mocks.settings.COBRANCA_TEST_SYNC_TIMEOUT_MS = 1;
    const vacProcessando = { ...VAC_CONCLUIDO, agente_status: "em_processamento", agente_cobranca_output_s3_path: null };
    mocks.valoresRepo.findOne.mockResolvedValue(vacProcessando);

    const result = await runCobrancaTest("office-1", { valor_a_cobrar_id: "vac-1" }, { sessionId: "session" });

    expect(mocks.gerarCobranca).not.toHaveBeenCalled();
    expect(result.status).toBe("erro");
    expect(result.erro).toContain("não concluiu");
    expect(mocks.agentInvokeJsonText).not.toHaveBeenCalled();
  });
});
