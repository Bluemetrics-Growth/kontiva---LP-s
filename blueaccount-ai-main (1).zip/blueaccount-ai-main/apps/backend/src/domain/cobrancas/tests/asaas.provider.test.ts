import { describe, expect, it, vi } from "vitest";
import { AsaasApiError, type AsaasClient } from "../../../infrastructure/external-services/asaas/asaas.client.js";
import { AsaasProvider } from "../provedores/asaas.provider.js";

function makeClient() {
  return {
    findCustomerByCpfCnpj: vi.fn(),
    createCustomer: vi.fn(),
    createWebhook: vi.fn(),
    listPayments: vi.fn(),
  } as unknown as AsaasClient & {
    findCustomerByCpfCnpj: ReturnType<typeof vi.fn>;
    createCustomer: ReturnType<typeof vi.fn>;
    createWebhook: ReturnType<typeof vi.fn>;
    listPayments: ReturnType<typeof vi.fn>;
  };
}

describe("AsaasProvider", () => {
  it("reuses an existing customer by CPF/CNPJ before creating a new one", async () => {
    const client = makeClient();
    client.findCustomerByCpfCnpj.mockResolvedValue({ id: "cus_existing", name: "Cliente", cpfCnpj: "12345678000190" });
    const provider = new AsaasProvider(client);

    const result = await provider.criarCustomer({
      nome: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: null,
    });

    expect(result).toEqual({ idExterno: "cus_existing" });
    expect(client.findCustomerByCpfCnpj).toHaveBeenCalledWith("12345678000190");
    expect(client.createCustomer).not.toHaveBeenCalled();
  });

  it("creates a customer when no Asaas record exists", async () => {
    const client = makeClient();
    client.findCustomerByCpfCnpj.mockResolvedValue(null);
    client.createCustomer.mockResolvedValue({ id: "cus_new", name: "Cliente", cpfCnpj: "12345678000190" });
    const provider = new AsaasProvider(client);

    const result = await provider.criarCustomer({
      nome: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: "financeiro@example.com",
    });

    expect(result).toEqual({ idExterno: "cus_new" });
    expect(client.createCustomer).toHaveBeenCalledWith({
      name: "Cliente",
      cpfCnpj: "12345678000190",
      email: "financeiro@example.com",
    });
  });

  it("recovers from duplicate customer errors by searching again", async () => {
    const client = makeClient();
    client.findCustomerByCpfCnpj
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ id: "cus_race", name: "Cliente", cpfCnpj: "12345678000190" });
    client.createCustomer.mockRejectedValue(
      new AsaasApiError(400, { errors: [{ description: "Cliente já cadastrado." }] }, "duplicate"),
    );
    const provider = new AsaasProvider(client);

    const result = await provider.criarCustomer({
      nome: "Cliente",
      cpfCnpj: "12.345.678/0001-90",
      email: null,
    });

    expect(result).toEqual({ idExterno: "cus_race" });
    expect(client.findCustomerByCpfCnpj).toHaveBeenCalledTimes(2);
  });

  describe("buscarCustomerPorDocumento", () => {
    it("normaliza o documento e retorna o id externo quando existe", async () => {
      const client = makeClient();
      client.findCustomerByCpfCnpj.mockResolvedValue({ id: "cus_1", name: "Cliente", cpfCnpj: "12345678000190" });
      const provider = new AsaasProvider(client);

      const result = await provider.buscarCustomerPorDocumento("12.345.678/0001-90");

      expect(result).toEqual({ idExterno: "cus_1" });
      expect(client.findCustomerByCpfCnpj).toHaveBeenCalledWith("12345678000190");
    });

    it("retorna null quando o customer não existe na plataforma", async () => {
      const client = makeClient();
      client.findCustomerByCpfCnpj.mockResolvedValue(null);
      const provider = new AsaasProvider(client);

      const result = await provider.buscarCustomerPorDocumento("12345678000190");

      expect(result).toBeNull();
    });
  });

  describe("listarCobrancas", () => {
    it("pagina enquanto hasMore for true e mapeia os campos", async () => {
      const client = makeClient();
      client.listPayments
        .mockResolvedValueOnce({
          data: [
            { id: "pay_1", status: "RECEIVED", value: 100, dueDate: "2025-01-10", deleted: false },
            { id: "pay_2", status: "PENDING", value: 50.5, dueDate: "2025-01-20" },
          ],
          hasMore: true,
          totalCount: 3,
        })
        .mockResolvedValueOnce({
          data: [{ id: "pay_3", status: "DELETED", value: 30, dueDate: "2025-01-25", deleted: true }],
          hasMore: false,
          totalCount: 3,
        });
      const provider = new AsaasProvider(client);

      const result = await provider.listarCobrancas({
        customerExternoId: "cus_1",
        vencimentoDe: "2025-01-01",
        vencimentoAte: "2025-01-31",
      });

      expect(client.listPayments).toHaveBeenCalledTimes(2);
      expect(client.listPayments).toHaveBeenNthCalledWith(1, {
        customer: "cus_1",
        dueDateGe: "2025-01-01",
        dueDateLe: "2025-01-31",
        limit: 100,
        offset: 0,
      });
      expect(client.listPayments).toHaveBeenNthCalledWith(2, {
        customer: "cus_1",
        dueDateGe: "2025-01-01",
        dueDateLe: "2025-01-31",
        limit: 100,
        offset: 100,
      });
      expect(result).toEqual([
        { idExterno: "pay_1", valor: 100, vencimento: "2025-01-10", statusExterno: "RECEIVED", status: "paga", deletado: false, externalReference: null },
        { idExterno: "pay_2", valor: 50.5, vencimento: "2025-01-20", statusExterno: "PENDING", status: "pendente", deletado: false, externalReference: null },
        { idExterno: "pay_3", valor: 30, vencimento: "2025-01-25", statusExterno: "DELETED", status: "cancelada", deletado: true, externalReference: null },
      ]);
    });
  });

  describe("registrarWebhook", () => {
    it("chama createWebhook com os parâmetros corretos e retorna idExterno", async () => {
      const client = makeClient();
      client.createWebhook.mockResolvedValue({ id: "wbh_123", name: "Kontiva", url: "https://app.kontiva.com.br/webhooks/cobrancas/asaas/esc_1", enabled: true });
      const provider = new AsaasProvider(client);

      const result = await provider.registrarWebhook({
        url: "https://app.kontiva.com.br/webhooks/cobrancas/asaas/esc_1",
        email: "contato@escritorio.com",
        authToken: "tok_abc",
        events: ["PAYMENT_RECEIVED", "PAYMENT_OVERDUE"],
      });

      expect(result).toEqual({ idExterno: "wbh_123" });
      expect(client.createWebhook).toHaveBeenCalledWith({
        name: "Kontiva",
        url: "https://app.kontiva.com.br/webhooks/cobrancas/asaas/esc_1",
        email: "contato@escritorio.com",
        enabled: true,
        interrupted: false,
        apiVersion: 3,
        authToken: "tok_abc",
        sendType: "SEQUENTIALLY",
        events: ["PAYMENT_RECEIVED", "PAYMENT_OVERDUE"],
      });
    });

    it("propaga o erro da API quando createWebhook falha", async () => {
      const client = makeClient();
      client.createWebhook.mockRejectedValue(new AsaasApiError(422, { errors: [{ description: "URL inválida." }] }, "webhook error"));
      const provider = new AsaasProvider(client);

      await expect(
        provider.registrarWebhook({
          url: "https://app.kontiva.com.br/webhooks/cobrancas/asaas/esc_1",
          email: "contato@escritorio.com",
          authToken: "tok_abc",
          events: ["PAYMENT_RECEIVED"],
        }),
      ).rejects.toBeInstanceOf(AsaasApiError);
    });
  });
});
