import { CryptoService } from "../../infrastructure/security/crypto.service.js";
import { AsaasClient } from "../../infrastructure/external-services/asaas/asaas.client.js";
import { StripeClient } from "../../infrastructure/external-services/stripe/stripe.client.js";
import { AsaasProvider } from "./provedores/asaas.provider.js";
import { StripeProvider } from "./provedores/stripe.provider.js";
import type { PlataformaCobranca } from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";
import type { ProvedorCobranca } from "./provedor-cobranca.interface.js";

/** Decifra a credencial salva e instancia o adapter do provedor configurado. */
export function buildProvedor(plataforma: PlataformaCobranca, crypto: CryptoService): ProvedorCobranca {
  const apiKey = crypto.decrypt({
    ciphertext: plataforma.api_key_encrypted,
    iv: plataforma.api_key_iv,
    tag: plataforma.api_key_tag,
  });
  if (plataforma.plataforma === "asaas") {
    return new AsaasProvider(new AsaasClient(apiKey, plataforma.ambiente));
  }
  if (plataforma.plataforma === "stripe") {
    return new StripeProvider(new StripeClient(apiKey));
  }
  throw new Error(`Plataforma de cobrança não suportada: ${plataforma.plataforma}`);
}
