import type { StatusCobranca } from "../../database/modules/tenant/entities/cobranca.entity.js";

export interface ProvedorCobrancaCustomerInput {
  nome: string;
  cpfCnpj: string;
  email?: string | null;
}

export interface ProvedorCobrancaInput {
  customerExternoId: string;
  valor: number;
  vencimento: string;
  billingType: "BOLETO" | "PIX" | "CREDIT_CARD";
  externalReference: string;
  descricao?: string;
  metadata?: Record<string, string>;
  /**
   * Desconto condicional (ex.: por adimplência): concedido se pago até
   * `diasLimite` dias antes do vencimento (0 = até o próprio vencimento).
   */
  desconto?: {
    valor: number;
    tipo: "FIXED" | "PERCENTAGE";
    diasLimite?: number;
  };
}

export interface ProvedorCobrancaResult {
  idExterno: string;
  statusExterno: string;
  status: StatusCobranca;
  urlBoleto?: string | null;
  urlPix?: string | null;
  payload: Record<string, unknown>;
}

export interface ProvedorWebhookInput {
  url: string;
  email: string;
  authToken: string;
  events: string[];
}

export interface ProvedorWebhookResult {
  idExterno: string;
}

export interface ProvedorListarCobrancasInput {
  customerExternoId: string;
  vencimentoDe?: string;
  vencimentoAte?: string;
}

export interface ProvedorCobrancaItem {
  idExterno: string;
  valor: number;
  vencimento: string;
  statusExterno: string;
  status: StatusCobranca;
  deletado: boolean;
  /** Referência externa gravada na emissão (vac.id) — atribui a cobrança ao membro quando o customer é compartilhado (pagador holding). */
  externalReference: string | null;
}

export interface ProvedorCobranca {
  /** Valida se a credencial configurada consegue acessar o provedor. */
  validarChave(): Promise<void>;
  /** Cria um customer externo no provedor. */
  criarCustomer(input: ProvedorCobrancaCustomerInput): Promise<{ idExterno: string }>;
  /** Atualiza dados do customer quando o provedor suporta essa operação. */
  atualizarCustomer?(idExterno: string, input: ProvedorCobrancaCustomerInput): Promise<void>;
  /** Busca customer externo por CPF/CNPJ para evitar duplicidade. */
  buscarCustomerPorDocumento(cpfCnpj: string): Promise<{ idExterno: string } | null>;
  /** Cria a cobrança financeira no provedor. */
  criarCobranca(input: ProvedorCobrancaInput): Promise<ProvedorCobrancaResult>;
  /** Atualiza campos editáveis de uma cobrança no provedor. */
  atualizarCobranca(idExterno: string, patch: Partial<ProvedorCobrancaInput>): Promise<ProvedorCobrancaResult>;
  /** Cancela ou remove a cobrança no provedor. */
  deletarCobranca(idExterno: string): Promise<void>;
  /** Consulta uma cobrança externa e retorna o status normalizado. */
  consultarCobranca(idExterno: string): Promise<ProvedorCobrancaResult>;
  /** Lista cobranças externas do customer no intervalo solicitado. */
  listarCobrancas(input: ProvedorListarCobrancasInput): Promise<ProvedorCobrancaItem[]>;
  /** Registra webhook remoto quando o provedor oferece API para isso. */
  registrarWebhook(input: ProvedorWebhookInput): Promise<ProvedorWebhookResult>;
}
