import type Stripe from "stripe";
import type { StatusCobranca } from "../../../database/modules/tenant/entities/cobranca.entity.js";
import { StripeClient } from "../../../infrastructure/external-services/stripe/stripe.client.js";
import type {
  ProvedorCobranca,
  ProvedorCobrancaCustomerInput,
  ProvedorCobrancaInput,
  ProvedorCobrancaItem,
  ProvedorCobrancaResult,
  ProvedorListarCobrancasInput,
  ProvedorWebhookInput,
  ProvedorWebhookResult,
} from "../provedor-cobranca.interface.js";

/** Converte status de invoice Stripe para o status interno de cobrança. */
export function mapStripeInvoiceStatus(status: string | null | undefined): StatusCobranca {
  switch (status) {
    case "paid":
      return "paga";
    case "void":
      return "cancelada";
    case "uncollectible":
      return "estornada";
    default:
      return "pendente";
  }
}

/** Converte eventos de webhook Stripe e status da invoice para o status interno. */
export function mapStripeWebhookEventStatus(eventType: string, invoiceStatus: string | null | undefined): StatusCobranca {
  if (eventType === "invoice.paid" || invoiceStatus === "paid") return "paga";
  if (eventType === "invoice.voided" || invoiceStatus === "void") return "cancelada";
  if (eventType === "invoice.marked_uncollectible" || invoiceStatus === "uncollectible") return "estornada";
  return mapStripeInvoiceStatus(invoiceStatus);
}

/** Extrai a data de vencimento da invoice em formato YYYY-MM-DD. */
function invoiceDueDate(invoice: Stripe.Invoice): string {
  const timestamp = invoice.due_date ?? invoice.created;
  return new Date(timestamp * 1000).toISOString().slice(0, 10);
}

/** Converte centavos da Stripe para valor monetário em reais. */
function invoiceAmount(invoice: Stripe.Invoice): number {
  return Number(((invoice.amount_due ?? invoice.total ?? 0) / 100).toFixed(2));
}

/** Normaliza uma invoice Stripe para o contrato comum de provedores. */
function mapInvoice(invoice: Stripe.Invoice): ProvedorCobrancaResult {
  const statusExterno = invoice.status ?? "unknown";
  return {
    idExterno: invoice.id,
    statusExterno,
    status: mapStripeInvoiceStatus(statusExterno),
    urlBoleto: invoice.hosted_invoice_url ?? null,
    urlPix: null,
    payload: invoice as unknown as Record<string, unknown>,
  };
}

export class StripeProvider implements ProvedorCobranca {
  /** Recebe o client HTTP concreto da Stripe. */
  constructor(private readonly client: StripeClient) {}

  /** Verifica se a API key Stripe consegue acessar a API. */
  async validarChave(): Promise<void> {
    await this.client.ping();
  }

  /** Procura customer Stripe pelo documento salvo em metadata. */
  async buscarCustomerPorDocumento(cpfCnpj: string): Promise<{ idExterno: string } | null> {
    const customer = await this.client.findCustomerByCpfCnpj(cpfCnpj);
    return customer ? { idExterno: customer.id } : null;
  }

  /** Reusa ou cria customer Stripe, atualizando dados quando já existe. */
  async criarCustomer(input: ProvedorCobrancaCustomerInput): Promise<{ idExterno: string }> {
    const existing = await this.client.findCustomerByCpfCnpj(input.cpfCnpj);
    if (existing) {
      await this.atualizarCustomer(existing.id, input);
      return { idExterno: existing.id };
    }
    const customer = await this.client.createCustomer({
      name: input.nome,
      cpfCnpj: input.cpfCnpj,
      email: input.email ?? undefined,
    });
    return { idExterno: customer.id };
  }

  /** Atualiza customer Stripe quando há e-mail válido para cobrança. */
  async atualizarCustomer(idExterno: string, input: ProvedorCobrancaCustomerInput): Promise<void> {
    if (!input.email) return;
    await this.client.updateCustomer(idExterno, {
      name: input.nome,
      cpfCnpj: input.cpfCnpj,
      email: input.email,
    });
  }

  /** Cria invoice Stripe em BRL e retorna o link hospedado como URL de pagamento. */
  async criarCobranca(input: ProvedorCobrancaInput): Promise<ProvedorCobrancaResult> {
    const invoice = await this.client.createInvoice({
      customer: input.customerExternoId,
      amountCents: Math.round(input.valor * 100),
      dueDate: input.vencimento,
      description: input.descricao,
      externalReference: input.externalReference,
      metadata: {
        ...(input.metadata ?? {}),
        valor_a_cobrar_id: input.externalReference,
      },
    });
    return mapInvoice(invoice);
  }

  /** Retifica campos permitidos da invoice Stripe aberta. */
  async atualizarCobranca(
    idExterno: string,
    patch: Partial<ProvedorCobrancaInput>,
  ): Promise<ProvedorCobrancaResult> {
    if (patch.valor !== undefined || patch.billingType !== undefined) {
      throw new Error("Stripe v1 permite retificar apenas vencimento/descrição de invoices abertas.");
    }
    const invoice = await this.client.updateInvoice(idExterno, {
      dueDate: patch.vencimento,
      description: patch.descricao,
    });
    return mapInvoice(invoice);
  }

  /** Cancela a invoice Stripe via void. */
  async deletarCobranca(idExterno: string): Promise<void> {
    await this.client.voidInvoice(idExterno);
  }

  /** Consulta uma invoice Stripe e normaliza o resultado. */
  async consultarCobranca(idExterno: string): Promise<ProvedorCobrancaResult> {
    return mapInvoice(await this.client.retrieveInvoice(idExterno));
  }

  /** Lista invoices do customer e filtra localmente pelo intervalo de vencimento. */
  async listarCobrancas(input: ProvedorListarCobrancasInput): Promise<ProvedorCobrancaItem[]> {
    const invoices = await this.client.listInvoices({ customer: input.customerExternoId });
    return invoices
      .filter((invoice) => {
        const dueDate = invoiceDueDate(invoice);
        if (input.vencimentoDe && dueDate < input.vencimentoDe) return false;
        if (input.vencimentoAte && dueDate > input.vencimentoAte) return false;
        return true;
      })
      .map((invoice) => {
        const statusExterno = invoice.status ?? "unknown";
        return {
          idExterno: invoice.id,
          valor: invoiceAmount(invoice),
          vencimento: invoiceDueDate(invoice),
          statusExterno,
          status: mapStripeInvoiceStatus(statusExterno),
          deletado: invoice.status === "void",
          externalReference: invoice.metadata?.valor_a_cobrar_id ?? invoice.metadata?.externalReference ?? null,
        };
      });
  }

  /** Bloqueia registro remoto automático porque Stripe exige configuração com signing secret. */
  async registrarWebhook(_input: ProvedorWebhookInput): Promise<ProvedorWebhookResult> {
    throw new Error("Webhooks Stripe devem ser configurados no Stripe Dashboard usando o signing secret.");
  }
}
