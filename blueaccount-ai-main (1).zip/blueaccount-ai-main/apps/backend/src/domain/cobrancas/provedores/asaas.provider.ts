import {
  AsaasApiError,
  AsaasClient,
  type AsaasBillingType,
  type AsaasPayment,
} from "../../../infrastructure/external-services/asaas/asaas.client.js";
import type { StatusCobranca } from "../../../database/modules/tenant/entities/cobranca.entity.js";
import type {
  ProvedorCobranca,
  ProvedorCobrancaCustomerInput,
  ProvedorCobrancaInput,
  ProvedorCobrancaItem,
  ProvedorCobrancaResult,
  ProvedorListarCobrancasInput,
  ProvedorWebhookInput,
  ProvedorWebhookResult,
} from "../provedor-cobranca.interface.js";
import { somenteDigitos } from "../../texto.js";

/** Converte status de pagamento Asaas para o status interno de cobrança. */
export function mapAsaasStatus(asaasStatus: string): StatusCobranca {
  switch (asaasStatus) {
    case "RECEIVED":
    case "CONFIRMED":
    case "RECEIVED_IN_CASH":
      return "paga";
    case "OVERDUE":
      return "atrasada";
    case "REFUNDED":
    case "CHARGEBACK_REQUESTED":
    case "CHARGEBACK_DISPUTE":
    case "AWAITING_CHARGEBACK_REVERSAL":
      return "estornada";
    case "DELETED":
      return "cancelada";
    default:
      return "pendente";
  }
}

/** Normaliza um payment Asaas para o contrato comum de provedores. */
function mapPayment(payment: AsaasPayment): ProvedorCobrancaResult {
  return {
    idExterno: payment.id,
    statusExterno: payment.status,
    status: mapAsaasStatus(payment.status),
    urlBoleto: payment.bankSlipUrl ?? payment.invoiceUrl ?? null,
    urlPix: payment.pixTransaction?.qrCode?.payload ?? null,
    payload: payment as unknown as Record<string, unknown>,
  };
}

export class AsaasProvider implements ProvedorCobranca {
  /** Recebe o client HTTP concreto da Asaas. */
  constructor(private readonly client: AsaasClient) {}

  /** Verifica se a API key Asaas consegue acessar a API. */
  async validarChave(): Promise<void> {
    await this.client.ping();
  }

  /** Procura customer Asaas pelo CPF/CNPJ normalizado. */
  async buscarCustomerPorDocumento(cpfCnpj: string): Promise<{ idExterno: string } | null> {
    const normalizado = somenteDigitos(cpfCnpj);
    const existing = await this.client.findCustomerByCpfCnpj(normalizado);
    return existing ? { idExterno: existing.id } : null;
  }

  /** Reusa ou cria customer Asaas, tratando corrida de duplicidade por documento. */
  async criarCustomer(input: ProvedorCobrancaCustomerInput): Promise<{ idExterno: string }> {
    const cpfCnpj = somenteDigitos(input.cpfCnpj);
    const existing = await this.client.findCustomerByCpfCnpj(cpfCnpj);
    if (existing) return { idExterno: existing.id };

    let customer;
    try {
      customer = await this.client.createCustomer({
        name: input.nome,
        cpfCnpj,
        email: input.email ?? undefined,
      });
    } catch (error) {
      if (!isCustomerAlreadyExistsError(error)) throw error;

      const createdByAnotherFlow = await this.client.findCustomerByCpfCnpj(cpfCnpj);
      if (!createdByAnotherFlow) throw error;
      customer = createdByAnotherFlow;
    }
    return { idExterno: customer.id };
  }

  /** Cria payment Asaas com valor, vencimento, tipo de cobrança e desconto condicional. */
  async criarCobranca(input: ProvedorCobrancaInput): Promise<ProvedorCobrancaResult> {
    const payment = await this.client.createPayment({
      customer: input.customerExternoId,
      billingType: input.billingType as AsaasBillingType,
      value: Number(input.valor.toFixed(2)),
      dueDate: input.vencimento,
      description: input.descricao,
      externalReference: input.externalReference,
      ...(input.desconto
        ? {
            discount: {
              value: Number(input.desconto.valor.toFixed(2)),
              dueDateLimitDays: input.desconto.diasLimite ?? 0,
              type: input.desconto.tipo,
            },
          }
        : {}),
    });
    return mapPayment(payment);
  }

  /** Atualiza campos editáveis de um payment Asaas e remapeia o retorno. */
  async atualizarCobranca(
    idExterno: string,
    patch: Partial<ProvedorCobrancaInput>,
  ): Promise<ProvedorCobrancaResult> {
    const body: Record<string, unknown> = {};
    if (patch.valor !== undefined) body.value = Number(patch.valor.toFixed(2));
    if (patch.vencimento) body.dueDate = patch.vencimento;
    if (patch.billingType) body.billingType = patch.billingType;
    if (patch.descricao) body.description = patch.descricao;
    const payment = await this.client.updatePayment(idExterno, body as never);
    return mapPayment(payment);
  }

  /** Remove/cancela o payment Asaas no provedor. */
  async deletarCobranca(idExterno: string): Promise<void> {
    await this.client.deletePayment(idExterno);
  }

  /** Consulta um payment Asaas e normaliza o resultado. */
  async consultarCobranca(idExterno: string): Promise<ProvedorCobrancaResult> {
    const payment = await this.client.getPayment(idExterno);
    return mapPayment(payment);
  }

  /** Lista payments Asaas paginados no intervalo de vencimento solicitado. */
  async listarCobrancas(input: ProvedorListarCobrancasInput): Promise<ProvedorCobrancaItem[]> {
    const PAGE_SIZE = 100;
    const itens: ProvedorCobrancaItem[] = [];
    let offset = 0;

    // Pagina enquanto a Asaas indicar que há mais resultados.
    for (;;) {
      const page = await this.client.listPayments({
        customer: input.customerExternoId,
        dueDateGe: input.vencimentoDe,
        dueDateLe: input.vencimentoAte,
        limit: PAGE_SIZE,
        offset,
      });
      for (const payment of page.data ?? []) {
        itens.push({
          idExterno: payment.id,
          valor: Number(payment.value ?? 0),
          vencimento: payment.dueDate,
          statusExterno: payment.status,
          status: mapAsaasStatus(payment.status),
          deletado: payment.deleted === true,
          externalReference: payment.externalReference ?? null,
        });
      }
      if (!page.hasMore) break;
      offset += PAGE_SIZE;
    }

    return itens;
  }

  /** Cria o webhook remoto na Asaas com token de autenticação gerado pela Kontiva. */
  async registrarWebhook(input: ProvedorWebhookInput): Promise<ProvedorWebhookResult> {
    const webhook = await this.client.createWebhook({
      name: "Kontiva",
      url: input.url,
      email: input.email,
      enabled: true,
      interrupted: false,
      apiVersion: 3,
      authToken: input.authToken,
      sendType: "SEQUENTIALLY",
      events: input.events,
    });
    return { idExterno: webhook.id };
  }
}

/** Identifica respostas Asaas que indicam customer já cadastrado por outra execução. */
function isCustomerAlreadyExistsError(error: unknown): boolean {
  if (!(error instanceof AsaasApiError)) return false;
  if (![400, 409].includes(error.status)) return false;

  const payload = JSON.stringify(error.body ?? {}).toLowerCase();
  return (
    payload.includes("duplic") ||
    payload.includes("already") ||
    payload.includes("já cadastrado") ||
    payload.includes("ja cadastrado")
  );
}
