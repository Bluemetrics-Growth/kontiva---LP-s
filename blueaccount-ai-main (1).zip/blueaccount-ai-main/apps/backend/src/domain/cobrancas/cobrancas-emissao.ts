import { runQueryWithRls } from "../../database/data-source.js";
import { Cobranca } from "../../database/modules/tenant/entities/cobranca.entity.js";
import {
  ValoresACobrar,
  type MembroComContratoSnapshot,
} from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { registrarEdicoesManuais } from "../edicoes.js";
import { resolverClientePagador } from "../clientes/grupo.service.js";
import { insumosDivergem } from "../valores-a-cobrar/billing-versao.service.js";
import { somaCobrancasMembros } from "../valores-a-cobrar/cobrancas-membros.js";
import { computeApprovalHash } from "./cobrancas-approval.js";
import { buildDescricaoCobranca } from "./cobrancas-descricao.js";
import { computeDescontoAdimplencia } from "./cobrancas-desconto.js";
import { garantirCustomerExterno } from "./cobrancas-customers.js";
import type { CobrancasServiceDeps } from "./cobrancas-context.js";
import {
  ApprovalHashMismatchError,
  CobrancaStaleError,
  FaturamentoExistenteError,
  MembroGrupoConsolidadoError,
  MembrosPendentesError,
  PlataformaCobrancaAusenteError,
  StatusNaoElegivelError,
} from "./cobrancas-errors.js";
import { avaliarMembrosDoGrupo, isFilhaEmGrupoConsolidado } from "./cobrancas-grupo.js";
import type { EnviarCobrancaInput, PreviewCobrancaResult } from "./cobrancas-types.js";
import { PG_UNIQUE_VIOLATION } from "./cobrancas-utils.js";
import { buildProvedor } from "./provedor.factory.js";

/** Define vencimento padrão de sete dias para emissões sem data explícita. */
function defaultVencimento(): string {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return d.toISOString().slice(0, 10);
}

function temFaturamentoObservado(vac: ValoresACobrar): boolean {
  if (vac.total_cobrado !== null && vac.total_cobrado !== undefined) return true;
  return (vac.linhagem?.faturamento ?? []).some((item) => item.faturamento_ativo !== false);
}

/** Monta o snapshot de aprovação sem tocar o provedor nem persistir efeitos financeiros. */
export async function previewCobranca(
  id: string,
  escritorioId: string,
): Promise<PreviewCobrancaResult | null> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const vac = await manager.getRepository(ValoresACobrar).findOne({
      where: { id, escritorio_id: escritorioId },
      relations: ["cliente"],
    });
    if (!vac) return null;

    const calc = (vac.valores_calculados ?? {}) as Record<string, unknown>;
    const temFaturamento = temFaturamentoObservado(vac);

    if (await isFilhaEmGrupoConsolidado(manager, escritorioId, vac.cliente)) {
      return {
        emissivel: false,
        approval_hash: null,
        motivo_nao_emissivel: "membro_grupo_consolidado" as const,
        preview: {
          valor_a_cobrar_id: vac.id,
          cliente: {
            id: vac.cliente_id,
            cnpj: vac.cliente?.cnpj ?? null,
            razao_social: vac.cliente?.razao_social ?? null,
          },
          competencia: vac.competencia,
          status: vac.status,
          mensagem:
            "Empresa de grupo consolidado: o valor desta cobrança entra como item na fatura única da holding.",
        },
      };
    }

    const grupoAvaliacao = await avaliarMembrosDoGrupo(manager, escritorioId, vac);
    const membrosPendentes = grupoAvaliacao?.pendentes ?? [];

    const statusElegivel = vac.status === "pronto_para_revisao";
    const estaDesatualizado = statusElegivel && (vac.stale || insumosDivergem(vac));
    const emissivel = statusElegivel && !estaDesatualizado && membrosPendentes.length === 0 && !temFaturamento;

    const pagador = vac.cliente ? await resolverClientePagador(manager, escritorioId, vac.cliente) : null;
    const pagadorDiferente = pagador !== null && pagador.id !== vac.cliente_id;

    return {
      emissivel,
      approval_hash: emissivel ? computeApprovalHash(vac, pagadorDiferente ? pagador.id : null) : null,
      ...(statusElegivel && membrosPendentes.length
        ? { motivo_nao_emissivel: "membros_pendentes" as const }
        : estaDesatualizado
          ? { motivo_nao_emissivel: "desatualizado" as const }
          : temFaturamento
            ? { motivo_nao_emissivel: "faturamento_existente" as const }
        : {}),
      ...(membrosPendentes.length ? { membros_pendentes: membrosPendentes } : {}),
      preview: {
        valor_a_cobrar_id: vac.id,
        cliente: {
          id: vac.cliente_id,
          cnpj: vac.cliente?.cnpj ?? null,
          razao_social: vac.cliente?.razao_social ?? null,
        },
        ...(pagadorDiferente
          ? {
              cliente_pagador: {
                id: pagador.id,
                cnpj: pagador.cnpj,
                razao_social: pagador.razao_social,
              },
            }
          : {}),
        competencia: vac.competencia,
        status: vac.status,
        total_cobrado: vac.total_cobrado,
        faturamento: vac.linhagem?.faturamento ?? [],
        valor_base: calc.valor_base ?? null,
        total_excedentes: calc.total_excedentes ?? vac.total_excedentes ?? null,
        total_a_cobrar: calc.total_a_cobrar ?? vac.total ?? null,
        ajuste_grupo: calc.ajuste_grupo ?? null,
        valor_ajuste_grupo: calc.valor_ajuste_grupo ?? null,
        itens: calc.itens ?? null,
        excedentes: calc.excedentes ?? null,
        outros_servicos: vac.outros_servicos_prestados ?? null,
        explicacao_ia: vac.explicacao_ia ?? null,
        cobranca_mitigacao: vac.cobranca_mitigacao ?? null,
        ...(grupoAvaliacao
          ? {
              cobrancas_membros: grupoAvaliacao.itensVivos,
              valor_membros_total: somaCobrancasMembros(grupoAvaliacao.itensVivos),
            }
          : {}),
      },
    };
  });
}

/** Valida a aprovação e cria a cobrança externa, persistindo o vínculo com o VAC. */
export async function enviarCobrancaParaValorACobrar(
  deps: CobrancasServiceDeps,
  input: EnviarCobrancaInput,
): Promise<Cobranca> {
  return runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const cobrancaRepo = manager.getRepository(Cobranca);

    const jaEmitida = await cobrancaRepo.findOne({
      where: { escritorio_id: input.escritorioId, idempotency_key: input.idempotencyKey },
    });
    if (jaEmitida) return jaEmitida;

    const vacRepo = manager.getRepository(ValoresACobrar);
    const vac = await vacRepo.findOne({
      where: { id: input.valorACobrarId, escritorio_id: input.escritorioId },
      relations: ["cliente"],
    });
    if (!vac) throw new Error("ValoresACobrar não encontrado.");

    if (await isFilhaEmGrupoConsolidado(manager, input.escritorioId, vac.cliente)) {
      throw new MembroGrupoConsolidadoError();
    }

    if (vac.status !== "pronto_para_revisao") {
      throw new StatusNaoElegivelError(vac.status);
    }

    if (temFaturamentoObservado(vac)) {
      throw new FaturamentoExistenteError();
    }

    if (vac.stale || insumosDivergem(vac)) {
      throw new CobrancaStaleError(vac.stale_motivo);
    }

    const grupoAvaliacao = await avaliarMembrosDoGrupo(manager, input.escritorioId, vac);
    if (grupoAvaliacao && grupoAvaliacao.pendentes.length > 0) {
      throw new MembrosPendentesError(grupoAvaliacao.pendentes);
    }

    const pagador = await resolverClientePagador(manager, input.escritorioId, vac.cliente);
    const pagadorDiferente = pagador.id !== vac.cliente_id;

    const currentHash = computeApprovalHash(vac, pagadorDiferente ? pagador.id : null);
    if (currentHash !== input.approvalHash) {
      throw new ApprovalHashMismatchError(input.approvalHash, currentHash);
    }

    if (vac.cobranca_id) {
      const existing = await cobrancaRepo.findOne({ where: { id: vac.cobranca_id } });
      if (existing && existing.status !== "cancelada") {
        throw new Error("Já existe uma cobrança ativa para este registro.");
      }
    }

    const plataforma = await deps.plataformas.getAtivaParaEscritorio(manager, input.escritorioId);
    if (!plataforma) throw new PlataformaCobrancaAusenteError();

    const customerId = await garantirCustomerExterno(deps, manager, plataforma, pagador);
    const provedor = buildProvedor(plataforma, deps.crypto);

    const calc = (vac.valores_calculados ?? {}) as {
      valor_base?: number | string | null;
      excedentes?: Array<{
        referencia?: string | null;
        quantidade?: number | null;
        valor_unitario?: number | null;
        valor_total?: number | null;
      }>;
      cobrancas_membros?: MembroComContratoSnapshot[];
      valor_ajuste_grupo?: number | string | null;
      itens_multa?: Array<{ valor?: number | null; motivo?: string | null }>;
      valor_multas_total?: number | string | null;
    };
    const valorBase = Number(calc.valor_base ?? 0);
    const excedentes = calc.excedentes ?? [];
    const totalExcedentes = excedentes.reduce(
      (sum, exc) => sum + Number(exc.valor_total ?? Number(exc.quantidade ?? 0) * Number(exc.valor_unitario ?? 0)),
      0,
    );
    const cobrancasMembros = Array.isArray(calc.cobrancas_membros) ? calc.cobrancas_membros : [];
    const valorAjusteGrupo = Number(calc.valor_ajuste_grupo ?? 0) || 0;
    const itensMulta = Array.isArray(calc.itens_multa) ? calc.itens_multa : [];
    const valorMultasTotal = Number(calc.valor_multas_total ?? 0) || 0;
    const valor = Number(Number(vac.total ?? 0).toFixed(2));
    if (!Number.isFinite(valor) || valor <= 0) {
      throw new Error(`Valor da cobrança deve ser maior que zero (total=${vac.total}).`);
    }

    const descontoAdimplencia = computeDescontoAdimplencia(vac);
    const desconto =
      descontoAdimplencia > 0 && descontoAdimplencia < valor
        ? { valor: descontoAdimplencia, tipo: "FIXED" as const, diasLimite: 0 }
        : undefined;
    if (descontoAdimplencia > 0 && !desconto) {
      console.warn(
        `[cobrancas] desconto de adimplência (${descontoAdimplencia}) >= valor (${valor}) — ignorado para o VAC ${vac.id}.`,
      );
    }

    const descricao = buildDescricaoCobranca({
      competencia: vac.competencia,
      valorBase,
      excedentes,
      totalExcedentes,
      membros: cobrancasMembros,
      ajusteGrupo: valorAjusteGrupo,
      multas: itensMulta,
      valorMultasTotal,
      descontoAdimplencia: desconto ? descontoAdimplencia : 0,
      total: valor,
    });

    const vencimento = input.vencimento ?? defaultVencimento();
    const result = await provedor.criarCobranca({
      customerExternoId: customerId,
      valor,
      vencimento,
      billingType: input.billingType ?? "BOLETO",
      externalReference: vac.id,
      descricao,
      metadata: {
        escritorio_id: input.escritorioId,
        cliente_id: vac.cliente_id,
        pagador_cliente_id: pagador.id,
      },
      ...(desconto ? { desconto } : {}),
    });

    const cobranca = cobrancaRepo.create({
      escritorio_id: input.escritorioId,
      cliente_id: vac.cliente_id,
      valor_a_cobrar_id: vac.id,
      plataforma_id: plataforma.id,
      idempotency_key: input.idempotencyKey,
      id_externo: result.idExterno,
      id_externo_cliente: customerId,
      valor,
      vencimento,
      billing_type: input.billingType ?? "BOLETO",
      status: result.status,
      status_externo: result.statusExterno,
      url_boleto: result.urlBoleto ?? null,
      url_pix: result.urlPix ?? null,
      payload_ultimo_evento: result.payload,
    });
    let saved: Cobranca;
    try {
      saved = await cobrancaRepo.save(cobranca);
    } catch (err: unknown) {
      if (err && typeof err === "object" && (err as { code?: string }).code === PG_UNIQUE_VIOLATION) {
        const existente = await cobrancaRepo.findOne({
          where: { escritorio_id: input.escritorioId, idempotency_key: input.idempotencyKey },
        });
        if (existente) return existente;
      }
      throw err;
    }

    vac.cobranca_id = saved.id;
    vac.status = "enviado";
    vac.edicoes = registrarEdicoesManuais({
      edicoesAtuais: vac.edicoes,
      edicoesRecebidas: input.edicoes,
      usuarioNome: input.usuarioNome ?? null,
    });
    await vacRepo.save(vac);

    return saved;
  });
}
