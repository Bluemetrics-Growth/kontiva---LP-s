// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
import type { MembroComContratoSnapshot } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { round2 } from "../dinheiro.js";

/**
 * Interpreta o texto livre de `desconto_por_adimplencia` (ex.: "5%", "17,5%",
 * "R$ 100"). Percentual quando há "%"; FIXED quando há marca de moeda; número
 * puro ≤ 100 é assumido como percentual (adimplência costuma ser %). Retorna
 * null quando vazio/inválido.
 */
export function parseDescontoAdimplencia(
  texto: string | null | undefined,
): { tipo: "PERCENTAGE" | "FIXED"; valor: number } | null {
  if (!texto || typeof texto !== "string") return null;
  const t = texto.trim();
  if (!t) return null;
  const isPercent = t.includes("%");
  const isCurrency = /r\$|reais/i.test(t);
  const num = Number(
    t
      .replace(/[^\d,.-]/g, "")
      .replace(/\.(?=\d{3}(?:\D|$))/g, "")
      .replace(",", "."),
  );
  if (!Number.isFinite(num) || num <= 0) return null;
  if (isPercent) return { tipo: "PERCENTAGE", valor: num };
  if (isCurrency) return { tipo: "FIXED", valor: num };
  return num <= 100 ? { tipo: "PERCENTAGE", valor: num } : { tipo: "FIXED", valor: num };
}

/** Aplica o desconto normalizado sobre uma base monetária. */
function aplicaDesconto(
  parsed: { tipo: "PERCENTAGE" | "FIXED"; valor: number } | null,
  base: number,
): number {
  if (!parsed) return 0;
  return parsed.tipo === "PERCENTAGE" ? base * (parsed.valor / 100) : parsed.valor;
}

/**
 * Valor absoluto (R$) do desconto condicional por adimplência a aplicar no
 * boleto. Agrega o desconto da própria entidade (sobre valor_base + excedentes)
 * com o de cada membro com contrato (sobre o total dele). Retorna 0 se não houver.
 */
export function computeDescontoAdimplencia(vac: {
  valores_calculados?: unknown;
  valores_contratados?: unknown;
  total_excedentes?: number | string | null;
}): number {
  const calc = (vac.valores_calculados ?? {}) as {
    valor_base?: number | string | null;
    cobrancas_membros?: MembroComContratoSnapshot[];
  };
  const vc = (vac.valores_contratados ?? {}) as { desconto_por_adimplencia?: string | null };

  const valorBase = Number(calc.valor_base ?? 0) || 0;
  const totalExcedentes = Number(vac.total_excedentes ?? 0) || 0;
  let desconto = aplicaDesconto(parseDescontoAdimplencia(vc.desconto_por_adimplencia), valorBase + totalExcedentes);

  const membros = Array.isArray(calc.cobrancas_membros) ? calc.cobrancas_membros : [];
  for (const m of membros) {
    if (!m.calculado || m.ja_cobrado_individualmente) continue;
    desconto += aplicaDesconto(parseDescontoAdimplencia(m.desconto_por_adimplencia), Number(m.total ?? 0));
  }
  return round2(desconto);
}
