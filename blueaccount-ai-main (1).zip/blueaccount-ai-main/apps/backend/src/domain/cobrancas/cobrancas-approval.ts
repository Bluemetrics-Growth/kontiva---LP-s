// Extraido de cobrancas.service.ts para isolar regras puras do servico transacional.
import { createHash } from "node:crypto";

/** Gera o hash server-side que congela o snapshot aprovado entre preview e emissão. */
export function computeApprovalHash(
  vac: {
    id: string;
    competencia: string | null;
    cliente_id: string;
    valores_calculados: unknown;
    total: number | string | null;
    status: string;
  },
  /**
   * Cliente pagador quando diferente do cliente do registro (grupo econômico com
   * pagador na holding). Incluído no hash para que mudar o pagador entre o
   * preview e a emissão invalide o hash em vez de trocar silenciosamente o
   * destino da cobrança. Null/omitido preserva os hashes existentes.
   */
  pagadorClienteId: string | null = null,
): string {
  const payload = JSON.stringify({
    id: vac.id,
    competencia: vac.competencia,
    cliente_id: vac.cliente_id,
    valores_calculados: vac.valores_calculados,
    total: vac.total,
    status: vac.status,
    ...(pagadorClienteId ? { pagador_cliente_id: pagadorClienteId } : {}),
  });
  return createHash("sha256").update(payload).digest("hex").slice(0, 32);
}
