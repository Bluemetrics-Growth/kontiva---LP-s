import type { EntityManager } from "typeorm";
import type Stripe from "stripe";
import { runQueryWithRls } from "../../database/data-source.js";
import { Cobranca, type StatusCobranca } from "../../database/modules/tenant/entities/cobranca.entity.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import type { PlataformaCobranca } from "../../database/modules/tenant/entities/plataforma-cobranca.entity.js";
import { ValoresACobrar } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { buildPaginatedResult, normalizePagination } from "../pagination.js";
import { buildProvedor } from "./provedor.factory.js";
import { mapAsaasStatus } from "./provedores/asaas.provider.js";
import { mapStripeWebhookEventStatus } from "./provedores/stripe.provider.js";
import type { CobrancasServiceDeps } from "./cobrancas-context.js";
import { plataformaLabel } from "./cobrancas-utils.js";

/** Cancela no provedor uma cobrança ainda não paga e salva o status interno. */
export async function cancelar(
  deps: CobrancasServiceDeps,
  id: string,
  escritorioId: string,
): Promise<Cobranca> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const cobrancaRepo = manager.getRepository(Cobranca);
    const cobranca = await cobrancaRepo.findOne({
      where: { id, escritorio_id: escritorioId },
      relations: ["plataforma"],
    });
    if (!cobranca) throw new Error("Cobrança não encontrada.");
    if (cobranca.status === "paga") {
      throw new Error("Não é possível cancelar uma cobrança já paga.");
    }
    const provedor = buildProvedor(cobranca.plataforma, deps.crypto);
    await provedor.deletarCobranca(cobranca.id_externo);
    cobranca.status = "cancelada";
    return cobrancaRepo.save(cobranca);
  });
}

/** Retifica dados permitidos de uma cobrança aberta e espelha a resposta do provedor. */
export async function retificar(
  deps: CobrancasServiceDeps,
  id: string,
  escritorioId: string,
  patch: { valor?: number; vencimento?: string; billing_type?: "BOLETO" | "PIX" },
): Promise<Cobranca> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const cobrancaRepo = manager.getRepository(Cobranca);
    const cobranca = await cobrancaRepo.findOne({
      where: { id, escritorio_id: escritorioId },
      relations: ["plataforma"],
    });
    if (!cobranca) throw new Error("Cobrança não encontrada.");
    if (cobranca.status === "paga" || cobranca.status === "cancelada") {
      throw new Error(`Não é possível retificar uma cobrança com status "${cobranca.status}".`);
    }
    const provedor = buildProvedor(cobranca.plataforma, deps.crypto);
    const result = await provedor.atualizarCobranca(cobranca.id_externo, {
      valor: patch.valor,
      vencimento: patch.vencimento,
      billingType: patch.billing_type,
      customerExternoId: cobranca.id_externo_cliente ?? undefined,
      externalReference: cobranca.valor_a_cobrar_id ?? undefined,
    });
    if (patch.valor !== undefined) cobranca.valor = patch.valor;
    if (patch.vencimento) cobranca.vencimento = patch.vencimento;
    if (patch.billing_type) cobranca.billing_type = patch.billing_type;
    cobranca.status = result.status;
    cobranca.status_externo = result.statusExterno;
    cobranca.payload_ultimo_evento = result.payload;
    return cobrancaRepo.save(cobranca);
  });
}

/** Consulta a cobrança no provedor e reaplica o status resultante no domínio local. */
export async function sincronizar(
  deps: CobrancasServiceDeps,
  id: string,
  escritorioId: string,
): Promise<Cobranca> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const cobrancaRepo = manager.getRepository(Cobranca);
    const cobranca = await cobrancaRepo.findOne({
      where: { id, escritorio_id: escritorioId },
      relations: ["plataforma"],
    });
    if (!cobranca) throw new Error("Cobrança não encontrada.");
    const provedor = buildProvedor(cobranca.plataforma, deps.crypto);
    const result = await provedor.consultarCobranca(cobranca.id_externo);
    return aplicarStatus(
      manager,
      cobranca,
      result.status,
      result.statusExterno,
      result.payload,
      plataformaLabel(cobranca.plataforma),
    );
  });
}

/** Lista cobranças sem paginação para integrações e telas legadas. */
export async function list(escritorioId: string, filtros: { status?: string; cliente_id?: string }): Promise<Cobranca[]> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Cobranca)
      .createQueryBuilder("c")
      .leftJoinAndSelect("c.cliente", "cliente")
      .where("c.escritorio_id = :escritorioId", { escritorioId });
    if (filtros.status) qb.andWhere("c.status = :status", { status: filtros.status });
    if (filtros.cliente_id) qb.andWhere("c.cliente_id = :cliente_id", { cliente_id: filtros.cliente_id });
    return qb.orderBy("c.created_at", "DESC").getMany();
  });
}

/** Lista cobranças paginadas com campos projetados para a UI operacional. */
export async function listPaginated(
  escritorioId: string,
  filtros: { status?: string; cliente_id?: string; page?: number; pageSize?: number },
) {
  const { page, pageSize, skip } = normalizePagination(filtros);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Cobranca)
      .createQueryBuilder("cobranca")
      .innerJoin("cobranca.cliente", "cliente")
      .select("cobranca.id", "id")
      .addSelect("cobranca.cliente_id", "cliente_id")
      .addSelect("cobranca.valor_a_cobrar_id", "valor_a_cobrar_id")
      .addSelect("cobranca.plataforma_id", "plataforma_id")
      .addSelect("cobranca.id_externo", "id_externo")
      .addSelect("cobranca.id_externo_cliente", "id_externo_cliente")
      .addSelect("cobranca.valor", "valor")
      .addSelect("cobranca.vencimento", "vencimento")
      .addSelect("cobranca.billing_type", "billing_type")
      .addSelect("cobranca.status", "status")
      .addSelect("cobranca.status_externo", "status_externo")
      .addSelect("cobranca.url_boleto", "url_boleto")
      .addSelect("cobranca.url_pix", "url_pix")
      .addSelect("cobranca.pago_em", "pago_em")
      .addSelect("cobranca.created_at", "created_at")
      .addSelect("cobranca.updated_at", "updated_at")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .where("cobranca.escritorio_id = :escritorioId", { escritorioId });
    if (filtros.status) qb.andWhere("cobranca.status = :status", { status: filtros.status });
    if (filtros.cliente_id) qb.andWhere("cobranca.cliente_id = :clienteId", { clienteId: filtros.cliente_id });
    const total = await qb.clone().getCount();
    const rows = await qb.orderBy("cobranca.created_at", "DESC").offset(skip).limit(pageSize)
      .getRawMany<Record<string, unknown>>();
    return buildPaginatedResult(rows.map((row) => ({
      id: String(row.id),
      cliente_id: String(row.cliente_id),
      valor_a_cobrar_id: row.valor_a_cobrar_id ?? null,
      plataforma_id: String(row.plataforma_id),
      id_externo: String(row.id_externo),
      id_externo_cliente: row.id_externo_cliente ?? null,
      valor: Number(row.valor),
      vencimento: String(row.vencimento),
      billing_type: String(row.billing_type),
      status: String(row.status),
      status_externo: row.status_externo ?? null,
      url_boleto: row.url_boleto ?? null,
      url_pix: row.url_pix ?? null,
      pago_em: row.pago_em ?? null,
      created_at: row.created_at,
      updated_at: row.updated_at,
      cliente: {
        id: String(row.cliente_id),
        razao_social: String(row.cliente_razao_social),
        cnpj: row.cliente_cnpj ?? null,
      },
    })), total, page, pageSize);
  });
}

/** Recebe um payload Asaas autenticado e aplica o status no registro mais recente correspondente. */
export async function aplicarStatusViaToken(payload: {
  payment?: { id?: string; status?: string; paymentDate?: string };
}, plataforma: PlataformaCobranca): Promise<void> {
  const paymentId = payload.payment?.id;
  if (!paymentId) return;
  await runQueryWithRls({ escritorio_id: plataforma.escritorio_id }, async (manager) => {
    const cobranca = await manager.getRepository(Cobranca).findOne({
      where: { plataforma_id: plataforma.id, id_externo: paymentId },
      order: { created_at: "DESC" },
    });
    if (!cobranca) return;
    const statusExterno = payload.payment?.status ?? cobranca.status_externo ?? "";
    const novoStatus = mapAsaasStatus(statusExterno);
    await aplicarStatus(
      manager,
      cobranca,
      novoStatus,
      statusExterno,
      payload as Record<string, unknown>,
      plataformaLabel(plataforma),
    );
  });
}

/** Recebe um evento Stripe autenticado e aplica o status da invoice no registro correspondente. */
export async function aplicarStatusStripeWebhook(event: Stripe.Event, plataforma: PlataformaCobranca): Promise<void> {
  const invoice = event.data.object as Stripe.Invoice;
  const invoiceId = typeof invoice.id === "string" ? invoice.id : "";
  if (!invoiceId) return;

  await runQueryWithRls({ escritorio_id: plataforma.escritorio_id }, async (manager) => {
    const cobranca = await manager.getRepository(Cobranca).findOne({
      where: { plataforma_id: plataforma.id, id_externo: invoiceId },
      order: { created_at: "DESC" },
    });
    if (!cobranca) return;
    const statusExterno = invoice.status ?? event.type;
    const novoStatus = mapStripeWebhookEventStatus(event.type, invoice.status);
    await aplicarStatus(
      manager,
      cobranca,
      novoStatus,
      statusExterno,
      event as unknown as Record<string, unknown>,
      plataformaLabel(plataforma),
    );
  });
}

/** Persiste a mudança de status e propaga efeitos finais para VAC e faturamento. */
export async function aplicarStatus(
  manager: EntityManager,
  cobranca: Cobranca,
  novoStatus: StatusCobranca,
  statusExterno: string,
  payload: Record<string, unknown>,
  providerLabel: string,
): Promise<Cobranca> {
  cobranca.status = novoStatus;
  cobranca.status_externo = statusExterno;
  cobranca.payload_ultimo_evento = payload;
  if (novoStatus === "paga") {
    cobranca.pago_em = new Date();
  }
  const saved = await manager.getRepository(Cobranca).save(cobranca);

  if ((novoStatus === "paga" || novoStatus === "estornada" || novoStatus === "cancelada") && cobranca.valor_a_cobrar_id) {
    const vacRepo = manager.getRepository(ValoresACobrar);
    const vac = await vacRepo.findOne({ where: { id: cobranca.valor_a_cobrar_id } });
    if (vac) {
      if (novoStatus === "paga") {
        vac.status = "pago";
        vac.total_cobrado = Number(cobranca.valor);
      } else {
        vac.status = "enviado";
      }
      await vacRepo.save(vac);

      const faturamentoRepo = manager.getRepository(Faturamento);
      const existente = await faturamentoRepo.findOne({
        where: {
          cliente_id: vac.cliente_id,
          competencia: vac.competencia,
          faturamento_ativo: true,
        },
      });
      if (existente) {
        existente.valor_cobrado = Number(cobranca.valor);
        await faturamentoRepo.save(existente);
      } else {
        const novo = faturamentoRepo.create({
          escritorio_id: vac.escritorio_id,
          cliente_id: vac.cliente_id,
          competencia: vac.competencia,
          valor_cobrado: Number(cobranca.valor),
          discriminacao: `${providerLabel} ${cobranca.id_externo}`,
          faturamento_ativo: true,
        });
        await faturamentoRepo.save(novo);
      }
    }
  }
  return saved;
}
