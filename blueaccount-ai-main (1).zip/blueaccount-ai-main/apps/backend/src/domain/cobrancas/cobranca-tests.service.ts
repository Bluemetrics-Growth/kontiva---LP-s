import { randomUUID } from "node:crypto";
import { runQueryWithRls } from "../../database/data-source.js";
import { CobrancaTest } from "../../database/modules/tenant/entities/cobranca-test.entity.js";
import { ValoresACobrar } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { ValoresACobrarVersao } from "../../database/modules/tenant/entities/valores-a-cobrar-versoes.entity.js";
import { AgentCoreRuntimeClient } from "../../infrastructure/external-services/agentcore-runtime.client.js";
import { settings } from "../../settings.js";
import { isEscritorioAmbienteTesteCobranca } from "../escritorios/escritorio.service.js";

const DEFAULT_GRADING_INSTRUCTIONS = [
  "Valores certos.",
  "Tudo que deveria ter sido cobrado foi cobrado.",
  "Serviços extras prestados devem estar incluídos.",
  "Totais devem bater com os itens cobrados.",
].join(" ");

const TEST_PASSING_GRADE = 85;
const POLL_INTERVAL_MS = 2_000;

export class CobrancaEvalForbiddenError extends Error {}
export class CobrancaEvalNotFoundError extends Error {}
export class CobrancaEvalValidationError extends Error {}

export type CobrancaTestResumo = Pick<
  CobrancaTest,
  | "id"
  | "escritorio_id"
  | "valor_a_cobrar_id"
  | "cliente_id"
  | "competencia"
  | "status"
  | "agent_trace_id"
  | "agent_output_s3_uri"
  | "grade"
  | "explanation"
  | "erro"
  | "started_at"
  | "finished_at"
  | "created_at"
  | "updated_at"
>;

export interface RunCobrancaEvalInput {
  valor_a_cobrar_id: string;
  grading_instructions?: string;
}

export interface RunCobrancaEvalOptions {
  sessionId?: string;
}

interface BillingEvalTarget {
  valor_a_cobrar_id: string;
  cliente_id: string;
  contrato_id: string;
  competencia: string;
  valores_contratados: Record<string, unknown>;
  valores_observados: Record<string, unknown>;
  outros_servicos_prestados: unknown[];
  linhagem: unknown;
  valores_calculados: Record<string, unknown>;
  total: number | null;
  total_excedentes: number | null;
  agente_trace_id: string | null;
  agente_output_s3_uri: string | null;
  versao_ativa: {
    id: string;
    versao: number;
    input_hash: string | null;
    total: number | null;
    total_excedentes: number | null;
    valores_calculados: Record<string, unknown>;
    created_at: Date;
  } | null;
}

interface GraderResult {
  grade: number;
  explanation: string;
  raw: Record<string, unknown>;
}

/** Aguarda um intervalo curto entre polls do agente de cobrança. */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Converte números opcionais do snapshot para número ou null. */
function toNumberOrNull(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Garante que um valor desconhecido possa ser tratado como objeto JSON. */
function normalizeJsonObject(value: unknown): Record<string, unknown> {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return { value };
}

/** Faz parse de JSON simples ou de JSON serializado como string dentro da resposta. */
function parseJsonMaybeNested(text: string): unknown {
  const trimmed = text.trim();
  if (!trimmed) return {};
  const parsed = JSON.parse(trimmed);
  if (typeof parsed === "string" && parsed.trim().startsWith("{")) {
    return JSON.parse(parsed);
  }
  return parsed;
}

/** Extrai grade e explicação da resposta estruturada do GraderAgent. */
function extractGraderResult(responseText: string): GraderResult {
  const parsed = parseJsonMaybeNested(responseText);
  const candidates = [
    parsed,
    normalizeJsonObject(parsed).result,
    normalizeJsonObject(parsed).output,
    normalizeJsonObject(parsed).structured_output,
    normalizeJsonObject(parsed).structuredOutput,
  ];

  for (const candidate of candidates) {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) continue;
    const obj = candidate as Record<string, unknown>;
    const grade = Number(obj.grade);
    const explanation = typeof obj.explanation === "string" ? obj.explanation : "";
    if (Number.isFinite(grade) && explanation) {
      return {
        grade: Math.max(0, Math.min(100, Math.round(grade))),
        explanation,
        raw: normalizeJsonObject(parsed),
      };
    }
  }

  throw new Error(`GraderAgent retornou resposta sem grade/explanation: ${responseText.slice(0, 500)}`);
}

/** Projeta uma execução de teste para o resumo listado na UI/API. */
function mapResumo(test: CobrancaTest): CobrancaTestResumo {
  return {
    id: test.id,
    escritorio_id: test.escritorio_id,
    valor_a_cobrar_id: test.valor_a_cobrar_id,
    cliente_id: test.cliente_id,
    competencia: test.competencia,
    status: test.status,
    agent_trace_id: test.agent_trace_id,
    agent_output_s3_uri: test.agent_output_s3_uri,
    grade: test.grade,
    explanation: test.explanation,
    erro: test.erro,
    started_at: test.started_at,
    finished_at: test.finished_at,
    created_at: test.created_at,
    updated_at: test.updated_at,
  };
}

/** Bloqueia uso do harness fora de escritórios marcados como ambiente de teste. */
async function assertEscritorioTeste(escritorioId: string): Promise<void> {
  const isTeste = await isEscritorioAmbienteTesteCobranca(escritorioId);
  if (!isTeste) {
    throw new CobrancaEvalForbiddenError("Recurso não encontrado.");
  }
}

/** Busca o VAC alvo da avaliação ou falha com erro de domínio controlado. */
async function getVacOrThrow(escritorioId: string, valorACobrarId: string): Promise<ValoresACobrar> {
  const vac = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return await manager.getRepository(ValoresACobrar).findOne({
      where: { id: valorACobrarId, escritorio_id: escritorioId },
    });
  });
  if (!vac) {
    throw new CobrancaEvalNotFoundError("ValoresACobrar não encontrado.");
  }
  return vac;
}

/** Atualiza uma linha de teste mantendo RLS e erro explícito quando ela desaparece. */
async function updateTest(
  escritorioId: string,
  testId: string,
  patch: Partial<CobrancaTest>,
): Promise<CobrancaTest> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(CobrancaTest);
    const test = await repo.findOne({ where: { id: testId, escritorio_id: escritorioId } });
    if (!test) throw new CobrancaEvalNotFoundError("Teste de cobrança não encontrado.");
    Object.assign(test, patch);
    return await repo.save(test);
  });
}

/** Cria a linha inicial de teste em processamento para rastrear a avaliação. */
async function createTest(
  escritorioId: string,
  vac: ValoresACobrar,
  gradingInstructions: string,
): Promise<CobrancaTest> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(CobrancaTest);
    return await repo.save(repo.create({
      escritorio_id: escritorioId,
      valor_a_cobrar_id: vac.id,
      cliente_id: vac.cliente_id,
      competencia: vac.competencia,
      status: "em_processamento",
      grading_instructions: gradingInstructions,
      started_at: new Date(),
      finished_at: null,
    }));
  });
}

/** Espera o agente de cobrança concluir para obter output avaliável. */
async function waitForBillingDone(escritorioId: string, valorACobrarId: string): Promise<ValoresACobrar> {
  const deadline = Date.now() + settings.COBRANCA_TEST_SYNC_TIMEOUT_MS;
  let latest = await getVacOrThrow(escritorioId, valorACobrarId);

  while (latest.agente_status === "em_processamento" && Date.now() < deadline) {
    await sleep(Math.max(1, Math.min(POLL_INTERVAL_MS, deadline - Date.now())));
    latest = await getVacOrThrow(escritorioId, valorACobrarId);
  }

  if (latest.agente_status === "em_processamento") {
    throw new Error(`Agente de cobrança não concluiu em ${settings.COBRANCA_TEST_SYNC_TIMEOUT_MS}ms.`);
  }
  if (latest.agente_status === "erro") {
    throw new Error(latest.agente_erro || "Agente de cobrança terminou com erro.");
  }
  if (latest.agente_status !== "concluido") {
    throw new Error(`Agente de cobrança não produziu resultado avaliável (status: ${latest.agente_status ?? "nulo"}).`);
  }
  if (!latest.agente_cobranca_output_s3_path) {
    throw new Error("Agente de cobrança concluiu sem output S3.");
  }

  return latest;
}

/** Detecta se o VAC já possui saída de cobrança reaproveitável para avaliação. */
function hasReusableBillingOutput(vac: ValoresACobrar): boolean {
  return vac.agente_status === "concluido" && Boolean(vac.agente_cobranca_output_s3_path);
}

/** Decide entre reutilizar output existente, aguardar processamento ou falhar com orientação. */
async function resolveBillingOutputForEval(
  escritorioId: string,
  valorACobrarId: string,
  currentVac: ValoresACobrar,
): Promise<ValoresACobrar> {
  if (hasReusableBillingOutput(currentVac)) {
    return currentVac;
  }

  if (currentVac.agente_status === "em_processamento") {
    return await waitForBillingDone(escritorioId, valorACobrarId);
  }

  throw new Error("Cobrança ainda não possui output avaliável. Calcule a cobrança antes de rodar o teste.");
}

/** Monta o alvo objetivo que o GraderAgent usa para comparar a resposta do agente de cobrança. */
async function buildTarget(escritorioId: string, vac: ValoresACobrar): Promise<BillingEvalTarget> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const versaoAtiva = vac.versao_ativa_id
      ? await manager.getRepository(ValoresACobrarVersao).findOne({
          where: { id: vac.versao_ativa_id, escritorio_id: escritorioId, valor_a_cobrar_id: vac.id },
        })
      : null;

    return {
      valor_a_cobrar_id: vac.id,
      cliente_id: vac.cliente_id,
      contrato_id: vac.contrato_id,
      competencia: vac.competencia,
      valores_contratados: vac.valores_contratados ?? {},
      valores_observados: vac.valores_observados ?? {},
      outros_servicos_prestados: vac.outros_servicos_prestados ?? [],
      linhagem: vac.linhagem ?? null,
      valores_calculados: vac.valores_calculados ?? {},
      total: toNumberOrNull(vac.total),
      total_excedentes: toNumberOrNull(vac.total_excedentes),
      agente_trace_id: vac.agente_trace_id,
      agente_output_s3_uri: vac.agente_cobranca_output_s3_path,
      versao_ativa: versaoAtiva
        ? {
            id: versaoAtiva.id,
            versao: versaoAtiva.versao,
            input_hash: versaoAtiva.input_hash,
            total: toNumberOrNull(versaoAtiva.total),
            total_excedentes: toNumberOrNull(versaoAtiva.total_excedentes),
            valores_calculados: versaoAtiva.valores_calculados ?? {},
            created_at: versaoAtiva.created_at,
          }
        : null,
    };
  });
}

/** Invoca o GraderAgent com resposta do agente de cobrança e alvo esperado. */
async function invokeGraderAgent(input: {
  testId: string;
  agentResponse: string;
  target: BillingEvalTarget;
  gradingInstructions: string;
}): Promise<GraderResult> {
  if (!settings.GRADER_AGENT_RUNTIME_ARN) {
    throw new Error("Missing required setting: GRADER_AGENT_RUNTIME_ARN");
  }

  const payload = {
    trace_id: `cobranca-test-${input.testId}`,
    prompt: input.agentResponse,
    target: JSON.stringify(input.target, null, 2),
    grading_instructions: input.gradingInstructions,
  };
  const responseText = await new AgentCoreRuntimeClient().invokeJsonText({
    agentRuntimeArn: settings.GRADER_AGENT_RUNTIME_ARN,
    qualifier: settings.GRADER_AGENT_RUNTIME_QUALIFIER || undefined,
    runtimeSessionId: `grader-${input.testId}-${randomUUID()}`,
    traceId: payload.trace_id,
    payload,
  });

  return extractGraderResult(responseText);
}

/** Lista as avaliações recentes de cobrança disponíveis para um escritório de teste. */
export async function listCobrancaTests(escritorioId: string): Promise<CobrancaTestResumo[]> {
  await assertEscritorioTeste(escritorioId);
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const tests = await manager.getRepository(CobrancaTest).find({
      where: { escritorio_id: escritorioId },
      order: { created_at: "DESC" },
      take: 25,
    });
    return tests.map(mapResumo);
  });
}

/** Busca uma avaliação específica de cobrança em ambiente de teste. */
export async function getCobrancaTest(escritorioId: string, id: string): Promise<CobrancaTest | null> {
  await assertEscritorioTeste(escritorioId);
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return await manager.getRepository(CobrancaTest).findOne({ where: { id, escritorio_id: escritorioId } });
  });
}

/** Executa uma avaliação completa do output de cobrança contra o GraderAgent. */
export async function runCobrancaTest(
  escritorioId: string,
  input: RunCobrancaEvalInput,
  _options: RunCobrancaEvalOptions = {},
): Promise<CobrancaTest> {
  await assertEscritorioTeste(escritorioId);

  const valorACobrarId = String(input.valor_a_cobrar_id || "").trim();
  if (!valorACobrarId) {
    throw new CobrancaEvalValidationError("valor_a_cobrar_id é obrigatório.");
  }

  const gradingInstructions = String(input.grading_instructions || "").trim() || DEFAULT_GRADING_INSTRUCTIONS;
  const initialVac = await getVacOrThrow(escritorioId, valorACobrarId);
  const test = await createTest(escritorioId, initialVac, gradingInstructions);

  try {
    const completedVac = await resolveBillingOutputForEval(escritorioId, valorACobrarId, initialVac);
    const agentOutputS3Uri = completedVac.agente_cobranca_output_s3_path!;
    const agentResponse = await new AgentCoreRuntimeClient().readS3ObjectText(agentOutputS3Uri);
    const target = await buildTarget(escritorioId, completedVac);
    const graderResult = await invokeGraderAgent({
      testId: test.id,
      agentResponse,
      target,
      gradingInstructions,
    });

    return await updateTest(escritorioId, test.id, {
      status: graderResult.grade >= TEST_PASSING_GRADE ? "aprovado" : "reprovado",
      agent_trace_id: completedVac.agente_trace_id,
      agent_output_s3_uri: agentOutputS3Uri,
      agent_response: agentResponse,
      target: target as unknown as Record<string, unknown>,
      grade: graderResult.grade,
      explanation: graderResult.explanation,
      grader_raw_response: graderResult.raw,
      erro: null,
      finished_at: new Date(),
    });
  } catch (err) {
    return await updateTest(escritorioId, test.id, {
      status: "erro",
      erro: err instanceof Error ? err.message : String(err),
      finished_at: new Date(),
    });
  }
}
