import { AppDataSource } from "../../database/data-source.js";
import { ContractExtractionComplexity } from "../../database/modules/public/entities/contract-extraction-complexity.entity.js";

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

export type ContractExtractionComplexityInput = {
  nivel?: number;
  nome?: string;
  descricao?: string | null;
  inference_profile_id?: string | null;
  ativo?: boolean;
};

function normalizeNivel(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  if (!Number.isInteger(parsed) || parsed < 1) return null;
  return parsed;
}

function normalizeText(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

async function seedDefaultsIfMissing(): Promise<void> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(ContractExtractionComplexity);
  const count = await repo.count();
  if (count > 0) return;

  await repo.save([
    repo.create({
      nivel: 1,
      nome: "Standard",
      descricao: "Modelo padrao de extracao de contrato (default global quando inference_profile_id nulo).",
      inference_profile_id: null,
      ativo: true,
    }),
    repo.create({
      nivel: 2,
      nome: "High accuracy",
      descricao: "Modelo de maior capacidade para contratos complexos.",
      inference_profile_id: null,
      ativo: true,
    }),
  ]);
}

export async function listContractExtractionComplexities(
  includeInactive = true,
): Promise<ContractExtractionComplexity[]> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(ContractExtractionComplexity);
  return repo.find({
    where: includeInactive ? {} : { ativo: true },
    order: { nivel: "ASC" },
  });
}

export async function createContractExtractionComplexity(
  input: ContractExtractionComplexityInput,
): Promise<ContractExtractionComplexity> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(ContractExtractionComplexity);
  const nivel = normalizeNivel(input.nivel);
  const nome = normalizeText(input.nome);

  if (!nivel) throw new Error("nivel deve ser um inteiro positivo.");
  if (!nome) throw new Error("nome é obrigatório.");

  const existing = await repo.findOne({ where: { nivel } });
  if (existing) throw new Error(`Já existe uma complexidade de extração para o nível ${nivel}.`);

  return repo.save(
    repo.create({
      nivel,
      nome,
      descricao: normalizeText(input.descricao),
      inference_profile_id: normalizeText(input.inference_profile_id),
      ativo: input.ativo ?? true,
    }),
  );
}

export async function updateContractExtractionComplexity(
  nivelInput: number | string,
  input: ContractExtractionComplexityInput,
): Promise<ContractExtractionComplexity> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(ContractExtractionComplexity);
  const nivel = normalizeNivel(nivelInput);
  if (!nivel) throw new Error("nivel inválido.");

  const existing = await repo.findOne({ where: { nivel } });
  if (!existing) throw new Error("Complexidade de extração não encontrada.");

  const nextAtivo = "ativo" in input ? Boolean(input.ativo) : existing.ativo;
  if (existing.ativo && !nextAtivo) {
    const activeCount = await repo.count({ where: { ativo: true } });
    if (activeCount <= 1) throw new Error("Não é possível desativar a última complexidade ativa.");
  }

  if ("nome" in input) {
    const nome = normalizeText(input.nome);
    if (!nome) throw new Error("nome é obrigatório.");
    existing.nome = nome;
  }
  if ("descricao" in input) existing.descricao = normalizeText(input.descricao);
  if ("inference_profile_id" in input) existing.inference_profile_id = normalizeText(input.inference_profile_id);
  existing.ativo = nextAtivo;

  return repo.save(existing);
}

export async function deactivateContractExtractionComplexity(
  nivelInput: number | string,
): Promise<ContractExtractionComplexity> {
  return updateContractExtractionComplexity(nivelInput, { ativo: false });
}

/**
 * Resolve a complexidade de extração para runtime. Dado o nível do escritório,
 * devolve o registro ativo correspondente (fallback: primeiro ativo). Use
 * `inference_profile_id` resultante como `model_id` do ContractAgent.
 */
export async function resolveContractExtractionComplexityForRuntime(
  nivelInput: unknown,
): Promise<ContractExtractionComplexity> {
  const rows = await listContractExtractionComplexities(false);
  if (rows.length === 0) {
    throw new Error("Nenhuma complexidade de extração de contrato ativa configurada.");
  }
  const nivel = normalizeNivel(nivelInput);
  return rows.find((row) => row.nivel === nivel) ?? rows[0];
}
