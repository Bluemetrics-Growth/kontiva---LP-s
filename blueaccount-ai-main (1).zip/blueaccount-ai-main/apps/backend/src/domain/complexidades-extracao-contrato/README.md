# `src/domain/complexidades-extracao-contrato`

Domínio dos níveis de complexidade usados pela extração de contratos.

## Responsabilidades

- manter o catálogo admin de complexidades de extração de contrato
- validar entradas de nível, nome, descrição e `inference_profile_id`
- resolver o nível ativo que define o modelo usado pelo fluxo de extração de contrato

## Arquivos

- `complexidade-extracao-contrato.service.ts` - CRUD do catálogo e resolução de runtime

## Consumidores

- `src/domain/escritorios/contract-extraction-config.ts` combina o nível do escritório com este catálogo.
- `src/modules/escritorios` expõe os endpoints admin `contract-extraction-complexities`.

Os slugs HTTP continuam em inglês por compatibilidade com o frontend e clientes existentes; a padronização PT aqui é interna ao domínio.
