# `domain/oauth`

OAuth 2.1 helpers for ChatGPT/MCP integrations.

The OAuth implementation wraps the existing BlueAccount application session:

- users authenticate through the existing Cognito-backed login flow
- authorization codes, access tokens, and rotating refresh tokens are opaque and stored as SHA-256 hashes
- access tokens map back to `sessoes.session_id_hash`
- refresh-token replay, revocation, or expiration invalidates the associated credential family
- each user has at most one active credential family per OAuth client/resource
- `/api/*` can accept either the normal `blueaccount_session_id` cookie or an OAuth bearer token
