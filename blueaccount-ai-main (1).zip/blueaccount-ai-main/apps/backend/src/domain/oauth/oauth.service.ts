import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { EntityManager, In, IsNull, MoreThan } from "typeorm";
import { AppDataSource } from "../../database/data-source.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { OAuthAccessToken } from "../../database/modules/public/entities/oauth-access-token.entity.js";
import { OAuthAuthorizationCode } from "../../database/modules/public/entities/oauth-authorization-code.entity.js";
import { OAuthClient } from "../../database/modules/public/entities/oauth-client.entity.js";
import { OAuthRefreshToken } from "../../database/modules/public/entities/oauth-refresh-token.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import {
  ensureDatabase,
  hashSessionId,
  resolveApplicationSessionFromHash,
  resolveApplicationSessionFromId,
  type ApplicationSessionContext,
} from "../autenticacao/autenticacao.service.js";
import { settings } from "../../settings.js";

const DEFAULT_SCOPE = "blueaccount.api";
const CODE_TTL_SECONDS = 10 * 60;
const ACCESS_TOKEN_TTL_SECONDS = 60 * 60;
const REFRESH_TOKEN_TTL_SECONDS = 60 * 60 * 24;

export type OAuthAuthorizeParams = {
  response_type?: string;
  client_id?: string;
  redirect_uri?: string;
  scope?: string;
  state?: string;
  code_challenge?: string;
  code_challenge_method?: string;
  resource?: string;
};

export type OAuthTokenRequest = {
  grant_type?: string;
  code?: string;
  redirect_uri?: string;
  client_id?: string;
  client_secret?: string;
  code_verifier?: string;
  refresh_token?: string;
  resource?: string;
};

export type OAuthTokenResponse = {
  access_token: string;
  refresh_token: string;
  token_type: "Bearer";
  expires_in: number;
  scope: string;
};

export type OAuthClientRegistrationRequest = {
  client_name?: string;
  redirect_uris?: string[];
  token_endpoint_auth_method?: string;
  scope?: string;
  usuario_id?: string | null;
  escritorio_id?: string | null;
};

export type OAuthTokenIntrospection = {
  active: boolean;
  client_id?: string;
  scope?: string;
  exp?: number;
  sub?: string;
  aud?: string;
  username?: string;
  escritorio_id?: string;
  usuario_id?: string;
};

export function getOAuthIssuer(baseUrl: string): string {
  return (settings.OAUTH_ISSUER_URL.trim() || baseUrl).replace(/\/+$/g, "");
}

export function getOAuthResource(baseUrl: string): string {
  return (settings.OAUTH_MCP_RESOURCE_URL.trim() || `${getOAuthIssuer(baseUrl)}/mcp`).replace(/\/+$/g, "");
}

export function hashOAuthSecret(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function generateOpaqueToken(prefix: string): string {
  return `${prefix}_${randomBytes(32).toString("base64url")}`;
}

export async function registerOAuthClient(input: OAuthClientRegistrationRequest): Promise<{
  client_id: string;
  client_secret?: string;
  client_id_issued_at: number;
  redirect_uris: string[];
  token_endpoint_auth_method: string;
  client_name?: string;
  scope: string;
}> {
  await ensureDatabase();

  const redirectUris = Array.isArray(input.redirect_uris)
    ? input.redirect_uris.filter((uri) => typeof uri === "string" && isAllowedRedirectUri(uri))
    : [];
  if (redirectUris.length === 0) {
    throw new OAuthRequestError("invalid_client_metadata", "redirect_uris precisa conter ao menos uma URL HTTPS ou localhost.");
  }

  const method = input.token_endpoint_auth_method?.trim() || "none";
  if (!["none", "client_secret_post"].includes(method)) {
    throw new OAuthRequestError("invalid_client_metadata", "token_endpoint_auth_method não suportado.");
  }

  const clientId = generateOpaqueToken("client");
  const clientSecret = method === "none" ? undefined : generateOpaqueToken("secret");

  const repo = AppDataSource.getRepository(OAuthClient);
  await repo.save(repo.create({
    client_id: clientId,
    client_secret_hash: clientSecret ? hashOAuthSecret(clientSecret) : null,
    client_name: input.client_name?.trim() || null,
    usuario_id: input.usuario_id ?? null,
    escritorio_id: input.escritorio_id ?? null,
    redirect_uris: redirectUris,
    token_endpoint_auth_method: method,
    scope: input.scope?.trim() || DEFAULT_SCOPE,
  }));

  return {
    client_id: clientId,
    ...(clientSecret ? { client_secret: clientSecret } : {}),
    client_id_issued_at: Math.floor(Date.now() / 1000),
    redirect_uris: redirectUris,
    token_endpoint_auth_method: method,
    ...(input.client_name ? { client_name: input.client_name } : {}),
    scope: input.scope?.trim() || DEFAULT_SCOPE,
  };
}

export async function listOAuthClientsForEscritorio(escritorioId: string): Promise<Array<{
  id: string;
  client_id: string;
  client_name: string | null;
  redirect_uris: string[];
  token_endpoint_auth_method: string;
  scope: string | null;
  created_at: Date;
  updated_at: Date;
}>> {
  await ensureDatabase();

  const repo = AppDataSource.getRepository(OAuthClient);
  const clients = await repo.find({
    where: { escritorio_id: escritorioId },
    order: { created_at: "DESC" },
  });

  return clients.map((client) => ({
    id: client.id,
    client_id: client.client_id,
    client_name: client.client_name,
    redirect_uris: client.redirect_uris,
    token_endpoint_auth_method: client.token_endpoint_auth_method,
    scope: client.scope,
    created_at: client.created_at,
    updated_at: client.updated_at,
  }));
}

export async function validateAuthorizationRequest(params: OAuthAuthorizeParams): Promise<OAuthClient> {
  await ensureDatabase();

  if (params.response_type !== "code") {
    throw new OAuthRequestError("unsupported_response_type", "response_type deve ser code.");
  }

  if (!params.client_id) {
    throw new OAuthRequestError("invalid_request", "client_id é obrigatório.");
  }

  if (!params.redirect_uri) {
    throw new OAuthRequestError("invalid_request", "redirect_uri é obrigatório.");
  }

  if (!params.code_challenge || params.code_challenge_method !== "S256") {
    throw new OAuthRequestError("invalid_request", "PKCE S256 é obrigatório.");
  }

  const repo = AppDataSource.getRepository(OAuthClient);
  const client = await repo.findOne({ where: { client_id: params.client_id } });
  if (!client) {
    throw new OAuthRequestError("unauthorized_client", "client_id desconhecido.");
  }

  if (!client.redirect_uris.includes(params.redirect_uri)) {
    throw new OAuthRequestError("invalid_request", "redirect_uri não registrada para este client.");
  }

  return client;
}

export async function issueAuthorizationCode(params: OAuthAuthorizeParams, sessionId: string): Promise<string> {
  const session = await resolveApplicationSessionFromId(sessionId);
  if (!session) {
    throw new OAuthRequestError("access_denied", "Sessão BlueAccount inválida ou expirada.");
  }

  await validateAuthorizationRequest(params);

  const code = generateOpaqueToken("code");
  const repo = AppDataSource.getRepository(OAuthAuthorizationCode);
  await repo.save(repo.create({
    code_hash: hashOAuthSecret(code),
    client_id: params.client_id!,
    usuario_id: session.usuario_id,
    escritorio_id: session.escritorio_id,
    session_id_hash: hashSessionId(sessionId),
    redirect_uri: params.redirect_uri!,
    code_challenge: params.code_challenge!,
    code_challenge_method: "S256",
    scope: params.scope?.trim() || DEFAULT_SCOPE,
    resource: params.resource?.trim() || null,
    expires_at: new Date(Date.now() + CODE_TTL_SECONDS * 1000),
    consumed_at: null,
  }));

  return code;
}

export async function exchangeAuthorizationCode(input: OAuthTokenRequest): Promise<OAuthTokenResponse> {
  await ensureDatabase();

  if (input.grant_type !== "authorization_code") {
    throw new OAuthRequestError("unsupported_grant_type", "grant_type deve ser authorization_code.");
  }

  if (!input.code || !input.client_id || !input.redirect_uri || !input.code_verifier) {
    throw new OAuthRequestError("invalid_request", "code, client_id, redirect_uri e code_verifier são obrigatórios.");
  }

  const client = await validateTokenClient(input);
  const codeRepo = AppDataSource.getRepository(OAuthAuthorizationCode);
  const codeRecord = await codeRepo.findOne({ where: { code_hash: hashOAuthSecret(input.code) } });
  if (!codeRecord || codeRecord.client_id !== client.client_id) {
    throw new OAuthRequestError("invalid_grant", "Código inválido.");
  }

  if (codeRecord.consumed_at || codeRecord.expires_at.getTime() <= Date.now()) {
    throw new OAuthRequestError("invalid_grant", "Código expirado ou já consumido.");
  }

  if (codeRecord.redirect_uri !== input.redirect_uri) {
    throw new OAuthRequestError("invalid_grant", "redirect_uri não corresponde ao código.");
  }

  if (input.resource && codeRecord.resource && input.resource !== codeRecord.resource) {
    throw new OAuthRequestError("invalid_target", "resource não corresponde ao código.");
  }

  if (!verifyPkce(input.code_verifier, codeRecord.code_challenge)) {
    throw new OAuthRequestError("invalid_grant", "code_verifier inválido.");
  }

  const session = await resolveApplicationSessionFromHash(codeRecord.session_id_hash);
  if (!session) {
    throw new OAuthRequestError("invalid_grant", "Sessão vinculada ao código expirou.");
  }

  return AppDataSource.transaction(async (manager) => {
    const now = new Date();
    await manager.getRepository(OAuthAuthorizationCode).update(codeRecord.id, { consumed_at: now });
    const resource = input.resource || codeRecord.resource;
    await revokeCredentialsForClient(manager, {
      clientId: client.client_id,
      usuarioId: session.usuario_id,
      resource,
      now,
    });
    return issueTokenPair(manager, {
      clientId: client.client_id,
      session,
      sessionIdHash: codeRecord.session_id_hash,
      scope: codeRecord.scope || DEFAULT_SCOPE,
      resource,
      familyId: randomUUID(),
      now,
    });
  });
}

export async function exchangeRefreshToken(input: OAuthTokenRequest): Promise<OAuthTokenResponse> {
  await ensureDatabase();
  if (input.grant_type !== "refresh_token") {
    throw new OAuthRequestError("unsupported_grant_type", "grant_type deve ser refresh_token.");
  }
  if (!input.refresh_token || !input.client_id) {
    throw new OAuthRequestError("invalid_request", "refresh_token e client_id são obrigatórios.");
  }

  const client = await validateTokenClient(input);
  const result = await AppDataSource.transaction(async (manager) => {
    const refreshRepo = manager.getRepository(OAuthRefreshToken);
    const tokenRecord = await refreshRepo.createQueryBuilder("refresh")
      .setLock("pessimistic_write")
      .where("refresh.token_hash = :tokenHash", { tokenHash: hashOAuthSecret(input.refresh_token!) })
      .getOne();
    const now = new Date();

    if (!tokenRecord || tokenRecord.client_id !== client.client_id) {
      return { status: "invalid" as const };
    }
    if (tokenRecord.revoked_at || tokenRecord.expires_at.getTime() <= now.getTime()) {
      await revokeTokenFamily(manager, tokenRecord.family_id, now);
      return { status: "replayed" as const };
    }

    const session = await resolveApplicationSessionFromHash(tokenRecord.session_id_hash);
    if (!session) {
      await revokeTokenFamily(manager, tokenRecord.family_id, now);
      return { status: "expired_session" as const };
    }
    if (input.resource && tokenRecord.resource && input.resource !== tokenRecord.resource) {
      return { status: "invalid_target" as const };
    }

    await refreshRepo.update(tokenRecord.id, { revoked_at: now, last_seen_at: now });
    await manager.getRepository(OAuthAccessToken).createQueryBuilder()
      .update(OAuthAccessToken)
      .set({ revoked_at: now })
      .where("family_id = :familyId", { familyId: tokenRecord.family_id })
      .andWhere("revoked_at IS NULL")
      .execute();
    return {
      status: "ok" as const,
      response: await issueTokenPair(manager, {
        clientId: client.client_id,
        session,
        sessionIdHash: tokenRecord.session_id_hash,
        scope: tokenRecord.scope || DEFAULT_SCOPE,
        resource: tokenRecord.resource,
        familyId: tokenRecord.family_id,
        rotatedFromId: tokenRecord.id,
        now,
      }),
    };
  });

  if (result.status === "ok") return result.response;
  if (result.status === "invalid_target") {
    throw new OAuthRequestError("invalid_target", "resource não corresponde ao refresh token.");
  }
  throw new OAuthRequestError("invalid_grant", "Refresh token inválido, expirado ou já utilizado.");
}

async function issueTokenPair(
  manager: EntityManager,
  input: {
    clientId: string;
    session: ApplicationSessionContext;
    sessionIdHash: string;
    scope: string;
    resource: string | null;
    familyId: string;
    rotatedFromId?: string;
    now: Date;
  },
): Promise<OAuthTokenResponse> {
  const accessToken = generateOpaqueToken("ba");
  const refreshToken = generateOpaqueToken("refresh");
  await manager.getRepository(OAuthAccessToken).save({
    token_hash: hashOAuthSecret(accessToken),
    client_id: input.clientId,
    usuario_id: input.session.usuario_id,
    escritorio_id: input.session.escritorio_id,
    session_id_hash: input.sessionIdHash,
    family_id: input.familyId,
    scope: input.scope,
    resource: input.resource,
    expires_at: new Date(input.now.getTime() + ACCESS_TOKEN_TTL_SECONDS * 1000),
    revoked_at: null,
    last_seen_at: input.now,
  });
  await manager.getRepository(OAuthRefreshToken).save({
    token_hash: hashOAuthSecret(refreshToken),
    family_id: input.familyId,
    client_id: input.clientId,
    usuario_id: input.session.usuario_id,
    escritorio_id: input.session.escritorio_id,
    session_id_hash: input.sessionIdHash,
    scope: input.scope,
    resource: input.resource,
    expires_at: new Date(input.now.getTime() + REFRESH_TOKEN_TTL_SECONDS * 1000),
    revoked_at: null,
    last_seen_at: input.now,
    rotated_from_id: input.rotatedFromId ?? null,
  });
  return {
    access_token: accessToken,
    refresh_token: refreshToken,
    token_type: "Bearer",
    expires_in: ACCESS_TOKEN_TTL_SECONDS,
    scope: input.scope,
  };
}

async function revokeCredentialsForClient(
  manager: EntityManager,
  input: { clientId: string; usuarioId: string; resource: string | null; now: Date },
): Promise<void> {
  for (const entity of [OAuthAccessToken, OAuthRefreshToken]) {
    await manager.getRepository(entity).createQueryBuilder()
      .update(entity)
      .set({ revoked_at: input.now })
      .where("client_id = :clientId", { clientId: input.clientId })
      .andWhere("usuario_id = :usuarioId", { usuarioId: input.usuarioId })
      .andWhere("revoked_at IS NULL")
      .andWhere(resourceWhereClause(input.resource), { resource: input.resource })
      .execute();
  }
}

async function revokeTokenFamily(manager: EntityManager, familyId: string, now: Date): Promise<void> {
  for (const entity of [OAuthAccessToken, OAuthRefreshToken]) {
    await manager.getRepository(entity).createQueryBuilder()
      .update(entity)
      .set({ revoked_at: now })
      .where("family_id = :familyId", { familyId })
      .andWhere("revoked_at IS NULL")
      .execute();
  }
}

function resourceWhereClause(resource: string | null): string {
  return resource ? "resource = :resource" : "resource IS NULL";
}

export async function resolveApplicationSessionFromOAuthAccessToken(accessToken: string): Promise<ApplicationSessionContext | null> {
  if (!accessToken) return null;
  await ensureDatabase();

  const repo = AppDataSource.getRepository(OAuthAccessToken);
  const tokenRecord = await repo.findOne({ where: { token_hash: hashOAuthSecret(accessToken) } });
  if (!tokenRecord) return null;
  if (tokenRecord.revoked_at) return null;
  if (tokenRecord.expires_at.getTime() <= Date.now()) return null;

  const session = await resolveApplicationSessionFromHash(tokenRecord.session_id_hash);
  if (!session) return null;

  await repo.update(tokenRecord.id, { last_seen_at: new Date() });
  return session;
}

export async function introspectOAuthToken(accessToken: string): Promise<OAuthTokenIntrospection> {
  const session = await resolveApplicationSessionFromOAuthAccessToken(accessToken);
  if (!session) return { active: false };

  const repo = AppDataSource.getRepository(OAuthAccessToken);
  const tokenRecord = await repo.findOne({ where: { token_hash: hashOAuthSecret(accessToken) } });
  if (!tokenRecord) return { active: false };

  return {
    active: true,
    client_id: tokenRecord.client_id,
    scope: tokenRecord.scope ?? DEFAULT_SCOPE,
    exp: Math.floor(tokenRecord.expires_at.getTime() / 1000),
    sub: session.usuario_id,
    username: session.usuario.email,
    aud: tokenRecord.resource ?? undefined,
    escritorio_id: session.escritorio_id,
    usuario_id: session.usuario_id,
  };
}

export async function revokeOAuthToken(token: string): Promise<void> {
  if (!token) return;
  await ensureDatabase();

  const tokenHash = hashOAuthSecret(token);
  await AppDataSource.transaction(async (manager) => {
    const [accessToken, refreshToken] = await Promise.all([
      manager.getRepository(OAuthAccessToken).findOne({ where: { token_hash: tokenHash } }),
      manager.getRepository(OAuthRefreshToken).findOne({ where: { token_hash: tokenHash } }),
    ]);
    const familyId = accessToken?.family_id ?? refreshToken?.family_id;
    const now = new Date();
    if (familyId) {
      await revokeTokenFamily(manager, familyId, now);
    } else if (accessToken && !accessToken.revoked_at) {
      await manager.getRepository(OAuthAccessToken).update(accessToken.id, { revoked_at: now });
    }
  });
}

export type AdminOAuthTokenView = {
  id: string;
  client_id: string;
  usuario_id: string;
  usuario_email: string | null;
  escritorio_id: string;
  escritorio_nome: string | null;
  scope: string | null;
  resource: string | null;
  last_seen_at: Date | null;
  expires_at: Date;
  created_at: Date;
};

export async function listOAuthAccessTokens(): Promise<AdminOAuthTokenView[]> {
  await ensureDatabase();

  const repo = AppDataSource.getRepository(OAuthAccessToken);
  const tokens = await repo.find({
    where: { revoked_at: IsNull(), expires_at: MoreThan(new Date()) },
    order: { created_at: "DESC" },
  });

  if (tokens.length === 0) return [];

  const usuarioIds = Array.from(new Set(tokens.map((token) => token.usuario_id)));
  const escritorioIds = Array.from(new Set(tokens.map((token) => token.escritorio_id)));

  const [usuarios, escritorios] = await Promise.all([
    AppDataSource.getRepository(Usuario).find({ where: { id: In(usuarioIds) } }),
    AppDataSource.getRepository(Escritorio).find({ where: { id: In(escritorioIds) } }),
  ]);

  const usuarioById = new Map(usuarios.map((usuario) => [usuario.id, usuario]));
  const escritorioById = new Map(escritorios.map((escritorio) => [escritorio.id, escritorio]));

  return tokens.map((token) => ({
    id: token.id,
    client_id: token.client_id,
    usuario_id: token.usuario_id,
    usuario_email: usuarioById.get(token.usuario_id)?.email ?? null,
    escritorio_id: token.escritorio_id,
    escritorio_nome: escritorioById.get(token.escritorio_id)?.nome ?? null,
    scope: token.scope,
    resource: token.resource,
    last_seen_at: token.last_seen_at,
    expires_at: token.expires_at,
    created_at: token.created_at,
  }));
}

export async function revokeOAuthTokenByEntityId(id: string): Promise<boolean> {
  if (!id) return false;
  await ensureDatabase();

  const repo = AppDataSource.getRepository(OAuthAccessToken);
  const tokenRecord = await repo.findOne({ where: { id } });
  if (!tokenRecord) return false;

  await AppDataSource.transaction(async (manager) => {
    const now = new Date();
    if (tokenRecord.family_id) {
      await revokeTokenFamily(manager, tokenRecord.family_id, now);
    } else if (!tokenRecord.revoked_at) {
      await manager.getRepository(OAuthAccessToken).update(tokenRecord.id, { revoked_at: now });
    }
  });
  return true;
}

async function validateTokenClient(input: OAuthTokenRequest): Promise<OAuthClient> {
  const repo = AppDataSource.getRepository(OAuthClient);
  const client = await repo.findOne({ where: { client_id: input.client_id } });
  if (!client) {
    throw new OAuthRequestError("invalid_client", "client_id inválido.");
  }

  if (client.client_secret_hash) {
    if (!input.client_secret || !safeEqual(hashOAuthSecret(input.client_secret), client.client_secret_hash)) {
      throw new OAuthRequestError("invalid_client", "client_secret inválido.");
    }
  }

  return client;
}

function verifyPkce(codeVerifier: string, expectedChallenge: string): boolean {
  const challenge = createHash("sha256").update(codeVerifier).digest("base64url");
  return safeEqual(challenge, expectedChallenge);
}

function safeEqual(a: string, b: string): boolean {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

function isAllowedRedirectUri(uri: string): boolean {
  try {
    const parsed = new URL(uri);
    return parsed.protocol === "https:" || parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1";
  } catch {
    return false;
  }
}

export class OAuthRequestError extends Error {
  constructor(
    public readonly error: string,
    message: string,
    public readonly statusCode = 400,
  ) {
    super(message);
  }
}
