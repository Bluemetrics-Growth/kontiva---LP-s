import type { OpcaoIbsCbs } from "../../database/modules/tenant/entities/fornecedor.entity.js";
import type { RegimeTributario } from "../clientes/regime-tributario.js";

/**
 * Fornecedores genéricos: contrapartes sintéticas, uma por perfil de regime, existentes em todo
 * escritório.
 *
 * Por que existem: o motor só reconhece crédito de IBS/CBS quando a linha tem `fornecedor_id` e o
 * cadastro comprova o regime (`domain/simulacoes/calculo.ts`, ramo `perfilFornecedor !== null`).
 * Uma despesa manual sem fornecedor fica com crédito zerado, e a saída "cadastre um fornecedor
 * Lucro Presumido" não existia: `fornecedores.cnpj` era obrigatório e único, então um genérico
 * exigiria um documento inventado.
 *
 * O que NÃO carregam, de propósito:
 *
 * - `cnpj`: não há documento. É a diferença honesta entre "fornecedor no Lucro Presumido" e "este
 *   fornecedor". Garantido por `CHK_fornecedores_generico`;
 * - `uf`/`codigo_municipio_ibge`: origem desconhecida. `resolverLocalidadeDaEntrada` já lê ausência
 *   de UF como operação interna (alíquota do próprio estado do cenário) e desliga o DIFAL, que é a
 *   leitura certa para uma contraparte sem identidade;
 * - `cnae_principal`: sem ramo. Consequência que precisa ser dita: num cliente com
 *   `cnaes_fornecedores_permitidos`, `permiteCreditoPorCnaeFornecedor` reprova linha sem CNAE, então
 *   o crédito de **ICMS** da linha fica bloqueado até alguém informar `cnae_override` nela. IBS/CBS
 *   não passa por esse gate e é justamente o que o genérico resolve;
 * - `aliquota_credito_presumido_*`: os percentuais oficiais do art. 47, §9º, II dependem de
 *   regulamento CGIBS/RFB não publicado. Genérico de Simples/MEI portanto entra como `presumido`
 *   com percentual zero, igual a qualquer fornecedor real do Simples sem percentual informado.
 *
 * Quem escreve as linhas é a migration `1787200000000-add-fornecedores-genericos`, que roda tanto no
 * escritório recém-provisionado (`provisionEscritorioSchema`) quanto nos existentes
 * (`migration:sync-tenants`). Este módulo é o contrato legível dela e a base do teste que prova o
 * perfil de crédito de cada perfil; a lista é duplicada porque migration é snapshot e não pode
 * importar domínio vivo. Ao adicionar um perfil: mexer aqui e escrever uma migration nova.
 */
export type FornecedorGenericoModelo = {
  razao_social: string;
  regime_tributario: RegimeTributario;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
};

/**
 * Um modelo por perfil de crédito distinto que `resolverCreditoFornecedor` sabe produzir.
 *
 * Simples Nacional aparece duas vezes porque a opção do art. 41 (a "híbrida") muda o perfil de
 * `presumido` para `integral` sem mudar o regime. MEI leva `regime_unico` explícito em vez de nulo
 * para a chave da UNIQUE parcial ficar completa, e porque o efeito é o mesmo (o art. 41 é exclusivo
 * do Simples Nacional).
 */
export const FORNECEDORES_GENERICOS: readonly FornecedorGenericoModelo[] = [
  { razao_social: "Genérico - Lucro Real", regime_tributario: "Lucro Real", opcao_ibs_cbs: null },
  {
    razao_social: "Genérico - Lucro Presumido",
    regime_tributario: "Lucro Presumido",
    opcao_ibs_cbs: null,
  },
  {
    razao_social: "Genérico - Simples Nacional (DAS)",
    regime_tributario: "Simples Nacional",
    opcao_ibs_cbs: "regime_unico",
  },
  {
    razao_social: "Genérico - Simples Nacional (híbrido)",
    regime_tributario: "Simples Nacional",
    opcao_ibs_cbs: "regime_regular",
  },
  { razao_social: "Genérico - MEI", regime_tributario: "MEI", opcao_ibs_cbs: "regime_unico" },
  {
    razao_social: "Genérico - Pessoa Física",
    regime_tributario: "Pessoa Física",
    opcao_ibs_cbs: null,
  },
] as const;
