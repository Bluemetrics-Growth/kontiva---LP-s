import { Brackets, IsNull, type EntityManager } from "typeorm";
import { runQueryWithRls } from "../../database/data-source.js";
import {
  Fornecedor,
  type AliquotaFonte,
  type CnaeSecundario,
  type OpcaoIbsCbs,
} from "../../database/modules/tenant/entities/fornecedor.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import { normalizarCnpj, DocumentoClienteInvalidoError } from "../clientes/cliente.service.js";
import {
  normalizarRegimeParaDocumento,
  REGIMES_TRIBUTARIOS,
  type RegimeTributario,
} from "../clientes/regime-tributario.js";
import { normalizarCodigoMunicipioIbge } from "../simulacoes/localidade/ibge.js";
import { somenteDigitos } from "../texto.js";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginatedResult,
  type PaginationInput,
} from "../pagination.js";
import {
  permiteOpcaoIbsCbsRegimeRegular,
  resolverCreditoFornecedor,
  type CreditoFornecedorResolvido,
} from "./regime-credito.js";
import { consultarCnpjSemBloquear, type CadastroCnpjConsultado } from "./consulta-cnpj.service.js";
import { FORNECEDORES_GENERICOS } from "./fornecedores-genericos.js";

export { DocumentoClienteInvalidoError };

/** Erro de validação de payload de fornecedor. Vira HTTP 400, não 500. */
export class FornecedorValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FornecedorValidationError";
  }
}

const OPCOES_IBS_CBS: readonly OpcaoIbsCbs[] = ["regime_unico", "regime_regular"];

/**
 * Opção do art. 41 a assumir quando o chamador não informa nenhuma.
 *
 * Sai do próprio catálogo, não de uma lista de regimes escrita à mão: o genérico de MEI é semeado
 * com `regime_unico` explícito, então procurar `opcao_ibs_cbs IS NULL` para MEI não achava linha
 * nenhuma e a importação inteira morria com "Planilha inválida." — a tela manda o regime escolhido
 * sem opção, porque o art. 41 é exclusivo do Simples Nacional. Simples é o único regime com dois
 * genéricos (DAS e híbrido) e o único caso ambíguo: sem escolha explícita, vale o conservador
 * `regime_unico`.
 */
function opcaoPadraoDoGenerico(regimeTributario: string): OpcaoIbsCbs | null {
  const modelos = FORNECEDORES_GENERICOS.filter((modelo) => modelo.regime_tributario === regimeTributario);
  if (modelos.length === 1) return modelos[0].opcao_ibs_cbs;
  return modelos.some((modelo) => modelo.opcao_ibs_cbs === "regime_unico") ? "regime_unico" : null;
}

export type FornecedorResumo = {
  id: string;
  /** Null em fornecedor genérico: não há documento a afirmar. */
  cnpj: string | null;
  /** Contraparte sintética por perfil de regime. Ver `fornecedores-genericos.ts`. */
  generico: boolean;
  razao_social: string;
  nome_fantasia: string | null;
  regime_tributario: string | null;
  uf: string | null;
  municipio: string | null;
  /** Código IBGE de 7 dígitos. Chave da alíquota de ISS derivada da localidade. */
  codigo_municipio_ibge: string | null;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
  aliquota_credito_presumido_ibs: number | null;
  aliquota_credito_presumido_cbs: number | null;
  /** Alíquota nominal (cheia) de ICMS, pré-fator de retenção do cronograma. */
  aliquota_icms_nominal: number | null;
  aliquota_iss_nominal: number | null;
  /** Somente leitura: `nfe` = derivada das notas, `manual` = digitada (importação não sobrescreve). */
  aliquota_icms_fonte: AliquotaFonte | null;
  aliquota_iss_fonte: AliquotaFonte | null;
  cnae_principal: string | null;
  cnae_principal_descricao: string | null;
  cnaes_secundarios: CnaeSecundario[] | null;
  porte: string | null;
  natureza_juridica: string | null;
  situacao_cadastral: string | null;
  optante_simples: boolean | null;
  optante_mei: boolean | null;
  consulta_cnpj_em: string | null;
  consulta_cnpj_fonte: string | null;
  observacoes: string | null;
  ativo: boolean;
  /** Perfil de crédito derivado, para a tela explicar o número sem repetir a regra. */
  credito: CreditoFornecedorResolvido;
};

export type FornecedorInput = {
  cnpj?: unknown;
  razao_social?: unknown;
  nome_fantasia?: unknown;
  regime_tributario?: unknown;
  uf?: unknown;
  municipio?: unknown;
  codigo_municipio_ibge?: unknown;
  opcao_ibs_cbs?: unknown;
  aliquota_credito_presumido_ibs?: unknown;
  aliquota_credito_presumido_cbs?: unknown;
  aliquota_icms_nominal?: unknown;
  aliquota_iss_nominal?: unknown;
  cnae_principal?: unknown;
  cnae_principal_descricao?: unknown;
  cnaes_secundarios?: unknown;
  porte?: unknown;
  natureza_juridica?: unknown;
  situacao_cadastral?: unknown;
  optante_simples?: unknown;
  optante_mei?: unknown;
  consulta_cnpj_em?: unknown;
  consulta_cnpj_fonte?: unknown;
  observacoes?: unknown;
  ativo?: unknown;
};

function textoOuNulo(value: unknown): string | null {
  if (value == null) return null;
  const texto = String(value).trim();
  return texto === "" ? null : texto;
}

function textoObrigatorio(value: unknown, campo: string): string {
  const texto = textoOuNulo(value);
  if (texto === null) throw new FornecedorValidationError(`${campo} é obrigatório.`);
  return texto;
}

function ufOuNulo(value: unknown): string | null {
  const texto = textoOuNulo(value);
  if (texto === null) return null;
  const uf = texto.toUpperCase();
  if (!/^[A-Z]{2}$/.test(uf)) {
    throw new FornecedorValidationError(`uf inválida: "${texto}". Use a sigla de 2 letras.`);
  }
  return uf;
}

function opcaoIbsCbsOuNulo(value: unknown): OpcaoIbsCbs | null {
  const texto = textoOuNulo(value);
  if (texto === null) return null;
  if (!OPCOES_IBS_CBS.includes(texto as OpcaoIbsCbs)) {
    throw new FornecedorValidationError(
      `opcao_ibs_cbs inválida: "${texto}". Valores aceitos: ${OPCOES_IBS_CBS.join(", ")}.`,
    );
  }
  return texto as OpcaoIbsCbs;
}

/** Alíquota como fração (0 a 1). Rejeita percentual solto tipo 15 para não gerar crédito absurdo. */
function aliquotaOuNulo(value: unknown, campo: string): number | null {
  if (value == null || value === "") return null;
  const numero = Number(value);
  if (!Number.isFinite(numero) || numero < 0 || numero > 1) {
    throw new FornecedorValidationError(
      `${campo} deve ser uma fração entre 0 e 1 (ex.: 0.015 para 1,5%).`,
    );
  }
  return numero;
}

function cnaeOuNulo(value: unknown): string | null {
  const texto = textoOuNulo(value);
  if (texto === null) return null;
  const digitos = somenteDigitos(texto);
  if (digitos.length === 0 || digitos.length > 7) {
    throw new FornecedorValidationError(`cnae_principal inválido: "${texto}".`);
  }
  return digitos.padStart(7, "0");
}

function cnaesSecundariosOuNulo(value: unknown): CnaeSecundario[] | null {
  if (value == null) return null;
  if (!Array.isArray(value)) {
    throw new FornecedorValidationError("cnaes_secundarios deve ser uma lista.");
  }
  const itens = value
    .map((item) => {
      const registro = (item ?? {}) as Record<string, unknown>;
      const codigo = somenteDigitos(textoOuNulo(registro.codigo));
      if (!codigo) return null;
      return { codigo: codigo.padStart(7, "0"), descricao: textoOuNulo(registro.descricao) ?? "" };
    })
    .filter((item): item is CnaeSecundario => item !== null);
  return itens.length > 0 ? itens : null;
}

function booleanoOuNulo(value: unknown, campo: string): boolean | null {
  if (value == null || value === "") return null;
  if (typeof value === "boolean") return value;
  const texto = String(value).trim().toLowerCase();
  if (["true", "1", "sim"].includes(texto)) return true;
  if (["false", "0", "nao", "não"].includes(texto)) return false;
  throw new FornecedorValidationError(`${campo} deve ser booleano.`);
}

function dataOuNulo(value: unknown): Date | null {
  if (value == null || value === "") return null;
  const data = new Date(String(value));
  return Number.isNaN(data.getTime()) ? null : data;
}

function paraResumo(f: Fornecedor): FornecedorResumo {
  return {
    id: f.id,
    cnpj: f.cnpj,
    generico: f.generico === true,
    razao_social: f.razao_social,
    nome_fantasia: f.nome_fantasia,
    regime_tributario: f.regime_tributario,
    uf: f.uf,
    municipio: f.municipio,
    codigo_municipio_ibge: f.codigo_municipio_ibge,
    opcao_ibs_cbs: f.opcao_ibs_cbs,
    aliquota_credito_presumido_ibs:
      f.aliquota_credito_presumido_ibs == null ? null : Number(f.aliquota_credito_presumido_ibs),
    aliquota_credito_presumido_cbs:
      f.aliquota_credito_presumido_cbs == null ? null : Number(f.aliquota_credito_presumido_cbs),
    aliquota_icms_nominal: f.aliquota_icms_nominal == null ? null : Number(f.aliquota_icms_nominal),
    aliquota_iss_nominal: f.aliquota_iss_nominal == null ? null : Number(f.aliquota_iss_nominal),
    aliquota_icms_fonte: f.aliquota_icms_fonte,
    aliquota_iss_fonte: f.aliquota_iss_fonte,
    cnae_principal: f.cnae_principal,
    cnae_principal_descricao: f.cnae_principal_descricao,
    cnaes_secundarios: f.cnaes_secundarios,
    porte: f.porte,
    natureza_juridica: f.natureza_juridica,
    situacao_cadastral: f.situacao_cadastral,
    optante_simples: f.optante_simples,
    optante_mei: f.optante_mei,
    consulta_cnpj_em: f.consulta_cnpj_em ? new Date(f.consulta_cnpj_em).toISOString() : null,
    consulta_cnpj_fonte: f.consulta_cnpj_fonte,
    observacoes: f.observacoes,
    ativo: f.ativo,
    credito: resolverCreditoFornecedor({
      regime_tributario: f.regime_tributario,
      opcao_ibs_cbs: f.opcao_ibs_cbs,
      aliquota_credito_presumido_ibs:
        f.aliquota_credito_presumido_ibs == null ? null : Number(f.aliquota_credito_presumido_ibs),
      aliquota_credito_presumido_cbs:
        f.aliquota_credito_presumido_cbs == null ? null : Number(f.aliquota_credito_presumido_cbs),
    }),
  };
}

/**
 * Aplica os campos presentes no input sobre a entidade. Segue o padrão de `patchCliente`: só o que
 * veio no corpo é tocado, para um PATCH parcial não apagar campo omitido.
 */
function aplicarCampos(fornecedor: Fornecedor, input: FornecedorInput, documento: string): void {
  if ("razao_social" in input) {
    fornecedor.razao_social = textoObrigatorio(input.razao_social, "razao_social");
  }
  if ("nome_fantasia" in input) fornecedor.nome_fantasia = textoOuNulo(input.nome_fantasia);
  if ("regime_tributario" in input) {
    fornecedor.regime_tributario = normalizarRegimeParaDocumento(input.regime_tributario, documento);
  }
  // ORDEM IMPORTA: `uf` primeiro. O guard do código de município valida o prefixo contra a UF da
  // linha, e aplicá-lo antes compararia com a UF antiga — numa mudança de estado, o código novo
  // seria rejeitado (ou o antigo, aceito) silenciosamente.
  if ("uf" in input) fornecedor.uf = ufOuNulo(input.uf);
  if ("municipio" in input) fornecedor.municipio = textoOuNulo(input.municipio);
  if ("codigo_municipio_ibge" in input) {
    fornecedor.codigo_municipio_ibge = normalizarCodigoMunicipioIbge(
      input.codigo_municipio_ibge,
      fornecedor.uf,
    );
  }
  if ("opcao_ibs_cbs" in input) fornecedor.opcao_ibs_cbs = opcaoIbsCbsOuNulo(input.opcao_ibs_cbs);
  if ("aliquota_credito_presumido_ibs" in input) {
    fornecedor.aliquota_credito_presumido_ibs = aliquotaOuNulo(
      input.aliquota_credito_presumido_ibs,
      "aliquota_credito_presumido_ibs",
    );
  }
  if ("aliquota_credito_presumido_cbs" in input) {
    fornecedor.aliquota_credito_presumido_cbs = aliquotaOuNulo(
      input.aliquota_credito_presumido_cbs,
      "aliquota_credito_presumido_cbs",
    );
  }
  // Alíquota informada no corpo é decisão do contador: marca a fonte como `manual` e a importação de
  // NF-e passa a respeitar o número. Valor nulo é "sem opinião" e devolve o campo à derivação — sem
  // isso, salvar o formulário com o campo vazio congelaria o fornecedor em branco para sempre.
  if ("aliquota_icms_nominal" in input) {
    fornecedor.aliquota_icms_nominal = aliquotaOuNulo(
      input.aliquota_icms_nominal,
      "aliquota_icms_nominal",
    );
    fornecedor.aliquota_icms_fonte = fornecedor.aliquota_icms_nominal === null ? null : "manual";
  }
  if ("aliquota_iss_nominal" in input) {
    fornecedor.aliquota_iss_nominal = aliquotaOuNulo(
      input.aliquota_iss_nominal,
      "aliquota_iss_nominal",
    );
    fornecedor.aliquota_iss_fonte = fornecedor.aliquota_iss_nominal === null ? null : "manual";
  }
  if ("cnae_principal" in input) fornecedor.cnae_principal = cnaeOuNulo(input.cnae_principal);
  if ("cnae_principal_descricao" in input) {
    fornecedor.cnae_principal_descricao = textoOuNulo(input.cnae_principal_descricao);
  }
  if ("cnaes_secundarios" in input) {
    fornecedor.cnaes_secundarios = cnaesSecundariosOuNulo(input.cnaes_secundarios);
  }
  if ("porte" in input) fornecedor.porte = textoOuNulo(input.porte);
  if ("natureza_juridica" in input) fornecedor.natureza_juridica = textoOuNulo(input.natureza_juridica);
  if ("situacao_cadastral" in input) fornecedor.situacao_cadastral = textoOuNulo(input.situacao_cadastral);
  if ("optante_simples" in input) {
    fornecedor.optante_simples = booleanoOuNulo(input.optante_simples, "optante_simples");
  }
  if ("optante_mei" in input) {
    fornecedor.optante_mei = booleanoOuNulo(input.optante_mei, "optante_mei");
  }
  if ("consulta_cnpj_em" in input) fornecedor.consulta_cnpj_em = dataOuNulo(input.consulta_cnpj_em);
  if ("consulta_cnpj_fonte" in input) {
    fornecedor.consulta_cnpj_fonte = textoOuNulo(input.consulta_cnpj_fonte);
  }
  if ("observacoes" in input) fornecedor.observacoes = textoOuNulo(input.observacoes);
  if ("ativo" in input) fornecedor.ativo = booleanoOuNulo(input.ativo, "ativo") ?? true;

  if (
    fornecedor.opcao_ibs_cbs === "regime_regular" &&
    !permiteOpcaoIbsCbsRegimeRegular(fornecedor.regime_tributario)
  ) {
    throw new FornecedorValidationError(
      'opcao_ibs_cbs "regime_regular" é exclusiva do Simples Nacional.',
    );
  }
}

function valorAusente(value: unknown): boolean {
  return value == null || (typeof value === "string" && value.trim() === "");
}

export function completarInputComConsulta(
  input: FornecedorInput,
  consulta: CadastroCnpjConsultado,
  options: { preferirIdentificacaoPublica?: boolean } = {},
): FornecedorInput {
  const fallback: FornecedorInput = {
    razao_social: consulta.razao_social,
    nome_fantasia: consulta.nome_fantasia,
    regime_tributario: consulta.regime_tributario_sugerido,
    uf: consulta.uf,
    municipio: consulta.municipio,
    codigo_municipio_ibge: consulta.codigo_municipio_ibge,
    cnae_principal: consulta.cnae_principal,
    cnae_principal_descricao: consulta.cnae_principal_descricao,
    cnaes_secundarios: consulta.cnaes_secundarios,
    porte: consulta.porte,
    natureza_juridica: consulta.natureza_juridica,
    situacao_cadastral:
      consulta.descricao_situacao_cadastral ?? consulta.situacao_cadastral,
    optante_simples: consulta.optante_simples,
    optante_mei: consulta.optante_mei,
    consulta_cnpj_em: consulta.consultado_em,
    consulta_cnpj_fonte: consulta.fonte,
  };
  const combinado: FornecedorInput = { ...input };
  if (options.preferirIdentificacaoPublica) {
    if (!valorAusente(fallback.razao_social)) {
      combinado.razao_social = fallback.razao_social;
    }
    if (!valorAusente(fallback.nome_fantasia)) {
      combinado.nome_fantasia = fallback.nome_fantasia;
    }
  }
  for (const [campo, value] of Object.entries(fallback)) {
    const chave = campo as keyof FornecedorInput;
    if (valorAusente(combinado[chave]) && !valorAusente(value)) {
      combinado[chave] = value;
    }
  }
  return combinado;
}

/**
 * Opções de recorte compartilhadas pelas duas listagens.
 *
 * `incluirGenericos` é o único jeito de um genérico aparecer numa listagem: a tela de fornecedores
 * nunca pede, e por isso nunca os vê; o seletor do editor de simulação pede, e recebe os cadastros
 * reais mais os seis perfis de regime.
 */
export type FiltroFornecedores = {
  apenasAtivos?: boolean;
  /** Inclui os perfis de regime sem documento. Default `false` = só fornecedores reais. */
  incluirGenericos?: boolean;
};

export async function listarFornecedores(
  escritorioId: string,
  options: FiltroFornecedores = {},
): Promise<FornecedorResumo[]> {
  await ensureDatabase();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const base = options.apenasAtivos
      ? { escritorio_id: escritorioId, ativo: true }
      : { escritorio_id: escritorioId };
    const fornecedores = await manager.getRepository(Fornecedor).find({
      where: options.incluirGenericos ? base : { ...base, generico: false },
      order: { razao_social: "ASC" },
    });
    return fornecedores.map(paraResumo);
  });
}

export async function listarFornecedoresPaginado(
  escritorioId: string,
  input: PaginationInput & { query?: string } & FiltroFornecedores = {},
): Promise<PaginatedResult<FornecedorResumo>> {
  await ensureDatabase();
  const { page, pageSize, skip } = normalizePagination(input);

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Fornecedor)
      .createQueryBuilder("fornecedor")
      .where("fornecedor.escritorio_id = :escritorioId", { escritorioId });

    if (input.apenasAtivos) qb.andWhere("fornecedor.ativo = true");

    if (!input.incluirGenericos) qb.andWhere("fornecedor.generico = false");

    const query = input.query?.trim();
    if (query) {
      qb.andWhere(
        new Brackets((sub) => {
          sub
            .where("fornecedor.cnpj ILIKE :query", { query: `%${query}%` })
            .orWhere("fornecedor.razao_social ILIKE :query", { query: `%${query}%` })
            .orWhere("fornecedor.nome_fantasia ILIKE :query", { query: `%${query}%` });
        }),
      );
    }

    const total = await qb.clone().getCount();
    const rows = await qb.orderBy("fornecedor.razao_social", "ASC").skip(skip).take(pageSize).getMany();

    return buildPaginatedResult(rows.map(paraResumo), total, page, pageSize);
  });
}

export async function obterFornecedor(
  escritorioId: string,
  fornecedorId: string,
): Promise<FornecedorResumo | null> {
  await ensureDatabase();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const fornecedor = await manager
      .getRepository(Fornecedor)
      .findOne({ where: { id: fornecedorId, escritorio_id: escritorioId } });
    return fornecedor ? paraResumo(fornecedor) : null;
  });
}

export async function buscarFornecedorPorCnpj(
  escritorioId: string,
  cnpj: unknown,
): Promise<FornecedorResumo | null> {
  await ensureDatabase();
  const documento = normalizarCnpj(cnpj);

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const fornecedor = await manager
      .getRepository(Fornecedor)
      .findOne({ where: { cnpj: documento, escritorio_id: escritorioId } });
    return fornecedor ? paraResumo(fornecedor) : null;
  });
}

export async function criarFornecedor(
  escritorioId: string,
  input: FornecedorInput,
): Promise<FornecedorResumo> {
  await ensureDatabase();
  const documento = normalizarCnpj(input.cnpj);
  const razaoSocial = textoObrigatorio(input.razao_social, "razao_social");

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Fornecedor);

    const existente = await repo.findOne({
      where: { cnpj: documento, escritorio_id: escritorioId },
    });
    if (existente) {
      throw new FornecedorValidationError(`Já existe fornecedor cadastrado com o documento ${documento}.`);
    }

    const fornecedor = repo.create({
      escritorio_id: escritorioId,
      cnpj: documento,
      razao_social: razaoSocial,
      ativo: true,
    });
    aplicarCampos(fornecedor, input, documento);

    return paraResumo(await repo.save(fornecedor));
  });
}

/**
 * Cria o fornecedor tentando antes completar os campos pelo cadastro público. A consulta é
 * best-effort: inexistência/indisponibilidade não bloqueiam o cadastro manual.
 */
export async function criarFornecedorComEnriquecimento(
  escritorioId: string,
  input: FornecedorInput,
): Promise<FornecedorResumo> {
  const consulta = await consultarCnpjSemBloquear(input.cnpj);
  // O canal MCP pode cadastrar somente com o documento. Se a consulta pública não
  // responder, conserva um identificador explícito e rastreável em vez de falhar
  // exigindo uma razão social que o agente não possui.
  const preenchido = consulta ? completarInputComConsulta(input, consulta) : input;
  const razaoSocialFallback = textoOuNulo(preenchido.razao_social) ?? textoOuNulo(input.cnpj);
  return criarFornecedor(
    escritorioId,
    { ...preenchido, razao_social: razaoSocialFallback },
  );
}

/**
 * Resolve o fornecedor canônico de um CNPJ pelo mesmo caminho do cadastro público. A consulta e
 * o enriquecimento acontecem antes de a operação consumidora abrir sua transação, para que uma
 * entrada de simulação e o POST de fornecedores tenham a mesma semântica de criação.
 */
export async function resolverFornecedorPorCnpjComEnriquecimento(
  escritorioId: string,
  cnpj: unknown,
): Promise<FornecedorResumo> {
  const existente = await buscarFornecedorPorCnpj(escritorioId, cnpj);
  if (existente) return existente;

  try {
    return await criarFornecedorComEnriquecimento(escritorioId, { cnpj });
  } catch (erro) {
    // Duas entradas concorrentes podem observar a ausência e tentar criar o mesmo CNPJ. A segunda
    // mantém a idempotência do vínculo relendo o registro recém-criado; qualquer outro erro segue
    // para o chamador como erro de validação/autorização normal.
    if (erro instanceof FornecedorValidationError) {
      const criadoEmParalelo = await buscarFornecedorPorCnpj(escritorioId, cnpj);
      if (criadoEmParalelo) return criadoEmParalelo;
    }
    throw erro;
  }
}

export async function atualizarFornecedor(
  escritorioId: string,
  fornecedorId: string,
  input: FornecedorInput,
): Promise<FornecedorResumo | null> {
  await ensureDatabase();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Fornecedor);
    const fornecedor = await repo.findOne({
      where: { id: fornecedorId, escritorio_id: escritorioId },
    });
    if (!fornecedor) return null;

    // Genérico é catálogo, não cadastro: o regime é a identidade dele, e editá-lo mudaria em silêncio
    // o crédito de toda linha de simulação que já o referencia. Desativar cai aqui também, via
    // `desativarFornecedor`.
    if (fornecedor.generico) {
      throw new FornecedorValidationError(
        "Fornecedor genérico não pode ser editado nem desativado: é um perfil de regime fixo do escritório.",
      );
    }

    // Trocar documento é permitido, mas o cruzamento regime x documento usa o documento final.
    if ("cnpj" in input && input.cnpj != null && input.cnpj !== "") {
      const novo = normalizarCnpj(input.cnpj);
      if (novo !== fornecedor.cnpj) {
        const duplicado = await repo.findOne({ where: { cnpj: novo, escritorio_id: escritorioId } });
        if (duplicado) {
          throw new FornecedorValidationError(`Já existe fornecedor cadastrado com o documento ${novo}.`);
        }
        fornecedor.cnpj = novo;
      }
    }

    // Invariante de `CHK_fornecedores_generico`: só genérico fica sem documento, e genérico já saiu no
    // guard acima. O ramo existe para o cruzamento regime x documento não receber um documento vazio.
    if (fornecedor.cnpj === null) {
      throw new FornecedorValidationError("Fornecedor sem documento não é editável.");
    }

    aplicarCampos(fornecedor, input, fornecedor.cnpj);

    return paraResumo(await repo.save(fornecedor));
  });
}

/**
 * Desativa em vez de apagar: entradas de simulação referenciam o fornecedor, e apagar zeraria a
 * explicação do crédito das linhas históricas (a FK é `ON DELETE SET NULL`).
 */
export async function desativarFornecedor(
  escritorioId: string,
  fornecedorId: string,
): Promise<FornecedorResumo | null> {
  return atualizarFornecedor(escritorioId, fornecedorId, { ativo: false });
}

/**
 * Encontra ou cria um fornecedor pelo documento, dentro de uma transação RLS já aberta.
 *
 * Usado pela importação de NF-e, que já está numa transação e persiste vários lançamentos: recebe o
 * `EntityManager` do chamador de propósito, no mesmo padrão de
 * `fillClienteNullFieldsFromContrato`. Não faz consulta externa de CNPJ — o enriquecimento é
 * posterior e sob demanda, para não disparar N chamadas de rede dentro do laço de importação.
 */
export async function encontrarOuCriarFornecedorPorCnpj(
  manager: EntityManager,
  escritorioId: string,
  cnpj: unknown,
  dados: { razao_social?: string | null; regime_tributario?: string | null } = {},
): Promise<{ fornecedor: Fornecedor; criado: boolean } | null> {
  let documento: string;
  try {
    documento = normalizarCnpj(cnpj);
  } catch {
    // Documento ilegível no XML não deve derrubar a importação inteira.
    return null;
  }

  const repo = manager.getRepository(Fornecedor);
  const existente = await repo.findOne({ where: { cnpj: documento, escritorio_id: escritorioId } });
  if (existente) {
    // Preenche só o que está em branco; nunca sobrescreve decisão do contador.
    let mudou = false;
    if (!existente.regime_tributario && dados.regime_tributario) {
      existente.regime_tributario = dados.regime_tributario;
      mudou = true;
    }
    if (!existente.nome_fantasia && dados.razao_social) {
      existente.nome_fantasia = dados.razao_social;
      mudou = true;
    }
    return {
      fornecedor: mudou ? await repo.save(existente) : existente,
      criado: false,
    };
  }

  const fornecedor = repo.create({
    escritorio_id: escritorioId,
    cnpj: documento,
    razao_social: dados.razao_social?.trim() || `Fornecedor ${documento}`,
    regime_tributario: dados.regime_tributario ?? null,
    ativo: true,
  });
  return {
    fornecedor: await repo.save(fornecedor),
    criado: true,
  };
}

/**
 * Resolve o fornecedor genérico do escritório (`fornecedores-genericos.ts`) para um par
 * regime/opção informado numa linha da importação em lote de dados de simulação
 * (`domain/simulacoes/dados-simulacao.service.ts`) — mesma leitura de `fornecedorGenericoPadraoOuNulo`
 * (`domain/simulacoes/simulacao.service.ts`), mas chaveada por regime em vez de UUID.
 *
 * Simples Nacional sem `opcaoIbsCbs` informada assume `regime_unico` (crédito presumido/DAS): decisão
 * de produto já tomada, o mesmo perfil do catálogo `Genérico - Simples Nacional (DAS)`. Regime fora
 * dos cinco valores canônicos, ou par sem correspondente no catálogo, lança em vez de devolver `null`
 * — silenciar aqui deixaria a linha sem fornecedor sem o contador saber por quê.
 */
export async function buscarFornecedorGenericoPorRegime(
  manager: EntityManager,
  escritorioId: string,
  regimeTributario: string,
  opcaoIbsCbs: string | null,
): Promise<Fornecedor> {
  if (!REGIMES_TRIBUTARIOS.includes(regimeTributario as RegimeTributario)) {
    throw new Error(
      `regime_tributario "${regimeTributario}" não é reconhecido. Use um destes valores: ${REGIMES_TRIBUTARIOS.join(", ")}.`,
    );
  }

  const opcaoEfetiva = opcaoIbsCbs ?? opcaoPadraoDoGenerico(regimeTributario);

  const fornecedor = await manager.getRepository(Fornecedor).findOne({
    where: {
      escritorio_id: escritorioId,
      generico: true,
      regime_tributario: regimeTributario,
      opcao_ibs_cbs: opcaoEfetiva === null ? IsNull() : (opcaoEfetiva as OpcaoIbsCbs),
    },
  });
  if (!fornecedor) {
    throw new Error(
      `Nenhum fornecedor genérico encontrado para o regime "${regimeTributario}"` +
        (opcaoEfetiva ? ` com opção "${opcaoEfetiva}"` : "") +
        ". Confirme o catálogo de fornecedores genéricos do escritório.",
    );
  }
  return fornecedor;
}

/** Alíquotas nominais consolidadas de um fornecedor, prontas para gravação. */
export type AliquotasDerivadasFornecedor = {
  fornecedor_id: string;
  aliquota_icms_nominal: number | null;
  aliquota_iss_nominal: number | null;
};

/**
 * Grava as alíquotas nominais derivadas das NF-e importadas, **sem tocar no que foi digitado à mão**.
 *
 * O filtro `fonte IS DISTINCT FROM 'manual'` é a razão de as colunas `*_fonte` existirem: sem ele, o
 * próximo lote de notas apagaria silenciosamente a alíquota que o contador escolheu. O filtro é por
 * tributo, então travar o ICMS não trava o ISS.
 *
 * Um único UPDATE para o lote inteiro (`unnest`), no mesmo padrão anti-N+1 da consolidação. Roda
 * dentro de uma transação RLS já aberta pelo chamador. Devolve quantos cadastros mudaram.
 */
export async function atualizarAliquotasDerivadas(
  manager: EntityManager,
  escritorioId: string,
  valores: AliquotasDerivadasFornecedor[],
): Promise<number> {
  if (valores.length === 0) return 0;

  const atualizadas: Array<{ id: string }> = await manager.query(
    `UPDATE "fornecedores" f
        SET "aliquota_icms_nominal" = CASE
              WHEN f."aliquota_icms_fonte" IS DISTINCT FROM 'manual' AND v.icms IS NOT NULL THEN v.icms
              ELSE f."aliquota_icms_nominal" END,
            "aliquota_icms_fonte" = CASE
              WHEN f."aliquota_icms_fonte" IS DISTINCT FROM 'manual' AND v.icms IS NOT NULL THEN 'nfe'
              ELSE f."aliquota_icms_fonte" END,
            "aliquota_iss_nominal" = CASE
              WHEN f."aliquota_iss_fonte" IS DISTINCT FROM 'manual' AND v.iss IS NOT NULL THEN v.iss
              ELSE f."aliquota_iss_nominal" END,
            "aliquota_iss_fonte" = CASE
              WHEN f."aliquota_iss_fonte" IS DISTINCT FROM 'manual' AND v.iss IS NOT NULL THEN 'nfe'
              ELSE f."aliquota_iss_fonte" END,
            "updated_at" = now()
       FROM unnest($2::uuid[], $3::numeric[], $4::numeric[]) AS v(id, icms, iss)
      WHERE f."id" = v.id
        AND f."escritorio_id" = $1
        AND (
          (f."aliquota_icms_fonte" IS DISTINCT FROM 'manual' AND v.icms IS NOT NULL)
          OR (f."aliquota_iss_fonte" IS DISTINCT FROM 'manual' AND v.iss IS NOT NULL)
        )
      RETURNING f."id"`,
    [
      escritorioId,
      valores.map((v) => v.fornecedor_id),
      valores.map((v) => v.aliquota_icms_nominal),
      valores.map((v) => v.aliquota_iss_nominal),
    ],
  );

  return atualizadas.length;
}

/**
 * Enriquece um fornecedor já existente sem sobrescrever decisões do contador. Usado depois do
 * commit da importação de NF-e, para nunca manter rede aberta dentro da transação. Quando o cadastro
 * acabou de ser criado pela própria importação, a identificação oficial da consulta pública
 * substitui o nome provisório vindo do XML.
 */
export async function enriquecerFornecedorPorCnpj(
  escritorioId: string,
  cnpj: unknown,
  options: {
    preferirIdentificacaoPublica?: boolean;
    substituirIdentificacaoProvisoria?: boolean;
  } = {},
): Promise<FornecedorResumo | null> {
  const consulta = await consultarCnpjSemBloquear(cnpj);
  if (!consulta) return null;
  const documento = normalizarCnpj(cnpj);

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Fornecedor);
    const fornecedor = await repo.findOne({
      where: { cnpj: documento, escritorio_id: escritorioId },
    });
    if (!fornecedor) return null;

    const razaoSocialAtual = textoOuNulo(fornecedor.razao_social);
    const razaoSocialDigitos = somenteDigitos(razaoSocialAtual);
    const identificacaoProvisoria =
      razaoSocialAtual === `Fornecedor ${documento}` ||
      razaoSocialDigitos === somenteDigitos(documento);

    const input = completarInputComConsulta(
      {
        razao_social: fornecedor.razao_social,
        nome_fantasia: fornecedor.nome_fantasia,
        regime_tributario: fornecedor.regime_tributario,
        uf: fornecedor.uf,
        municipio: fornecedor.municipio,
        cnae_principal: fornecedor.cnae_principal,
        cnae_principal_descricao: fornecedor.cnae_principal_descricao,
        cnaes_secundarios: fornecedor.cnaes_secundarios,
        porte: fornecedor.porte,
        natureza_juridica: fornecedor.natureza_juridica,
        situacao_cadastral: fornecedor.situacao_cadastral,
      },
      consulta,
      {
        preferirIdentificacaoPublica:
          options.preferirIdentificacaoPublica ||
          (options.substituirIdentificacaoProvisoria && identificacaoProvisoria),
      },
    );
    // Evidência da consulta é sempre atualizada; os demais campos continuam sendo apenas fallback.
    input.optante_simples = consulta.optante_simples;
    input.optante_mei = consulta.optante_mei;
    input.consulta_cnpj_em = consulta.consultado_em;
    input.consulta_cnpj_fonte = consulta.fonte;
    aplicarCampos(fornecedor, input, documento);
    return paraResumo(await repo.save(fornecedor));
  });
}
