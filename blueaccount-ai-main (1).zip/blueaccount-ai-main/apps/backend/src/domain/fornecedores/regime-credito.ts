import type { OpcaoIbsCbs } from "../../database/modules/tenant/entities/fornecedor.entity.js";

/**
 * Perfil de crédito de IBS/CBS que a compra de um fornecedor gera para o adquirente.
 *
 * - `integral`: crédito cheio pelas alíquotas da entrada/simulação (regime regular, ou Simples que
 *   optou pelo regime regular de IBS/CBS — a "opção híbrida" da LC 214/2025, art. 41).
 * - `presumido`: crédito limitado ao percentual padronizado da parcela de IBS/CBS embutida no DAS do
 *   fornecedor do Simples (LC 214/2025, art. 47, §9º, II). Aplicado sobre `base_ibs_cbs`.
 * - `sem_credito`: a operação não gera crédito (contraparte não contribuinte).
 */
export type PerfilCreditoFornecedor = "integral" | "presumido" | "sem_credito";

export type CreditoFornecedorResolvido = {
  perfil: PerfilCreditoFornecedor;
  /** Fração da base de IBS/CBS transferida como crédito de IBS. Null = zero. */
  aliquota_credito_presumido_ibs: number | null;
  /** Fração da base de IBS/CBS transferida como crédito de CBS. Null = zero. */
  aliquota_credito_presumido_cbs: number | null;
  /** Texto legível exibido na linha calculada, com a base legal. */
  justificativa: string;
  /**
   * `true` somente quando o perfil `sem_credito` vem da AUSÊNCIA de `regime_tributario` no cadastro —
   * ou seja, o crédito está pendente de evidência, não negado pela lei. Distingue "falta cadastrar"
   * de "cadastrado e realmente sem crédito" (ex.: `Pessoa Física`), que é o que a UI precisa para não
   * pedir o cadastro de um regime que já está lá.
   */
  evidencia_pendente: boolean;
};

export type FornecedorParaCredito = {
  regime_tributario: string | null;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
  aliquota_credito_presumido_ibs: number | null;
  aliquota_credito_presumido_cbs: number | null;
};

/** Regimes do Simples: são os únicos em que `opcao_ibs_cbs` importa. */
const REGIMES_SIMPLIFICADOS = new Set(["Simples Nacional", "MEI"]);

/** A opção do regime regular prevista no art. 41 é exclusiva do Simples Nacional. */
export function permiteOpcaoIbsCbsRegimeRegular(regime: string | null): boolean {
  return regime?.trim() === "Simples Nacional";
}

const JUSTIFICATIVA_INTEGRAL_REGULAR =
  "Fornecedor no regime regular: crédito integral de IBS/CBS pelo destaque da operação.";

const JUSTIFICATIVA_INTEGRAL_HIBRIDO =
  "Fornecedor optante do Simples que recolhe IBS/CBS pelo regime regular (opção híbrida, " +
  "LC 214/2025, art. 41): destaque integral na nota, crédito cheio para o adquirente.";

const JUSTIFICATIVA_SEM_CREDITO_PF =
  "Contraparte pessoa física não contribuinte: a operação não destaca IBS/CBS e não gera crédito.";
const JUSTIFICATIVA_PENDENTE =
  "Regime do fornecedor não comprovado: crédito de IBS/CBS pendente de evidência fiscal.";

function justificativaPresumido(regime: string): string {
  return (
    `Fornecedor no ${regime} em regime único: crédito limitado ao percentual presumido da parcela ` +
    "de IBS/CBS embutida no DAS (LC 214/2025, art. 47, §9º, II). Percentuais oficiais dependem de " +
    "regulamento conjunto CGIBS/RFB."
  );
}

function normalizarAliquota(value: number | null): number | null {
  if (value == null) return null;
  const numero = Number(value);
  if (!Number.isFinite(numero) || numero <= 0) return null;
  return numero;
}

/**
 * Deriva, de forma determinística e sem banco, quanto de crédito de IBS/CBS o fornecedor transfere.
 *
 * Regra de fundo: o regime *tributário* diz se há destaque na nota; a *opção de IBS/CBS* diz, para
 * quem está no Simples, se o destaque é integral (regime regular) ou se o crédito fica limitado ao
 * percentual presumido (regime único). ICMS não passa por aqui — segue `tratamento_icms` da linha.
 *
 * `regime_tributario` nulo é conservador: sem documento ou cadastro fiscal suficiente não há como
 * afirmar destaque integral, portanto o crédito fica pendente e zerado.
 */
export function resolverCreditoFornecedor(
  fornecedor: FornecedorParaCredito,
): CreditoFornecedorResolvido {
  const regime = fornecedor.regime_tributario?.trim() || null;
  const semPresumido = { aliquota_credito_presumido_ibs: null, aliquota_credito_presumido_cbs: null };

  if (regime === null) {
    return {
      perfil: "sem_credito",
      ...semPresumido,
      justificativa: JUSTIFICATIVA_PENDENTE,
      evidencia_pendente: true,
    };
  }

  if (regime === "Pessoa Física") {
    return {
      perfil: "sem_credito",
      ...semPresumido,
      justificativa: JUSTIFICATIVA_SEM_CREDITO_PF,
      evidencia_pendente: false,
    };
  }

  if (regime && REGIMES_SIMPLIFICADOS.has(regime)) {
    // A opção do art. 41, §3º é exclusiva do Simples Nacional. MEI permanece no regime próprio,
    // mesmo que um dado legado inválido ainda carregue `regime_regular`.
    if (permiteOpcaoIbsCbsRegimeRegular(regime) && fornecedor.opcao_ibs_cbs === "regime_regular") {
      return {
        perfil: "integral",
        ...semPresumido,
        justificativa: JUSTIFICATIVA_INTEGRAL_HIBRIDO,
        evidencia_pendente: false,
      };
    }

    // `regime_unico` ou não informado — o default conservador é o regime único.
    return {
      perfil: "presumido",
      aliquota_credito_presumido_ibs: normalizarAliquota(fornecedor.aliquota_credito_presumido_ibs),
      aliquota_credito_presumido_cbs: normalizarAliquota(fornecedor.aliquota_credito_presumido_cbs),
      justificativa: justificativaPresumido(regime),
      evidencia_pendente: false,
    };
  }

  return {
    perfil: "integral",
    ...semPresumido,
    justificativa: JUSTIFICATIVA_INTEGRAL_REGULAR,
    evidencia_pendente: false,
  };
}
