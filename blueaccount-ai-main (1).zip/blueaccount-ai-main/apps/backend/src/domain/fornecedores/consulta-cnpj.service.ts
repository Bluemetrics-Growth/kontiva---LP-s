import type { QueryDeepPartialEntity } from "typeorm/query-builder/QueryPartialEntity.js";
import { AppDataSource } from "../../database/data-source.js";
import { CadastroCnpj } from "../../database/modules/public/entities/cadastro-cnpj.entity.js";
import type { CnaeSecundario } from "../../database/modules/tenant/entities/fornecedor.entity.js";
import {
  requisitarCadastroCnpj,
  CnpjNaoEncontradoError,
  ConsultaCnpjIndisponivelError,
  type RespostaCadastroCnpj,
} from "../../infrastructure/external-services/cadastro-cnpj.client.js";
import { normalizarCnpj } from "../clientes/cliente.service.js";
import { normalizarCodigoMunicipioIbge } from "../simulacoes/localidade/ibge.js";
import { settings } from "../../settings.js";
import { somenteDigitos } from "../texto.js";

export { CnpjNaoEncontradoError, ConsultaCnpjIndisponivelError };

const RETRY_DELAY_MS = 400;

/**
 * Campos de PII de terceiro que NUNCA são persistidos: `qsa` traz nome e documento parcial de
 * sócios, e email/telefone identificam pessoas. Nada disso é usado para calcular crédito.
 */
const CAMPOS_PII = ["qsa", "email", "ddd_telefone_1", "ddd_telefone_2", "ddd_fax"] as const;

/** Cadastro público devolvido para sugestão e enriquecimento do fornecedor. */
export type CadastroCnpjConsultado = {
  cnpj: string;
  razao_social: string | null;
  nome_fantasia: string | null;
  uf: string | null;
  municipio: string | null;
  /** Código IBGE de 7 dígitos, já validado contra o prefixo da UF. Chave da tabela de ISS. */
  codigo_municipio_ibge: string | null;
  /**
   * Endereço legível composto a partir de logradouro/numero/complemento/bairro/municipio/uf/cep da
   * resposta da fonte. `null` quando não há nenhuma parte aproveitável. Ver `comporEndereco`.
   */
  endereco_sugerido: string | null;
  cnae_principal: string | null;
  cnae_principal_descricao: string | null;
  cnaes_secundarios: CnaeSecundario[] | null;
  porte: string | null;
  natureza_juridica: string | null;
  situacao_cadastral: string | null;
  descricao_situacao_cadastral: string | null;
  optante_simples: boolean | null;
  optante_mei: boolean | null;
  /** Simples/MEI têm precedência; fora deles, usa o histórico anual mais recente e inequívoco. */
  regime_tributario_sugerido: "Simples Nacional" | "MEI" | "Lucro Real" | "Lucro Presumido" | null;
  /** Ano da ECF usada para sugerir Lucro Real/Presumido; null para Simples/MEI. */
  regime_tributario_ano: number | null;
  fonte: string;
  consultado_em: string;
  /** true quando a resposta veio do cache local, sem tocar a rede. */
  do_cache: boolean;
};

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

function textoOuNulo(value: unknown): string | null {
  if (value == null) return null;
  const texto = String(value).trim();
  return texto === "" ? null : texto;
}

/**
 * A fonte devolve `null` (não `false`) para quem não é optante, então `null` e "não optante" são
 * indistinguíveis no dado público. Normalizamos para booleano: ausência = não optante.
 */
function booleanoOptante(value: unknown): boolean | null {
  if (value === true) return true;
  if (value === false) return false;
  if (value == null) return false;
  const texto = String(value).trim().toLowerCase();
  if (["sim", "s", "true", "1"].includes(texto)) return true;
  if (["nao", "não", "n", "false", "0"].includes(texto)) return false;
  return null;
}

/** CNAE vem como inteiro (ex.: 6204000); precisa virar string de 7 dígitos com zero à esquerda. */
function normalizarCnae(value: unknown): string | null {
  const digitos = somenteDigitos(value);
  if (!digitos) return null;
  return digitos.padStart(7, "0").slice(0, 7);
}

function normalizarCnaesSecundarios(value: unknown): CnaeSecundario[] | null {
  if (!Array.isArray(value)) return null;
  const itens = value
    .map((item) => {
      const registro = (item ?? {}) as Record<string, unknown>;
      const codigo = normalizarCnae(registro.codigo ?? registro.code);
      const descricao = textoOuNulo(registro.descricao ?? registro.text);
      if (!codigo) return null;
      return { codigo, descricao: descricao ?? "" };
    })
    .filter((item): item is CnaeSecundario => item !== null);
  return itens.length > 0 ? itens : null;
}

/** Remove PII de terceiro antes de qualquer persistência. Chamada obrigatória. */
export function higienizarPayloadCnpj(payload: RespostaCadastroCnpj): Record<string, unknown> {
  const limpo: Record<string, unknown> = { ...payload };
  for (const campo of CAMPOS_PII) delete limpo[campo];
  return limpo;
}

export function regimeHistoricoSugerido(
  value: unknown,
): { regime: "Lucro Real" | "Lucro Presumido"; ano: number } | null {
  if (!Array.isArray(value)) return null;

  const reconhecidos = value
    .map((item) => {
      const registro = (item ?? {}) as Record<string, unknown>;
      const ano = Number(registro.ano);
      const forma = textoOuNulo(registro.forma_de_tributacao)
        ?.normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toUpperCase();
      if (!Number.isInteger(ano) || !forma) return null;
      if (forma.includes("LUCRO PRESUMIDO")) {
        return { regime: "Lucro Presumido" as const, ano };
      }
      if (forma.includes("LUCRO REAL")) {
        return { regime: "Lucro Real" as const, ano };
      }
      return null;
    })
    .filter((item): item is { regime: "Lucro Real" | "Lucro Presumido"; ano: number } => item !== null);

  if (reconhecidos.length === 0) return null;
  const anoMaisRecente = Math.max(...reconhecidos.map((item) => item.ano));
  const regimesMaisRecentes = new Set(
    reconhecidos.filter((item) => item.ano === anoMaisRecente).map((item) => item.regime),
  );
  if (regimesMaisRecentes.size !== 1) return null;
  return { regime: [...regimesMaisRecentes][0], ano: anoMaisRecente };
}

function regimeSugerido(
  optanteSimples: boolean | null,
  optanteMei: boolean | null,
  payload: Record<string, unknown> | null,
): {
  regime: "Simples Nacional" | "MEI" | "Lucro Real" | "Lucro Presumido";
  ano: number | null;
} | null {
  if (optanteMei === true) return { regime: "MEI", ano: null };
  if (optanteSimples === true) return { regime: "Simples Nacional", ano: null };
  const historico = regimeHistoricoSugerido(payload?.regime_tributario);
  return historico ? { regime: historico.regime, ano: historico.ano } : null;
}

function paraConsultado(registro: CadastroCnpj, doCache: boolean): CadastroCnpjConsultado {
  const regime = regimeSugerido(registro.optante_simples, registro.optante_mei, registro.payload);
  return {
    cnpj: registro.cnpj,
    razao_social: registro.razao_social,
    nome_fantasia: registro.nome_fantasia,
    uf: registro.uf,
    municipio: registro.municipio,
    // Fallback ao payload para registros gravados antes da coluna existir: eles seguem válidos pelo
    // TTL, e sem isto um fornecedor cadastrado a partir de cache antigo ficaria sem código de
    // município até o cache expirar.
    codigo_municipio_ibge:
      registro.codigo_municipio_ibge ??
      normalizarCodigoMunicipioIbge(registro.payload?.codigo_municipio_ibge, registro.uf),
    endereco_sugerido: comporEndereco(registro.payload),
    cnae_principal: registro.cnae_principal,
    cnae_principal_descricao: registro.cnae_principal_descricao,
    cnaes_secundarios: registro.cnaes_secundarios,
    porte: registro.porte,
    natureza_juridica: registro.natureza_juridica,
    situacao_cadastral: registro.situacao_cadastral,
    descricao_situacao_cadastral: registro.descricao_situacao_cadastral,
    optante_simples: registro.optante_simples,
    optante_mei: registro.optante_mei,
    regime_tributario_sugerido: regime?.regime ?? null,
    regime_tributario_ano: regime?.ano ?? null,
    fonte: registro.fonte,
    consultado_em: new Date(registro.consultado_em).toISOString(),
    do_cache: doCache,
  };
}

function formatarCep(value: unknown): string | null {
  const digitos = somenteDigitos(value);
  if (digitos.length !== 8) return textoOuNulo(value);
  return `${digitos.slice(0, 5)}-${digitos.slice(5)}`;
}

/**
 * Compõe um endereço legível a partir dos campos de logradouro da resposta de CNPJ (guardados só no
 * `payload` jsonb — não viraram coluna própria de `cadastros_cnpj`). Usa só as partes presentes;
 * nunca lança e devolve `null` quando não há nenhuma parte aproveitável.
 */
export function comporEndereco(payload: Record<string, unknown> | null | undefined): string | null {
  if (!payload) return null;

  const logradouro = textoOuNulo(payload.logradouro);
  const numero = textoOuNulo(payload.numero);
  const complemento = textoOuNulo(payload.complemento);
  const bairro = textoOuNulo(payload.bairro);
  const municipio = textoOuNulo(payload.municipio);
  const uf = textoOuNulo(payload.uf);
  const cep = formatarCep(payload.cep);

  const partesRua: string[] = [];
  const ruaNumero = logradouro && numero ? `${logradouro}, ${numero}` : logradouro ?? numero;
  if (ruaNumero) partesRua.push(ruaNumero);
  if (complemento) partesRua.push(complemento);
  if (bairro) partesRua.push(bairro);

  let endereco = partesRua.join(" - ");

  const cidadeUf = municipio && uf ? `${municipio}/${uf}` : municipio ?? uf;
  if (cidadeUf) {
    endereco = endereco ? `${endereco}, ${cidadeUf}` : cidadeUf;
  }

  if (cep) {
    endereco = endereco ? `${endereco} - CEP ${cep}` : `CEP ${cep}`;
  }

  return endereco === "" ? null : endereco;
}

function cacheExpirado(consultadoEm: Date): boolean {
  const idadeMs = Date.now() - new Date(consultadoEm).getTime();
  return idadeMs > settings.CNPJ_LOOKUP_TTL_DIAS * 24 * 60 * 60 * 1000;
}

/** Uma tentativa extra apenas para indisponibilidade; 404 é definitivo e sobe direto. */
async function buscarNaFonte(cnpjDigitos: string): Promise<RespostaCadastroCnpj> {
  try {
    return await requisitarCadastroCnpj(cnpjDigitos);
  } catch (err) {
    if (err instanceof CnpjNaoEncontradoError) throw err;
    await delay(RETRY_DELAY_MS);
    return await requisitarCadastroCnpj(cnpjDigitos);
  }
}

/**
 * Consulta o cadastro público de um CNPJ, com cache compartilhado em `cadastros_cnpj`.
 *
 * Devolve `null` para documento que não é CNPJ de 14 dígitos (CPF não tem cadastro público
 * consultável) — sem tocar a rede. Lança `CnpjNaoEncontradoError` (→ 404) ou
 * `ConsultaCnpjIndisponivelError` (→ 503); o chamador trata as duas como não-fatais, porque o
 * cadastro manual do fornecedor nunca depende desta consulta.
 */
export async function consultarCnpj(
  cnpj: unknown,
  options: { forcar?: boolean } = {},
): Promise<CadastroCnpjConsultado | null> {
  const digitos = somenteDigitos(cnpj);
  if (digitos.length !== 14) return null;

  // Duas representações do mesmo documento, cada uma na ponta que a exige: a URL da BrasilAPI só
  // aceita dígitos; a coluna guarda mascarado, como `clientes.cnpj` e `fornecedores.cnpj`. Guardar
  // dígitos aqui fazia qualquer JOIN com aquelas tabelas casar zero linhas, em silêncio.
  const documento = normalizarCnpj(digitos);

  await ensureDatabase();
  const repo = AppDataSource.getRepository(CadastroCnpj);

  if (!options.forcar) {
    const cacheado = await repo.findOneBy({ cnpj: documento });
    if (cacheado && !cacheExpirado(cacheado.consultado_em)) {
      return paraConsultado(cacheado, true);
    }
  }

  const resposta = await buscarNaFonte(digitos);

  const optanteSimples = booleanoOptante(resposta.opcao_pelo_simples);
  const optanteMei = booleanoOptante(resposta.opcao_pelo_mei);

  const uf = textoOuNulo(resposta.uf)?.toUpperCase().slice(0, 2) ?? null;

  const registro: Partial<CadastroCnpj> = {
    cnpj: documento,
    razao_social: textoOuNulo(resposta.razao_social),
    nome_fantasia: textoOuNulo(resposta.nome_fantasia),
    uf,
    municipio: textoOuNulo(resposta.municipio),
    // Só `codigo_municipio_ibge`, nunca `codigo_municipio` — o segundo é o código TOM/SIAFI de 4
    // dígitos. O guard de prefixo confere que o código pertence mesmo à UF deste cadastro.
    codigo_municipio_ibge: normalizarCodigoMunicipioIbge(resposta.codigo_municipio_ibge, uf),
    cnae_principal: normalizarCnae(resposta.cnae_fiscal),
    cnae_principal_descricao: textoOuNulo(resposta.cnae_fiscal_descricao),
    cnaes_secundarios: normalizarCnaesSecundarios(resposta.cnaes_secundarios),
    porte: textoOuNulo(resposta.porte),
    natureza_juridica: textoOuNulo(resposta.natureza_juridica),
    situacao_cadastral: textoOuNulo(resposta.situacao_cadastral),
    descricao_situacao_cadastral: textoOuNulo(resposta.descricao_situacao_cadastral),
    optante_simples: optanteSimples,
    optante_mei: optanteMei,
    fonte: "BrasilAPI",
    payload: higienizarPayloadCnpj(resposta),
    consultado_em: new Date(),
  };

  // O cast existe porque o DeepPartial do TypeORM não aceita `Record<string, unknown>` numa coluna
  // jsonb; o objeto acima já é o shape da entidade.
  await repo.upsert(registro as QueryDeepPartialEntity<CadastroCnpj>, ["cnpj"]);

  const persistido = await repo.findOneBy({ cnpj: documento });
  if (!persistido) throw new ConsultaCnpjIndisponivelError(`Falha ao gravar cache do CNPJ ${documento}.`);
  return paraConsultado(persistido, false);
}

/**
 * `consultarCnpj` sem deixar indisponibilidade/inexistência subir. Best-effort: quem chama nunca deve
 * ter o próprio fluxo (cadastro de fornecedor ou cliente) bloqueado por uma falha desta consulta.
 * Compartilhado por `fornecedor.service.ts` e `clientes/cliente.service.ts`.
 */
export async function consultarCnpjSemBloquear(cnpj: unknown): Promise<CadastroCnpjConsultado | null> {
  try {
    return await consultarCnpj(cnpj);
  } catch (error) {
    if (error instanceof CnpjNaoEncontradoError || error instanceof ConsultaCnpjIndisponivelError) {
      return null;
    }
    throw error;
  }
}
