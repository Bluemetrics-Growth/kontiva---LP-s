import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  CnpjNaoEncontradoError,
  ConsultaCnpjIndisponivelError,
} from "../consulta-cnpj.service.js";
import {
  consultarCnpjsEmLote,
  LIMITE_LOTE_CONSULTA_CNPJ,
} from "../consultar-cnpjs-lote.js";

/**
 * Só `consultarCnpj` é dublado; as classes de erro continuam as reais, porque é por `instanceof` que
 * o lote decide entre `nao_encontrado` (definitivo) e `indisponivel` (transitório).
 */
const consultarCnpjMock = vi.hoisted(() => vi.fn());
vi.mock("../consulta-cnpj.service.js", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../consulta-cnpj.service.js")>()),
  consultarCnpj: consultarCnpjMock,
}));

type Consulta = Awaited<ReturnType<typeof import("../consulta-cnpj.service.js").consultarCnpj>>;

const cadastro = (extra: Partial<NonNullable<Consulta>> = {}): NonNullable<Consulta> => ({
  cnpj: "11.111.111/0001-91",
  razao_social: "EMPRESA TESTE",
  nome_fantasia: null,
  uf: "RS",
  municipio: "CAXIAS DO SUL",
  codigo_municipio_ibge: "4305108",
  endereco_sugerido: null,
  cnae_principal: null,
  cnae_principal_descricao: null,
  cnaes_secundarios: null,
  porte: null,
  natureza_juridica: null,
  situacao_cadastral: "2",
  descricao_situacao_cadastral: "ATIVA",
  optante_simples: false,
  optante_mei: false,
  regime_tributario_sugerido: null,
  regime_tributario_ano: null,
  fonte: "BrasilAPI",
  consultado_em: "2026-08-27T12:00:00.000Z",
  do_cache: false,
  ...extra,
});

beforeEach(() => {
  consultarCnpjMock.mockReset();
});

describe("consultarCnpjsEmLote", () => {
  it("classifica cada documento por conta própria, sem deixar uma falha derrubar o lote", async () => {
    consultarCnpjMock.mockImplementation(async (documento: unknown) => {
      switch (documento) {
        case "11111111000191":
          return cadastro({ regime_tributario_sugerido: "Simples Nacional", optante_simples: true });
        case "22222222000191":
          return cadastro({ regime_tributario_sugerido: "Lucro Real", regime_tributario_ano: 2024 });
        // Cadastro existe, mas o público não decide o regime: fica manual, não vira "Presumido".
        case "33333333000191":
          return cadastro();
        case "44444444000191":
          throw new CnpjNaoEncontradoError("44444444000191");
        case "55555555000191":
          throw new ConsultaCnpjIndisponivelError("Consulta de CNPJ respondeu 502.");
        default:
          throw new Error(`documento inesperado: ${String(documento)}`);
      }
    });

    const resumo = await consultarCnpjsEmLote([
      "11.111.111/0001-91",
      "22222222000191",
      "33333333000191",
      "44444444000191",
      "55555555000191",
      // CPF não tem cadastro público: nem chega à fonte.
      "046.318.779-52",
      // Repetido: responde do que já foi feito, sem uma segunda ida à rede.
      "11111111000191",
    ]);

    expect(resumo.itens.map((item) => [item.cnpj, item.situacao])).toEqual([
      ["11111111000191", "consultado"],
      ["22222222000191", "consultado"],
      ["33333333000191", "sem_regime"],
      ["44444444000191", "nao_encontrado"],
      ["55555555000191", "indisponivel"],
      ["04631877952", "sem_cadastro_publico"],
      ["11111111000191", "duplicado_no_lote"],
    ]);

    expect(resumo).toMatchObject({
      total: 7,
      consultados: 2,
      sem_regime: 1,
      nao_encontrados: 1,
      sem_cadastro_publico: 1,
      indisponiveis: 1,
      duplicados_no_lote: 1,
    });

    // O documento repetido e o CPF não custam uma chamada à fonte.
    expect(consultarCnpjMock).toHaveBeenCalledTimes(5);
  });

  it("não sugere regime quando o cadastro público não decide", async () => {
    consultarCnpjMock.mockResolvedValue(cadastro());

    const { itens } = await consultarCnpjsEmLote(["11111111000191"]);

    expect(itens[0].situacao).toBe("sem_regime");
    expect(itens[0].regime_tributario_sugerido).toBeNull();
    // Situação cadastral viaja para a tela poder mostrar que a contraparte está ATIVA/BAIXADA.
    expect(itens[0].descricao_situacao_cadastral).toBe("ATIVA");
  });

  it("consulta um documento por vez, nunca em paralelo", async () => {
    // `consultarCnpj` faz `upsert` no cache compartilhado `cadastros_cnpj`: duas consultas
    // concorrentes do mesmo documento correriam entre si, e o mesmo vale para o teto da fonte.
    let emVoo = 0;
    let concorrenciaMaxima = 0;
    consultarCnpjMock.mockImplementation(async () => {
      emVoo += 1;
      concorrenciaMaxima = Math.max(concorrenciaMaxima, emVoo);
      await new Promise((resolve) => setTimeout(resolve, 1));
      emVoo -= 1;
      return cadastro({ regime_tributario_sugerido: "Lucro Presumido", regime_tributario_ano: 2024 });
    });

    await consultarCnpjsEmLote(["11111111000191", "22222222000191", "33333333000191"]);

    expect(concorrenciaMaxima).toBe(1);
  });

  it("propaga erro inesperado em vez de virar um item silencioso", async () => {
    // Só 404 e indisponibilidade são resultado de negócio. Bug de programação tem de estourar.
    consultarCnpjMock.mockRejectedValue(new TypeError("undefined is not a function"));

    await expect(consultarCnpjsEmLote(["11111111000191"])).rejects.toThrow(TypeError);
  });

  it("mantém o teto de lote alinhado com a importação de clientes", () => {
    expect(LIMITE_LOTE_CONSULTA_CNPJ).toBe(100);
  });
});
