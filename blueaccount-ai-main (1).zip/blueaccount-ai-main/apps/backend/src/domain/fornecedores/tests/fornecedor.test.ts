import { describe, expect, it } from "vitest";
import { FindOperator, type EntityManager } from "typeorm";
import {
  buscarFornecedorGenericoPorRegime,
  completarInputComConsulta,
  type FornecedorInput,
} from "../fornecedor.service.js";
import type { CadastroCnpjConsultado } from "../consulta-cnpj.service.js";
import { FORNECEDORES_GENERICOS } from "../fornecedores-genericos.js";

const consulta: CadastroCnpjConsultado = {
  cnpj: "19131243000197",
  razao_social: "Razão da Receita",
  nome_fantasia: "Fantasia pública",
  uf: "SP",
  municipio: "São Paulo",
  endereco_sugerido: "Avenida Paulista, 1000, São Paulo/SP",
  cnae_principal: "6204000",
  cnae_principal_descricao: "Consultoria",
  cnaes_secundarios: [{ codigo: "6201501", descricao: "Desenvolvimento" }],
  porte: "DEMAIS",
  natureza_juridica: "Sociedade Empresária Limitada",
  situacao_cadastral: "2",
  descricao_situacao_cadastral: "ATIVA",
  optante_simples: false,
  optante_mei: false,
  regime_tributario_sugerido: "Lucro Real",
  regime_tributario_ano: 2024,
  fonte: "BrasilAPI",
  consultado_em: "2026-07-29T10:00:00.000Z",
  do_cache: false,
};

describe("completarInputComConsulta", () => {
  it("preenche campos ausentes e inclui a evidência da consulta", () => {
    expect(completarInputComConsulta({ cnpj: consulta.cnpj }, consulta)).toMatchObject({
      razao_social: "Razão da Receita",
      regime_tributario: "Lucro Real",
      cnaes_secundarios: consulta.cnaes_secundarios,
      optante_simples: false,
      optante_mei: false,
      consulta_cnpj_em: consulta.consultado_em,
      consulta_cnpj_fonte: "BrasilAPI",
    });
  });

  it("preserva dados informados pelo usuário ou já decididos pelo contador", () => {
    const input: FornecedorInput = {
      razao_social: "Razão revisada",
      regime_tributario: "Lucro Presumido",
      uf: "RJ",
    };

    expect(completarInputComConsulta(input, consulta)).toMatchObject({
      razao_social: "Razão revisada",
      regime_tributario: "Lucro Presumido",
      uf: "RJ",
      municipio: "São Paulo",
    });
  });

  it("prefere a identificação pública para fornecedor recém-criado pela NF-e", () => {
    const input: FornecedorInput = {
      razao_social: "EMITENTE LTDA",
      nome_fantasia: "Nome provisório do XML",
      regime_tributario: "Lucro Presumido",
    };

    expect(
      completarInputComConsulta(input, consulta, {
        preferirIdentificacaoPublica: true,
      }),
    ).toMatchObject({
      razao_social: "Razão da Receita",
      nome_fantasia: "Fantasia pública",
      regime_tributario: "Lucro Presumido",
    });
  });
});

/**
 * Manager fake que responde ao MESMO shape de `where` que `buscarFornecedorGenericoPorRegime` monta
 * (`regime_tributario` + `opcao_ibs_cbs`, com `IsNull()` do TypeORM quando a opção efetiva é nula),
 * sobre o catálogo real de `fornecedores-genericos.ts` — sem banco.
 */
function fakeManagerComCatalogo(): EntityManager {
  const catalogo = FORNECEDORES_GENERICOS.map((modelo, indice) => ({
    id: `generico-${indice}`,
    regime_tributario: modelo.regime_tributario,
    opcao_ibs_cbs: modelo.opcao_ibs_cbs,
  }));
  return {
    getRepository: () => ({
      findOne: async ({ where }: { where: Record<string, unknown> }) => {
        const opcaoWhere = where.opcao_ibs_cbs;
        const casaOpcao = (opcao: string | null) =>
          opcaoWhere instanceof FindOperator
            ? opcaoWhere.type === "isNull"
              ? opcao === null
              : opcao === opcaoWhere.value
            : opcao === opcaoWhere;
        return (
          catalogo.find((f) => f.regime_tributario === where.regime_tributario && casaOpcao(f.opcao_ibs_cbs)) ?? null
        );
      },
    }),
  } as unknown as EntityManager;
}

describe("buscarFornecedorGenericoPorRegime", () => {
  it("Simples Nacional sem opcao_ibs_cbs assume regime_unico (DAS) — decisão de produto", async () => {
    const fornecedor = await buscarFornecedorGenericoPorRegime(
      fakeManagerComCatalogo(),
      "escritorio-1",
      "Simples Nacional",
      null,
    );
    expect(fornecedor.opcao_ibs_cbs).toBe("regime_unico");
  });

  it("Simples Nacional com regime_regular explícito resolve o híbrido", async () => {
    const fornecedor = await buscarFornecedorGenericoPorRegime(
      fakeManagerComCatalogo(),
      "escritorio-1",
      "Simples Nacional",
      "regime_regular",
    );
    expect(fornecedor.opcao_ibs_cbs).toBe("regime_regular");
  });

  it("MEI sem opcao_ibs_cbs resolve o genérico semeado com regime_unico", async () => {
    // Regressão: a tela manda só `{ regime }` — o art. 41 é exclusivo do Simples Nacional. O
    // genérico de MEI é semeado com `regime_unico` explícito, então procurar `opcao_ibs_cbs IS NULL`
    // não achava linha e a confirmação da importação Domínio morria inteira com "Planilha inválida.".
    const fornecedor = await buscarFornecedorGenericoPorRegime(
      fakeManagerComCatalogo(),
      "escritorio-1",
      "MEI",
      null,
    );
    expect(fornecedor.opcao_ibs_cbs).toBe("regime_unico");
  });

  it("todo regime do catálogo resolve sem o chamador informar opcao_ibs_cbs", async () => {
    // O default sai do catálogo, então adicionar um genérico novo com opção explícita não recria o
    // buraco do MEI: este teste falha junto se alguém voltar a decidir o default por regime na mão.
    for (const regime of new Set(FORNECEDORES_GENERICOS.map((modelo) => modelo.regime_tributario))) {
      const fornecedor = await buscarFornecedorGenericoPorRegime(
        fakeManagerComCatalogo(),
        "escritorio-1",
        regime,
        null,
      );
      expect(fornecedor.regime_tributario).toBe(regime);
    }
  });

  it("regime fora dos cinco valores canônicos lança em vez de devolver null", async () => {
    await expect(
      buscarFornecedorGenericoPorRegime(fakeManagerComCatalogo(), "escritorio-1", "Autonomo Inc", null),
    ).rejects.toThrow(/não é reconhecido/);
  });

  it("par regime/opção sem correspondente no catálogo lança em vez de devolver null", async () => {
    // "Lucro Real" só existe no catálogo com opcao_ibs_cbs nula — "regime_regular" não tem par.
    await expect(
      buscarFornecedorGenericoPorRegime(fakeManagerComCatalogo(), "escritorio-1", "Lucro Real", "regime_regular"),
    ).rejects.toThrow(/Nenhum fornecedor genérico encontrado/);
  });
});
