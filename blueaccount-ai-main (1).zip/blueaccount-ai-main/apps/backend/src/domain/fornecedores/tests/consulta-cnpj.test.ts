import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  comporEndereco,
  consultarCnpj,
  higienizarPayloadCnpj,
  regimeHistoricoSugerido,
} from "../consulta-cnpj.service.js";
import { normalizarCodigoMunicipioIbge } from "../../simulacoes/localidade/ibge.js";

const fixturesDir = join(dirname(fileURLToPath(import.meta.url)), "fixtures");
/** Resposta REAL da BrasilAPI, congelada (PII já removida). Ver o describe de código de município. */
const respostaReal = () =>
  JSON.parse(
    readFileSync(join(fixturesDir, "brasilapi-cnpj-19131243000197.json"), "utf8"),
  ) as Record<string, unknown>;

describe("higienizarPayloadCnpj", () => {
  it("remove PII de terceiro antes de qualquer persistência", () => {
    const limpo = higienizarPayloadCnpj({
      cnpj: "19131243000197",
      razao_social: "OPEN KNOWLEDGE BRASIL",
      uf: "SP",
      cnae_fiscal: 9430800,
      // PII: sócios, e-mail e telefones não são usados para calcular crédito.
      qsa: [{ nome_socio: "Fulano de Tal", cpf_cnpj_socio: "***123456**" }],
      email: "contato@exemplo.org",
      ddd_telefone_1: "1123851939",
      ddd_telefone_2: "1123851940",
      ddd_fax: "1123851941",
    });

    expect(limpo).not.toHaveProperty("qsa");
    expect(limpo).not.toHaveProperty("email");
    expect(limpo).not.toHaveProperty("ddd_telefone_1");
    expect(limpo).not.toHaveProperty("ddd_telefone_2");
    expect(limpo).not.toHaveProperty("ddd_fax");

    // O resto sobrevive: é o dado cadastral que alimenta o fornecedor.
    expect(limpo.razao_social).toBe("OPEN KNOWLEDGE BRASIL");
    expect(limpo.uf).toBe("SP");
    expect(limpo.cnae_fiscal).toBe(9430800);
  });

  it("não muta o objeto original", () => {
    const original = { cnpj: "19131243000197", qsa: [{ nome_socio: "Fulano" }] };
    higienizarPayloadCnpj(original);
    expect(original.qsa).toHaveLength(1);
  });
});

describe("código de município na resposta da fonte", () => {
  it("a fonte real traz codigo_municipio_ibge (7 dígitos) e codigo_municipio (TOM, 4 dígitos)", () => {
    // Este teste existe para travar a premissa do mapeamento. Se a BrasilAPI mudar o nome do campo
    // ou parar de devolvê-lo, é aqui que se descobre — e não numa alíquota de ISS errada em produção.
    const resposta = respostaReal();
    expect(resposta.codigo_municipio_ibge).toBe(3550308);
    expect(resposta.codigo_municipio).toBe(7107);
    expect(resposta.uf).toBe("SP");
  });

  it("promove o codigo_municipio_ibge da resposta real", () => {
    const resposta = respostaReal();
    expect(normalizarCodigoMunicipioIbge(resposta.codigo_municipio_ibge, resposta.uf)).toBe("3550308");
  });

  it("recusa o codigo_municipio da mesma resposta — é TOM/SIAFI, não IBGE", () => {
    const resposta = respostaReal();
    expect(normalizarCodigoMunicipioIbge(resposta.codigo_municipio, resposta.uf)).toBeNull();
  });

  it("recusa código cujo prefixo não bate com a UF do cadastro", () => {
    const resposta = respostaReal();
    expect(normalizarCodigoMunicipioIbge(resposta.codigo_municipio_ibge, "RJ")).toBeNull();
  });

  it("devolve null quando a resposta não traz o campo, sem lançar", () => {
    expect(normalizarCodigoMunicipioIbge(undefined, "SP")).toBeNull();
  });

  it("higienizarPayloadCnpj preserva o código: não é PII", () => {
    const limpo = higienizarPayloadCnpj(respostaReal());
    expect(limpo.codigo_municipio_ibge).toBe(3550308);
  });
});

describe("formato do CNPJ no cache", () => {
  it("a chave do cache usa o MESMO formato de clientes.cnpj e fornecedores.cnpj", async () => {
    // Regressão de um bug silencioso: enquanto `cadastros_cnpj.cnpj` guardava só dígitos e as outras
    // duas tabelas guardavam mascarado, qualquer JOIN entre elas comparando as colunas cruas casava
    // ZERO linhas — sem erro, sem log, só um backfill que não fazia nada.
    const { normalizarCnpj } = await import("../../clientes/cliente.service.js");
    expect(normalizarCnpj("19131243000197")).toBe("19.131.243/0001-97");
    // A URL da fonte continua exigindo dígitos; as duas representações coexistem, cada uma na ponta
    // que a exige.
    expect(normalizarCnpj("19.131.243/0001-97").replace(/\D/g, "")).toBe("19131243000197");
  });
});

describe("consultarCnpj", () => {
  it("devolve null para CPF sem tocar rede nem banco", async () => {
    // Documento de 11 dígitos não tem cadastro público consultável; retorna antes de abrir conexão.
    await expect(consultarCnpj("123.456.789-01")).resolves.toBeNull();
    await expect(consultarCnpj("")).resolves.toBeNull();
    await expect(consultarCnpj(null)).resolves.toBeNull();
  });
});

describe("comporEndereco", () => {
  it("compõe o endereço com todas as partes da resposta real da BrasilAPI", () => {
    // Fixture: logradouro="PAULISTA 37", numero="37", complemento="ANDAR 4", bairro="BELA VISTA",
    // cep="01311902", municipio="SAO PAULO", uf="SP".
    const endereco = comporEndereco(respostaReal());

    expect(endereco).not.toBeNull();
    expect(endereco).toContain("PAULISTA 37");
    expect(endereco).toContain("37");
    expect(endereco).toContain("ANDAR 4");
    expect(endereco).toContain("BELA VISTA");
    expect(endereco).toContain("SAO PAULO/SP");
    expect(endereco).toContain("CEP 01311-902");
  });

  it("compõe só com o que estiver presente quando faltam campos de logradouro", () => {
    expect(comporEndereco({ municipio: "Curitiba", uf: "PR" })).toBe("Curitiba/PR");
    expect(comporEndereco({ logradouro: "Rua das Flores", numero: "10" })).toBe("Rua das Flores, 10");
    expect(comporEndereco({ bairro: "Centro" })).toBe("Centro");
  });

  it("devolve null quando o payload é null, vazio ou sem nenhum campo de endereço", () => {
    expect(comporEndereco(null)).toBeNull();
    expect(comporEndereco(undefined)).toBeNull();
    expect(comporEndereco({})).toBeNull();
    expect(comporEndereco({ cnae_fiscal: 6204000 })).toBeNull();
  });

  it("nunca lança, mesmo com tipos inesperados nos campos", () => {
    expect(() =>
      comporEndereco({ logradouro: 123, numero: null, cep: {} } as unknown as Record<string, unknown>),
    ).not.toThrow();
  });
});

describe("regimeHistoricoSugerido", () => {
  it("usa o regime reconhecido do ano mais recente", () => {
    expect(
      regimeHistoricoSugerido([
        { ano: 2022, forma_de_tributacao: "Lucro Presumido" },
        { ano: "2024", forma_de_tributacao: "LUCRO REAL" },
        { ano: 2023, forma_de_tributacao: "Lucro Presumido" },
      ]),
    ).toEqual({ regime: "Lucro Real", ano: 2024 });
  });

  it("aceita descrições compostas e normaliza acentos", () => {
    expect(
      regimeHistoricoSugerido([
        { ano: 2025, forma_de_tributacao: "Lucro Presumido - apuração trimestral" },
      ]),
    ).toEqual({ regime: "Lucro Presumido", ano: 2025 });
  });

  it("não sugere quando o ano mais recente é ambíguo ou não reconhecido", () => {
    expect(
      regimeHistoricoSugerido([
        { ano: 2024, forma_de_tributacao: "Lucro Real" },
        { ano: 2024, forma_de_tributacao: "Lucro Presumido" },
      ]),
    ).toBeNull();
    expect(regimeHistoricoSugerido([{ ano: 2025, forma_de_tributacao: "Imune" }])).toBeNull();
  });
});
