import { describe, expect, it } from "vitest";
import {
  permiteOpcaoIbsCbsRegimeRegular,
  resolverCreditoFornecedor,
} from "../regime-credito.js";

const base = {
  regime_tributario: null as string | null,
  opcao_ibs_cbs: null as "regime_unico" | "regime_regular" | null,
  aliquota_credito_presumido_ibs: null as number | null,
  aliquota_credito_presumido_cbs: null as number | null,
};

describe("resolverCreditoFornecedor", () => {
  it("Lucro Real e Lucro Presumido geram crédito integral e ignoram opcao_ibs_cbs", () => {
    for (const regime of ["Lucro Real", "Lucro Presumido"]) {
      const resultado = resolverCreditoFornecedor({
        ...base,
        regime_tributario: regime,
        opcao_ibs_cbs: "regime_unico",
      });
      expect(resultado.perfil).toBe("integral");
      expect(resultado.aliquota_credito_presumido_ibs).toBeNull();
      expect(resultado.aliquota_credito_presumido_cbs).toBeNull();
    }
  });

  it("Simples Nacional com opção híbrida gera crédito integral e cita o art. 41", () => {
    const resultado = resolverCreditoFornecedor({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_regular",
      // Alíquotas presumidas cadastradas são ignoradas no híbrido: há destaque integral na nota.
      aliquota_credito_presumido_ibs: 0.015,
      aliquota_credito_presumido_cbs: 0.015,
    });
    expect(resultado.perfil).toBe("integral");
    expect(resultado.aliquota_credito_presumido_ibs).toBeNull();
    expect(resultado.justificativa).toContain("art. 41");
  });

  it("Simples Nacional em regime único gera crédito presumido e cita o art. 47", () => {
    const resultado = resolverCreditoFornecedor({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_unico",
      aliquota_credito_presumido_ibs: 0.015,
      aliquota_credito_presumido_cbs: 0.0135,
    });
    expect(resultado.perfil).toBe("presumido");
    expect(resultado.aliquota_credito_presumido_ibs).toBe(0.015);
    expect(resultado.aliquota_credito_presumido_cbs).toBe(0.0135);
    expect(resultado.justificativa).toContain("art. 47");
  });

  it("Simples Nacional sem opcao_ibs_cbs informada assume regime único", () => {
    const resultado = resolverCreditoFornecedor({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: null,
    });
    expect(resultado.perfil).toBe("presumido");
    // Sem percentual cadastrado o crédito é zero — não se inventa número antes do regulamento.
    expect(resultado.aliquota_credito_presumido_ibs).toBeNull();
    expect(resultado.aliquota_credito_presumido_cbs).toBeNull();
  });

  it("MEI nunca recebe crédito integral pela opção híbrida", () => {
    expect(
      resolverCreditoFornecedor({
        ...base,
        regime_tributario: "MEI",
        opcao_ibs_cbs: "regime_regular",
      }).perfil,
    ).toBe("presumido");

    expect(
      resolverCreditoFornecedor({ ...base, regime_tributario: "MEI", opcao_ibs_cbs: "regime_unico" })
        .perfil,
    ).toBe("presumido");
  });

  it("restringe a opção do regime regular ao Simples Nacional", () => {
    expect(permiteOpcaoIbsCbsRegimeRegular("Simples Nacional")).toBe(true);
    expect(permiteOpcaoIbsCbsRegimeRegular("MEI")).toBe(false);
    expect(permiteOpcaoIbsCbsRegimeRegular("Lucro Real")).toBe(false);
    expect(permiteOpcaoIbsCbsRegimeRegular(null)).toBe(false);
  });

  it("Pessoa Física não gera crédito", () => {
    const resultado = resolverCreditoFornecedor({
      ...base,
      regime_tributario: "Pessoa Física",
      // Nem opção nem percentual mudam o resultado: não há IBS/CBS destacado.
      opcao_ibs_cbs: "regime_regular",
      aliquota_credito_presumido_ibs: 0.5,
    });
    expect(resultado.perfil).toBe("sem_credito");
    expect(resultado.justificativa).toContain("não contribuinte");
    // Regime informado: o resultado é final, não uma pendência de cadastro.
    expect(resultado.evidencia_pendente).toBe(false);
  });

  it("regime não informado deixa o crédito pendente de evidência", () => {
    expect(resolverCreditoFornecedor(base).perfil).toBe("sem_credito");
    expect(resolverCreditoFornecedor({ ...base, regime_tributario: "   " }).perfil).toBe("sem_credito");
    expect(resolverCreditoFornecedor(base).justificativa).toContain("pendente");
    expect(resolverCreditoFornecedor(base).evidencia_pendente).toBe(true);
    expect(resolverCreditoFornecedor({ ...base, regime_tributario: "   " }).evidencia_pendente).toBe(true);
  });

  it("descarta alíquota presumida inválida (zero, negativa ou não numérica)", () => {
    const resultado = resolverCreditoFornecedor({
      ...base,
      regime_tributario: "Simples Nacional",
      opcao_ibs_cbs: "regime_unico",
      aliquota_credito_presumido_ibs: 0,
      aliquota_credito_presumido_cbs: -0.1,
    });
    expect(resultado.aliquota_credito_presumido_ibs).toBeNull();
    expect(resultado.aliquota_credito_presumido_cbs).toBeNull();
  });
});
