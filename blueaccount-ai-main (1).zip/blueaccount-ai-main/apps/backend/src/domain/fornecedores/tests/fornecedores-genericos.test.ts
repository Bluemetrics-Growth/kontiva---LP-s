import { describe, expect, it } from "vitest";
import { FORNECEDORES_GENERICOS } from "../fornecedores-genericos.js";
import { resolverCreditoFornecedor } from "../regime-credito.js";

describe("catálogo de fornecedores genéricos", () => {
  it("cobre um perfil de crédito por regime, incluindo os dois do Simples Nacional", () => {
    const perfis = FORNECEDORES_GENERICOS.map((modelo) => ({
      razao_social: modelo.razao_social,
      perfil: resolverCreditoFornecedor({
        regime_tributario: modelo.regime_tributario,
        opcao_ibs_cbs: modelo.opcao_ibs_cbs,
        aliquota_credito_presumido_ibs: null,
        aliquota_credito_presumido_cbs: null,
      }).perfil,
    }));

    // É o contrato que dá sentido ao recurso: escolher "Genérico - Lucro Presumido" numa despesa
    // manual tem de gerar o mesmo crédito integral que um fornecedor real naquele regime.
    expect(perfis).toEqual([
      { razao_social: "Genérico - Lucro Real", perfil: "integral" },
      { razao_social: "Genérico - Lucro Presumido", perfil: "integral" },
      { razao_social: "Genérico - Simples Nacional (DAS)", perfil: "presumido" },
      { razao_social: "Genérico - Simples Nacional (híbrido)", perfil: "integral" },
      { razao_social: "Genérico - MEI", perfil: "presumido" },
      { razao_social: "Genérico - Pessoa Física", perfil: "sem_credito" },
    ]);
  });

  it("não tem par (regime, opcao_ibs_cbs) repetido, que colidiria na UNIQUE parcial", () => {
    const chaves = FORNECEDORES_GENERICOS.map(
      (m) => `${m.regime_tributario}|${m.opcao_ibs_cbs ?? ""}`,
    );
    expect(new Set(chaves).size).toBe(chaves.length);
  });
});
