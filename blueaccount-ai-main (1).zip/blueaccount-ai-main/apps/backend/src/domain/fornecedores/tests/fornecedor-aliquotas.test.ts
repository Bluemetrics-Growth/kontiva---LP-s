import { beforeEach, describe, expect, it, vi } from "vitest";

/**
 * Contrato central da editabilidade: informar a alíquota de ICMS/ISS no corpo marca a fonte como
 * `manual`, e é esse marcador que impede a próxima importação de NF-e de apagar o número do contador.
 */

const mocks = vi.hoisted(() => {
  const fornecedor: Record<string, unknown> = {
    id: "forn-1",
    escritorio_id: "office-1",
    cnpj: "19131243000197",
    razao_social: "Acme Insumos",
    regime_tributario: "Lucro Presumido",
    aliquota_icms_nominal: 0.18,
    aliquota_icms_fonte: "nfe",
    aliquota_iss_nominal: null,
    aliquota_iss_fonte: null,
  };
  const repo = {
    findOne: vi.fn(async () => fornecedor),
    create: vi.fn((value: Record<string, unknown>) => value),
    save: vi.fn(async (value: Record<string, unknown>) => value),
  };
  const manager = { getRepository: vi.fn(() => repo) };
  return {
    fornecedor,
    repo,
    manager,
    runQueryWithRls: vi.fn(async (_contexto, callback) => callback(manager)),
    ensureDatabase: vi.fn(async () => undefined),
  };
});

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: mocks.runQueryWithRls,
}));

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: mocks.ensureDatabase,
}));

const { atualizarFornecedor } = await import("../fornecedor.service.js");

describe("alíquotas nominais de ICMS/ISS no cadastro do fornecedor", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.fornecedor.aliquota_icms_nominal = 0.18;
    mocks.fornecedor.aliquota_icms_fonte = "nfe";
    mocks.fornecedor.aliquota_iss_nominal = null;
    mocks.fornecedor.aliquota_iss_fonte = null;
  });

  it("valor informado à mão marca a fonte como manual", async () => {
    const resumo = await atualizarFornecedor("office-1", "forn-1", { aliquota_icms_nominal: 0.2 });

    expect(resumo).toMatchObject({
      aliquota_icms_nominal: 0.2,
      aliquota_icms_fonte: "manual",
    });
  });

  it("limpar o campo devolve a alíquota à derivação (fonte volta a null)", async () => {
    const resumo = await atualizarFornecedor("office-1", "forn-1", { aliquota_icms_nominal: null });

    expect(resumo).toMatchObject({
      aliquota_icms_nominal: null,
      aliquota_icms_fonte: null,
    });
  });

  it("marcador é por tributo: mexer no ICMS não trava o ISS", async () => {
    const resumo = await atualizarFornecedor("office-1", "forn-1", { aliquota_icms_nominal: 0.2 });

    expect(resumo).toMatchObject({ aliquota_icms_fonte: "manual", aliquota_iss_fonte: null });
  });

  it("PATCH que não menciona a alíquota preserva valor e fonte derivada", async () => {
    const resumo = await atualizarFornecedor("office-1", "forn-1", { municipio: "Campinas" });

    expect(resumo).toMatchObject({
      aliquota_icms_nominal: 0.18,
      aliquota_icms_fonte: "nfe",
    });
  });

  it("rejeita percentual solto, que geraria alíquota 100x maior", async () => {
    await expect(
      atualizarFornecedor("office-1", "forn-1", { aliquota_icms_nominal: 18 }),
    ).rejects.toThrow(/fração entre 0 e 1/);
  });
});
