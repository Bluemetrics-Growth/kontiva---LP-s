import {
  consultarCnpj,
  CnpjNaoEncontradoError,
  ConsultaCnpjIndisponivelError,
} from "./consulta-cnpj.service.js";
import { somenteDigitos } from "../texto.js";

/**
 * Teto de documentos por requisição.
 *
 * Mesmo raciocínio de `LIMITE_LOTE_CLIENTES`: cada item é uma consulta pública de CNPJ (BrasilAPI,
 * com cache compartilhado em `cadastros_cnpj`), então num cache frio o tempo da requisição cresce
 * linearmente e um lote grande estoura o timeout do ALB/CloudFront antes de terminar. O cliente da
 * API pagina; o servidor recusa acima deste teto em vez de aceitar um lote que não termina.
 */
export const LIMITE_LOTE_CONSULTA_CNPJ = 100;

export type SituacaoConsultaCnpjLote =
  /** Cadastro encontrado e com regime inequívoco: dá para preencher o campo. */
  | "consultado"
  /** Cadastro encontrado, mas o regime não é dedutível do dado público. Continua manual. */
  | "sem_regime"
  /** CNPJ inexistente no cadastro da Receita (404). Não é transitório. */
  | "nao_encontrado"
  /** Documento não é CNPJ de 14 dígitos — CPF não tem cadastro público consultável. */
  | "sem_cadastro_publico"
  /** Fonte fora do ar, timeout ou 5xx. Transitório: repetir o lote é seguro. */
  | "indisponivel"
  /** O mesmo documento apareceu antes no lote; a segunda linha não repete a consulta. */
  | "duplicado_no_lote";

export interface ItemConsultaCnpjLote {
  /** Dígitos, exatamente como chegaram: é a chave que o chamador usa para casar a resposta. */
  cnpj: string;
  situacao: SituacaoConsultaCnpjLote;
  /** Um dos cinco regimes canônicos de pessoa jurídica, ou `null` quando o público não decide. */
  regime_tributario_sugerido: "Simples Nacional" | "MEI" | "Lucro Real" | "Lucro Presumido" | null;
  /** Ano da ECF que embasou Lucro Real/Presumido; `null` para Simples/MEI e para os demais casos. */
  regime_tributario_ano: number | null;
  situacao_cadastral: string | null;
  descricao_situacao_cadastral: string | null;
  /** true quando a resposta veio do cache local, sem tocar a rede. */
  do_cache: boolean;
  erro: string | null;
}

export interface ResumoConsultaCnpjLote {
  total: number;
  consultados: number;
  sem_regime: number;
  nao_encontrados: number;
  sem_cadastro_publico: number;
  indisponiveis: number;
  duplicados_no_lote: number;
  itens: ItemConsultaCnpjLote[];
}

/**
 * Consulta o cadastro público de vários CNPJs e devolve o regime sugerido de cada um.
 *
 * Três decisões definem o comportamento, e as duas primeiras são as mesmas de
 * `importarClientesEmLote`:
 *
 * 1. **Sequencial, nunca `Promise.all`.** Cada item vai à rede e faz `upsert` no cache
 *    compartilhado `cadastros_cnpj`; consultas concorrentes do mesmo documento correriam entre si.
 * 2. **Resultado por item, nunca tudo-ou-nada.** Um CNPJ inexistente ou uma indisponibilidade
 *    momentânea da fonte no meio do lote não pode apagar o que as outras linhas já resolveram —
 *    quem chama precisa poder repetir só o que faltou.
 * 3. **Sugestão, nunca gravação.** Esta função não escreve fornecedor, cliente nem entrada de
 *    simulação: ela devolve o que o dado público diz, e quem decide o que fazer com isso é a tela.
 *    `sem_regime` é resposta legítima e frequente — o cadastro público não carrega o regime de
 *    quem não é optante do Simples e não tem ECF recente, e inventar "Lucro Presumido" aí seria
 *    escolher o regime da contraparte no lugar do contador.
 *
 * Repetir o mesmo lote é seguro e barato: o cache responde sem tocar a rede dentro da validade.
 */
export async function consultarCnpjsEmLote(
  documentos: unknown[],
): Promise<ResumoConsultaCnpjLote> {
  const itens: ItemConsultaCnpjLote[] = [];
  // Chave dos documentos já consultados nesta requisição. A lista de contrapartes pendentes já vem
  // distinta, mas o teto existe para proteger a fonte: repetido no payload não vira segunda ida.
  const vistos = new Set<string>();

  for (const bruto of documentos) {
    const digitos = somenteDigitos(bruto);

    const registrar = (
      situacao: SituacaoConsultaCnpjLote,
      extra: Partial<ItemConsultaCnpjLote> = {},
    ) => {
      itens.push({
        cnpj: digitos,
        situacao,
        regime_tributario_sugerido: null,
        regime_tributario_ano: null,
        situacao_cadastral: null,
        descricao_situacao_cadastral: null,
        do_cache: false,
        erro: null,
        ...extra,
      });
    };

    if (digitos.length !== 14) {
      registrar("sem_cadastro_publico", {
        erro: "Consulta disponível apenas para CNPJ com 14 dígitos; CPF não tem cadastro público.",
      });
      continue;
    }

    if (vistos.has(digitos)) {
      registrar("duplicado_no_lote");
      continue;
    }
    vistos.add(digitos);

    try {
      const consulta = await consultarCnpj(digitos);
      if (!consulta) {
        // `consultarCnpj` só devolve `null` para documento que não é CNPJ, e isso já foi filtrado
        // acima. Chegar aqui é defensivo, não um caminho esperado.
        registrar("sem_cadastro_publico");
        continue;
      }
      registrar(consulta.regime_tributario_sugerido ? "consultado" : "sem_regime", {
        regime_tributario_sugerido: consulta.regime_tributario_sugerido,
        regime_tributario_ano: consulta.regime_tributario_ano,
        situacao_cadastral: consulta.situacao_cadastral,
        descricao_situacao_cadastral: consulta.descricao_situacao_cadastral,
        do_cache: consulta.do_cache,
      });
    } catch (error) {
      if (error instanceof CnpjNaoEncontradoError) {
        registrar("nao_encontrado", { erro: error.message });
        continue;
      }
      if (error instanceof ConsultaCnpjIndisponivelError) {
        registrar("indisponivel", { erro: error.message });
        continue;
      }
      throw error;
    }
  }

  const contar = (situacao: SituacaoConsultaCnpjLote) =>
    itens.filter((item) => item.situacao === situacao).length;

  return {
    total: itens.length,
    consultados: contar("consultado"),
    sem_regime: contar("sem_regime"),
    nao_encontrados: contar("nao_encontrado"),
    sem_cadastro_publico: contar("sem_cadastro_publico"),
    indisponiveis: contar("indisponivel"),
    duplicados_no_lote: contar("duplicado_no_lote"),
    itens,
  };
}
