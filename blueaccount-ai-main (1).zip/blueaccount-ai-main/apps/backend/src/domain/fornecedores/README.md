# `src/domain/fornecedores`

Cadastro de **fornecedores** (contrapartes de compra) e derivação do crédito de IBS/CBS que a compra
transfere ao adquirente. Consumido pelas simulações da reforma tributária.

## Por que existe separado de `clientes`

`clientes` responde "quem eu atendo"; `fornecedores` responde "quanto de crédito esta compra devolve".
São perguntas diferentes, com campos diferentes (UF, CNAE, opção de IBS/CBS) e ciclo de vida próprio.
Um mesmo CNPJ pode ser cliente de um escritório e fornecedor de outro.

## Arquivos

- `regime-credito.ts`: núcleo **puro** — `resolverCreditoFornecedor` mapeia regime + opção de IBS/CBS
  para um `PerfilCreditoFornecedor` (`integral | presumido | sem_credito`), as alíquotas presumidas e
  a justificativa legal. Sem banco, sem rede, testável isolado.
- `fornecedor.service.ts`: CRUD com `runQueryWithRls`, enriquecimento best-effort,
  `encontrarOuCriarFornecedorPorCnpj` (recebe o `EntityManager` do chamador, usado pela importação
  de NF-e dentro da transação dela) e `atualizarAliquotasDerivadas` (grava a alíquota consolidada
  das NF-e sem sobrescrever o que foi digitado à mão).
- `consulta-cnpj.service.ts`: consulta pública de CNPJ com cache em `cadastros_cnpj` (schema público).
  `consultarCnpjSemBloquear` (best-effort, nunca lança) e `comporEndereco` (compõe `endereco_sugerido`
  a partir de logradouro/número/complemento/bairro/município/UF/CEP do `payload` cacheado) moram
  aqui mas não são exclusivos de fornecedor: `domain/clientes/cliente.service.ts` também importa os
  dois, com precedência oposta (API vence sobre extraído/digitado — ver `domain/clientes/README.md`).
- `consultar-cnpjs-lote.ts`: a mesma consulta para uma lista de documentos, com teto de 100
  (`LIMITE_LOTE_CONSULTA_CNPJ`), classificando cada item em `consultado`/`sem_regime`/
  `nao_encontrado`/`sem_cadastro_publico`/`indisponivel`/`duplicado_no_lote`. Sequencial pelos mesmos
  dois motivos de `importarClientesEmLote` (ida à rede por item e `upsert` no cache compartilhado), e
  **sugestão, nunca gravação**: `sem_regime` é resposta legítima, porque o cadastro público não
  carrega o regime de quem não é optante do Simples e não tem ECF reconhecível — inventar "Lucro
  Presumido" ali seria escolher o regime da contraparte no lugar do contador.
- `fornecedores-genericos.ts`: catálogo fechado dos **fornecedores genéricos** (um por perfil de
  regime). É contrato legível e base de teste; quem escreve as linhas é a migration. Ver a seção
  "Fornecedores genéricos" abaixo.
- `tests/`: `regime-credito.test.ts` (tabela de decisão), `consulta-cnpj.test.ts` (higienização de
  PII, CPF sem rede e histórico tributário), `consultar-cnpjs-lote.test.ts` (classificação por item,
  sequencialidade e erro inesperado propagado), `fornecedor.test.ts` (merge de enriquecimento) e
  `fornecedores-genericos.test.ts` (perfil de crédito resolvido de cada genérico).

O client HTTP fica em `infrastructure/external-services/cadastro-cnpj.client.ts`.

## Regra de crédito (LC 214/2025)

| `regime_tributario` | `opcao_ibs_cbs` | perfil | efeito no cálculo |
| --- | --- | --- | --- |
| `Lucro Real` / `Lucro Presumido` | irrelevante | `integral` | crédito cheio pelas alíquotas da linha/simulação |
| `Simples Nacional` | `regime_regular` | `integral` | opção híbrida (art. 41): destaque integral na nota |
| `Simples Nacional` | `regime_unico` ou nulo | `presumido` | `base_ibs_cbs × aliquota_credito_presumido_*` (art. 47, §9º, II) |
| `MEI` | nulo / `regime_unico` | `presumido` | não pode optar pelo regime regular; dado legado `regime_regular` também é tratado como presumido |
| `Pessoa Física` | irrelevante | `sem_credito` | não contribuinte, sem IBS/CBS destacado |
| nulo | irrelevante | `sem_credito` | sem regime cadastrado não há evidência de destaque: crédito pendente |

Duas coisas contraintuitivas, ambas deliberadas:

1. **As alíquotas presumidas incidem sobre a base de IBS/CBS**, não sobre o crédito cheio. Diferente de
   `simulacao_entradas.percentual_credito`, que é fração do crédito integral. O art. 47, §9º, II
   opera como "compra × percentual = crédito".
2. **O default é nulo, ou seja crédito presumido zero.** Os percentuais oficiais dependem de
   regulamento conjunto CGIBS/RFB que varia por CNAE, faixa de receita e Anexo do Simples, e ainda
   não foi publicado. O sistema não inventa número: quem informa é o contador.
3. **`regime_tributario` nulo resolve `sem_credito`, não `integral`.** Sem cadastro nem documento não
   há como afirmar destaque integral, e afirmar por omissão inflava o crédito de toda linha ligada a
   fornecedor incompleto. Atenção na implantação: fornecedores já cadastrados sem regime passam a não
   gerar crédito, e a tabela `fornecedores` **não** é limpa junto com as simulações.

O crédito presumido é só de IBS/CBS. **ICMS não passa pela tabela acima** — a decisão de crédito de
ICMS segue `tratamento_icms` da linha. O que o fornecedor contribui em ICMS/ISS é a *alíquota*, na
seção seguinte.

## Fornecedores genéricos

Uma despesa manual sem `fornecedor_id` sai com crédito de IBS/CBS **zerado**: `calculo.ts` só
reconhece crédito quando um cadastro comprova o regime da contraparte (a única exceção é
`regra_credito: "manual"`, valor digitado). Isso é o default conservador certo, mas deixava o contador
sem saída quando a despesa é real e o documento não está à mão: `cnpj` era obrigatório e único, então
não havia como cadastrar "um fornecedor no Lucro Presumido".

Os genéricos são essa saída. Seis linhas por escritório, como todo fornecedor:

| `razao_social` | regime | `opcao_ibs_cbs` | perfil resultante |
| --- | --- | --- | --- |
| `Genérico - Lucro Real` | `Lucro Real` | nulo | `integral` |
| `Genérico - Lucro Presumido` | `Lucro Presumido` | nulo | `integral` |
| `Genérico - Simples Nacional (DAS)` | `Simples Nacional` | `regime_unico` | `presumido` |
| `Genérico - Simples Nacional (híbrido)` | `Simples Nacional` | `regime_regular` | `integral` |
| `Genérico - MEI` | `MEI` | `regime_unico` | `presumido` |
| `Genérico - Pessoa Física` | `Pessoa Física` | nulo | `sem_credito` |

Regras que os distinguem de um cadastro real:

- **`cnpj IS NULL`**, garantido por `CHK_fornecedores_generico` (que também exige o inverso: real
  sempre com documento). A UNIQUE de documento é parcial (`WHERE cnpj IS NOT NULL`) e a unicidade do
  genérico é `(COALESCE(regime_tributario, ''), COALESCE(opcao_ibs_cbs, ''))` — schema-per-escritório,
  então isso já é unicidade por escritório, igual ao que a UNIQUE de `cnpj` sempre fez.
- **Invisíveis por default.** `listarFornecedores`/`listarFornecedoresPaginado` só os incluem quando
  recebem `incluirGenericos`, o que na HTTP é `GET /api/fornecedores?genericos=true`. A tela de
  fornecedores não pede, e por isso não os mostra.
- **Imutáveis pela API.** `atualizarFornecedor` (e portanto `desativarFornecedor`) lança
  `FornecedorValidationError` sobre genérico: o regime é a identidade dele, e editá-lo mudaria em
  silêncio o crédito de toda linha que já o referencia.
- **`uf` e `codigo_municipio_ibge` nulos de propósito.** `resolverLocalidadeDaEntrada` já lê origem
  desconhecida como operação interna para ICMS/ISS (alíquota do próprio estado do cenário) e devolve
  `null` no DIFAL, que é a leitura certa para uma contraparte sem identidade.
- **`cnae_principal` nulo tem uma consequência.** Num cliente com `cnaes_fornecedores_permitidos`
  cadastrada, `permiteCreditoPorCnaeFornecedor` reprova linha sem CNAE, então o crédito de **ICMS**
  da linha fica bloqueado até alguém informar `cnae_override` nela. Por isso o editor mantém o campo
  de CNAE editável quando o vínculo é genérico, em vez de exibir o CNAE do fornecedor. IBS/CBS não
  passa por esse gate, que é justamente o problema que o genérico resolve.

**Quem cria as linhas é a migration** `1787200000000-add-fornecedores-genericos`, não código de
runtime. Ela resolve o `escritorio_id` a partir do **nome do schema** (`escritorio_<uuid>`, contrato
de `database/tenant-naming.ts`), porque dentro de um tenant não há outra fonte confiável: derivar de
`clientes` existentes falharia justamente no escritório recém-criado, que ainda não tem linha nenhuma.
Como `provisionEscritorioSchema` roda as migrations do tenant ao criar o escritório e
`migration:sync-tenants` roda nos que já existem, o mesmo caminho cobre escritório novo e antigo, sem
seed em runtime. Em schema fora do formato esperado a migration insere zero linhas em vez de falhar.

O catálogo em `fornecedores-genericos.ts` espelha a lista congelada na migration. Para adicionar um
perfil: mexer no catálogo e escrever uma migration nova. Migration é snapshot e não pode importar
domínio vivo.

**Consumidor por regime (em vez de UUID): `buscarFornecedorGenericoPorRegime`**
(`fornecedor.service.ts`). A importação em lote de dados de simulação
(`domain/simulacoes/dados-simulacao.service.ts`) recebe `fornecedor_regime`/`fornecedor_opcao_ibs_cbs`
por linha da planilha (contraparte sem CNPJ — ver `domain/simulacoes/README.md` → "Contraparte por
linha na importação"), então precisa resolver o genérico pelo PAR regime/opção, não por um UUID já
conhecido como `fornecedorGenericoPadraoOuNulo` (`simulacao.service.ts`) faz. A query é
`WHERE escritorio_id = ? AND generico = true AND regime_tributario = ? AND opcao_ibs_cbs IS NOT
DISTINCT FROM ?` — `opcao_ibs_cbs` nula usa `IsNull()` do TypeORM, para não cair na armadilha de
`opcao_ibs_cbs = NULL` nunca casar em SQL.

Regras da função:

- **`opcaoIbsCbs` não informada sai do próprio catálogo**, via `opcaoPadraoDoGenerico`: o regime com um
  único genérico usa a opção dele, e o único regime ambíguo (Simples Nacional, com DAS e híbrido)
  assume `regime_unico` — o genérico `Genérico - Simples Nacional (DAS)`, crédito **presumido**, mesma
  decisão de produto já registrada na seção de importação do README de `domain/simulacoes`. Uma
  planilha que só diz "Simples Nacional" sem opinar sobre a opção recebe o perfil mais conservador,
  não o híbrido integral. **Esta regra já foi um bug:** o default era decidido por regime na mão, só
  para Simples, e o genérico de **MEI** é semeado com `regime_unico` explícito — então `MEI` sem opção
  procurava `opcao_ibs_cbs IS NULL`, não achava linha e a confirmação da importação Domínio reprovava
  o lote inteiro com "Planilha inválida.". Tirar o default do catálogo fecha isso e qualquer perfil
  novo com opção explícita;
- `regimeTributario` fora dos cinco valores de `REGIMES_TRIBUTARIOS` lança em vez de devolver `null` —
  mesma filosofia de `normalizarRegimeTributario` (`domain/clientes/regime-tributario.ts`): silenciar
  aqui deixaria a linha sem fornecedor sem o contador saber por quê;
- par regime/opção sem correspondente no catálogo (ex.: "Lucro Real" com `regime_regular` — o
  catálogo só tem Lucro Real com opção nula) também lança, nunca devolve `null` silenciosamente —
  o catálogo é fechado e a query não deveria ficar sem match fora de erro de digitação.

## Alíquota nominal de ICMS/ISS (`aliquota_*_nominal` + `aliquota_*_fonte`)

`aliquota_icms_nominal` e `aliquota_iss_nominal` guardam a alíquota **cheia**, antes da redução do
cronograma da reforma. No motor elas são um nível intermediário de precedência: perdem do
`aliquota_*_override` da linha e ganham do `aliquota_*_padrao` do cenário
(`domain/simulacoes/README.md` → "Ano do cenário e alíquotas").

Valem para **qualquer regime tributário** — ao contrário de `opcao_ibs_cbs` e das alíquotas
presumidas, que só existem no Simples. Na tela, os campos ficam deliberadamente fora do bloco gated
por Simples Nacional.

`aliquota_icms_fonte` / `aliquota_iss_fonte` (`nfe` | `manual` | `NULL`) decidem quem pode escrever:

- `atualizarAliquotasDerivadas` (chamada pela importação de NF-e) só grava onde a fonte
  `IS DISTINCT FROM 'manual'`, e marca `'nfe'`. Sem esse marcador, o próximo lote de notas apagaria
  silenciosamente a alíquota que o contador digitou — perda de dado garantida;
- informar a alíquota no corpo de `POST`/`PATCH` marca `'manual'`. Valor nulo é "sem opinião" e
  devolve a fonte a `NULL`, ou seja o campo volta a ser derivável. Sem isso, salvar o formulário com o
  campo vazio congelaria o fornecedor em branco para sempre;
- o marcador é **por tributo**: travar o ICMS não trava a derivação do ISS.

A média é ponderada pela base tributada das notas (`domain/simulacoes/nfe/aliquotas-fornecedor.ts`),
cobre todas as simulações do escritório — o cadastro é escritório-wide — e é sempre re-derivável do
zero a partir de `simulacao_notas_fiscais`.

Limitação conhecida: o ISS quase sempre chega vazio, porque vive na NFS-e municipal, que não é
importada (não há leiaute nacional único). Por isso o campo é editável à mão.

Cobertura: `tests/fornecedor-aliquotas.test.ts`.

## Consulta de CNPJ

Fonte default: BrasilAPI (`CNPJ_LOOKUP_BASE_URL`), grátis e sem chave, sobre os dados abertos da RFB.
Cache-first em `cadastros_cnpj` com TTL de `CNPJ_LOOKUP_TTL_DIAS` (30 por default).

**Formato do CNPJ:** `cadastros_cnpj.cnpj` guarda **mascarado** (`00.000.000/0000-00`), igual a
`clientes.cnpj` e `fornecedores.cnpj` — as três colunas de CNPJ do banco usam o mesmo formato.
Enquanto esta era a única guardada só com dígitos, qualquer `JOIN` com as outras duas comparando as
colunas cruas casava **zero linhas**, sem erro e sem log. As duas representações coexistem, cada uma
na ponta que a exige: a URL da BrasilAPI só aceita dígitos, a coluna guarda mascarado. Normalize com
`normalizarCnpj` antes de consultar o cache.

O que a consulta **resolve**: razão social, nome fantasia, UF, município, código IBGE do município,
CNAE principal + descrição, CNAEs secundários, porte, natureza jurídica, situação cadastral, optante
do Simples e do MEI.

### `codigo_municipio_ibge`

Código IBGE de 7 dígitos, chave da alíquota de ISS derivada da localidade
(`domain/simulacoes/localidade/iss-municipal.ts`). `municipio` sozinho não serve: é texto livre e
municípios homônimos em estados diferentes são indistinguíveis.

**Armadilha:** a BrasilAPI devolve dois campos vizinhos e quase homônimos para o mesmo CNPJ —
`codigo_municipio_ibge` (ex.: `3550308`, São Paulo) e `codigo_municipio` (ex.: `7107`, o código
TOM/SIAFI da Receita). **Só o primeiro é IBGE.** `RespostaCadastroCnpj` declara apenas o primeiro
justamente para ninguém usar o outro por engano; o segundo viraria uma alíquota de ISS plausível e
falsa, sem erro nenhum. Fixture com a resposta real congelada em
`tests/fixtures/brasilapi-cnpj-19131243000197.json`.

`normalizarCodigoMunicipioIbge` (em `domain/simulacoes/localidade/ibge.ts`) exige 7 dígitos **e**
prefixo compatível com a UF da própria linha, e devolve `null` em vez de lançar. Em `aplicarCampos`,
a `uf` é aplicada **antes** do código: o guard valida contra a UF da linha, e inverter a ordem
compararia com a UF antiga numa mudança de estado.

Somente leitura na UI: é chave técnica, e um campo editável convidaria a digitação errada que vira
alíquota errada. **Não** interage com a trava `aliquota_*_fonte` — a alíquota derivada da localidade
é calculada em tempo de leitura e nunca é persistida em `aliquota_*_nominal`.

Para o regime, `optante_mei` e `optante_simples` têm precedência. Fora deles, o sistema lê
`regime_tributario` da BrasilAPI e sugere `Lucro Real` ou `Lucro Presumido` somente quando o ano mais
recente possui um único regime reconhecido. A resposta inclui `regime_tributario_ano` para deixar a
antiguidade explícita. Histórico ausente, desconhecido ou ambíguo fica nulo.

A opção híbrida de IBS/CBS continua manual: não é dado público e só é aceita para Simples Nacional.

**PII de terceiro nunca é persistida.** `higienizarPayloadCnpj` remove `qsa` (nomes e documentos de
sócios), `email` e telefones antes de qualquer gravação. Há teste afirmando isso.

Erros são tipados e não fatais: `CnpjNaoEncontradoError` → 404, `ConsultaCnpjIndisponivelError` → 503.
O `POST` tenta enriquecer automaticamente, usando a consulta apenas como fallback dos campos que o
usuário deixou vazios. Inexistência ou indisponibilidade não bloqueiam o cadastro manual.

Na importação de NF-e, fornecedores são criados dentro da transação apenas com dados do XML. Depois
do commit, os CNPJs são deduplicados e enriquecidos em lotes com concorrência limitada. Assim não há
rede dentro da transação e uma falha da BrasilAPI não desfaz notas já importadas. Para fornecedor
recém-criado pela importação, razão social e nome fantasia da BrasilAPI substituem a identificação
provisória do XML. Em fornecedor que já existia, dados preenchidos e decisões do contador não são
sobrescritos; a evidência da consulta é atualizada.

O CNPJ digitado diretamente numa entrada de simulação chama
`resolverFornecedorPorCnpjComEnriquecimento`: primeiro localiza o registro existente ou usa o mesmo
fluxo de criação/enriquecimento do `POST /api/fornecedores`, depois vincula o UUID à entrada. Assim a
consulta pública ocorre antes da transação da entrada; se a gravação posterior da entrada falhar, o
fornecedor recém-criado pode permanecer no cadastro.

## Regra prática

Decisão de crédito fica em `regime-credito.ts`, puro. Persistência e RLS ficam em
`fornecedor.service.ts`. Rede e cache ficam em `consulta-cnpj.service.ts`. O motor de cálculo
(`domain/simulacoes/calculo.ts`) **não** importa `Fornecedor`: recebe o perfil já resolvido.
