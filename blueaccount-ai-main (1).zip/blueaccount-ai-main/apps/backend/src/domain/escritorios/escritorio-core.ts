import { AppDataSource } from "../../database/data-source.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import { Sessao } from "../../database/modules/public/entities/sessao.entity.js";
import { OAuthAccessToken } from "../../database/modules/public/entities/oauth-access-token.entity.js";
import { OAuthAuthorizationCode } from "../../database/modules/public/entities/oauth-authorization-code.entity.js";
import { OAuthClient } from "../../database/modules/public/entities/oauth-client.entity.js";
import { OAuthRefreshToken } from "../../database/modules/public/entities/oauth-refresh-token.entity.js";
import { AgentLog } from "../../database/modules/public/entities/agent-log.entity.js";
import { Contexto } from "../../database/modules/public/entities/contexto.entity.js";
import { SolicitacaoPrivacidade } from "../../database/modules/public/entities/solicitacao-privacidade.entity.js";
import { dropEscritorioSchema, provisionEscritorioSchema } from "../../database/escritorio-schema.js";
import { buildEscritorioSchemaName } from "../../database/tenant-naming.js";
import { runTenantMigrations } from "../../database/tenant-module-runner.js";
import {
  grantTenantRoleToRuntimeRoles,
  reconcileTenantPrivileges,
  revokePublicTablePrivilegesFromTenantRole,
  buildTenantPrivilegeTarget,
} from "../../database/tenant-privileges.js";
import {
  deleteCognitoUser,
  ensureAiUserForEscritorio,
  ensureDatabase,
} from "../autenticacao/autenticacao.service.js";
import type { EntityManager } from "typeorm";
import {
  adminAuditLogger,
  mapEscritorio,
  type DeleteEscritorioResult,
  type EscritorioResumo,
  type ProvisionEscritorioSchemaResult,
} from "./escritorio-shared.js";

export async function listEscritorios(input: { includeInactive?: boolean } = {}): Promise<EscritorioResumo[]> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(Escritorio);
  const escritorios = await repo.find({
    where: input.includeInactive ? {} : { ativo: true },
    order: { nome: "ASC" },
  });

  return await Promise.all(escritorios.map(mapEscritorio));
}

/** Resumo de um escritório específico para superfícies autenticadas do próprio tenant. */
export async function getEscritorioResumo(escritorioId: string): Promise<EscritorioResumo | null> {
  await ensureDatabase();
  const id = escritorioId.trim();
  if (!id) return null;
  const escritorio = await AppDataSource.getRepository(Escritorio).findOneBy({ id });
  return escritorio ? mapEscritorio(escritorio) : null;
}

/** Consulta mínima para cabeçalhos de documentos do próprio tenant. Não chama
 * a inspeção de migrations/schema usada pelo resumo administrativo completo. */
export async function getNomeEscritorio(escritorioId: string): Promise<string | null> {
  await ensureDatabase();
  const id = escritorioId.trim();
  if (!id) return null;
  const escritorio = await AppDataSource.getRepository(Escritorio).findOne({
    select: { nome: true },
    where: { id },
  });
  return escritorio?.nome?.trim() || null;
}

export async function createEscritorio(nome: string): Promise<EscritorioResumo | null> {
  await ensureDatabase();

  const trimmed = nome.trim();
  if (!trimmed) {
    return null;
  }

  const repo = AppDataSource.getRepository(Escritorio);
  const escritorio = repo.create({
    nome: trimmed,
    contract_agent_input_mode: "pdf",
    report_agent_input_mode: "pdf",
  });
  const saved = await repo.save(escritorio);
  await ensureAiUserForEscritorio(saved);

  return await mapEscritorio(saved);
}

export type UpdateEscritorioInput = {
  ativo?: boolean;
  ambiente_teste_cobranca?: boolean;
  contract_extraction_complexity?: number;
  contract_agent_input_mode?: "ocr" | "pdf";
  report_extraction_complexity?: number;
  report_agent_input_mode?: "ocr" | "pdf";
  report_agent_instructions?: string | null;
  provedor_ia?: "chatgpt" | "claude";
  locale?: "pt" | "en";
  is_trial?: boolean;
  trial_max_documentos?: number;
  trial_max_cobranca_execucoes?: number;
  trial_max_paginas_por_documento?: number;
  conector_drive_folder_id?: string | null;
  conector_drive_ativo?: boolean;
};

export type UpdateEscritorioResult =
  | { ok: true; escritorio: EscritorioResumo }
  | { ok: false; status: 400 | 404; error: string };

export async function updateEscritorio(
  escritorioId: string,
  input: UpdateEscritorioInput,
): Promise<UpdateEscritorioResult> {
  await ensureDatabase();

  const trimmedId = escritorioId.trim();
  if (!trimmedId) {
    return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
  }

  const hasAmbiente = typeof input.ambiente_teste_cobranca === "boolean";
  const hasAtivo = typeof input.ativo === "boolean";
  const hasComplexity = Number.isInteger(input.contract_extraction_complexity) && (input.contract_extraction_complexity as number) >= 1;
  const hasContractAgentInputMode =
    input.contract_agent_input_mode === "ocr" || input.contract_agent_input_mode === "pdf";
  const hasReportComplexity = Number.isInteger(input.report_extraction_complexity) && (input.report_extraction_complexity as number) >= 1;
  const hasReportAgentInputMode =
    input.report_agent_input_mode === "ocr" || input.report_agent_input_mode === "pdf";
  const hasReportAgentInstructions = input.report_agent_instructions !== undefined;
  const hasProvedorIa = input.provedor_ia === "chatgpt" || input.provedor_ia === "claude";
  const hasLocale = input.locale === "pt" || input.locale === "en";
  const hasIsTrial = typeof input.is_trial === "boolean";
  // Limites de trial: inteiros >= 0.
  const isValidLimit = (v: unknown) => Number.isInteger(v) && (v as number) >= 0;
  const hasMaxDocs = input.trial_max_documentos !== undefined;
  const hasMaxCobranca = input.trial_max_cobranca_execucoes !== undefined;
  const hasMaxPaginas = input.trial_max_paginas_por_documento !== undefined;
  const hasConectorDriveFolderId = input.conector_drive_folder_id !== undefined;
  const hasConectorDriveAtivo = typeof input.conector_drive_ativo === "boolean";
  if (input.contract_extraction_complexity !== undefined && !hasComplexity) {
    return { ok: false, status: 400, error: "contract_extraction_complexity deve ser um inteiro >= 1." };
  }
  if (input.contract_agent_input_mode !== undefined && !hasContractAgentInputMode) {
    return { ok: false, status: 400, error: "contract_agent_input_mode deve ser 'ocr' ou 'pdf'." };
  }
  if (input.report_extraction_complexity !== undefined && !hasReportComplexity) {
    return { ok: false, status: 400, error: "report_extraction_complexity deve ser um inteiro >= 1." };
  }
  if (input.report_agent_input_mode !== undefined && !hasReportAgentInputMode) {
    return { ok: false, status: 400, error: "report_agent_input_mode deve ser 'ocr' ou 'pdf'." };
  }
  if (input.provedor_ia !== undefined && !hasProvedorIa) {
    return { ok: false, status: 400, error: "provedor_ia deve ser 'chatgpt' ou 'claude'." };
  }
  if (input.locale !== undefined && !hasLocale) {
    return { ok: false, status: 400, error: "locale deve ser 'pt' ou 'en'." };
  }
  if (
    hasReportAgentInstructions &&
    input.report_agent_instructions !== null &&
    typeof input.report_agent_instructions !== "string"
  ) {
    return { ok: false, status: 400, error: "report_agent_instructions deve ser texto ou null." };
  }
  if (typeof input.report_agent_instructions === "string" && input.report_agent_instructions.trim().length > 8000) {
    return { ok: false, status: 400, error: "report_agent_instructions deve ter no máximo 8000 caracteres." };
  }
  if (hasMaxDocs && !isValidLimit(input.trial_max_documentos)) {
    return { ok: false, status: 400, error: "trial_max_documentos deve ser um inteiro >= 0." };
  }
  if (hasMaxCobranca && !isValidLimit(input.trial_max_cobranca_execucoes)) {
    return { ok: false, status: 400, error: "trial_max_cobranca_execucoes deve ser um inteiro >= 0." };
  }
  if (hasMaxPaginas && !isValidLimit(input.trial_max_paginas_por_documento)) {
    return { ok: false, status: 400, error: "trial_max_paginas_por_documento deve ser um inteiro >= 0." };
  }
  if (
    !hasAtivo &&
    !hasAmbiente &&
    !hasComplexity &&
    !hasContractAgentInputMode &&
    !hasReportComplexity &&
    !hasReportAgentInputMode &&
    !hasReportAgentInstructions &&
    !hasProvedorIa &&
    !hasLocale &&
    !hasIsTrial &&
    !hasMaxDocs &&
    !hasMaxCobranca &&
    !hasMaxPaginas &&
    !hasConectorDriveFolderId &&
    !hasConectorDriveAtivo
  ) {
    return { ok: false, status: 400, error: "Nenhum campo editável foi informado." };
  }

  const repo = AppDataSource.getRepository(Escritorio);
  const escritorio = await repo.findOneBy({ id: trimmedId });
  if (!escritorio) {
    return { ok: false, status: 404, error: "Escritório não encontrado." };
  }

  if (hasAtivo) escritorio.ativo = input.ativo as boolean;
  if (hasAmbiente) escritorio.ambiente_teste_cobranca = input.ambiente_teste_cobranca as boolean;
  if (hasComplexity) escritorio.contract_extraction_complexity = input.contract_extraction_complexity as number;
  if (hasContractAgentInputMode) escritorio.contract_agent_input_mode = input.contract_agent_input_mode as "ocr" | "pdf";
  if (hasReportComplexity) escritorio.report_extraction_complexity = input.report_extraction_complexity as number;
  if (hasReportAgentInputMode) escritorio.report_agent_input_mode = input.report_agent_input_mode as "ocr" | "pdf";
  if (hasReportAgentInstructions) {
    const instructions = input.report_agent_instructions;
    escritorio.report_agent_instructions = typeof instructions === "string" && instructions.trim()
      ? instructions.trim()
      : null;
  }
  if (hasProvedorIa) escritorio.provedor_ia = input.provedor_ia as "chatgpt" | "claude";
  if (hasLocale) escritorio.locale = input.locale as "pt" | "en";
  if (hasIsTrial) escritorio.is_trial = input.is_trial as boolean;
  if (hasMaxDocs) escritorio.trial_max_documentos = input.trial_max_documentos as number;
  if (hasMaxCobranca) escritorio.trial_max_cobranca_execucoes = input.trial_max_cobranca_execucoes as number;
  if (hasMaxPaginas) escritorio.trial_max_paginas_por_documento = input.trial_max_paginas_por_documento as number;
  if (hasConectorDriveFolderId) {
    const folderId = input.conector_drive_folder_id;
    escritorio.conector_drive_folder_id = typeof folderId === "string" && folderId.trim() ? folderId.trim() : null;
  }
  if (hasConectorDriveAtivo) escritorio.conector_drive_ativo = input.conector_drive_ativo as boolean;
  const saved = await repo.save(escritorio);

  adminAuditLogger.info("escritorio_atualizado", {
    escritorio_id: saved.id,
    ativo: saved.ativo,
    ambiente_teste_cobranca: saved.ambiente_teste_cobranca,
    contract_extraction_complexity: saved.contract_extraction_complexity,
    contract_agent_input_mode: saved.contract_agent_input_mode,
    report_extraction_complexity: saved.report_extraction_complexity,
    report_agent_input_mode: saved.report_agent_input_mode,
    report_agent_instructions_present: Boolean(saved.report_agent_instructions),
    provedor_ia: saved.provedor_ia,
    locale: saved.locale,
    is_trial: saved.is_trial,
    trial_max_documentos: saved.trial_max_documentos,
    trial_max_cobranca_execucoes: saved.trial_max_cobranca_execucoes,
    trial_max_paginas_por_documento: saved.trial_max_paginas_por_documento,
    conector_drive_folder_id: saved.conector_drive_folder_id,
    conector_drive_ativo: saved.conector_drive_ativo,
  });

  return { ok: true, escritorio: await mapEscritorio(saved) };
}

/**
 * Lê — fora de RLS, no schema public — se o escritório é ambiente de teste de
 * cobrança. NUNCA lança: na ausência do registro ou em qualquer erro, assume
 * `false`. Uma flag de configuração jamais pode quebrar a geração de cobrança.
 */
export async function isEscritorioAmbienteTesteCobranca(escritorioId: string): Promise<boolean> {
  try {
    await ensureDatabase();
    const escritorio = await AppDataSource.getRepository(Escritorio).findOne({
      where: { id: escritorioId },
      select: { id: true, ambiente_teste_cobranca: true },
    });
    return escritorio?.ambiente_teste_cobranca === true;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    adminAuditLogger.warn("escritorio_ambiente_teste_lookup_failed", {
      escritorio_id: escritorioId,
      error: message,
    });
    return false;
  }
}

export async function provisionEscritorio(
  escritorioId: string,
): Promise<ProvisionEscritorioSchemaResult> {
  await ensureDatabase();

  const trimmedEscritorioId = escritorioId.trim();
  if (!trimmedEscritorioId) {
    return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
  }

  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  const escritorio = await escritorioRepo.findOneBy({ id: trimmedEscritorioId, ativo: true });
  if (!escritorio) {
    return { ok: false, status: 404, error: "Escritório não encontrado." };
  }

  try {
    await ensureAiUserForEscritorio(escritorio);
    const result = await provisionEscritorioSchema(AppDataSource.manager as EntityManager, trimmedEscritorioId);
    const schemaCheck = await AppDataSource.query(
      "SELECT nspname FROM pg_namespace WHERE nspname = $1 LIMIT 1",
      [result.schemaName],
    );
    if (!Array.isArray(schemaCheck) || schemaCheck.length === 0) {
      return { ok: false, status: 502, error: `Schema não encontrado após provisionamento: ${result.schemaName}` };
    }

    return {
      ok: true,
      schema_name: result.schemaName,
    };
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    return { ok: false, status: 502, error: message || "Erro ao provisionar schema do escritório." };
  }
}

export async function deleteEscritorio(escritorioId: string): Promise<DeleteEscritorioResult> {
  await ensureDatabase();

  const trimmedId = escritorioId.trim();
  if (!trimmedId) {
    return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
  }

  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  // Sem filtro `ativo`: permite re-executar o hard-delete de um escritório que
  // já foi soft-deletado (idempotência / limpeza de resíduos).
  const escritorio = await escritorioRepo.findOneBy({ id: trimmedId });
  if (!escritorio) {
    return { ok: false, status: 404, error: "Escritório não encontrado." };
  }

  const usuarioRepo = AppDataSource.getRepository(Usuario);
  // `find` traz também os já soft-deletados (coluna `deleted_at` é comum, não paranoid).
  const usuarios = await usuarioRepo.find({ where: { escritorio_id: trimmedId } });

  // Remove TODOS os usuários do Cognito (ativos + já soft-deletados). O username
  // do Cognito é o email; para soft-deletados o email pode ter sido mangled, então
  // também tentamos pelo cognito_sub como fallback. deleteCognitoUser é idempotente
  // em UserNotFoundException.
  for (const usuario of usuarios) {
    try {
      await deleteCognitoUser(usuario.email);
      if (usuario.cognito_sub) {
        await deleteCognitoUser(usuario.cognito_sub);
      }
    } catch (cognitoErr: unknown) {
      const message = cognitoErr instanceof Error ? cognitoErr.message : String(cognitoErr);
      return {
        ok: false,
        status: 502,
        error: `Falha ao remover usuário ${usuario.email} do Cognito: ${message}`,
      };
    }
  }

  const schemaName = buildEscritorioSchemaName(trimmedId);

  try {
    await AppDataSource.transaction(async (manager: EntityManager): Promise<void> => {
      // 1. Quebra a FK escritorios.ai_user_id → usuarios antes de apagar os usuários.
      await manager.getRepository(Escritorio).update(trimmedId, { ai_user_id: null });

      // 2. Purga dados identificáveis no schema public: sessões, OAuth e logs.
      //    Usage events agregáveis permanecem para auditoria financeira; não carregam corpo/prompt.
      //    Tokens antes de clients por causa da FK client_id.
      await manager.getRepository(Sessao).delete({ escritorio_id: trimmedId });
      await manager.getRepository(OAuthAccessToken).delete({ escritorio_id: trimmedId });
      await manager.getRepository(OAuthRefreshToken).delete({ escritorio_id: trimmedId });
      await manager.getRepository(OAuthAuthorizationCode).delete({ escritorio_id: trimmedId });
      await manager.getRepository(OAuthClient).delete({ escritorio_id: trimmedId });
      await manager.getRepository(Contexto).delete({ escritorio_id: trimmedId });
      await manager.getRepository(AgentLog).delete({ escritorio_id: trimmedId });
      await manager.getRepository(SolicitacaoPrivacidade).update(
        { escritorio_id: trimmedId },
        { escritorio_id: null, usuario_id: null },
      );

      // 3. Hard-delete de todos os usuários do escritório (ativos + soft-deletados).
      await manager.getRepository(Usuario).delete({ escritorio_id: trimmedId });

      // 4. Tombstone: mantém a linha do escritório, mas remove o PII (`nome`).
      await manager.getRepository(Escritorio).update(trimmedId, {
        ativo: false,
        nome: `[removido] ${trimmedId.slice(0, 8)}`,
      });

      // 5. Dropa o schema/role do tenant (CASCADE) — erradica os dados do tenant.
      await dropEscritorioSchema(manager, trimmedId);
    });

    return { ok: true, deletedUsuarios: usuarios.length, schemaDeleted: true, schemaName };
  } catch (dbErr: unknown) {
    const message = dbErr instanceof Error ? dbErr.message : String(dbErr);
    return { ok: false, status: 502, error: message };
  }
}

export type RunMigracoesResult =
  | { ok: true; schema_name: string; migrations_applied: boolean }
  | { ok: false; status: 400 | 404 | 502; error: string };

export async function runMigracoesEscritorio(escritorioId: string): Promise<RunMigracoesResult> {
  await ensureDatabase();

  const trimmedId = escritorioId.trim();
  if (!trimmedId) {
    return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
  }

  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  const escritorio = await escritorioRepo.findOneBy({ id: trimmedId, ativo: true });
  if (!escritorio) {
    return { ok: false, status: 404, error: "Escritório não encontrado." };
  }

  const schemaName = buildEscritorioSchemaName(trimmedId);
  const schemaRows = await AppDataSource.query(
    "SELECT nspname FROM pg_namespace WHERE nspname = $1 LIMIT 1",
    [schemaName],
  );
  if (!Array.isArray(schemaRows) || schemaRows.length === 0) {
    return { ok: false, status: 400, error: "Schema não provisionado. Provisione o schema antes de rodar migrações." };
  }

  try {
    const target = buildTenantPrivilegeTarget(trimmedId);
    await runTenantMigrations(schemaName);
    await reconcileTenantPrivileges(AppDataSource.manager as EntityManager, target);
    await revokePublicTablePrivilegesFromTenantRole(AppDataSource.manager as EntityManager, target.roleName);
    await grantTenantRoleToRuntimeRoles(AppDataSource.manager as EntityManager, target.roleName);
    return { ok: true, schema_name: schemaName, migrations_applied: true };
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    return { ok: false, status: 502, error: message || "Erro ao rodar migrações do escritório." };
  }
}
