// Barrel público do domínio de escritórios. A implementação foi decomposta por
// caso de uso em arquivos irmãos; este arquivo só re-exporta para preservar os
// import paths existentes (`from ".../escritorio.service.js"`).
//
// - escritorio-shared.ts       — tipos, mappers, redação de PII, paginação, status de schema
// - escritorio-core.ts         — ciclo de vida do escritório (list/create/update/provision/delete/migrate)
// - escritorio-usuarios.ts     — CRUD de usuários + bootstrap de admin
// - escritorio-observability.ts — listagem de contextos e agent logs (admin)
export * from "./escritorio-shared.js";
export * from "./escritorio-core.js";
export * from "./escritorio-usuarios.js";
export * from "./escritorio-observability.js";
