import { AppDataSource } from "../../database/data-source.js";
import { Contexto, type JsonValue } from "../../database/modules/public/entities/contexto.entity.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import { buildEscritorioSchemaName } from "../../database/tenant-naming.js";
import { AgentLogger } from "../../infrastructure/logging/agent.logger.js";

/** Trilha de auditoria de ações administrativas sobre usuários (persistida em agent_logs). */
export const adminAuditLogger = new AgentLogger("admin-usuarios");

export type EscritorioResumo = {
  id: string;
  nome: string;
  ativo: boolean;
  ambiente_teste_cobranca: boolean;
  contract_extraction_complexity: number;
  contract_agent_input_mode: "ocr" | "pdf";
  report_extraction_complexity: number;
  report_agent_input_mode: "ocr" | "pdf";
  report_agent_instructions: string | null;
  provedor_ia: "chatgpt" | "claude";
  locale: "pt" | "en";
  is_trial: boolean;
  trial_max_documentos: number;
  trial_max_cobranca_execucoes: number;
  trial_max_paginas_por_documento: number;
  trial_cobranca_execucoes_usadas: number;
  conector_drive_folder_id: string | null;
  conector_drive_ativo: boolean;
  schema_name: string;
  schema_status: "provisioned" | "missing";
  schema_version: string | null;
  schema_migration_name: string | null;
  schema_migration_timestamp: number | null;
  created_at: Date | string;
  updated_at: Date | string;
};

export type UsuarioResumo = {
  id: string;
  nome: string;
  email: string;
  cognito_sub: string | null;
  admin_escritorio: boolean;
  papel: "administrador" | "operador" | "consulta";
  ativo: boolean;
  escritorio_id: string;
  escritorio: {
    id: string;
    nome: string;
  } | null;
  created_at: Date | string;
  updated_at: Date | string;
};

export type CreateUsuarioInput = {
  nome: string;
  email: string;
  escritorio_id: string;
  admin_escritorio?: boolean;
  papel?: "administrador" | "operador" | "consulta";
};

export type CreateUsuarioResult =
  | { ok: true; usuario: UsuarioResumo }
  | { ok: false; status: 400 | 404 | 409 | 502; error: string };

export type ProvisionEscritorioSchemaResult =
  | { ok: true; schema_name: string }
  | { ok: false; status: 400 | 404 | 502; error: string };

export type DeleteUsuarioResult =
  | { ok: true }
  | { ok: false; status: 400 | 404 | 502; error: string };

export type UpdateUsuarioInput = {
  admin_escritorio?: boolean;
  papel?: "administrador" | "operador" | "consulta";
  escritorio_id?: string;
};

export type UpdateUsuarioResult =
  | { ok: true; usuario: UsuarioResumo }
  | { ok: false; status: 400 | 404; error: string };

export type DeleteEscritorioResult =
  | { ok: true; deletedUsuarios: number; schemaDeleted: boolean; schemaName: string }
  | { ok: false; status: 400 | 404 | 502; error: string };

export type ContextoResumo = {
  id: string;
  trace_id: string;
  escritorio_id: string | null;
  escritorio_nome: string | null;
  usuario_id: string | null;
  usuario_nome: string | null;
  usuario_email: string | null;
  sessao_id: string | null;
  rota: string;
  metodo: string;
  pagina: string | null;
  status_code: number | null;
  sucesso: boolean;
  latency_ms: number | null;
  request_payload: JsonValue | null;
  response_payload: JsonValue | null;
  error_payload: JsonValue | null;
  created_at: Date | string;
};

export type ListContextosInput = {
  page?: number;
  pageSize?: number;
  rota?: string;
  metodo?: string;
  sucesso?: boolean;
  status_code?: number;
  escritorio_id?: string;
  usuario_id?: string;
  trace_id?: string;
  date_from?: string;
  date_to?: string;
};

export type ListContextosResult = {
  data: ContextoResumo[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

export type AgentLogResumo = {
  id: string;
  escritorio_id: string;
  agent_name: string;
  level: string;
  event: string;
  context: Record<string, unknown> | null;
  prompt: string | null;
  status: string | null;
  execution_arn: string | null;
  trace_id: string | null;
  model_id: string | null;
  input_tokens: number | null;
  output_tokens: number | null;
  total_tokens: number | null;
  latency_ms: number | null;
  created_at: Date | string;
};

export type ListAgentLogsInput = {
  page?: number;
  pageSize?: number;
  agent_name?: string;
  level?: string;
  event?: string;
  status?: string;
  trace_id?: string;
  model_id?: string;
  escritorio_id?: string;
  date_from?: string;
  date_to?: string;
};

export type AgentLogAverages = {
  avg_input_tokens: number | null;
  avg_output_tokens: number | null;
  avg_total_tokens: number | null;
  avg_latency_ms: number | null;
};

export type ListAgentLogsResult = {
  data: AgentLogResumo[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  averages: AgentLogAverages;
};

export type CreateAdminUsuarioInput = {
  escritorio_id: string;
  email: string;
  nome?: string;
};

type TenantSchemaStatus = {
  schema_name: string;
  schema_status: "provisioned" | "missing";
  schema_version: string | null;
  schema_migration_name: string | null;
  schema_migration_timestamp: number | null;
};

function quoteIdentifier(value: string): string {
  return `"${value.replace(/"/g, '""')}"`;
}

export async function getTenantSchemaStatus(escritorioId: string): Promise<TenantSchemaStatus> {
  const schemaName = buildEscritorioSchemaName(escritorioId);
  const schemaExistsRows = await AppDataSource.query(
    "SELECT nspname FROM pg_namespace WHERE nspname = $1 LIMIT 1",
    [schemaName],
  );

  if (!Array.isArray(schemaExistsRows) || schemaExistsRows.length === 0) {
    return {
      schema_name: schemaName,
      schema_status: "missing",
      schema_version: null,
      schema_migration_name: null,
      schema_migration_timestamp: null,
    };
  }

  const migrationTableRows = await AppDataSource.query(
    `
      SELECT EXISTS (
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = $1
          AND table_name = '_tenant_migrations'
      ) AS exists
    `,
    [schemaName],
  );
  const hasMigrationTable = migrationTableRows?.[0]?.exists === true || migrationTableRows?.[0]?.exists === "true";

  if (!hasMigrationTable) {
    return {
      schema_name: schemaName,
      schema_status: "provisioned",
      schema_version: null,
      schema_migration_name: null,
      schema_migration_timestamp: null,
    };
  }

  const migrationRows = await AppDataSource.query(
    `
      SELECT timestamp, name
      FROM ${quoteIdentifier(schemaName)}."_tenant_migrations"
      ORDER BY timestamp DESC
      LIMIT 1
    `,
  );
  const lastMigration = Array.isArray(migrationRows) ? migrationRows[0] : null;
  const migrationTimestamp =
    lastMigration?.timestamp === undefined || lastMigration?.timestamp === null
      ? null
      : Number(lastMigration.timestamp);
  const migrationName = typeof lastMigration?.name === "string" ? lastMigration.name : null;

  return {
    schema_name: schemaName,
    schema_status: "provisioned",
    schema_version: migrationTimestamp && migrationName ? `${migrationTimestamp}-${migrationName}` : null,
    schema_migration_name: migrationName,
    schema_migration_timestamp: migrationTimestamp,
  };
}

export async function mapEscritorio(escritorio: Escritorio): Promise<EscritorioResumo> {
  const schema = await getTenantSchemaStatus(escritorio.id);
  return {
    id: escritorio.id,
    nome: escritorio.nome,
    ativo: escritorio.ativo,
    ambiente_teste_cobranca: escritorio.ambiente_teste_cobranca === true,
    contract_extraction_complexity: Number(escritorio.contract_extraction_complexity ?? 1),
    contract_agent_input_mode: escritorio.contract_agent_input_mode === "pdf" ? "pdf" : "ocr",
    report_extraction_complexity: Number(escritorio.report_extraction_complexity ?? 1),
    report_agent_input_mode: escritorio.report_agent_input_mode === "pdf" ? "pdf" : "ocr",
    report_agent_instructions: escritorio.report_agent_instructions?.trim() || null,
    provedor_ia: escritorio.provedor_ia === "claude" ? "claude" : "chatgpt",
    locale: escritorio.locale === "en" ? "en" : "pt",
    is_trial: escritorio.is_trial === true,
    trial_max_documentos: Number(escritorio.trial_max_documentos ?? 20),
    trial_max_cobranca_execucoes: Number(escritorio.trial_max_cobranca_execucoes ?? 20),
    trial_max_paginas_por_documento: Number(escritorio.trial_max_paginas_por_documento ?? 10),
    trial_cobranca_execucoes_usadas: Number(escritorio.trial_cobranca_execucoes_usadas ?? 0),
    conector_drive_folder_id: escritorio.conector_drive_folder_id ?? null,
    conector_drive_ativo: escritorio.conector_drive_ativo === true,
    ...schema,
    created_at: escritorio.created_at,
    updated_at: escritorio.updated_at,
  };
}

export function mapUsuario(usuario: Usuario): UsuarioResumo {
  return {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    cognito_sub: usuario.cognito_sub,
    admin_escritorio: usuario.admin_escritorio,
    papel: usuario.papel ?? (usuario.admin_escritorio ? "administrador" : "operador"),
    ativo: usuario.ativo,
    escritorio_id: usuario.escritorio_id,
    escritorio: usuario.escritorio
      ? {
          id: usuario.escritorio.id,
          nome: usuario.escritorio.nome,
        }
      : null,
    created_at: usuario.created_at,
    updated_at: usuario.updated_at,
  };
}

export function mapContexto(contexto: Contexto): ContextoResumo {
  return {
    id: contexto.id,
    trace_id: contexto.trace_id,
    escritorio_id: contexto.escritorio_id,
    escritorio_nome: contexto.escritorio?.nome ?? null,
    usuario_id: contexto.usuario_id,
    usuario_nome: contexto.usuario?.nome ?? null,
    usuario_email: contexto.usuario?.email ?? null,
    sessao_id: contexto.sessao_id,
    rota: contexto.rota,
    metodo: contexto.metodo,
    pagina: contexto.pagina,
    status_code: contexto.status_code,
    sucesso: contexto.sucesso,
    latency_ms: contexto.latency_ms,
    request_payload: redactAdminValue(contexto.request_payload) as JsonValue | null,
    response_payload: redactAdminValue(contexto.response_payload) as JsonValue | null,
    error_payload: redactAdminValue(contexto.error_payload) as JsonValue | null,
    created_at: contexto.created_at,
  };
}

export function redactAdminValue(value: unknown): unknown {
  if (value == null) return value;
  if (typeof value === "string") {
    if (/arn:aws:/i.test(value)) return "[redacted:aws-arn]";
    if (/s3:\/\/[^\s]+/i.test(value)) return "[redacted:s3-uri]";
    if (/bearer\s+[a-z0-9._-]+/i.test(value)) return "[redacted:token]";
    return value;
  }
  if (Array.isArray(value)) return value.map(redactAdminValue);
  if (typeof value === "object") {
    const redacted: Record<string, unknown> = {};
    for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
      redacted[key] = /password|senha|secret|token|cookie|authorization|api[_-]?key|prompt/i.test(key)
        ? "[redacted]"
        : redactAdminValue(nested);
    }
    return redacted;
  }
  return value;
}

export function clampPageSize(value: number | undefined): number {
  if (!value || Number.isNaN(value)) return 25;
  return Math.min(Math.max(Math.trunc(value), 10), 100);
}

export function normalizePage(value: number | undefined): number {
  if (!value || Number.isNaN(value)) return 1;
  return Math.max(Math.trunc(value), 1);
}
