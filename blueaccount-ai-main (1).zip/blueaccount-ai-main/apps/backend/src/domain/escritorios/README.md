# `src/domain/escritorios`

Esta pasta concentra a regra de negócio relacionada a escritórios e usuários administrativos.

## Responsabilidades

- ciclo de vida do escritório (listar, criar, atualizar flags/trial, provisionar schema, migrar, deletar)
- CRUD de usuários administrativos com integração ao Cognito
- observabilidade admin (contextos de request + agent logs) com redação de PII

## Arquivos

`escritorio.service.ts` é um **barrel** que re-exporta a implementação decomposta por caso de uso
(preserva os import paths existentes `from ".../escritorio.service.js"`):

- `escritorio-shared.ts` — tipos, mappers (`mapEscritorio`/`mapUsuario`/`mapContexto`), redação de PII (`redactAdminValue`), paginação e status de schema do tenant + `adminAuditLogger`
- `escritorio-core.ts` — `listEscritorios`, `createEscritorio`, `updateEscritorio`, `isEscritorioAmbienteTesteCobranca`, `provisionEscritorio`, `deleteEscritorio`, `runMigracoesEscritorio`
- `escritorio-usuarios.ts` — `createAdminUsuarioEscritorio`, `listUsuarios`, `createUsuario`, `deleteUsuario`
- `escritorio-observability.ts` — `listContextos`, `listAgentLogs`

`createEscritorio` cria novos escritórios com AgentCore + PDF-direto como padrão para contratos e
relatórios (`*_extraction_engine = "agent"` e `*_agent_input_mode = "pdf"`). Esse padrão não
altera escritórios existentes; o admin pode continuar selecionando `converse` e/ou `ocr` por
escritório para compatibilidade ou fallback.

Fora do barrel, dois arquivos leves resolvem a config de engine/modelo por escritório para o
trigger da SM de ingestão (usados por `modules/documentos/documentos.service.ts`, não puxam a
cadeia Cognito): `contract-extraction-config.ts` (`getEscritorioContractExtractionConfig`) e
`report-extraction-config.ts` (`getEscritorioReportExtractionConfig`). Ambos leem os campos
`*_extraction_engine`/`*_extraction_complexity` do escritório e resolvem `model_id` pela
tabela-catálogo compartilhada `contract_extraction_complexities`, com fallback seguro para
`{ engine: "converse", complexity: 1, model_id: null }` quando não há escritório ou a consulta
falha. `getEscritorioReportExtractionConfig` também retorna `inputMode: "ocr" | "pdf"` (lido de
`report_agent_input_mode`), usado pelo módulo de documentos para decidir se pode pular o OCR e
enviar o PDF/imagem direto ao agente de relatório (só quando `engine = "agent"` também está ativo).

A integração com Cognito passa por `domain/autenticacao` (que por sua vez usa
`infrastructure/security/cognito-auth.client.ts`); este domínio não fala AWS SDK direto.

## Testes

- `tests/escritorio.service.test.ts` (importa pelo barrel)
