import { AppDataSource } from "../../database/data-source.js";
import { Contexto } from "../../database/modules/public/entities/contexto.entity.js";
import { AgentLog } from "../../database/modules/public/entities/agent-log.entity.js";
import { AlertaAgentcore } from "../../database/modules/public/entities/alerta-agentcore.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import {
  clampPageSize,
  mapContexto,
  normalizePage,
  redactAdminValue,
  type ListAgentLogsInput,
  type ListAgentLogsResult,
  type ListContextosInput,
  type ListContextosResult,
} from "./escritorio-shared.js";

export async function listContextos(input: ListContextosInput = {}): Promise<ListContextosResult> {
  await ensureDatabase();

  const page = normalizePage(input.page);
  const pageSize = clampPageSize(input.pageSize);
  const repo = AppDataSource.getRepository(Contexto);
  const qb = repo
    .createQueryBuilder("contexto")
    .leftJoinAndSelect("contexto.escritorio", "escritorio")
    .leftJoinAndSelect("contexto.usuario", "usuario")
    .orderBy("contexto.created_at", "DESC")
    .skip((page - 1) * pageSize)
    .take(pageSize);

  if (input.rota?.trim()) {
    qb.andWhere("contexto.rota ILIKE :rota", { rota: `%${input.rota.trim()}%` });
  }

  if (input.metodo?.trim()) {
    qb.andWhere("contexto.metodo = :metodo", { metodo: input.metodo.trim().toUpperCase() });
  }

  if (typeof input.sucesso === "boolean") {
    qb.andWhere("contexto.sucesso = :sucesso", { sucesso: input.sucesso });
  }

  if (typeof input.status_code === "number" && !Number.isNaN(input.status_code)) {
    qb.andWhere("contexto.status_code = :status_code", { status_code: input.status_code });
  }

  if (input.escritorio_id?.trim()) {
    qb.andWhere("contexto.escritorio_id = :escritorio_id", { escritorio_id: input.escritorio_id.trim() });
  }

  if (input.usuario_id?.trim()) {
    qb.andWhere("contexto.usuario_id = :usuario_id", { usuario_id: input.usuario_id.trim() });
  }

  if (input.trace_id?.trim()) {
    qb.andWhere("contexto.trace_id ILIKE :trace_id", { trace_id: `%${input.trace_id.trim()}%` });
  }

  if (input.date_from?.trim()) {
    qb.andWhere("contexto.created_at >= :date_from", { date_from: input.date_from.trim() });
  }

  if (input.date_to?.trim()) {
    qb.andWhere("contexto.created_at <= :date_to", { date_to: input.date_to.trim() });
  }

  const [rows, total] = await qb.getManyAndCount();
  return {
    data: rows.map(mapContexto),
    total,
    page,
    pageSize,
    totalPages: Math.max(Math.ceil(total / pageSize), 1),
  };
}

export async function listAgentLogs(input: ListAgentLogsInput = {}): Promise<ListAgentLogsResult> {
  await ensureDatabase();

  const page = normalizePage(input.page);
  const pageSize = clampPageSize(input.pageSize);
  const repo = AppDataSource.getRepository(AgentLog);
  const qb = repo
    .createQueryBuilder("agent_log")
    .leftJoinAndSelect("agent_log.escritorio", "escritorio")
    .orderBy("agent_log.created_at", "DESC")
    .skip((page - 1) * pageSize)
    .take(pageSize);

  if (input.agent_name?.trim()) {
    qb.andWhere("agent_log.agent_name ILIKE :agent_name", { agent_name: `%${input.agent_name.trim()}%` });
  }

  if (input.level?.trim()) {
    qb.andWhere("agent_log.level = :level", { level: input.level.trim().toUpperCase() });
  }

  if (input.event?.trim()) {
    qb.andWhere("agent_log.event ILIKE :event", { event: `%${input.event.trim()}%` });
  }

  if (input.status?.trim()) {
    qb.andWhere("agent_log.status = :status", { status: input.status.trim() });
  }

  if (input.trace_id?.trim()) {
    qb.andWhere("agent_log.trace_id ILIKE :trace_id", { trace_id: `%${input.trace_id.trim()}%` });
  }

  if (input.model_id?.trim()) {
    qb.andWhere("agent_log.model_id ILIKE :model_id", { model_id: `%${input.model_id.trim()}%` });
  }

  if (input.escritorio_id?.trim()) {
    qb.andWhere("agent_log.escritorio_id = :escritorio_id", { escritorio_id: input.escritorio_id.trim() });
  }

  if (input.date_from?.trim()) {
    qb.andWhere("agent_log.created_at >= :date_from", { date_from: input.date_from.trim() });
  }

  if (input.date_to?.trim()) {
    qb.andWhere("agent_log.created_at <= :date_to", { date_to: input.date_to.trim() });
  }

  const [rows, total] = await qb.getManyAndCount();

  const avgQb = repo
    .createQueryBuilder("agent_log")
    .select("AVG(agent_log.input_tokens)", "avg_input_tokens")
    .addSelect("AVG(agent_log.output_tokens)", "avg_output_tokens")
    .addSelect("AVG(agent_log.total_tokens)", "avg_total_tokens")
    .addSelect("AVG(agent_log.latency_ms)", "avg_latency_ms");

  if (input.agent_name?.trim()) {
    avgQb.andWhere("agent_log.agent_name ILIKE :agent_name", { agent_name: `%${input.agent_name.trim()}%` });
  }
  if (input.level?.trim()) {
    avgQb.andWhere("agent_log.level = :level", { level: input.level.trim().toUpperCase() });
  }
  if (input.event?.trim()) {
    avgQb.andWhere("agent_log.event ILIKE :event", { event: `%${input.event.trim()}%` });
  }
  if (input.status?.trim()) {
    avgQb.andWhere("agent_log.status = :status", { status: input.status.trim() });
  }
  if (input.trace_id?.trim()) {
    avgQb.andWhere("agent_log.trace_id ILIKE :trace_id", { trace_id: `%${input.trace_id.trim()}%` });
  }
  if (input.model_id?.trim()) {
    avgQb.andWhere("agent_log.model_id ILIKE :model_id", { model_id: `%${input.model_id.trim()}%` });
  }
  if (input.escritorio_id?.trim()) {
    avgQb.andWhere("agent_log.escritorio_id = :escritorio_id", { escritorio_id: input.escritorio_id.trim() });
  }
  if (input.date_from?.trim()) {
    avgQb.andWhere("agent_log.created_at >= :date_from", { date_from: input.date_from.trim() });
  }
  if (input.date_to?.trim()) {
    avgQb.andWhere("agent_log.created_at <= :date_to", { date_to: input.date_to.trim() });
  }

  const avgRow = await avgQb.getRawOne<{
    avg_input_tokens: string | null;
    avg_output_tokens: string | null;
    avg_total_tokens: string | null;
    avg_latency_ms: string | null;
  }>();

  const round = (v: string | null) => v != null ? Math.round(Number(v)) : null;

  return {
    data: rows.map((log) => ({
      id: log.id,
      escritorio_id: log.escritorio_id,
      agent_name: log.agent_name,
      level: log.level,
      event: log.event,
      context: redactAdminValue(log.context) as Record<string, unknown> | null,
      prompt: log.prompt ? "[redacted]" : null,
      status: log.status,
      execution_arn: log.execution_arn ? "[redacted:aws-arn]" : null,
      trace_id: log.trace_id,
      model_id: log.model_id,
      input_tokens: log.input_tokens,
      output_tokens: log.output_tokens,
      total_tokens: log.total_tokens,
      latency_ms: log.latency_ms,
      created_at: log.created_at,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.max(Math.ceil(total / pageSize), 1),
    averages: {
      avg_input_tokens: round(avgRow?.avg_input_tokens ?? null),
      avg_output_tokens: round(avgRow?.avg_output_tokens ?? null),
      avg_total_tokens: round(avgRow?.avg_total_tokens ?? null),
      avg_latency_ms: round(avgRow?.avg_latency_ms ?? null),
    },
  };
}

export async function listAlertasAgentcore(input: { page?: number; pageSize?: number } = {}) {
  await ensureDatabase();
  const page = normalizePage(input.page);
  const pageSize = clampPageSize(input.pageSize);
  const [rows, total] = await AppDataSource.getRepository(AlertaAgentcore).findAndCount({
    order: { transition_at: "DESC" },
    skip: (page - 1) * pageSize,
    take: pageSize,
  });
  return {
    data: rows.map((row) => ({
      id: row.id,
      alarm_name: row.alarm_name,
      agent_name: row.agent_name,
      condicao: row.condicao,
      ambiente: row.ambiente,
      motivo: row.motivo,
      transition_at: row.transition_at,
      created_at: row.created_at,
    })),
    total,
    page,
    pageSize,
    totalPages: Math.max(Math.ceil(total / pageSize), 1),
  };
}
