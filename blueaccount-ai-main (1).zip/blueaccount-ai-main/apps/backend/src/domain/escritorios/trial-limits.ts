import { ForbiddenException } from "@nestjs/common";
import { AppDataSource, runQueryWithRls } from "../../database/data-source.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Documento } from "../../database/modules/tenant/entities/documento.entity.js";
import { AgentLogger } from "../../infrastructure/logging/agent.logger.js";

/**
 * Limites de contas trial por escritório (schema public, fora de RLS).
 *
 * `getTrialConfig` é fail-open: em erro de lookup ou escritório não-trial retorna
 * null (não pode quebrar upload/cobrança de cliente pagante). Já os `assert*`
 * lançam `TrialLimitError` (HTTP 403) quando um limite é excedido — como a
 * `TrialLimitError` estende `ForbiddenException`, o MulterExceptionFilter global
 * já a renderiza como 403 sem filtro novo.
 */

const log = new AgentLogger("trial-limits");

export interface TrialConfig {
  maxDocumentos: number;
  maxCobrancaExecucoes: number;
  maxPaginasPorDocumento: number;
  cobrancaExecucoesUsadas: number;
}

export type TrialLimitCode = "TRIAL_LIMIT_EXCEEDED" | "TRIAL_PAGE_LIMIT_EXCEEDED";

export class TrialLimitError extends ForbiddenException {
  constructor(
    message: string,
    meta?: { limit?: number; used?: number; code?: TrialLimitCode },
  ) {
    const { code = "TRIAL_LIMIT_EXCEEDED", ...rest } = meta ?? {};
    super({ error: message, code, ...rest });
  }
}

/** Lê a config de trial do escritório. null = não-trial ou erro (fail-open). */
export async function getTrialConfig(escritorioId: string): Promise<TrialConfig | null> {
  try {
    const escritorio = await AppDataSource.getRepository(Escritorio).findOne({
      where: { id: escritorioId },
      select: {
        id: true,
        is_trial: true,
        trial_max_documentos: true,
        trial_max_cobranca_execucoes: true,
        trial_max_paginas_por_documento: true,
        trial_cobranca_execucoes_usadas: true,
      },
    });
    if (!escritorio || escritorio.is_trial !== true) return null;
    return {
      maxDocumentos: Number(escritorio.trial_max_documentos),
      maxCobrancaExecucoes: Number(escritorio.trial_max_cobranca_execucoes),
      maxPaginasPorDocumento: Number(escritorio.trial_max_paginas_por_documento),
      cobrancaExecucoesUsadas: Number(escritorio.trial_cobranca_execucoes_usadas),
    };
  } catch (error: unknown) {
    log.warn("trial_config_lookup_failed", {
      escritorio_id: escritorioId,
      error: error instanceof Error ? error.message : String(error),
    });
    return null;
  }
}

/** Bloqueia o upload se o escritório trial já atingiu o teto de documentos. */
export async function assertTrialDocumentoQuota(escritorioId: string, cfg: TrialConfig): Promise<void> {
  const usados = await runQueryWithRls({ escritorio_id: escritorioId }, (manager) =>
    manager.getRepository(Documento).count({ where: { escritorio_id: escritorioId } }),
  );
  if (usados >= cfg.maxDocumentos) {
    throw new TrialLimitError(`Limite de documentos do trial atingido (${cfg.maxDocumentos}).`, {
      limit: cfg.maxDocumentos,
      used: usados,
    });
  }
}

/** Bloqueia documento com mais páginas que o permitido no trial. */
export function assertTrialPaginaLimite(cfg: TrialConfig, pageCount: number): void {
  if (pageCount > cfg.maxPaginasPorDocumento) {
    throw new TrialLimitError(
      `Documento excede o limite de ${cfg.maxPaginasPorDocumento} páginas do trial (${pageCount}).`,
      { limit: cfg.maxPaginasPorDocumento, used: pageCount, code: "TRIAL_PAGE_LIMIT_EXCEEDED" },
    );
  }
}

/** Reprocessamento de OCR é sempre bloqueado no trial. */
export function assertTrialReprocessamentoPermitido(_cfg: TrialConfig): void {
  throw new TrialLimitError("Reprocessamento de OCR não disponível em contas trial.");
}

/** Bloqueia nova execução de cobrança se o trial atingiu o teto. */
export function assertTrialCobrancaQuota(cfg: TrialConfig): void {
  if (cfg.cobrancaExecucoesUsadas >= cfg.maxCobrancaExecucoes) {
    throw new TrialLimitError(
      `Limite de execuções de cobrança do trial atingido (${cfg.maxCobrancaExecucoes}).`,
      { limit: cfg.maxCobrancaExecucoes, used: cfg.cobrancaExecucoesUsadas },
    );
  }
}

/** Incrementa (atômico) o contador de execuções de cobrança do trial. */
export async function incrementTrialCobrancaExecucao(escritorioId: string): Promise<void> {
  await AppDataSource.getRepository(Escritorio).increment(
    { id: escritorioId },
    "trial_cobranca_execucoes_usadas",
    1,
  );
}
