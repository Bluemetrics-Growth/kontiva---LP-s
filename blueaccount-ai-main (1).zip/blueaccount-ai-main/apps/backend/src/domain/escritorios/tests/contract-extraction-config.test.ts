import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const escritorioRepo = { findOne: vi.fn() };
  const complexityRepo = { findOne: vi.fn() };
  const AppDataSource = {
    isInitialized: true,
    initialize: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Escritorio") return escritorioRepo;
      if (entity?.name === "ContractExtractionComplexity") return complexityRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
  };

  return { escritorioRepo, complexityRepo, AppDataSource };
});

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: mocks.AppDataSource,
}));

import { getEscritorioContractExtractionConfig } from "../contract-extraction-config.js";

describe("getEscritorioContractExtractionConfig", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("usa OCR e nível padrão quando o escritório não possui configuração", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce({
      id: "escritorio-legado",
      contract_extraction_complexity: 1,
      contract_agent_input_mode: "ocr",
    });
    mocks.complexityRepo.findOne.mockResolvedValueOnce({ inference_profile_id: "" });

    await expect(getEscritorioContractExtractionConfig("escritorio-legado")).resolves.toEqual({
      complexity: 1,
      model_id: null,
      inputMode: "ocr",
    });
  });

  it("resolve agente com PDF-direto quando o escritório o configura", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce({
      id: "escritorio-agent",
      contract_extraction_complexity: 2,
      contract_agent_input_mode: "pdf",
    });
    mocks.complexityRepo.findOne.mockResolvedValueOnce({
      inference_profile_id: "arn:aws:bedrock:us-east-1:xxx:inference-profile/high-accuracy",
    });

    await expect(getEscritorioContractExtractionConfig("escritorio-agent")).resolves.toEqual({
      complexity: 2,
      model_id: "arn:aws:bedrock:us-east-1:xxx:inference-profile/high-accuracy",
      inputMode: "pdf",
    });
  });
});
