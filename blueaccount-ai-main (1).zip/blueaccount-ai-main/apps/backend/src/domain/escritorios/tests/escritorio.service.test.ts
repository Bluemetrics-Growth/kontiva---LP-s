import { beforeEach, describe, expect, it, vi } from "vitest";

const escritoriosMocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();
  const normalizeEmail = vi.fn((value: unknown) => (typeof value === "string" ? value.trim().toLowerCase() : null));
  const createCognitoUser = vi.fn();
  const deleteCognitoUser = vi.fn();
  const ensureAiUserForEscritorio = vi.fn();
  const createUsuario = vi.fn();
  const provisionEscritorioSchema = vi.fn();
  const dropEscritorioSchema = vi.fn();

  const purgeRepo = {
    delete: vi.fn(),
    update: vi.fn(),
  };

  const escritorioRepo = {
    find: vi.fn(),
    findOneBy: vi.fn(),
    create: vi.fn((value) => value),
    save: vi.fn(),
    delete: vi.fn(),
    update: vi.fn(),
  };
  const usuarioRepo = {
    find: vi.fn(),
    findOneBy: vi.fn(),
    create: vi.fn((value) => value),
    save: vi.fn(),
    delete: vi.fn(),
    update: vi.fn(),
  };
  const contextoQueryBuilder = {
    leftJoinAndSelect: vi.fn(),
    orderBy: vi.fn(),
    skip: vi.fn(),
    take: vi.fn(),
    andWhere: vi.fn(),
    getManyAndCount: vi.fn(),
  };
  const contextoRepo = {
    createQueryBuilder: vi.fn(() => contextoQueryBuilder),
  };
  const transactionQuery = vi.fn();

  const AppDataSource = {
    isInitialized: true,
    initialize: vi.fn(),
    manager: { query: vi.fn() },
    query: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Contexto") return contextoRepo;
      if (entity?.name === "Escritorio") return escritorioRepo;
      if (entity?.name === "Usuario") return usuarioRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
    transaction: vi.fn(),
  };

  return {
    ensureDatabase,
    normalizeEmail,
    createCognitoUser,
    deleteCognitoUser,
    ensureAiUserForEscritorio,
    createUsuario,
    provisionEscritorioSchema,
    dropEscritorioSchema,
    purgeRepo,
    escritorioRepo,
    usuarioRepo,
    contextoRepo,
    contextoQueryBuilder,
    AppDataSource,
    transactionQuery,
  };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: escritoriosMocks.ensureDatabase,
  normalizeEmail: escritoriosMocks.normalizeEmail,
  createCognitoUser: escritoriosMocks.createCognitoUser,
  deleteCognitoUser: escritoriosMocks.deleteCognitoUser,
  ensureAiUserForEscritorio: escritoriosMocks.ensureAiUserForEscritorio,
  createUsuario: escritoriosMocks.createUsuario,
}));

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: escritoriosMocks.AppDataSource,
}));

vi.mock("../../../database/escritorio-schema.js", () => ({
  provisionEscritorioSchema: escritoriosMocks.provisionEscritorioSchema,
  dropEscritorioSchema: escritoriosMocks.dropEscritorioSchema,
}));

  const {
  listEscritorios,
  createEscritorio,
  updateEscritorio,
  provisionEscritorio,
  createAdminUsuarioEscritorio,
  listContextos,
  listUsuarios,
  createUsuario,
  deleteEscritorio,
  deleteUsuario,
} = await import("../escritorio.service.js");

describe("escritorio service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    escritoriosMocks.provisionEscritorioSchema.mockResolvedValue({ schemaName: "escritorio_office_1" });
    escritoriosMocks.dropEscritorioSchema.mockResolvedValue({ schemaName: "escritorio_office_1" });
    escritoriosMocks.purgeRepo.delete.mockResolvedValue({ affected: 0 });
    escritoriosMocks.ensureAiUserForEscritorio.mockResolvedValue({ id: "ai-user-1" });
    escritoriosMocks.AppDataSource.query.mockResolvedValue([{ nspname: "escritorio_office_1" }]);
    escritoriosMocks.AppDataSource.transaction.mockImplementation(async (callback: (manager: { getRepository: (entity: { name?: string }) => unknown }) => Promise<unknown>) => {
      return callback({
        getRepository(entity: { name?: string }) {
          if (entity?.name === "Escritorio") return escritoriosMocks.escritorioRepo;
          if (entity?.name === "Usuario") return escritoriosMocks.usuarioRepo;
          if (
            entity?.name === "Sessao" ||
            entity?.name === "OAuthAccessToken" ||
            entity?.name === "OAuthRefreshToken" ||
            entity?.name === "OAuthAuthorizationCode" ||
            entity?.name === "OAuthClient" ||
            entity?.name === "Contexto" ||
            entity?.name === "AgentLog" ||
            entity?.name === "SolicitacaoPrivacidade"
          ) {
            return escritoriosMocks.purgeRepo;
          }
          throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
        },
        query: escritoriosMocks.transactionQuery,
      });
    });
    escritoriosMocks.contextoQueryBuilder.leftJoinAndSelect.mockReturnThis();
    escritoriosMocks.contextoQueryBuilder.orderBy.mockReturnThis();
    escritoriosMocks.contextoQueryBuilder.skip.mockReturnThis();
    escritoriosMocks.contextoQueryBuilder.take.mockReturnThis();
    escritoriosMocks.contextoQueryBuilder.andWhere.mockReturnThis();
    escritoriosMocks.contextoQueryBuilder.getManyAndCount.mockResolvedValue([[], 0]);
  });

  it("lists escritorios", async () => {
    escritoriosMocks.escritorioRepo.find.mockResolvedValue([
      { id: "office-1", nome: "Alpha", ativo: true, created_at: "c", updated_at: "u" },
    ]);

    const result = await listEscritorios();

    expect(escritoriosMocks.ensureDatabase).toHaveBeenCalledTimes(1);
    expect(escritoriosMocks.escritorioRepo.find).toHaveBeenCalledWith({
      where: { ativo: true },
      order: { nome: "ASC" },
    });
    expect(result).toEqual([
      {
        id: "office-1",
        nome: "Alpha",
        ativo: true,
        ambiente_teste_cobranca: false,
        contract_extraction_complexity: 1,
        contract_agent_input_mode: "ocr",
        report_extraction_complexity: 1,
        report_agent_input_mode: "ocr",
        report_agent_instructions: null,
        provedor_ia: "chatgpt",
        locale: "pt",
        is_trial: false,
        trial_max_documentos: 20,
        trial_max_cobranca_execucoes: 20,
        trial_max_paginas_por_documento: 10,
        trial_cobranca_execucoes_usadas: 0,
        conector_drive_folder_id: null,
        conector_drive_ativo: false,
        schema_name: "escritorio_office_1",
        schema_status: "provisioned",
        schema_version: null,
        schema_migration_name: null,
        schema_migration_timestamp: null,
        created_at: "c",
        updated_at: "u",
      },
    ]);
  });

  it("lists inactive escritorios when requested", async () => {
    escritoriosMocks.escritorioRepo.find.mockResolvedValue([
      { id: "office-1", nome: "Alpha", ativo: false, created_at: "c", updated_at: "u" },
    ]);

    const result = await listEscritorios({ includeInactive: true });

    expect(escritoriosMocks.escritorioRepo.find).toHaveBeenCalledWith({
      where: {},
      order: { nome: "ASC" },
    });
    expect(result[0]).toMatchObject({ id: "office-1", ativo: false });
  });

  it("returns tenant schema migration status when listing escritorios", async () => {
    escritoriosMocks.escritorioRepo.find.mockResolvedValue([
      { id: "office-1", nome: "Alpha", ativo: true, created_at: "c", updated_at: "u" },
    ]);
    escritoriosMocks.AppDataSource.query
      .mockResolvedValueOnce([{ nspname: "escritorio_office_1" }])
      .mockResolvedValueOnce([{ exists: true }])
      .mockResolvedValueOnce([{ timestamp: "1777400000000", name: "refactor_servicos_contratados" }]);

    const result = await listEscritorios();

    expect(result[0]).toMatchObject({
      schema_name: "escritorio_office_1",
      schema_status: "provisioned",
      schema_version: "1777400000000-refactor_servicos_contratados",
      schema_migration_name: "refactor_servicos_contratados",
      schema_migration_timestamp: 1777400000000,
    });
  });

  it("marks escritorio schema as missing when namespace does not exist", async () => {
    escritoriosMocks.escritorioRepo.find.mockResolvedValue([
      { id: "office-1", nome: "Alpha", ativo: true, created_at: "c", updated_at: "u" },
    ]);
    escritoriosMocks.AppDataSource.query.mockResolvedValueOnce([]);

    const result = await listEscritorios();

    expect(result[0]).toMatchObject({
      schema_name: "escritorio_office_1",
      schema_status: "missing",
      schema_version: null,
    });
  });

  it("creates an escritorio", async () => {
    escritoriosMocks.escritorioRepo.save.mockResolvedValue({
      id: "office-1",
      nome: "Alpha",
      ativo: true,
      contract_agent_input_mode: "pdf",
      report_agent_input_mode: "pdf",
      created_at: "c",
      updated_at: "u",
    });

    const result = await createEscritorio("  Alpha  ");

    expect(result).toEqual({
      id: "office-1",
      nome: "Alpha",
      ativo: true,
      ambiente_teste_cobranca: false,
      contract_extraction_complexity: 1,
      contract_agent_input_mode: "pdf",
      report_extraction_complexity: 1,
      report_agent_input_mode: "pdf",
      report_agent_instructions: null,
      provedor_ia: "chatgpt",
      locale: "pt",
      is_trial: false,
      trial_max_documentos: 20,
      trial_max_cobranca_execucoes: 20,
      trial_max_paginas_por_documento: 10,
      trial_cobranca_execucoes_usadas: 0,
      conector_drive_folder_id: null,
      conector_drive_ativo: false,
      schema_name: "escritorio_office_1",
      schema_status: "provisioned",
      schema_version: null,
      schema_migration_name: null,
      schema_migration_timestamp: null,
      created_at: "c",
      updated_at: "u",
    });
    expect(escritoriosMocks.AppDataSource.transaction).not.toHaveBeenCalled();
    expect(escritoriosMocks.escritorioRepo.save).toHaveBeenCalledWith({
      nome: "Alpha",
      contract_agent_input_mode: "pdf",
      report_agent_input_mode: "pdf",
    });
    expect(escritoriosMocks.ensureAiUserForEscritorio).toHaveBeenCalledWith({
      id: "office-1",
      nome: "Alpha",
      ativo: true,
      contract_agent_input_mode: "pdf",
      report_agent_input_mode: "pdf",
      created_at: "c",
      updated_at: "u",
    });
    expect(escritoriosMocks.provisionEscritorioSchema).not.toHaveBeenCalled();
  });

  it("updates escritorio lifecycle status", async () => {
    const existing = {
      id: "office-1",
      nome: "Alpha",
      ativo: true,
      created_at: "c",
      updated_at: "u",
    };
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue(existing);
    escritoriosMocks.escritorioRepo.save.mockResolvedValue({ ...existing, ativo: false });

    const result = await updateEscritorio("office-1", { ativo: false });

    expect(escritoriosMocks.escritorioRepo.findOneBy).toHaveBeenCalledWith({ id: "office-1" });
    expect(escritoriosMocks.escritorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({ ativo: false }));
    expect(result).toMatchObject({ ok: true, escritorio: { id: "office-1", ativo: false } });
  });

  it("updates provedor_ia", async () => {
    const existing = { id: "office-1", nome: "Alpha", ativo: true, provedor_ia: "chatgpt" };
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue(existing);
    escritoriosMocks.escritorioRepo.save.mockImplementation(async (value) => value);

    const result = await updateEscritorio("office-1", { provedor_ia: "claude" });

    expect(escritoriosMocks.escritorioRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ provedor_ia: "claude" }),
    );
    expect(result).toMatchObject({ ok: true, escritorio: { id: "office-1", provedor_ia: "claude" } });
  });

  it("rejeita provedor_ia inválido", async () => {
    const result = await updateEscritorio("office-1", { provedor_ia: "gemini" as "chatgpt" | "claude" });

    expect(result).toEqual({
      ok: false,
      status: 400,
      error: "provedor_ia deve ser 'chatgpt' ou 'claude'.",
    });
    expect(escritoriosMocks.escritorioRepo.findOneBy).not.toHaveBeenCalled();
  });

  it("normaliza e permite limpar instruções do Report Agent", async () => {
    const existing = { id: "office-1", nome: "Alpha", ativo: true };
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue(existing);
    escritoriosMocks.escritorioRepo.save.mockImplementation(async (value) => value);

    await updateEscritorio("office-1", { report_agent_instructions: "  Priorize receita recorrente.  " });
    expect(escritoriosMocks.escritorioRepo.save).toHaveBeenLastCalledWith(
      expect.objectContaining({ report_agent_instructions: "Priorize receita recorrente." }),
    );

    await updateEscritorio("office-1", { report_agent_instructions: "   " });
    expect(escritoriosMocks.escritorioRepo.save).toHaveBeenLastCalledWith(
      expect.objectContaining({ report_agent_instructions: null }),
    );
  });

  it("rejeita instruções do Report Agent acima de 8000 caracteres", async () => {
    const result = await updateEscritorio("office-1", { report_agent_instructions: "x".repeat(8001) });

    expect(result).toEqual({
      ok: false,
      status: 400,
      error: "report_agent_instructions deve ter no máximo 8000 caracteres.",
    });
    expect(escritoriosMocks.escritorioRepo.findOneBy).not.toHaveBeenCalled();
  });

  it("provisions escritorio schema", async () => {
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue({ id: "office-1", ativo: true });
    escritoriosMocks.provisionEscritorioSchema.mockResolvedValue({ schemaName: "escritorio_office_1" });

    const result = await provisionEscritorio("office-1");

    expect(result).toEqual({ ok: true, schema_name: "escritorio_office_1" });
    expect(escritoriosMocks.ensureAiUserForEscritorio).toHaveBeenCalledWith({ id: "office-1", ativo: true });
    expect(escritoriosMocks.provisionEscritorioSchema).toHaveBeenCalledTimes(1);
  });

  it("creates admin user for an escritorio", async () => {
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue({ id: "office-1" });
    escritoriosMocks.usuarioRepo.findOneBy.mockResolvedValue(null);
    escritoriosMocks.createCognitoUser.mockResolvedValue("sub-1");
    escritoriosMocks.usuarioRepo.save.mockResolvedValue({
      id: "user-1",
      nome: "Administrador",
      email: "admin@example.com",
      cognito_sub: "sub-1",
      admin_escritorio: true,
      ativo: true,
      escritorio_id: "office-1",
      escritorio: { id: "office-1", nome: "Alpha" },
      created_at: "c2",
      updated_at: "u2",
    });

    const result = await createAdminUsuarioEscritorio({
      escritorio_id: "office-1",
      email: "ADMIN@EXAMPLE.COM",
    });

    expect(result).toEqual({
      ok: true,
      usuario: {
        id: "user-1",
        nome: "Administrador",
        email: "admin@example.com",
        cognito_sub: "sub-1",
        admin_escritorio: true,
        papel: "administrador",
        ativo: true,
        escritorio_id: "office-1",
        escritorio: { id: "office-1", nome: "Alpha" },
        created_at: "c2",
        updated_at: "u2",
      },
    });
    expect(escritoriosMocks.createCognitoUser).toHaveBeenCalledWith("admin@example.com");
    expect(escritoriosMocks.usuarioRepo.save).toHaveBeenCalledWith({
      nome: "Administrador",
      email: "admin@example.com",
      cognito_sub: "sub-1",
      escritorio_id: "office-1",
      admin_escritorio: true,
      papel: "administrador",
    });
  });

  it("lists usuarios with escritorio details", async () => {
    escritoriosMocks.usuarioRepo.find.mockResolvedValue([
      {
        id: "user-1",
        nome: "Maria",
        email: "maria@example.com",
        cognito_sub: "sub-1",
        admin_escritorio: false,
        papel: "operador",
        ativo: true,
        escritorio_id: "office-1",
        escritorio: { id: "office-1", nome: "Alpha" },
        created_at: "c",
        updated_at: "u",
      },
    ]);

    const result = await listUsuarios();

    expect(result).toEqual([
      {
        id: "user-1",
        nome: "Maria",
        email: "maria@example.com",
        cognito_sub: "sub-1",
        admin_escritorio: false,
        papel: "operador",
        ativo: true,
        escritorio_id: "office-1",
        escritorio: { id: "office-1", nome: "Alpha" },
        created_at: "c",
        updated_at: "u",
      },
    ]);
  });

  it("lists contexto audit entries with filters and pagination", async () => {
    escritoriosMocks.contextoQueryBuilder.getManyAndCount.mockResolvedValue([
      [
        {
          id: "ctx-1",
          trace_id: "trace-1",
          escritorio_id: "office-1",
          escritorio: { nome: "Alpha" },
          usuario_id: "user-1",
          usuario: { nome: "Maria", email: "maria@example.com" },
          sessao_id: "session-1",
          rota: "/api/clientes",
          metodo: "GET",
          pagina: "clientes",
          status_code: 200,
          sucesso: true,
          latency_ms: 42,
          request_payload: { query: { a: "b" } },
          response_payload: { ok: true },
          error_payload: null,
          created_at: "2026-04-30T12:00:00.000Z",
        },
      ],
      1,
    ]);

    const result = await listContextos({
      page: 2,
      pageSize: 10,
      rota: "clientes",
      metodo: "get",
      sucesso: true,
      trace_id: "trace",
    });

    expect(escritoriosMocks.contextoRepo.createQueryBuilder).toHaveBeenCalledWith("contexto");
    expect(escritoriosMocks.contextoQueryBuilder.skip).toHaveBeenCalledWith(10);
    expect(escritoriosMocks.contextoQueryBuilder.take).toHaveBeenCalledWith(10);
    expect(escritoriosMocks.contextoQueryBuilder.andWhere).toHaveBeenCalledWith("contexto.rota ILIKE :rota", {
      rota: "%clientes%",
    });
    expect(result).toEqual({
      data: [
        expect.objectContaining({
          id: "ctx-1",
          escritorio_nome: "Alpha",
          usuario_nome: "Maria",
          usuario_email: "maria@example.com",
          rota: "/api/clientes",
        }),
      ],
      total: 1,
      page: 2,
      pageSize: 10,
      totalPages: 1,
    });
  });

  it("creates a usuario and rolls back Cognito on db failure", async () => {
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue({ id: "office-1" });
    escritoriosMocks.usuarioRepo.findOneBy.mockResolvedValue(null);
    escritoriosMocks.createCognitoUser.mockResolvedValue("sub-1");
    escritoriosMocks.usuarioRepo.save.mockRejectedValue(new Error("db down"));

    const result = await createUsuario({
      nome: "Maria",
      email: "MARIA@EXAMPLE.COM",
      escritorio_id: "office-1",
    });

    expect(result).toEqual({ ok: false, status: 502, error: "db down" });
    expect(escritoriosMocks.normalizeEmail).toHaveBeenCalledWith("MARIA@EXAMPLE.COM");
    expect(escritoriosMocks.createCognitoUser).toHaveBeenCalledWith("maria@example.com");
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("maria@example.com");
  });

  it("soft deletes usuario after removing from Cognito", async () => {
    escritoriosMocks.usuarioRepo.findOneBy.mockResolvedValue({
      id: "user-1",
      email: "maria@example.com",
    });
    escritoriosMocks.deleteCognitoUser.mockResolvedValue(undefined);
    escritoriosMocks.usuarioRepo.update.mockResolvedValue({
      affected: 1,
      raw: [],
      generatedMaps: [],
    });

    const result = await deleteUsuario("user-1");

    expect(result).toEqual({ ok: true });
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("maria@example.com");
    expect(escritoriosMocks.usuarioRepo.update).toHaveBeenCalledWith(
      "user-1",
      expect.objectContaining({
        deleted_at: expect.any(Date),
        email: expect.stringMatching(/^maria@example\.com_[0-9a-f]{5}$/),
      }),
    );
  });

  it("returns 404 when deleting a missing usuario", async () => {
    escritoriosMocks.usuarioRepo.findOneBy.mockResolvedValue(null);

    const result = await deleteUsuario("missing");

    expect(result).toEqual({
      ok: false,
      status: 404,
      error: "Usuário não encontrado.",
    });
    expect(escritoriosMocks.deleteCognitoUser).not.toHaveBeenCalled();
  });

  it("returns provider error when Cognito deletion fails", async () => {
    escritoriosMocks.usuarioRepo.findOneBy.mockResolvedValue({
      id: "user-1",
      email: "maria@example.com",
    });
    escritoriosMocks.deleteCognitoUser.mockRejectedValue(new Error("provider unavailable"));

    const result = await deleteUsuario("user-1");

    expect(result).toEqual({
      ok: false,
      status: 502,
      error: "Falha ao remover usuário do Cognito: provider unavailable",
    });
    expect(escritoriosMocks.usuarioRepo.update).not.toHaveBeenCalled();
  });

  it("hard-deletes an escritorio: purges users + Cognito + public data and drops the tenant schema, keeping a scrubbed tombstone", async () => {
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue({ id: "office-1", nome: "Alpha" });
    escritoriosMocks.usuarioRepo.find.mockResolvedValue([
      { id: "user-1", email: "admin@example.com", cognito_sub: "sub-1", deleted_at: null },
      { id: "user-2", email: "old@example.com_ab12c", cognito_sub: "sub-2", deleted_at: "2026-04-01" },
    ]);
    escritoriosMocks.deleteCognitoUser.mockResolvedValue(undefined);
    escritoriosMocks.usuarioRepo.delete.mockResolvedValue({ affected: 2 });
    escritoriosMocks.escritorioRepo.update.mockResolvedValue({ affected: 1 });

    const result = await deleteEscritorio("office-1");

    expect(result).toEqual({
      ok: true,
      deletedUsuarios: 2,
      schemaDeleted: true,
      schemaName: "escritorio_office_1",
    });
    // Todos os usuários (ativos + soft-deletados) saem do Cognito, por email e por sub.
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("admin@example.com");
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("sub-1");
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("old@example.com_ab12c");
    expect(escritoriosMocks.deleteCognitoUser).toHaveBeenCalledWith("sub-2");
    expect(escritoriosMocks.usuarioRepo.delete).toHaveBeenCalledWith({ escritorio_id: "office-1" });
    // Sessões + OAuth + logs identificáveis purgados.
    expect(escritoriosMocks.purgeRepo.delete).toHaveBeenCalledWith({ escritorio_id: "office-1" });
    expect(escritoriosMocks.purgeRepo.delete).toHaveBeenCalledTimes(7);
    expect(escritoriosMocks.purgeRepo.update).toHaveBeenCalledWith(
      { escritorio_id: "office-1" },
      { escritorio_id: null, usuario_id: null },
    );
    // FK ai_user_id zerada antes de apagar usuários; tombstone com nome scrubbed.
    expect(escritoriosMocks.escritorioRepo.update).toHaveBeenCalledWith("office-1", { ai_user_id: null });
    expect(escritoriosMocks.escritorioRepo.update).toHaveBeenCalledWith("office-1", {
      ativo: false,
      nome: "[removido] office-1",
    });
    // Schema do tenant dropado.
    expect(escritoriosMocks.dropEscritorioSchema).toHaveBeenCalledTimes(1);
    expect(escritoriosMocks.escritorioRepo.delete).not.toHaveBeenCalled();
    expect(escritoriosMocks.provisionEscritorioSchema).not.toHaveBeenCalled();
  });

  it("returns 404 when deleting a missing escritorio", async () => {
    escritoriosMocks.escritorioRepo.findOneBy.mockResolvedValue(null);

    const result = await deleteEscritorio("missing");

    expect(result).toEqual({
      ok: false,
      status: 404,
      error: "Escritório não encontrado.",
    });
    expect(escritoriosMocks.usuarioRepo.find).not.toHaveBeenCalled();
  });
});
