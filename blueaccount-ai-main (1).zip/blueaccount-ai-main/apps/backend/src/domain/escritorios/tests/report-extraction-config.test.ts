import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const escritorioRepo = {
    findOne: vi.fn(),
  };
  const complexityRepo = {
    findOne: vi.fn(),
  };

  const AppDataSource = {
    isInitialized: true,
    initialize: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Escritorio") return escritorioRepo;
      if (entity?.name === "ContractExtractionComplexity") return complexityRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
  };

  return { escritorioRepo, complexityRepo, AppDataSource };
});

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: mocks.AppDataSource,
}));

import { getEscritorioReportExtractionConfig } from "../report-extraction-config.js";

describe("getEscritorioReportExtractionConfig", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("retorna nível 1 e OCR quando o escritório não configurou nada", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce(null);
    mocks.complexityRepo.findOne
      .mockResolvedValueOnce(null) // busca por nivel=1
      .mockResolvedValueOnce({ inference_profile_id: null }); // fallback nivel mais baixo ativo

    const result = await getEscritorioReportExtractionConfig("escritorio-1");

    expect(result).toEqual({ complexity: 1, model_id: null, inputMode: "ocr", instructions: null });
  });

  it("retorna o model_id do catálogo quando o escritório está configurado", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce({
      id: "escritorio-1",
      report_extraction_complexity: 2,
      report_agent_instructions: "  Priorize receitas recorrentes.  ",
    });
    mocks.complexityRepo.findOne.mockResolvedValueOnce({
      inference_profile_id: "arn:aws:bedrock:us-east-1:xxx:inference-profile/high-accuracy",
    });

    const result = await getEscritorioReportExtractionConfig("escritorio-1");

    expect(result).toEqual({
      complexity: 2,
      model_id: "arn:aws:bedrock:us-east-1:xxx:inference-profile/high-accuracy",
      inputMode: "ocr",
      instructions: "Priorize receitas recorrentes.",
    });
    expect(mocks.complexityRepo.findOne).toHaveBeenCalledWith({
      where: { nivel: 2, ativo: true },
    });
  });

  it("preserva a configuração explícita de OCR", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce({
      id: "escritorio-legado",
      report_extraction_complexity: 1,
      report_agent_input_mode: "ocr",
    });
    mocks.complexityRepo.findOne.mockResolvedValueOnce({ inference_profile_id: "" });

    await expect(getEscritorioReportExtractionConfig("escritorio-legado")).resolves.toEqual({
      complexity: 1,
      model_id: null,
      inputMode: "ocr",
      instructions: null,
    });
  });

  it("nunca lança e cai no default seguro quando a consulta falha", async () => {
    mocks.escritorioRepo.findOne.mockRejectedValueOnce(new Error("db offline"));

    const result = await getEscritorioReportExtractionConfig("escritorio-1");

    expect(result).toEqual({ complexity: 1, model_id: null, inputMode: "ocr", instructions: null });
  });

  it("retorna inputMode 'pdf' quando o escritório optou por enviar PDF direto ao agente", async () => {
    mocks.escritorioRepo.findOne.mockResolvedValueOnce({
      id: "escritorio-1",
      report_extraction_complexity: 1,
      report_agent_input_mode: "pdf",
    });
    mocks.complexityRepo.findOne.mockResolvedValueOnce({ inference_profile_id: "" });

    const result = await getEscritorioReportExtractionConfig("escritorio-1");

    expect(result).toEqual({
      complexity: 1,
      model_id: null,
      inputMode: "pdf",
      instructions: null,
    });
  });
});
