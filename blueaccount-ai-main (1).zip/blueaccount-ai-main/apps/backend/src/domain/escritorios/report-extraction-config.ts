import { AppDataSource } from "../../database/data-source.js";
import { ContractExtractionComplexity } from "../../database/modules/public/entities/contract-extraction-complexity.entity.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";

/**
 * Lê — fora de RLS, schema public — a complexidade e o modo de input do agente
 * escritório, para o trigger passar como argumento à SM de orquestração de
 * relatórios. Espelha `getEscritorioContractExtractionConfig`, reaproveitando
 * o mesmo catálogo `contract_extraction_complexities` (compartilhado entre
 * contratos e relatórios → `inference_profile_id`). `"ocr"` mantém o Textract;
 * `"pdf"` envia o documento diretamente ao AgentCore (o chamador ainda
 * precisa validar mime/tamanho antes de usar). NUNCA lança: na ausência/erro,
 * assume o default seguro (nível 1, `inputMode: "ocr"`).
 *
 * Módulo leve de propósito: só depende de AppDataSource + Escritorio, sem puxar
 * a cadeia pesada (Cognito etc.) de `escritorio.service.ts`.
 */
export async function getEscritorioReportExtractionConfig(
  escritorioId: string,
): Promise<{
  complexity: number;
  model_id: string | null;
  inputMode: "ocr" | "pdf";
  instructions: string | null;
}> {
  try {
    if (!AppDataSource.isInitialized) await AppDataSource.initialize();
    const escritorio = await AppDataSource.getRepository(Escritorio).findOne({
      where: { id: escritorioId },
      select: {
        id: true,
        report_extraction_complexity: true,
        report_agent_input_mode: true,
        report_agent_instructions: true,
      },
    });
    const complexity = Number(escritorio?.report_extraction_complexity ?? 1);
    const complexityRepo = AppDataSource.getRepository(ContractExtractionComplexity);
    const configuredComplexity =
      (await complexityRepo.findOne({ where: { nivel: complexity, ativo: true } })) ??
      (await complexityRepo.findOne({ where: { ativo: true }, order: { nivel: "ASC" } }));
    return {
      complexity,
      model_id: configuredComplexity?.inference_profile_id?.trim() || null,
      inputMode: escritorio?.report_agent_input_mode === "pdf" ? "pdf" : "ocr",
      instructions: escritorio?.report_agent_instructions?.trim() || null,
    };
  } catch {
    return { complexity: 1, model_id: null, inputMode: "ocr", instructions: null };
  }
}
