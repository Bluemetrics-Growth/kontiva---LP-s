import { randomUUID } from "node:crypto";
import { AppDataSource } from "../../database/data-source.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";
import type { EntityManager } from "typeorm";
import { IsNull } from "typeorm";
import {
  createCognitoUser,
  deleteCognitoUser,
  ensureDatabase,
  normalizeEmail,
} from "../autenticacao/autenticacao.service.js";
import {
  adminAuditLogger,
  mapUsuario,
  type CreateAdminUsuarioInput,
  type CreateUsuarioInput,
  type CreateUsuarioResult,
  type DeleteUsuarioResult,
  type UpdateUsuarioInput,
  type UpdateUsuarioResult,
  type UsuarioResumo,
} from "./escritorio-shared.js";

export async function createAdminUsuarioEscritorio(
  input: CreateAdminUsuarioInput,
): Promise<CreateUsuarioResult> {
  const escritorioId = input.escritorio_id.trim();
  const email = normalizeEmail(input.email);
  const nome = (input.nome ?? "Administrador").trim() || "Administrador";

  if (!escritorioId) {
    return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
  }

  if (!email) {
    return { ok: false, status: 400, error: "E-mail inválido." };
  }

  return await createUsuario({
    nome,
    email,
    escritorio_id: escritorioId,
    admin_escritorio: true,
    papel: "administrador",
  });
}

export async function listUsuarios(): Promise<UsuarioResumo[]> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(Usuario);
  const usuarios = await repo.find({
    relations: ["escritorio"],
    where: { deleted_at: IsNull() },
    order: { nome: "ASC" },
  });

  return usuarios.map(mapUsuario);
}

export async function createUsuario(input: CreateUsuarioInput): Promise<CreateUsuarioResult> {
  await ensureDatabase();

  const nome = input.nome.trim();
  const email = normalizeEmail(input.email);
  const escritorioId = input.escritorio_id.trim();
  const papel = input.papel ?? (input.admin_escritorio ? "administrador" : "operador");

  if (!["administrador", "operador", "consulta"].includes(papel)) {
    return { ok: false, status: 400, error: "Papel de usuário inválido." };
  }

  if (!email) {
    return { ok: false, status: 400, error: "E-mail inválido." };
  }

  const escritorioRepo = AppDataSource.getRepository(Escritorio);
  const escritorio = await escritorioRepo.findOneBy({ id: escritorioId, ativo: true });

  if (!escritorio) {
    return { ok: false, status: 404, error: "Escritório não encontrado." };
  }

  const usuarioRepo = AppDataSource.getRepository(Usuario);
  const existingEmail = await usuarioRepo.findOneBy({ email });
  if (existingEmail) {
    return { ok: false, status: 409, error: "Já existe um usuário cadastrado com este e-mail." };
  }

  let cognitoSub: string | null = null;
  try {
    cognitoSub = await createCognitoUser(email);
  } catch (cognitoErr: unknown) {
    const errorName = cognitoErr && typeof cognitoErr === "object" && "name" in cognitoErr
      ? String((cognitoErr as { name?: unknown }).name)
      : "";
    const message = cognitoErr instanceof Error ? cognitoErr.message : String(cognitoErr);
    if (errorName === "UsernameExistsException") {
      return { ok: false, status: 409, error: "Já existe um usuário no Cognito com este e-mail." };
    }
    return { ok: false, status: 502, error: `Falha ao criar usuário no Cognito: ${message}` };
  }

  try {
    const saved = await AppDataSource.transaction(async (manager: EntityManager): Promise<Usuario> => {
      const repo = manager.getRepository(Usuario);
      const usuario = repo.create({
        nome,
        email,
        cognito_sub: cognitoSub,
        escritorio_id: escritorio.id,
        admin_escritorio: papel === "administrador",
        papel,
      });
      return await repo.save(usuario);
    });

    adminAuditLogger.info("usuario_criado", {
      escritorio_id: escritorio.id,
      usuario_id: saved.id,
      admin_escritorio: saved.admin_escritorio,
      papel: saved.papel,
    });

    return { ok: true, usuario: mapUsuario(saved) };
  } catch (dbErr: unknown) {
    try {
      await deleteCognitoUser(email);
    } catch (rollbackErr) {
      console.error("Falha ao remover usuário do Cognito após erro no banco:", rollbackErr);
    }

    const message = dbErr instanceof Error ? dbErr.message : String(dbErr);
    return { ok: false, status: 502, error: message };
  }
}

export async function updateUsuario(
  usuarioId: string,
  input: UpdateUsuarioInput,
): Promise<UpdateUsuarioResult> {
  await ensureDatabase();

  const trimmedId = usuarioId.trim();
  if (!trimmedId) {
    return { ok: false, status: 400, error: "O campo 'usuarioId' é obrigatório." };
  }

  const usuarioRepo = AppDataSource.getRepository(Usuario);
  const usuario = await usuarioRepo.findOne({ where: { id: trimmedId, deleted_at: IsNull() }, relations: ["escritorio"] });
  if (!usuario) {
    return { ok: false, status: 404, error: "Usuário não encontrado." };
  }

  const patch: Partial<Usuario> = {};

  if (input.escritorio_id !== undefined) {
    const escritorioId = input.escritorio_id.trim();
    if (!escritorioId) {
      return { ok: false, status: 400, error: "O campo 'escritorio_id' é obrigatório." };
    }
    const escritorioRepo = AppDataSource.getRepository(Escritorio);
    const escritorio = await escritorioRepo.findOneBy({ id: escritorioId });
    if (!escritorio) {
      return { ok: false, status: 404, error: "Escritório não encontrado." };
    }
    patch.escritorio_id = escritorio.id;
  }

  if (input.admin_escritorio !== undefined) {
    patch.admin_escritorio = input.admin_escritorio;
    patch.papel = input.admin_escritorio ? "administrador" : "operador";
  }

  if (input.papel !== undefined) {
    if (!["administrador", "operador", "consulta"].includes(input.papel)) {
      return { ok: false, status: 400, error: "Papel de usuário inválido." };
    }
    patch.papel = input.papel;
    patch.admin_escritorio = input.papel === "administrador";
  }

  if (Object.keys(patch).length === 0) {
    return { ok: true, usuario: mapUsuario(usuario) };
  }

  await usuarioRepo.update(trimmedId, patch);
  const atualizado = await usuarioRepo.findOne({ where: { id: trimmedId }, relations: ["escritorio"] });

  adminAuditLogger.info("usuario_atualizado", {
    escritorio_id: atualizado?.escritorio_id ?? usuario.escritorio_id,
    usuario_id: trimmedId,
    ...patch,
  });

  return { ok: true, usuario: mapUsuario(atualizado ?? usuario) };
}

export async function deleteUsuario(usuarioId: string): Promise<DeleteUsuarioResult> {
  await ensureDatabase();

  const trimmedId = usuarioId.trim();
  if (!trimmedId) {
    return { ok: false, status: 400, error: "O campo 'usuarioId' é obrigatório." };
  }

  const usuarioRepo = AppDataSource.getRepository(Usuario);
  const usuario = await usuarioRepo.findOneBy({ id: trimmedId });
  if (!usuario) {
    return { ok: false, status: 404, error: "Usuário não encontrado." };
  }

  try {
    await deleteCognitoUser(usuario.email);
  } catch (cognitoErr: unknown) {
    const message = cognitoErr instanceof Error ? cognitoErr.message : String(cognitoErr);
    return { ok: false, status: 502, error: `Falha ao remover usuário do Cognito: ${message}` };
  }

  try {
    await AppDataSource.transaction(async (manager: EntityManager): Promise<void> => {
      const repo = manager.getRepository(Usuario);
      await repo.update(trimmedId, {
        deleted_at: new Date(),
        email: `${usuario.email}_${randomUUID().replace(/-/g, "").slice(0, 5)}`,
      });
    });

    adminAuditLogger.info("usuario_removido", {
      escritorio_id: usuario.escritorio_id,
      usuario_id: usuario.id,
    });

    return { ok: true };
  } catch (dbErr: unknown) {
    const message = dbErr instanceof Error ? dbErr.message : String(dbErr);
    return { ok: false, status: 502, error: message };
  }
}
