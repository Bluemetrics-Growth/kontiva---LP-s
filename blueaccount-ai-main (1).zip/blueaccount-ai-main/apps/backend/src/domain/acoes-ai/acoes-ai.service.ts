import { runQueryWithRls } from "../../database/data-source.js";
import { AcaoAi, type StatusAcaoAi, type TipoAcaoAi, type PrioridadeAcaoAi, type SubAcaoAi, type OrigemAcaoAi } from "../../database/modules/tenant/entities/acao-ai.entity.js";
import { HistoricoAcaoAi } from "../../database/modules/tenant/entities/historico-acao-ai.entity.js";
import { ValoresACobrar } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import { In, LessThan, Between, type EntityManager } from "typeorm";
import { buildPaginatedResult, normalizePagination } from "../pagination.js";
import { resolveOrCreateSistemaAgente } from "../agentes/agentes.service.js";

export type HistoricoAcaoAiEntry = {
  id: string;
  acao_id: string;
  status: string;
  resultado: string | null;
  created_at: Date;
};

export type AcaoAiComHistorico = AcaoAi & { historico: HistoricoAcaoAiEntry[] };

export type AcaoAiCreateInput = {
  agente_id: string;
  cliente_id?: string | null;
  titulo?: string | null;
  descricao?: string | null;
  tipo_acao?: TipoAcaoAi | null;
  prioridade?: PrioridadeAcaoAi;
  status?: StatusAcaoAi;
  origem: OrigemAcaoAi;
  payload?: Record<string, unknown> | null;
  acoes?: SubAcaoAi[] | null;
  s3_output_path?: string | null;
};

export type AcaoAiListFilters = {
  status?: StatusAcaoAi;
  cliente_id?: string;
  prioridade?: PrioridadeAcaoAi;
  created_at_mes?: string;
  limit?: number;
  offset?: number;
};

// ── CRUD ────────────────────────────────────────────────────────────────────

export async function listAcoesAi(escritorioId: string, filters: AcaoAiListFilters = {}): Promise<AcaoAi[]> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const where: Record<string, unknown> = {};
    if (filters.status) where.status = filters.status;
    if (filters.cliente_id) where.cliente_id = filters.cliente_id;
    if (filters.prioridade) where.prioridade = filters.prioridade;

    if (filters.created_at_mes) {
      const [ano, mes] = filters.created_at_mes.split("-");
      if (ano && mes) {
        const year = Number(ano);
        const month = Number(mes);
        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59, 999);
        where.created_at = Between(startDate, endDate);
      }
    }

    return manager.find(AcaoAi, {
      where,
      order: { created_at: "DESC" },
      take: filters.limit ?? 50,
      skip: filters.offset ?? 0,
    });
  });
}

export async function listAcoesAiPaginated(
  escritorioId: string,
  filters: AcaoAiListFilters & { page?: number; pageSize?: number } = {},
) {
  await ensureDatabase();
  const { page, pageSize, skip } = normalizePagination(filters);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const where: Record<string, unknown> = {};
    if (filters.status) where.status = filters.status;
    if (filters.cliente_id) where.cliente_id = filters.cliente_id;
    if (filters.prioridade) where.prioridade = filters.prioridade;
    if (filters.created_at_mes) {
      const [ano, mes] = filters.created_at_mes.split("-");
      const year = Number(ano);
      const month = Number(mes);
      if (Number.isFinite(year) && Number.isFinite(month)) {
        where.created_at = Between(new Date(year, month - 1, 1), new Date(year, month, 0, 23, 59, 59, 999));
      }
    }
    const [items, total] = await manager.findAndCount(AcaoAi, {
      where,
      select: {
        id: true,
        agente_id: true,
        cliente_id: true,
        titulo: true,
        descricao: true,
        tipo_acao: true,
        prioridade: true,
        status: true,
        origem: true,
        acoes: true,
        resultado: true,
        executada_at: true,
        created_at: true,
        updated_at: true,
      },
      order: { created_at: "DESC" },
      take: pageSize,
      skip,
    });
    return buildPaginatedResult(items, total, page, pageSize);
  });
}

export async function getAcaoAi(escritorioId: string, acaoId: string): Promise<AcaoAi | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.findOne(AcaoAi, { where: { id: acaoId } });
  });
}

export async function getAcaoAiWithHistorico(
  escritorioId: string,
  acaoId: string,
): Promise<AcaoAiComHistorico | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const acao = await manager.findOne(AcaoAi, { where: { id: acaoId } });
    if (!acao) return null;

    const historico = await manager.find(HistoricoAcaoAi, {
      where: { acao_id: acaoId },
      order: { created_at: "ASC" },
    });

    return Object.assign(acao, { historico });
  });
}

export async function createAcaoAi(escritorioId: string, input: AcaoAiCreateInput): Promise<AcaoAi> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const acao = manager.create(AcaoAi, {
      agente_id: input.agente_id,
      cliente_id: input.cliente_id ?? null,
      titulo: input.titulo ?? null,
      descricao: input.descricao ?? null,
      tipo_acao: input.tipo_acao ?? null,
      prioridade: input.prioridade ?? "media",
      status: input.status ?? "pendente",
      origem: input.origem,
      payload: input.payload ?? null,
      acoes: input.acoes ?? null,
      s3_output_path: input.s3_output_path ?? null,
    });
    const saved = await manager.save(AcaoAi, acao);

    const entrada = manager.create(HistoricoAcaoAi, {
      acao_id: saved.id,
      status: saved.status,
      resultado: null,
    });
    await manager.save(HistoricoAcaoAi, entrada);

    return saved;
  });
}

export type AcaoAiUpdateInput = {
  status?: StatusAcaoAi;
  titulo?: string | null;
  descricao?: string | null;
  tipo_acao?: TipoAcaoAi | null;
  prioridade?: PrioridadeAcaoAi;
  payload?: Record<string, unknown> | null;
  acoes?: SubAcaoAi[] | null;
  cliente_id?: string | null;
  resultado?: string | null;
  s3_output_path?: string | null;
};

export async function updateAcaoAi(
  escritorioId: string,
  acaoId: string,
  patch: AcaoAiUpdateInput,
): Promise<AcaoAi | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const acao = await manager.findOne(AcaoAi, { where: { id: acaoId } });
    if (!acao) return null;

    if (patch.status !== undefined) {
      acao.status = patch.status;
      if (patch.status === "executada") acao.executada_at = new Date();
    }
    if (patch.titulo !== undefined) acao.titulo = patch.titulo;
    if (patch.descricao !== undefined) acao.descricao = patch.descricao;
    if (patch.tipo_acao !== undefined) acao.tipo_acao = patch.tipo_acao;
    if (patch.prioridade !== undefined) acao.prioridade = patch.prioridade;
    if (patch.payload !== undefined) acao.payload = patch.payload;
    if (patch.acoes !== undefined) acao.acoes = patch.acoes;
    if (patch.cliente_id !== undefined) acao.cliente_id = patch.cliente_id;
    if (patch.resultado !== undefined) acao.resultado = patch.resultado;
    if (patch.s3_output_path !== undefined) acao.s3_output_path = patch.s3_output_path;

    return manager.save(AcaoAi, acao);
  });
}

export async function updateStatusAcaoAi(
  escritorioId: string,
  acaoId: string,
  status: StatusAcaoAi,
  resultado?: string | null,
): Promise<AcaoAi | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const acao = await manager.findOne(AcaoAi, { where: { id: acaoId } });
    if (!acao) return null;

    acao.status = status;
    acao.executada_at = status === "executada" ? new Date() : null;
    if (resultado !== undefined) acao.resultado = resultado ?? null;

    await manager.save(AcaoAi, acao);

    const entrada = manager.create(HistoricoAcaoAi, {
      acao_id: acaoId,
      status,
      resultado: resultado ?? null,
    });
    await manager.save(HistoricoAcaoAi, entrada);

    return acao;
  });
}

export async function deleteAcaoAi(escritorioId: string, acaoId: string): Promise<boolean> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const result = await manager.delete(AcaoAi, { id: acaoId });
    return (result.affected ?? 0) > 0;
  });
}

export async function registrarAcaoContratoProntoParaRevisao(input: {
  escritorioId: string;
  documentoId: string;
  clienteId: string | null | undefined;
}): Promise<AcaoAi | null> {
  const documentoId = input.documentoId.trim();
  const clienteId = input.clienteId?.trim();
  if (!documentoId || !clienteId) return null;

  await ensureDatabase();
  const existente = await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    return manager
      .getRepository(AcaoAi)
      .createQueryBuilder("acao")
      .where("acao.origem = :origem", { origem: "rule" })
      .andWhere("acao.tipo_acao = :tipo", { tipo: "revisao_contrato" })
      .andWhere("acao.status IN (:...statuses)", {
        statuses: ["processando", "pendente", "aceita", "em_progresso"],
      })
      .andWhere("acao.payload ->> 'motivo' = :motivo", { motivo: "contrato_pronto_para_revisao" })
      .andWhere("acao.payload ->> 'documento_id' = :documentoId", { documentoId })
      .getOne();
  });
  if (existente) return existente;

  const agente = await resolveOrCreateSistemaAgente(input.escritorioId);
  return createAcaoAi(input.escritorioId, {
    agente_id: agente.id,
    cliente_id: clienteId,
    titulo: "Contrato pronto para revisão",
    descricao: "Há um contrato novo extraído e pronto para revisão antes de ativar as novas regras de cobrança.",
    tipo_acao: "revisao_contrato",
    prioridade: "alta",
    origem: "rule",
    payload: {
      motivo: "contrato_pronto_para_revisao",
      documento_id: documentoId,
      cliente_id: clienteId,
    },
  });
}

// ── MOTOR DE REGRAS ─────────────────────────────────────────────────────────

type AcaoCandidata = Omit<AcaoAiCreateInput, "agente_id">;

type EventoContratoProximo = {
  tipo: "vencimento" | "aniversario";
  data: string;
  dias_ate: number;
};

type PendenciaRenovacaoContrato = {
  motivo: "sem_ultima_renovacao" | "renovacao_anterior_ao_ultimo_aniversario";
  ultima_renovacao: string | null;
  ultimo_aniversario: string | null;
};

const MS_PER_DAY = 1000 * 60 * 60 * 24;
const JANELA_CONTRATO_DIAS = 90;

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function parseDateOnly(value: string | null | undefined): Date | null {
  const raw = value?.trim();
  if (!raw) return null;

  const brDate = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (brDate) {
    const [, dd, mm, yyyy] = brDate;
    const date = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
    return Number.isFinite(date.getTime()) ? date : null;
  }

  const isoDate = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (isoDate) {
    const [, yyyy, mm, dd] = isoDate;
    const date = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
    return Number.isFinite(date.getTime()) ? date : null;
  }

  const parsed = new Date(raw);
  return Number.isFinite(parsed.getTime()) ? startOfLocalDay(parsed) : null;
}

function formatDateOnly(date: Date): string {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");
}

function diasAte(data: Date, hoje: Date): number {
  return Math.round((startOfLocalDay(data).getTime() - startOfLocalDay(hoje).getTime()) / MS_PER_DAY);
}

function isDentroDaJanela(dias: number): boolean {
  return dias >= 0 && dias < JANELA_CONTRATO_DIAS;
}

function proximoAniversario(dataInicio: Date, hoje: Date): Date {
  const hojeDia = startOfLocalDay(hoje);
  let aniversario = new Date(hojeDia.getFullYear(), dataInicio.getMonth(), dataInicio.getDate());
  if (aniversario.getTime() < hojeDia.getTime()) {
    aniversario = new Date(hojeDia.getFullYear() + 1, dataInicio.getMonth(), dataInicio.getDate());
  }
  return aniversario;
}

function ultimoAniversario(dataInicio: Date, hoje: Date): Date {
  const hojeDia = startOfLocalDay(hoje);
  let aniversario = new Date(hojeDia.getFullYear(), dataInicio.getMonth(), dataInicio.getDate());
  if (aniversario.getTime() > hojeDia.getTime()) {
    aniversario = new Date(hojeDia.getFullYear() - 1, dataInicio.getMonth(), dataInicio.getDate());
  }
  return aniversario;
}

function formatDias(dias: number): string {
  if (dias === 0) return "hoje";
  if (dias === 1) return "em 1 dia";
  return `em ${dias} dias`;
}

function chaveAcaoFixa(titulo: string | null | undefined, clienteId: string | null | undefined): string | null {
  const nome = titulo?.trim().toLowerCase();
  if (!nome) return null;
  return `${clienteId ?? "_sem_cliente"}::${nome}`;
}

async function regraExcedentesNaoCobrados(
  manager: EntityManager,
  clienteNomes: Map<string, string>,
): Promise<AcaoCandidata[]> {
  const acoes: AcaoCandidata[] = [];

  const excedentes = await manager.find(ValoresACobrar, {
    where: { status: "aberto" },
    take: 100,
  });

  for (const val of excedentes) {
    const temExcedentes =
      Array.isArray(val.valores_calculados?.excedentes) &&
      (val.valores_calculados.excedentes as unknown[]).length > 0;

    if (!temExcedentes) continue;

    const nomeCliente = val.cliente_id ? clienteNomes.get(val.cliente_id) : null;
    const prefixo = nomeCliente ? `${nomeCliente} — ` : "";

    acoes.push({
      cliente_id: val.cliente_id,
      titulo: `Excedente a cobrar — ${val.competencia}`,
      descricao: `${prefixo}Cliente possui excedentes calculados para a competência ${val.competencia} com status "aberto". Verificar e enviar cobrança.`,
      tipo_acao: "cobranca",
      prioridade: "alta",
      origem: "rule",
      payload: { valores_a_cobrar_id: val.id, competencia: val.competencia },
    });
  }

  return acoes;
}

async function regraContratosVencendo(
  manager: EntityManager,
  clienteNomes: Map<string, string>,
): Promise<AcaoCandidata[]> {
  const acoes: AcaoCandidata[] = [];
  const hoje = new Date();

  const contratos = await manager.find(Contrato, {
    where: { contrato_ativo: true },
    take: 500,
  });

  for (const contrato of contratos) {
    const eventos: EventoContratoProximo[] = [];

    const dataTermino = parseDateOnly(contrato.data_termino);
    if (dataTermino) {
      const dias = diasAte(dataTermino, hoje);
      if (isDentroDaJanela(dias)) {
        eventos.push({
          tipo: "vencimento",
          data: formatDateOnly(dataTermino),
          dias_ate: dias,
        });
      }
    }

    const dataInicio = parseDateOnly(contrato.data_inicio);
    if (dataInicio) {
      const aniversario = proximoAniversario(dataInicio, hoje);
      const dias = diasAte(aniversario, hoje);
      if (isDentroDaJanela(dias)) {
        eventos.push({
          tipo: "aniversario",
          data: formatDateOnly(aniversario),
          dias_ate: dias,
        });
      }
    }

    if (eventos.length === 0) continue;

    const prioridade: PrioridadeAcaoAi = eventos.some((evento) => evento.dias_ate <= 30) ? "alta" : "media";
    const detalhes = eventos
      .map((evento) =>
        evento.tipo === "vencimento"
          ? `vencimento ${formatDias(evento.dias_ate)}`
          : `aniversário ${formatDias(evento.dias_ate)}`,
      )
      .join(" e ");

    const nomeCliente = contrato.cliente_id ? clienteNomes.get(contrato.cliente_id) : null;
    const prefixo = nomeCliente ? `${nomeCliente} — ` : "";

    acoes.push({
      cliente_id: contrato.cliente_id,
      titulo: "Contrato com prazo importante em até 90 dias",
      descricao: `${prefixo}O contrato tem ${detalhes}. Verificar renovação, reajuste ou aditivo.`,
      tipo_acao: "revisao_contrato",
      prioridade,
      origem: "rule",
      payload: { contrato_id: contrato.id, eventos },
    });
  }

  return acoes;
}

async function regraContratosSemRenovacaoAtualizada(
  manager: EntityManager,
  clienteNomes: Map<string, string>,
): Promise<AcaoCandidata[]> {
  const acoes: AcaoCandidata[] = [];
  const hoje = new Date();

  const contratos = await manager.find(Contrato, {
    where: { contrato_ativo: true },
    take: 500,
  });

  for (const contrato of contratos) {
    const ultimaRenovacaoRaw = contrato.ultima_renovacao?.trim() || null;
    const dataInicio = parseDateOnly(contrato.data_inicio);
    const ultimoAniversarioContrato = dataInicio ? ultimoAniversario(dataInicio, hoje) : null;
    let pendencia: PendenciaRenovacaoContrato | null = null;

    if (!ultimaRenovacaoRaw) {
      pendencia = {
        motivo: "sem_ultima_renovacao",
        ultima_renovacao: null,
        ultimo_aniversario: ultimoAniversarioContrato ? formatDateOnly(ultimoAniversarioContrato) : null,
      };
    } else if (ultimoAniversarioContrato) {
      const ultimaRenovacao = parseDateOnly(ultimaRenovacaoRaw);
      if (ultimaRenovacao && startOfLocalDay(ultimaRenovacao).getTime() < startOfLocalDay(ultimoAniversarioContrato).getTime()) {
        pendencia = {
          motivo: "renovacao_anterior_ao_ultimo_aniversario",
          ultima_renovacao: formatDateOnly(ultimaRenovacao),
          ultimo_aniversario: formatDateOnly(ultimoAniversarioContrato),
        };
      }
    }

    if (!pendencia) continue;

    const nomeCliente = contrato.cliente_id ? clienteNomes.get(contrato.cliente_id) : null;
    const prefixo = nomeCliente ? `${nomeCliente} — ` : "";
    const detalhe = pendencia.motivo === "sem_ultima_renovacao"
      ? "não possui última renovação registrada"
      : `tem última renovação em ${pendencia.ultima_renovacao}, anterior ao último aniversário em ${pendencia.ultimo_aniversario}`;

    acoes.push({
      cliente_id: contrato.cliente_id,
      titulo: "Contrato sem renovação atualizada",
      descricao: `${prefixo}O contrato ${detalhe}. Revisar renovação, reajuste ou aditivo.`,
      tipo_acao: "revisao_contrato",
      prioridade: "alta",
      origem: "rule",
      payload: {
        contrato_id: contrato.id,
        motivo: pendencia.motivo,
        ultima_renovacao: pendencia.ultima_renovacao,
        ultimo_aniversario: pendencia.ultimo_aniversario,
      },
    });
  }

  return acoes;
}

async function regraRelatoriosAtrasados(
  manager: EntityManager,
  clienteNomes: Map<string, string>,
): Promise<AcaoCandidata[]> {
  const acoes: AcaoCandidata[] = [];
  const limite = new Date();
  limite.setDate(limite.getDate() - 45);

  const relatorios = await manager.find(Relatorio, {
    where: { created_at: LessThan(limite) },
    order: { cliente_id: "ASC", created_at: "DESC" },
    take: 200,
  });

  const ultimoPorCliente = new Map<string, Date>();
  for (const rel of relatorios) {
    if (!ultimoPorCliente.has(rel.cliente_id)) {
      ultimoPorCliente.set(rel.cliente_id, rel.created_at);
    }
  }

  for (const [clienteId, ultimaData] of ultimoPorCliente) {
    const diasSemRelatorio = Math.floor((Date.now() - ultimaData.getTime()) / (1000 * 60 * 60 * 24));
    const nomeCliente = clienteNomes.get(clienteId);
    const prefixo = nomeCliente ? `${nomeCliente} — ` : "";

    acoes.push({
      cliente_id: clienteId,
      titulo: `Cliente sem relatório há ${diasSemRelatorio} dia(s)`,
      descricao: `${prefixo}O último relatório foi recebido há ${diasSemRelatorio} dias. Solicitar envio ao cliente.`,
      tipo_acao: "alerta",
      prioridade: diasSemRelatorio > 90 ? "alta" : "media",
      origem: "rule",
      payload: { ultimo_relatorio_em: ultimaData.toISOString(), dias_sem_relatorio: diasSemRelatorio },
    });
  }

  return acoes;
}

export async function gerarAcoesPorRegras(
  escritorioId: string,
  agenteId: string,
): Promise<AcaoAi[]> {
  await ensureDatabase();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const clientes = await manager.find(Cliente, { select: ["id", "razao_social", "nome_fantasia"] });
    const clienteNomes = new Map(
      clientes.map((c) => [c.id, c.nome_fantasia?.trim() || c.razao_social]),
    );

    const [excedentes, contratos, renovacoes, relatorios] = await Promise.all([
      regraExcedentesNaoCobrados(manager, clienteNomes),
      regraContratosVencendo(manager, clienteNomes),
      regraContratosSemRenovacaoAtualizada(manager, clienteNomes),
      regraRelatoriosAtrasados(manager, clienteNomes),
    ]);

    const candidatas = [...excedentes, ...contratos, ...renovacoes, ...relatorios];
    if (candidatas.length === 0) return [];

    const nomesCandidatos = Array.from(
      new Set(
        candidatas
          .map((c) => c.titulo?.trim())
          .filter((titulo): titulo is string => !!titulo),
      ),
    );

    const existentes = nomesCandidatos.length > 0
      ? await manager.find(AcaoAi, {
          where: { origem: "rule", titulo: In(nomesCandidatos) },
          select: ["titulo", "cliente_id"],
          take: 1000,
        })
      : [];
    const chavesExistentes = new Set(
      existentes
        .map((acao) => chaveAcaoFixa(acao.titulo, acao.cliente_id))
        .filter((chave): chave is string => !!chave),
    );
    const chavesNestaExecucao = new Set<string>();

    const candidatasNovas = candidatas.filter((c) => {
      const chave = chaveAcaoFixa(c.titulo, c.cliente_id ?? null);
      if (!chave) return true;
      if (chavesExistentes.has(chave) || chavesNestaExecucao.has(chave)) return false;
      chavesNestaExecucao.add(chave);
      return true;
    });
    if (candidatasNovas.length === 0) return [];

    const acoes = candidatasNovas.map((c) =>
      manager.create(AcaoAi, {
        agente_id: agenteId,
        cliente_id: c.cliente_id ?? null,
        titulo: c.titulo,
        descricao: c.descricao,
        tipo_acao: c.tipo_acao,
        prioridade: c.prioridade ?? "media",
        status: "pendente",
        origem: "rule",
        payload: c.payload ?? null,
      }),
    );

    return manager.save(AcaoAi, acoes);
  });
}
