import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();
  const runQueryWithRls = vi.fn();

  const acaoRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
    createQueryBuilder: vi.fn(),
    delete: vi.fn(),
    save: vi.fn(),
  };
  const valoresRepo = { find: vi.fn() };
  const contratoRepo = { find: vi.fn() };
  const relatorioRepo = { find: vi.fn() };

  const resolveOrCreateSistemaAgente = vi.fn();

  return { ensureDatabase, runQueryWithRls, acaoRepo, valoresRepo, contratoRepo, relatorioRepo, resolveOrCreateSistemaAgente };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: mocks.ensureDatabase,
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: mocks.runQueryWithRls,
}));

vi.mock("../../agentes/agentes.service.js", () => ({
  resolveOrCreateSistemaAgente: mocks.resolveOrCreateSistemaAgente,
}));

const {
  listAcoesAi,
  getAcaoAi,
  createAcaoAi,
  updateStatusAcaoAi,
  deleteAcaoAi,
  gerarAcoesPorRegras,
  registrarAcaoContratoProntoParaRevisao,
} = await import("../acoes-ai.service.js");

// Manager dispatches find/findOne/save/create by entity class name
function makeManager() {
  return {
    find: (entity: { name?: string }, opts?: unknown) => {
      switch (entity?.name) {
        case "AcaoAi": return mocks.acaoRepo.find(entity, opts);
        case "ValoresACobrar": return mocks.valoresRepo.find(entity, opts);
        case "Contrato": return mocks.contratoRepo.find(entity, opts);
        case "Relatorio": return mocks.relatorioRepo.find(entity, opts);
        default: return Promise.resolve([]);
      }
    },
    findOne: (entity: { name?: string }, opts?: unknown) => {
      if (entity?.name === "AcaoAi") return mocks.acaoRepo.findOne(entity, opts);
      return Promise.resolve(null);
    },
    getRepository: (entity: { name?: string }) => {
      if (entity?.name === "AcaoAi") return mocks.acaoRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    },
    create: (_entity: unknown, data: unknown) => ({ ...data as object }),
    save: (entity: unknown, data: unknown) => mocks.acaoRepo.save(entity, data),
    delete: (entity: unknown, criteria: unknown) => mocks.acaoRepo.delete(entity, criteria),
  };
}

function addDays(date: Date, days: number): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

function formatDateOnly(date: Date): string {
  return [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0"),
  ].join("-");
}

function dateOnlyIn(days: number): string {
  return formatDateOnly(addDays(new Date(), days));
}

function aniversarioInicioIn(days: number): string {
  const upcoming = addDays(new Date(), days);
  return formatDateOnly(new Date(upcoming.getFullYear() - 2, upcoming.getMonth(), upcoming.getDate()));
}

function ultimoAniversarioInicioIn(days: number): string {
  const upcoming = addDays(new Date(), days);
  return formatDateOnly(new Date(upcoming.getFullYear() - 2, upcoming.getMonth(), upcoming.getDate()));
}

describe("acoes-ai service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.acaoRepo.find.mockResolvedValue([]);
    mocks.acaoRepo.createQueryBuilder.mockReturnValue({
      where: vi.fn().mockReturnThis(),
      andWhere: vi.fn().mockReturnThis(),
      getOne: vi.fn().mockResolvedValue(null),
    });
    mocks.resolveOrCreateSistemaAgente.mockResolvedValue({ id: "ag-sistema" });
    mocks.runQueryWithRls.mockImplementation(
      async (_rls: unknown, cb: (m: ReturnType<typeof makeManager>) => Promise<unknown>) =>
        cb(makeManager()),
    );
  });

  // ── CRUD ─────────────────────────────────────────────────────────────────

  describe("listAcoesAi", () => {
    it("returns all acoes without filters", async () => {
      const acoes = [{ id: "ac1", titulo: "Ação 1" }, { id: "ac2", titulo: "Ação 2" }];
      mocks.acaoRepo.find.mockResolvedValue(acoes);

      const result = await listAcoesAi("escritorio-1");

      expect(mocks.ensureDatabase).toHaveBeenCalledTimes(1);
      expect(result).toEqual(acoes);
    });

    it("applies status filter when provided", async () => {
      mocks.acaoRepo.find.mockResolvedValue([]);

      await listAcoesAi("escritorio-1", { status: "pendente" });

      expect(mocks.acaoRepo.find).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ where: expect.objectContaining({ status: "pendente" }) }),
      );
    });

    it("applies cliente_id and prioridade filters together", async () => {
      mocks.acaoRepo.find.mockResolvedValue([]);

      await listAcoesAi("escritorio-1", { cliente_id: "c1", prioridade: "alta" });

      expect(mocks.acaoRepo.find).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({
          where: expect.objectContaining({ cliente_id: "c1", prioridade: "alta" }),
        }),
      );
    });
  });

  describe("getAcaoAi", () => {
    it("returns acao when found", async () => {
      const acao = { id: "ac1", titulo: "Ação" };
      mocks.acaoRepo.findOne.mockResolvedValue(acao);

      const result = await getAcaoAi("escritorio-1", "ac1");

      expect(result).toEqual(acao);
    });

    it("returns null when not found", async () => {
      mocks.acaoRepo.findOne.mockResolvedValue(null);

      const result = await getAcaoAi("escritorio-1", "nao-existe");

      expect(result).toBeNull();
    });
  });

  describe("createAcaoAi", () => {
    it("creates acao with defaults for optional fields", async () => {
      const saved = { id: "ac1", titulo: "Nova Ação", status: "pendente", prioridade: "media" };
      mocks.acaoRepo.save.mockResolvedValue(saved);

      const result = await createAcaoAi("escritorio-1", {
        agente_id: "ag1",
        titulo: "Nova Ação",
        descricao: "Descrição",
        tipo_acao: "cobranca",
        origem: "rule",
      });

      expect(mocks.acaoRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({
          agente_id: "ag1",
          titulo: "Nova Ação",
          status: "pendente",
          prioridade: "media",
          origem: "rule",
          cliente_id: null,
          payload: null,
        }),
      );
      expect(result).toEqual(saved);
    });

    it("respects provided prioridade and cliente_id", async () => {
      mocks.acaoRepo.save.mockResolvedValue({});

      await createAcaoAi("escritorio-1", {
        agente_id: "ag1",
        cliente_id: "c1",
        titulo: "Ação Alta",
        descricao: "Desc",
        tipo_acao: "alerta",
        prioridade: "alta",
        origem: "ai",
      });

      expect(mocks.acaoRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ cliente_id: "c1", prioridade: "alta" }),
      );
    });
  });

  describe("registrarAcaoContratoProntoParaRevisao", () => {
    it("creates a rule action for a review-ready contract document", async () => {
      const saved = { id: "ac-contrato", titulo: "Contrato pronto para revisão" };
      mocks.acaoRepo.save.mockResolvedValue(saved);

      const result = await registrarAcaoContratoProntoParaRevisao({
        escritorioId: "escritorio-1",
        documentoId: "doc-1",
        clienteId: "cliente-1",
      });

      expect(mocks.resolveOrCreateSistemaAgente).toHaveBeenCalledWith("escritorio-1");
      expect(mocks.acaoRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({
          agente_id: "ag-sistema",
          cliente_id: "cliente-1",
          titulo: "Contrato pronto para revisão",
          tipo_acao: "revisao_contrato",
          prioridade: "alta",
          origem: "rule",
          payload: {
            motivo: "contrato_pronto_para_revisao",
            documento_id: "doc-1",
            cliente_id: "cliente-1",
          },
        }),
      );
      expect(result).toEqual(saved);
    });

    it("returns the existing open action for the same document", async () => {
      const existente = { id: "ac-existente", payload: { documento_id: "doc-1" } };
      const getOne = vi.fn().mockResolvedValue(existente);
      mocks.acaoRepo.createQueryBuilder.mockReturnValue({
        where: vi.fn().mockReturnThis(),
        andWhere: vi.fn().mockReturnThis(),
        getOne,
      });

      const result = await registrarAcaoContratoProntoParaRevisao({
        escritorioId: "escritorio-1",
        documentoId: "doc-1",
        clienteId: "cliente-1",
      });

      expect(result).toEqual(existente);
      expect(mocks.resolveOrCreateSistemaAgente).not.toHaveBeenCalled();
      expect(mocks.acaoRepo.save).not.toHaveBeenCalled();
    });

    it("does nothing without cliente_id", async () => {
      const result = await registrarAcaoContratoProntoParaRevisao({
        escritorioId: "escritorio-1",
        documentoId: "doc-1",
        clienteId: null,
      });

      expect(result).toBeNull();
      expect(mocks.acaoRepo.createQueryBuilder).not.toHaveBeenCalled();
    });
  });

  describe("updateStatusAcaoAi", () => {
    it("updates status and returns patched acao", async () => {
      const existing = { id: "ac1", status: "pendente", executada_at: null };
      mocks.acaoRepo.findOne.mockResolvedValue(existing);
      mocks.acaoRepo.save.mockResolvedValue({ ...existing, status: "aceita" });

      const result = await updateStatusAcaoAi("escritorio-1", "ac1", "aceita");

      expect(mocks.acaoRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ status: "aceita" }),
      );
      expect(result).toMatchObject({ status: "aceita" });
    });

    it("sets executada_at when status is 'executada'", async () => {
      const existing = { id: "ac1", status: "aceita", executada_at: null };
      mocks.acaoRepo.findOne.mockResolvedValue(existing);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, data: unknown) => Promise.resolve(data));

      const result = await updateStatusAcaoAi("escritorio-1", "ac1", "executada") as { executada_at: unknown };

      expect(result.executada_at).toBeInstanceOf(Date);
    });

    it("clears executada_at when reopening an executed acao", async () => {
      const existing = { id: "ac1", status: "executada", executada_at: new Date() };
      mocks.acaoRepo.findOne.mockResolvedValue(existing);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, data: unknown) => Promise.resolve(data));

      const result = await updateStatusAcaoAi("escritorio-1", "ac1", "em_progresso") as { executada_at: unknown };

      expect(result.executada_at).toBeNull();
    });

    it("returns null when acao not found", async () => {
      mocks.acaoRepo.findOne.mockResolvedValue(null);

      const result = await updateStatusAcaoAi("escritorio-1", "nao-existe", "aceita");

      expect(result).toBeNull();
    });
  });

  describe("deleteAcaoAi", () => {
    it("deletes acao and returns true when found", async () => {
      mocks.acaoRepo.delete.mockResolvedValue({ affected: 1 });

      const result = await deleteAcaoAi("escritorio-1", "ac1");

      expect(mocks.acaoRepo.delete).toHaveBeenCalledWith(
        expect.anything(),
        { id: "ac1" },
      );
      expect(result).toBe(true);
    });

    it("returns false when acao is not found", async () => {
      mocks.acaoRepo.delete.mockResolvedValue({ affected: 0 });

      const result = await deleteAcaoAi("escritorio-1", "nao-existe");

      expect(result).toBe(false);
    });
  });

  // ── MOTOR DE REGRAS ───────────────────────────────────────────────────────

  describe("gerarAcoesPorRegras", () => {
    it("returns empty array when no rules match", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
      expect(mocks.acaoRepo.save).not.toHaveBeenCalled();
    });

    it("gera acao de cobranca para excedentes abertos com itens", async () => {
      mocks.valoresRepo.find.mockResolvedValue([
        {
          id: "val1",
          cliente_id: "c1",
          competencia: "2026-03",
          status: "aberto",
          valores_calculados: { excedentes: [{ tipo: "funcionarios", valor_total: 100 }] },
        },
      ]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{ tipo_acao: string; origem: string; cliente_id: string }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        tipo_acao: "cobranca",
        origem: "rule",
        cliente_id: "c1",
      });
    });

    it("ignora excedentes abertos sem itens de excedente", async () => {
      mocks.valoresRepo.find.mockResolvedValue([
        {
          id: "val2",
          cliente_id: "c2",
          competencia: "2026-04",
          status: "aberto",
          valores_calculados: { excedentes: [] },
        },
      ]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
    });

    it("gera acao de revisao para contrato vencendo em menos de 90 dias", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct1", cliente_id: "c3", contrato_ativo: true, data_termino: dateOnlyIn(20), data_inicio: null, ultima_renovacao: dateOnlyIn(0) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{
        tipo_acao: string;
        prioridade: string;
        cliente_id: string;
        payload: { eventos: Array<{ tipo: string; dias_ate: number }> };
      }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        tipo_acao: "revisao_contrato",
        prioridade: "alta",
        cliente_id: "c3",
      });
      expect(result[0].payload.eventos).toEqual([
        expect.objectContaining({ tipo: "vencimento", dias_ate: 20 }),
      ]);
    });

    it("gera acao de revisao para aniversario de contrato em menos de 90 dias", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct2", cliente_id: "c4", contrato_ativo: true, data_termino: null, data_inicio: aniversarioInicioIn(45), ultima_renovacao: dateOnlyIn(0) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{
        tipo_acao: string;
        prioridade: string;
        cliente_id: string;
        payload: { eventos: Array<{ tipo: string; dias_ate: number }> };
      }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        tipo_acao: "revisao_contrato",
        prioridade: "media",
        cliente_id: "c4",
      });
      expect(result[0].payload.eventos).toEqual([
        expect.objectContaining({ tipo: "aniversario", dias_ate: 45 }),
      ]);
    });

    it("combina vencimento e aniversario proximos na mesma acao do cliente", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        {
          id: "ct3",
          cliente_id: "c5",
          contrato_ativo: true,
          data_termino: dateOnlyIn(15),
          data_inicio: aniversarioInicioIn(50),
          ultima_renovacao: dateOnlyIn(0),
        },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{
        cliente_id: string;
        payload: { eventos: Array<{ tipo: string; dias_ate: number }> };
      }>;

      expect(result).toHaveLength(1);
      expect(result[0].cliente_id).toBe("c5");
      expect(result[0].payload.eventos).toEqual([
        expect.objectContaining({ tipo: "vencimento", dias_ate: 15 }),
        expect.objectContaining({ tipo: "aniversario", dias_ate: 50 }),
      ]);
    });

    it("ignora contratos sem vencimento ou aniversario em menos de 90 dias", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct4", cliente_id: "c6", contrato_ativo: true, data_termino: dateOnlyIn(90), data_inicio: aniversarioInicioIn(120), ultima_renovacao: dateOnlyIn(0) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
    });

    it("gera acao de alerta para cliente sem relatorio ha mais de 45 dias", async () => {
      const ha60dias = new Date();
      ha60dias.setDate(ha60dias.getDate() - 60);

      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([
        { id: "rel1", cliente_id: "c5", created_at: ha60dias },
      ]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{ tipo_acao: string; cliente_id: string }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({ tipo_acao: "alerta", cliente_id: "c5" });
    });

    it("deduplica alertas de relatorio: apenas o mais recente por cliente", async () => {
      const ha50dias = new Date();
      ha50dias.setDate(ha50dias.getDate() - 50);
      const ha70dias = new Date();
      ha70dias.setDate(ha70dias.getDate() - 70);

      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([
        { id: "rel1", cliente_id: "c6", created_at: ha50dias },
        { id: "rel2", cliente_id: "c6", created_at: ha70dias },
      ]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<unknown>;

      expect(result).toHaveLength(1);
    });

    it("nao insere acao fixa quando ja existe uma com o mesmo titulo para o mesmo cliente", async () => {
      const titulo = "Excedente a cobrar — 2026-03";
      mocks.valoresRepo.find.mockResolvedValue([
        {
          id: "v1",
          cliente_id: "c1",
          competencia: "2026-03",
          status: "aberto",
          valores_calculados: { excedentes: [{ tipo: "funcionarios" }] },
        },
      ]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.find.mockResolvedValue([{ titulo, cliente_id: "c1", origem: "rule" }]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
      expect(mocks.acaoRepo.save).not.toHaveBeenCalled();
    });

    it("permite o mesmo titulo de acao fixa para clientes diferentes", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct1", cliente_id: "c1", contrato_ativo: true, data_termino: dateOnlyIn(10), data_inicio: null, ultima_renovacao: dateOnlyIn(0) },
        { id: "ct2", cliente_id: "c2", contrato_ativo: true, data_termino: dateOnlyIn(20), data_inicio: null, ultima_renovacao: dateOnlyIn(0) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.find.mockResolvedValue([
        { titulo: "Contrato com prazo importante em até 90 dias", cliente_id: "c1", origem: "rule" },
      ]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{ cliente_id: string }>;

      expect(result).toHaveLength(1);
      expect(result[0].cliente_id).toBe("c2");
    });

    it("deduplica acoes fixas repetidas dentro da mesma execucao", async () => {
      mocks.valoresRepo.find.mockResolvedValue([
        {
          id: "v1",
          cliente_id: "c1",
          competencia: "2026-03",
          status: "aberto",
          valores_calculados: { excedentes: [{ tipo: "funcionarios" }] },
        },
        {
          id: "v2",
          cliente_id: "c1",
          competencia: "2026-03",
          status: "aberto",
          valores_calculados: { excedentes: [{ tipo: "documentos" }] },
        },
      ]);
      mocks.contratoRepo.find.mockResolvedValue([]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{ cliente_id: string; titulo: string }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        cliente_id: "c1",
        titulo: "Excedente a cobrar — 2026-03",
      });
    });

    it("combina acoes de multiplas regras em um unico save", async () => {
      const ha60dias = new Date();
      ha60dias.setDate(ha60dias.getDate() - 60);

      mocks.valoresRepo.find.mockResolvedValue([
        { id: "v1", cliente_id: "c1", competencia: "2026-03", status: "aberto", valores_calculados: { excedentes: [{ tipo: "funcionarios" }] } },
      ]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct1", cliente_id: "c2", contrato_ativo: true, data_termino: dateOnlyIn(10), data_inicio: null, ultima_renovacao: dateOnlyIn(0) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([
        { id: "rel1", cliente_id: "c3", created_at: ha60dias },
      ]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<unknown>;

      expect(result).toHaveLength(3);
      expect(mocks.acaoRepo.save).toHaveBeenCalledTimes(1);
    });

    it("gera acao de revisao para contrato sem ultima renovacao", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct-ren-1", cliente_id: "c7", contrato_ativo: true, data_termino: null, data_inicio: "2024-05-01", ultima_renovacao: null },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{
        titulo: string;
        tipo_acao: string;
        prioridade: string;
        cliente_id: string;
        payload: { contrato_id: string; motivo: string; ultima_renovacao: string | null; ultimo_aniversario: string | null };
      }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        titulo: "Contrato sem renovação atualizada",
        tipo_acao: "revisao_contrato",
        prioridade: "alta",
        cliente_id: "c7",
        payload: expect.objectContaining({
          contrato_id: "ct-ren-1",
          motivo: "sem_ultima_renovacao",
          ultima_renovacao: null,
        }),
      });
    });

    it("gera acao quando ultima renovacao e anterior ao ultimo aniversario", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        {
          id: "ct-ren-2",
          cliente_id: "c8",
          contrato_ativo: true,
          data_termino: null,
          data_inicio: ultimoAniversarioInicioIn(-30),
          ultima_renovacao: dateOnlyIn(-60),
        },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{
        payload: { motivo: string; ultima_renovacao: string | null; ultimo_aniversario: string | null };
      }>;

      expect(result).toHaveLength(1);
      expect(result[0].payload).toMatchObject({
        motivo: "renovacao_anterior_ao_ultimo_aniversario",
        ultima_renovacao: dateOnlyIn(-60),
        ultimo_aniversario: dateOnlyIn(-30),
      });
    });

    it("nao gera acao quando ultima renovacao e igual ou posterior ao ultimo aniversario", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        {
          id: "ct-ren-3",
          cliente_id: "c9",
          contrato_ativo: true,
          data_termino: null,
          data_inicio: ultimoAniversarioInicioIn(-30),
          ultima_renovacao: dateOnlyIn(-30),
        },
        {
          id: "ct-ren-4",
          cliente_id: "c10",
          contrato_ativo: true,
          data_termino: null,
          data_inicio: ultimoAniversarioInicioIn(-30),
          ultima_renovacao: dateOnlyIn(-5),
        },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
    });

    it("gera acao sem data_inicio somente quando ultima renovacao esta ausente", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct-ren-5", cliente_id: "c11", contrato_ativo: true, data_termino: null, data_inicio: null, ultima_renovacao: null },
        { id: "ct-ren-6", cliente_id: "c12", contrato_ativo: true, data_termino: null, data_inicio: null, ultima_renovacao: dateOnlyIn(-5) },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.save.mockImplementation((_e: unknown, acoes: unknown) => Promise.resolve(acoes));

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1") as Array<{ cliente_id: string; payload: { motivo: string; ultimo_aniversario: string | null } }>;

      expect(result).toHaveLength(1);
      expect(result[0]).toMatchObject({
        cliente_id: "c11",
        payload: {
          motivo: "sem_ultima_renovacao",
          ultimo_aniversario: null,
        },
      });
    });

    it("deduplica a acao fixa de renovacao para o mesmo cliente", async () => {
      mocks.valoresRepo.find.mockResolvedValue([]);
      mocks.contratoRepo.find.mockResolvedValue([
        { id: "ct-ren-7", cliente_id: "c13", contrato_ativo: true, data_termino: null, data_inicio: null, ultima_renovacao: null },
      ]);
      mocks.relatorioRepo.find.mockResolvedValue([]);
      mocks.acaoRepo.find.mockResolvedValue([
        { titulo: "Contrato sem renovação atualizada", cliente_id: "c13", origem: "rule" },
      ]);

      const result = await gerarAcoesPorRegras("escritorio-1", "ag1");

      expect(result).toEqual([]);
      expect(mocks.acaoRepo.save).not.toHaveBeenCalled();
    });
  });
});
