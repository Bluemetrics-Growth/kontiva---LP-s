import type { ReportExtractionBatch } from "../../agent/index.js";
import { runQueryWithRls } from "../../database/data-source.js";
import { Extracao, type TipoExtracao, Documento } from "../../database/index.js";

let documentAgentPromise:
  | Promise<{
      ingestFromBuffer(buffer: Buffer, filename: string): Promise<Record<string, unknown>>;
    }>
  | undefined;

let reportAgentPromise:
  | Promise<{
      ingestFromBuffer(buffer: Buffer, filename: string): Promise<ReportExtractionBatch>;
    }>
  | undefined;

async function getDocumentAgent() {
  documentAgentPromise ??= import("../../agent/index.js").then(({ DocumentIngestionAgent }) => new DocumentIngestionAgent());
  return await documentAgentPromise;
}

async function getReportAgent() {
  reportAgentPromise ??= import("../../agent/index.js").then(({ ReportIngestionAgent }) => new ReportIngestionAgent());
  return await reportAgentPromise;
}

export async function extractDocument(buffer: Buffer, filename: string): Promise<Record<string, unknown>> {
  const documentAgent = await getDocumentAgent();
  return await documentAgent.ingestFromBuffer(buffer, filename);
}

export async function extractReport(buffer: Buffer, filename: string): Promise<ReportExtractionBatch> {
  const reportAgent = await getReportAgent();
  return await reportAgent.ingestFromBuffer(buffer, filename);
}

export async function saveExtracao(input: {
  escritorioId: string;
  documentoId: string;
  tipoExtracao: TipoExtracao;
  payloadJson: Record<string, unknown>;
  confidence?: number | null;
}): Promise<Extracao> {
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Extracao);
    const extracao = repo.create({
      documento_id: input.documentoId,
      tipo_extracao: input.tipoExtracao,
      payload_json: input.payloadJson,
      confidence: input.confidence ?? null,
    });
    return await repo.save(extracao);
  });
}

export async function listExtracoesByCliente(
  escritorioId: string,
  clienteId: string,
  limit: number = 10,
): Promise<Extracao[]> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Extracao);
    return await repo
      .createQueryBuilder("extracao")
      .select([
        "extracao.id",
        "extracao.documento_id",
        "extracao.payload_json",
        "extracao.created_at",
        "extracao.updated_at",
      ])
      .innerJoin(Documento, "documento", "documento.id = extracao.documento_id")
      .where("documento.cliente_id = :cliente_id", { cliente_id: clienteId })
      .andWhere("documento.escritorio_id = :escritorio_id", { escritorio_id: escritorioId })
      .orderBy("extracao.created_at", "DESC")
      .limit(limit)
      .getMany();
  });
}
