# `src/domain/extracao`

Esta pasta concentra os casos de uso de extração de documentos e relatórios.

## Responsabilidades

- extrair dados de documentos a partir de buffer (via `DocumentIngestionAgent`)
- extrair dados de relatórios a partir de buffer (via `ReportIngestionAgent`)
- salvar uma `Extracao` associada a um `Documento` quando o fluxo de upload já recebeu contexto de cliente
- listar extrações recentes por cliente

## Fluxo atual de confirmação

Os fluxos de revisão e confirmação do produto **não passam por esta pasta**:

- **Contratos**: `POST /contratos/:id/confirmar` → `confirmarContratoExtracted()` em `src/domain/contratos/contrato.service.ts` → TypeORM direto
- **Relatórios (novo)**: `POST /relatorios/:id/confirmar` → `confirmarRelatorioExtracted()` em `src/domain/relatorios/relatorio.service.ts` → TypeORM direto

O fluxo legado de persistência direta não faz parte do backend atual.

## Arquivos

- `extracao.service.ts`: orquestra os agentes de extração (`DocumentIngestionAgent`, `ReportIngestionAgent`), salva extrações e lista histórico por cliente

## Testes

- `tests/extracao.service.test.ts`

## Regra prática

Se a lógica decide como um arquivo vira dado extraído (via LLM), ela pertence aqui. Se a lógica decide como um payload confirmado é salvo no banco, ela pertence ao domínio correspondente (`contratos` ou `relatorios`).
