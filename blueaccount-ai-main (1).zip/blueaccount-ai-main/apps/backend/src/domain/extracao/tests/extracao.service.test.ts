import { beforeEach, describe, expect, it, vi } from "vitest";

const extractionMocks = vi.hoisted(() => {
  const documentAgentInstance = {
    ingestFromBuffer: vi.fn(),
  };
  const reportAgentInstance = {
    ingestFromBuffer: vi.fn(),
  };
  const DocumentIngestionAgent = vi.fn(function DocumentIngestionAgent() {
    return documentAgentInstance;
  });
  const ReportIngestionAgent = vi.fn(function ReportIngestionAgent() {
    return reportAgentInstance;
  });
  const runQueryWithRls = vi.fn();
  const extracaoRepo = {
    create: vi.fn((payload) => payload),
    save: vi.fn(async (payload) => ({ id: "extracao-1", ...payload })),
  };

  return {
    documentAgentInstance,
    reportAgentInstance,
    DocumentIngestionAgent,
    ReportIngestionAgent,
    runQueryWithRls,
    extracaoRepo,
  };
});

vi.mock("../../../agent/index.js", () => ({
  DocumentIngestionAgent: extractionMocks.DocumentIngestionAgent,
  ReportIngestionAgent: extractionMocks.ReportIngestionAgent,
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: extractionMocks.runQueryWithRls,
}));

const { extractDocument, extractReport, saveExtracao } = await import("../extracao.service.js");

describe("extracao service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    extractionMocks.runQueryWithRls.mockImplementation(async (_rls, callback) => {
      return callback({
        getRepository: () => extractionMocks.extracaoRepo,
      });
    });
  });

  it("extracts a document from buffer", async () => {
    extractionMocks.documentAgentInstance.ingestFromBuffer.mockResolvedValue({ ok: true, kind: "document" });

    const result = await extractDocument(Buffer.from("pdf"), "contrato.pdf");

    expect(result).toEqual({ ok: true, kind: "document" });
    expect(extractionMocks.documentAgentInstance.ingestFromBuffer).toHaveBeenCalledWith(Buffer.from("pdf"), "contrato.pdf");
  });

  it("extracts a report from buffer", async () => {
    extractionMocks.reportAgentInstance.ingestFromBuffer.mockResolvedValue({ ok: true, kind: "report" });

    const result = await extractReport(Buffer.from("pdf"), "relatorio.pdf");

    expect(result).toEqual({ ok: true, kind: "report" });
    expect(extractionMocks.reportAgentInstance.ingestFromBuffer).toHaveBeenCalledWith(Buffer.from("pdf"), "relatorio.pdf");
  });

  it("saves extraction payloads under RLS", async () => {
    const result = await saveExtracao({
      escritorioId: "office-1",
      documentoId: "doc-1",
      tipoExtracao: "contrato",
      payloadJson: { foo: "bar" },
      confidence: 0.9,
    });

    expect(result).toEqual({
      id: "extracao-1",
      documento_id: "doc-1",
      tipo_extracao: "contrato",
      payload_json: { foo: "bar" },
      confidence: 0.9,
    });
    expect(extractionMocks.runQueryWithRls).toHaveBeenCalledWith({ escritorio_id: "office-1" }, expect.any(Function));
  });
});
