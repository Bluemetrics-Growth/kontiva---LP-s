/**
 * Regime tributário do cliente: valores canônicos, normalização de variantes e
 * o cruzamento com o documento (CPF/CNPJ).
 *
 * Regime e documento são redundantes de propósito — "Pessoa Física" só existe
 * para cliente com CPF (11 dígitos) e os outros quatro só para cliente com CNPJ
 * (14 dígitos). Um par inconsistente prova que um dos dois campos está errado,
 * o que torna esse cruzamento o teste de acurácia mais barato que temos sobre a
 * extração automática de contratos.
 *
 * Esta lista é duplicada, por não haver pacote compartilhado entre os runtimes:
 * - `apps/mcp/src/tools/contratos.ts` (REGIMES_TRIBUTARIOS + o gate no zod)
 * - `apps/frontend/src/lib/regime-tributario.ts` (opções do dropdown)
 * - os prompts de extração (ver `apps/services/contratos/termos_gerais.md`)
 * Ao mexer aqui, mexer nos três.
 */

import { somenteDigitos } from "../texto.js";

export const REGIMES_TRIBUTARIOS = [
  "Simples Nacional",
  "Lucro Presumido",
  "Lucro Real",
  "MEI",
  "Pessoa Física",
] as const;

export type RegimeTributario = (typeof REGIMES_TRIBUTARIOS)[number];

/** Único regime que pareia com CPF (11 dígitos). */
export const REGIME_PESSOA_FISICA: RegimeTributario = "Pessoa Física";

/** Regime fora da lista canônica, ou par regime/documento inconsistente. Vira HTTP 400. */
export class RegimeTributarioInvalidoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RegimeTributarioInvalidoError";
  }
}

/** Remove acentos, colapsa espaços e sobe para maiúsculas, para casar variantes. */
function chaveDeComparacao(valor: string): string {
  return valor
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}

/**
 * Variantes aceitas → valor canônico.
 *
 * `SIMPLES` precisa estar aqui: é o valor que existe em dado legado e nos testes
 * antigos. Sem ele, qualquer PATCH num cliente legado passaria a devolver 400.
 */
const VARIANTES: Record<string, RegimeTributario> = {
  "SIMPLES NACIONAL": "Simples Nacional",
  SIMPLES: "Simples Nacional",
  SN: "Simples Nacional",

  "LUCRO PRESUMIDO": "Lucro Presumido",
  PRESUMIDO: "Lucro Presumido",

  "LUCRO REAL": "Lucro Real",
  REAL: "Lucro Real",

  MEI: "MEI",
  "MICROEMPREENDEDOR INDIVIDUAL": "MEI",

  "PESSOA FISICA": "Pessoa Física",
  PF: "Pessoa Física",
  AUTONOMO: "Pessoa Física",
  "PROFISSIONAL LIBERAL": "Pessoa Física",
};

/**
 * Normaliza o regime para um dos cinco valores canônicos.
 *
 * `null`, `undefined` e string vazia devolvem `null` (campo opcional, ausência é
 * válida). Valor irreconhecível **lança** em vez de virar `null`: silenciar aqui
 * apagaria justamente o sinal de que a extração errou.
 */
export function normalizarRegimeTributario(value: unknown): RegimeTributario | null {
  if (value == null) return null;

  const bruto = String(value).trim();
  if (!bruto) return null;

  const canonico = VARIANTES[chaveDeComparacao(bruto)];
  if (!canonico) {
    throw new RegimeTributarioInvalidoError(
      `regime_tributario "${bruto}" não é reconhecido. Use um destes valores: ${REGIMES_TRIBUTARIOS.join(", ")}.`,
    );
  }

  return canonico;
}

/** Conta só os dígitos: aceita documento mascarado ou cru. */
function quantidadeDeDigitos(documento: string): number {
  return somenteDigitos(documento).length;
}

/**
 * Cruza regime com documento. Não valida quando falta um dos dois — não há par
 * para checar, e ambos os campos são opcionais em vários caminhos de escrita.
 */
export function validarRegimeComDocumento(
  regime: RegimeTributario | null,
  documento: string | null | undefined,
): void {
  if (regime == null || documento == null) return;

  const digitos = quantidadeDeDigitos(String(documento));
  if (digitos !== 11 && digitos !== 14) return;

  const ehPessoaFisica = regime === REGIME_PESSOA_FISICA;

  if (ehPessoaFisica && digitos === 14) {
    throw new RegimeTributarioInvalidoError(
      `regime_tributario "${regime}" é incompatível com o documento "${documento}" (14 dígitos = CNPJ). ` +
        `Use "${REGIME_PESSOA_FISICA}" apenas para cliente com CPF; para uma empresa, escolha um dos regimes de pessoa jurídica.`,
    );
  }

  if (!ehPessoaFisica && digitos === 11) {
    throw new RegimeTributarioInvalidoError(
      `regime_tributario "${regime}" é incompatível com o documento "${documento}" (11 dígitos = CPF). ` +
        `Use "${REGIME_PESSOA_FISICA}" quando o cliente for pessoa física, ou corrija o documento se ele for uma empresa.`,
    );
  }
}

/**
 * Normaliza e cruza em uma passada. Atalho para os caminhos de escrita, que
 * sempre precisam das duas coisas juntas.
 */
export function normalizarRegimeParaDocumento(
  value: unknown,
  documento: string | null | undefined,
): RegimeTributario | null {
  const regime = normalizarRegimeTributario(value);
  validarRegimeComDocumento(regime, documento);
  return regime;
}

/** Regimes válidos para um documento. Espelha o filtro do dropdown do frontend. */
export function regimesPermitidosParaDocumento(
  documento: string | null | undefined,
): readonly RegimeTributario[] {
  if (documento == null) return REGIMES_TRIBUTARIOS;

  const digitos = quantidadeDeDigitos(String(documento));
  if (digitos === 11) return [REGIME_PESSOA_FISICA];
  if (digitos === 14) return REGIMES_TRIBUTARIOS.filter((r) => r !== REGIME_PESSOA_FISICA);
  return REGIMES_TRIBUTARIOS;
}
