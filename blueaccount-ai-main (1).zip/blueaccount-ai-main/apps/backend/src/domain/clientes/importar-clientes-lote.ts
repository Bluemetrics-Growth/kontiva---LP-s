import {
  ClienteJaExisteError,
  createCliente,
  normalizarCnpj,
  type ClienteCreateInput,
} from "./cliente.service.js";

/**
 * Teto de itens por requisição.
 *
 * `createCliente` faz uma consulta pública de CNPJ por item (BrasilAPI, com cache
 * compartilhado em `cadastros_cnpj`). Num lote frio isso é uma ida à rede por
 * empresa, então o tempo da requisição cresce linearmente e um lote grande estoura
 * o timeout do ALB/CloudFront antes de terminar. O cliente da API pagina; o
 * servidor recusa acima deste teto em vez de aceitar um lote que não termina.
 */
export const LIMITE_LOTE_CLIENTES = 100;

/** Campos aceitos por item. Espelha o payload de `GET /v1/empresas` do cliente local. */
export interface EmpresaParaImportar {
  cnpj: unknown;
  razao_social?: unknown;
  nome_fantasia?: unknown;
  uf?: unknown;
  /**
   * `codi_emp` do Domínio. Aceito e devolvido para o chamador correlacionar linha
   * com resultado, mas **não persistido**: o vínculo `codi_emp` → `cliente` é uma
   * tabela própria que ainda não existe. Sem ela, reimportar casa por CNPJ.
   */
  dominio_empresa_id?: unknown;
}

export type SituacaoImportacaoCliente =
  | "criado"
  | "ja_existe"
  | "duplicado_no_lote"
  | "erro";

export interface ResultadoImportacaoCliente {
  indice: number;
  dominio_empresa_id: number | null;
  cnpj: string | null;
  situacao: SituacaoImportacaoCliente;
  cliente_id: string | null;
  razao_social: string | null;
  erro: string | null;
}

export interface ResumoImportacaoClientes {
  total: number;
  criados: number;
  ja_existentes: number;
  duplicados_no_lote: number;
  com_erro: number;
  resultados: ResultadoImportacaoCliente[];
}

function texto(valor: unknown): string | undefined {
  if (typeof valor !== "string") return undefined;
  const limpo = valor.trim();
  return limpo === "" ? undefined : limpo;
}

function inteiro(valor: unknown): number | null {
  if (typeof valor === "number" && Number.isInteger(valor)) return valor;
  if (typeof valor === "string" && /^\d+$/.test(valor.trim())) return Number(valor.trim());
  return null;
}

/**
 * Cria vários clientes reusando `createCliente`, um por um.
 *
 * Duas decisões que definem o comportamento:
 *
 * 1. **Sequencial, nunca `Promise.all`.** Cada item faz uma consulta de CNPJ na
 *    rede, e criações concorrentes do mesmo CNPJ correriam entre si — o mesmo
 *    motivo pelo qual `finalizarIngestaoRelatoriosPlanilha` também é sequencial.
 * 2. **Resultado por item, nunca tudo-ou-nada.** Um CNPJ inválido no meio do lote
 *    não pode descartar as criações que já commitaram. Cada item é uma transação
 *    curta e independente dentro de `createCliente`, e a resposta diz o que
 *    aconteceu com cada linha.
 *
 * Reexecutar o mesmo lote é seguro: item já cadastrado volta como `ja_existe`, não
 * como erro. Isso é o que permite ao chamador repetir uma página que falhou no meio.
 */
export async function importarClientesEmLote(
  escritorioId: string,
  empresas: EmpresaParaImportar[],
): Promise<ResumoImportacaoClientes> {
  const resultados: ResultadoImportacaoCliente[] = [];
  // Chave normalizada das linhas já processadas nesta requisição. O Domínio tem
  // CNPJ repetido em `geempre` (matriz e filial no mesmo documento), então a
  // segunda linha do mesmo CNPJ é sinalizada em vez de virar um erro confuso.
  const vistos = new Set<string>();

  for (const [indice, bruta] of empresas.entries()) {
    const dominioEmpresaId = inteiro(bruta?.dominio_empresa_id);
    const cnpjBruto = texto(bruta?.cnpj) ?? null;

    const registrar = (
      situacao: SituacaoImportacaoCliente,
      extra: Partial<ResultadoImportacaoCliente> = {},
    ) => {
      resultados.push({
        indice,
        dominio_empresa_id: dominioEmpresaId,
        cnpj: cnpjBruto,
        situacao,
        cliente_id: null,
        razao_social: null,
        erro: null,
        ...extra,
      });
    };

    if (!cnpjBruto) {
      registrar("erro", { erro: "cnpj é obrigatório." });
      continue;
    }

    let chave: string;
    try {
      chave = normalizarCnpj(cnpjBruto);
    } catch (error) {
      registrar("erro", { erro: (error as Error).message });
      continue;
    }

    if (vistos.has(chave)) {
      registrar("duplicado_no_lote");
      continue;
    }
    vistos.add(chave);

    // `razao_social` é fallback de propósito: em `createCliente` a consulta pública
    // de CNPJ vence quando tem o dado. O nome vindo do Domínio só entra quando a
    // consulta não encontra o cadastro.
    const entrada: ClienteCreateInput = {
      cnpj: cnpjBruto,
      razao_social: texto(bruta?.razao_social) ?? "",
      nome_fantasia: texto(bruta?.nome_fantasia) ?? null,
      uf: texto(bruta?.uf) ?? null,
    };

    try {
      const { cliente } = await createCliente(escritorioId, entrada);
      registrar("criado", {
        cliente_id: cliente.id,
        // Volta a razão social efetivamente gravada: a consulta pública de CNPJ
        // pode ter sobrescrito o nome que veio do Domínio.
        razao_social: cliente.razao_social,
      });
    } catch (error) {
      if (error instanceof ClienteJaExisteError) {
        registrar("ja_existe");
        continue;
      }
      registrar("erro", { erro: (error as Error).message });
    }
  }

  return {
    total: resultados.length,
    criados: resultados.filter((r) => r.situacao === "criado").length,
    ja_existentes: resultados.filter((r) => r.situacao === "ja_existe").length,
    duplicados_no_lote: resultados.filter((r) => r.situacao === "duplicado_no_lote").length,
    com_erro: resultados.filter((r) => r.situacao === "erro").length,
    resultados,
  };
}
