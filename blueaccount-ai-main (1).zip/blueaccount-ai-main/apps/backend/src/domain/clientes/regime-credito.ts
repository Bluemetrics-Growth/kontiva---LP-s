import type { OpcaoIbsCbs, CnaeSecundario } from "../../database/modules/tenant/entities/fornecedor.entity.js";
import type { NcmPermitido } from "../../database/modules/tenant/entities/cliente.entity.js";
import type { PerfilCreditoEntrada } from "../simulacoes/calculo.js";
import { somenteDigitos } from "../texto.js";

/**
 * Perfil fiscal do cliente resolvido, análogo a `CreditoFornecedorResolvido`
 * (`domain/fornecedores/regime-credito.ts`), mas para o lado da receita/despesa do CLIENTE, não do
 * fornecedor vinculado à linha.
 */
export type PerfilFiscalClienteResolvido = {
  perfil: Extract<PerfilCreditoEntrada, "integral" | "sem_credito">;
  /** Texto legível exibido na linha calculada, com a base legal. */
  justificativa: string;
};

export type ClienteParaPerfilFiscal = {
  regime_tributario: string | null;
  opcao_ibs_cbs: OpcaoIbsCbs | null;
};

/** Regimes do Simples: são os únicos em que `opcao_ibs_cbs` importa. */
const REGIMES_SIMPLIFICADOS = new Set(["Simples Nacional"]);

const JUSTIFICATIVA_INTEGRAL_REGULAR =
  "Cliente no regime regular: débito e crédito de IBS/CBS seguem a alíquota efetiva da linha, sem ajuste.";

const JUSTIFICATIVA_INTEGRAL_HIBRIDO =
  "Cliente optante do Simples que recolhe IBS/CBS pelo regime regular (opção híbrida, LC 214/2025, " +
  "art. 41): débito e crédito seguem a alíquota efetiva da linha, sem ajuste.";

const JUSTIFICATIVA_SEM_CREDITO_NAO_CONTRIBUINTE =
  "Cliente não contribuinte de IBS/CBS: débito de receita e crédito de despesa zerados na simulação.";

function justificativaSemCreditoSimples(regime: string): string {
  return (
    `Cliente no ${regime} em regime único: não apura débitos nem apropria créditos próprios de ` +
    "IBS/CBS fora do Simples (LC 214/2025, art. 47, §9º, I)."
  );
}

/**
 * Deriva, de forma determinística e sem banco, o perfil fiscal do CLIENTE de uma simulação: gateia
 * débito de receita e crédito de despesa de IBS/CBS, e vence outright sobre fornecedor/linha quando
 * não `integral` ("cliente é o teto" — ver `domain/simulacoes/README.md`). ICMS não passa por aqui.
 *
 * Tabela de decisão deliberadamente DIFERENTE da de `resolverCreditoFornecedor`
 * (`domain/fornecedores/regime-credito.ts`):
 *
 * - `Pessoa Física` → `sem_credito`, igual ao fornecedor (não contribuinte).
 * - `MEI` → `sem_credito`, DIVERGE do fornecedor (que cai em `presumido`): para o cliente isto gateia
 *   também o próprio DÉBITO de receita, não só o crédito que um terceiro tomaria da nota dele. MEI
 *   não pode optar pelo regime regular de IBS/CBS.
 * - `Simples Nacional` com `opcao_ibs_cbs === "regime_regular"` → `integral` (opção híbrida, art. 41).
 * - `Simples Nacional` com `regime_unico` ou não informado → `presumido`, usando as alíquotas
 *   presumidas do PRÓPRIO cliente.
 * - `Lucro Presumido`/`Lucro Real`/nulo → `integral`, comportamento histórico preservado (é o caso da
 *   maioria dos clientes hoje e continua sendo depois do deploy, já que os três campos novos nascem
 *   `NULL` sem backfill).
 */
export function resolverPerfilFiscalCliente(
  cliente: ClienteParaPerfilFiscal,
): PerfilFiscalClienteResolvido {
  const regime = cliente.regime_tributario?.trim() || null;
  if (regime === "Pessoa Física" || regime === "MEI") {
    return {
      perfil: "sem_credito",
      justificativa: JUSTIFICATIVA_SEM_CREDITO_NAO_CONTRIBUINTE,
    };
  }

  if (regime && REGIMES_SIMPLIFICADOS.has(regime)) {
    if (cliente.opcao_ibs_cbs === "regime_regular") {
      return { perfil: "integral", justificativa: JUSTIFICATIVA_INTEGRAL_HIBRIDO };
    }

    // `regime_unico` ou não informado — o default conservador é o regime único.
    return {
      perfil: "sem_credito",
      justificativa: justificativaSemCreditoSimples(regime),
    };
  }

  return { perfil: "integral", justificativa: JUSTIFICATIVA_INTEGRAL_REGULAR };
}

/**
 * CNAE do fornecedor está na allowlist manual do cliente? Pura, sem banco. Lista vazia/null =
 * sem restrição cadastrada → sempre elegível. CNAE do fornecedor nulo/ausente = não elegível.
 * Ainda NÃO chamada de calculo.ts/resolverCreditoFornecedor — só a captura do dado nesta rodada.
 */
export function permiteCreditoPorCnaeFornecedor(
  cnaesPermitidos: CnaeSecundario[] | null,
  cnaeFornecedor: string | null,
): boolean {
  if (!cnaesPermitidos || cnaesPermitidos.length === 0) return true;
  if (!cnaeFornecedor) return false;
  const digitos = somenteDigitos(cnaeFornecedor).padStart(7, "0");
  return cnaesPermitidos.some((c) => c.codigo === digitos);
}

/**
 * NCM da linha está na allowlist manual do cliente? Pura, sem banco. Mesma forma de
 * `permiteCreditoPorCnaeFornecedor`, mas chaveada pelo NCM da LINHA (`simulacao_entradas.ncm`), não
 * pelo CNAE do fornecedor. Lista vazia/null = sem restrição cadastrada → sempre elegível. NCM da
 * linha nulo/ausente = não elegível.
 *
 * Quando o cliente tem allowlist de NCM cadastrada e a linha tem NCM, esta função decide SOZINHA —
 * `calculo.ts` nem consulta `permiteCreditoPorCnaeFornecedor` nesse caso (ver
 * `domain/clientes/README.md` para o combinador completo). `padStart(8, "0")` é defensivo: o NCM da
 * linha já chega com exatamente 8 dígitos (validado por `ncmOuNulo` em
 * `domain/simulacoes/simulacao.service.ts`), então isto nunca deveria alterar o valor comparado.
 */
export function permiteCreditoPorNcm(
  ncmsPermitidos: NcmPermitido[] | null,
  ncmEfetivo: string | null,
): boolean {
  if (!ncmsPermitidos || ncmsPermitidos.length === 0) return true;
  if (!ncmEfetivo) return false;
  const digitos = somenteDigitos(ncmEfetivo).padStart(8, "0");
  return ncmsPermitidos.some((n) => n.codigo === digitos);
}
