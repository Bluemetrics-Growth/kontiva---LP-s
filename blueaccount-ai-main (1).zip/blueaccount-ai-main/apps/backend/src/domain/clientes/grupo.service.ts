import { Logger } from "@nestjs/common";
import type { EntityManager } from "typeorm";
import { In, IsNull, Like } from "typeorm";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";

const logger = new Logger("GrupoEconomico");

/**
 * Grupo econômico via hierarquia de clientes (Plano 3).
 *
 * Modelo: a holding também é um Cliente; membros apontam para ela via
 * `holding_id` (um nível só). O modo do grupo é derivado dos contratos:
 * - contrato ativo na holding  → 'consolidado' (1 cobrança agregada no grupo)
 * - contrato ativo só em membro(s) → 'por_empresa' (cobranças individuais,
 *   sempre pagas pela holding)
 *
 * Modo híbrido: no grupo consolidado, membros PODEM ter contrato ativo
 * próprio. Essas filhas consolidam o próprio VAC (contrato delas × relatórios
 * delas) e ficam fora da agregação de relatórios da holding; o total calculado
 * de cada uma entra como item na cobrança única da holding. Filha de grupo
 * nunca emite cobrança no próprio nome.
 *
 * Todas as funções recebem EntityManager para rodar dentro das transações/RLS
 * dos chamadores (consolidação, contratos, clientes).
 */

export type PapelGrupo = "isolado" | "holding" | "membro";
export type ModoGrupo = "consolidado" | "por_empresa" | "sem_contrato";

export type GrupoDoCliente = {
  papel: PapelGrupo;
  /** A holding do grupo (o próprio cliente quando papel = 'holding'). */
  holding: Cliente | null;
  /** Membros do grupo (exclui a holding). Vazio quando isolado. */
  membros: Cliente[];
};

export class GrupoEconomicoError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "GrupoEconomicoError";
  }
}

export async function getGrupoDoCliente(
  manager: EntityManager,
  escritorioId: string,
  clienteId: string,
): Promise<GrupoDoCliente> {
  const repo = manager.getRepository(Cliente);
  const cliente = await repo.findOne({ where: { id: clienteId, escritorio_id: escritorioId } });
  if (!cliente) {
    return { papel: "isolado", holding: null, membros: [] };
  }

  if (cliente.holding_id) {
    const holding = await repo.findOne({ where: { id: cliente.holding_id, escritorio_id: escritorioId } });
    if (!holding) {
      return { papel: "isolado", holding: null, membros: [] };
    }
    const membros = await repo.find({
      where: { holding_id: holding.id, escritorio_id: escritorioId },
      order: { razao_social: "ASC" },
    });
    return { papel: "membro", holding, membros };
  }

  const membros = await repo.find({
    where: { holding_id: cliente.id, escritorio_id: escritorioId },
    order: { razao_social: "ASC" },
  });
  if (membros.length > 0) {
    return { papel: "holding", holding: cliente, membros };
  }

  return { papel: "isolado", holding: null, membros: [] };
}

/**
 * Deriva o modo do grupo a partir de onde estão os contratos ativos.
 * Contrato ativo na holding → 'consolidado', independente de membros também
 * terem contratos próprios (modo híbrido: essas filhas calculam o próprio VAC
 * e entram como itens na cobrança da holding).
 */
export async function resolverModoGrupo(
  manager: EntityManager,
  escritorioId: string,
  holdingId: string,
  membros?: Cliente[],
): Promise<ModoGrupo> {
  const contratoRepo = manager.getRepository(Contrato);

  const contratoHolding = await contratoRepo.findOne({
    where: { cliente_id: holdingId, escritorio_id: escritorioId, contrato_ativo: true },
  });
  if (contratoHolding) return "consolidado";

  const membrosDoGrupo =
    membros ??
    (await manager.getRepository(Cliente).find({
      where: { holding_id: holdingId, escritorio_id: escritorioId },
    }));
  if (membrosDoGrupo.length === 0) return "sem_contrato";

  const contratoMembro = await contratoRepo.findOne({
    where: {
      cliente_id: In(membrosDoGrupo.map((m) => m.id)),
      escritorio_id: escritorioId,
      contrato_ativo: true,
    },
  });
  return contratoMembro ? "por_empresa" : "sem_contrato";
}

export type MembroComContrato = { cliente: Cliente; contrato: Contrato };

/**
 * Lista os membros do grupo que têm contrato ativo próprio (modo híbrido).
 * Essas filhas consolidam o próprio VAC e ficam fora da agregação da holding.
 */
export async function listarMembrosComContratoAtivo(
  manager: EntityManager,
  escritorioId: string,
  membros: Cliente[],
): Promise<MembroComContrato[]> {
  if (membros.length === 0) return [];

  const contratos = await manager.getRepository(Contrato).find({
    where: {
      cliente_id: In(membros.map((m) => m.id)),
      escritorio_id: escritorioId,
      contrato_ativo: true,
    },
  });

  const membrosPorId = new Map(membros.map((m) => [m.id, m]));
  return contratos
    .map((contrato) => {
      const cliente = membrosPorId.get(contrato.cliente_id);
      return cliente ? { cliente, contrato } : null;
    })
    .filter((item): item is MembroComContrato => item !== null);
}

export type AlvoConsolidacao = {
  clienteIdAlvo: string;
  redirecionado: boolean;
  /** true quando o alvo é uma holding em modo grupo consolidado. */
  grupoConsolidado: boolean;
  /**
   * Filha com contrato próprio em grupo consolidado (modo híbrido): consolida
   * o próprio VAC, mas a holding precisa ser re-consolidada em background para
   * atualizar o snapshot/itens dos membros. Aponta o id da holding.
   */
  holdingParaRefresh?: string;
};

/**
 * Resolve o cliente sob o qual a consolidação deve rodar: se o cliente é
 * membro (ou a própria holding) de um grupo em modo consolidado, o alvo é a
 * holding. Exceção (híbrido): filha com contrato ativo próprio consolida o
 * próprio VAC e sinaliza a holding para refresh. Fora disso, o próprio cliente.
 */
export async function resolverAlvoConsolidacao(
  manager: EntityManager,
  escritorioId: string,
  clienteId: string,
): Promise<AlvoConsolidacao> {
  const grupo = await getGrupoDoCliente(manager, escritorioId, clienteId);
  if (grupo.papel === "isolado" || !grupo.holding) {
    return { clienteIdAlvo: clienteId, redirecionado: false, grupoConsolidado: false };
  }

  const modo = await resolverModoGrupo(manager, escritorioId, grupo.holding.id, grupo.membros);
  if (modo !== "consolidado") {
    return { clienteIdAlvo: clienteId, redirecionado: false, grupoConsolidado: false };
  }

  if (grupo.papel === "membro") {
    const contratoProprio = await manager.getRepository(Contrato).findOne({
      where: { cliente_id: clienteId, escritorio_id: escritorioId, contrato_ativo: true },
    });
    if (contratoProprio) {
      return {
        clienteIdAlvo: clienteId,
        redirecionado: false,
        grupoConsolidado: false,
        holdingParaRefresh: grupo.holding.id,
      };
    }
  }

  return {
    clienteIdAlvo: grupo.holding.id,
    redirecionado: grupo.holding.id !== clienteId,
    grupoConsolidado: true,
  };
}

/**
 * Valida a associação de um cliente a uma holding (um nível só):
 * - holding existe no escritório e não é o próprio cliente;
 * - a holding-alvo não é membro de outro grupo;
 * - o cliente que vira membro não tem membros próprios.
 * Contratos ativos no cliente e na holding ao mesmo tempo são permitidos
 * (modo híbrido): a filha calcula o próprio VAC e vira item da cobrança da
 * holding.
 */
export async function validarAssociacaoHolding(
  manager: EntityManager,
  escritorioId: string,
  clienteId: string,
  holdingId: string,
): Promise<void> {
  if (holdingId === clienteId) {
    throw new GrupoEconomicoError("Um cliente não pode ser holding de si mesmo.");
  }

  const repo = manager.getRepository(Cliente);
  const holding = await repo.findOne({ where: { id: holdingId, escritorio_id: escritorioId } });
  if (!holding) {
    throw new GrupoEconomicoError("Holding não encontrada para o escritório.");
  }
  if (holding.holding_id) {
    throw new GrupoEconomicoError(
      "A holding escolhida já pertence a outro grupo — a hierarquia suporta apenas um nível (holding → empresas).",
    );
  }

  const membrosDoCliente = await repo.find({ where: { holding_id: clienteId, escritorio_id: escritorioId } });
  if (membrosDoCliente.length > 0) {
    throw new GrupoEconomicoError(
      "Este cliente é holding de outras empresas e não pode virar membro de um grupo — a hierarquia suporta apenas um nível.",
    );
  }
}

/**
 * Valida a ativação de um contrato para um cliente do ponto de vista do grupo
 * econômico. Com o modo híbrido, holding e membros podem ter contratos ativos
 * ao mesmo tempo — hoje não há restrição; a função permanece como ponto de
 * extensão e para manter os callsites de ativação estáveis.
 */
export async function validarAtivacaoContrato(
  _manager: EntityManager,
  _escritorioId: string,
  _clienteId: string,
): Promise<void> {
  return;
}

/**
 * Resolve quem paga uma cobrança individual: filha de grupo nunca emite no
 * próprio nome — a cobrança sai sempre no customer da holding. O campo
 * `pagador_grupo` está deprecado e é ignorado.
 */
export async function resolverClientePagador(
  manager: EntityManager,
  escritorioId: string,
  cliente: Cliente,
): Promise<Cliente> {
  if (!cliente.holding_id) return cliente;

  const holding = await manager.getRepository(Cliente).findOne({
    where: { id: cliente.holding_id, escritorio_id: escritorioId },
  });
  if (!holding) return cliente;

  return holding;
}

/**
 * Raiz (8 primeiros dígitos) de um CNPJ mascarado (`##.###.###/####-##`).
 * `null` para CPF (não tem raiz de empresa) ou documento fora do formato esperado —
 * cópia própria de `domain/simulacoes/nfe/classificador.ts:raizCnpj`, deliberadamente
 * duplicada aqui para não inverter a dependência de camada (`simulacoes` já depende
 * de `clientes`, não o contrário).
 */
export function raizCnpjMascarado(cnpjMascarado: string): string | null {
  const digitos = cnpjMascarado.replace(/\D+/g, "");
  if (digitos.length !== 14) return null;
  return digitos.slice(0, 8);
}

/** Reconstrói o prefixo mascarado (`"XX.XXX.XXX/"`) a partir de uma raiz de 8 dígitos, para busca por `LIKE` sobre a coluna `cnpj` (que guarda valor mascarado, não dígitos crus). */
export function prefixoMascaradoDaRaiz(raiz: string): string {
  return `${raiz.slice(0, 2)}.${raiz.slice(2, 5)}.${raiz.slice(5, 8)}/`;
}

/** `true` quando o CNPJ mascarado tem sufixo de filial `0001` (convenção de matriz). */
export function ehMatrizMascarada(cnpjMascarado: string): boolean {
  const digitos = cnpjMascarado.replace(/\D+/g, "");
  return digitos.length === 14 && digitos.slice(8, 12) === "0001";
}

/**
 * Tenta vincular `membroId` a `holdingId` reaproveitando `validarAssociacaoHolding`.
 * Nunca lança: é chamado a partir de sincronização automática best-effort, então uma
 * candidata inválida (ex.: já é holding de outros) é só pulada, com aviso no log —
 * nunca pode bloquear a criação do cliente que disparou a busca.
 */
async function tentarVincular(
  manager: EntityManager,
  escritorioId: string,
  membroId: string,
  holdingId: string,
): Promise<boolean> {
  try {
    await validarAssociacaoHolding(manager, escritorioId, membroId, holdingId);
  } catch (error) {
    if (error instanceof GrupoEconomicoError) {
      logger.warn(
        `Auto-associação de grupo econômico pulada para cliente ${membroId} → holding ${holdingId}: ${error.message}`,
      );
      return false;
    }
    throw error;
  }

  await manager
    .getRepository(Cliente)
    .update({ id: membroId, escritorio_id: escritorioId }, { holding_id: holdingId });
  return true;
}

/**
 * Auto-associação de grupo econômico por raiz de CNPJ (matriz ↔ filiais). Chamada
 * pelos dois choke points de criação de cliente (`createCliente`,
 * `findOrCreateClienteByCnpj` em `cliente.service.ts`), dentro da mesma transação.
 *
 * - Cliente novo é **matriz** (sufixo `0001`): procura filiais já cadastradas no
 *   escritório com a mesma raiz e ainda sem grupo (`holding_id IS NULL`), e associa
 *   cada uma a esta matriz.
 * - Cliente novo é **filial**: procura a matriz já cadastrada (mesma raiz, sufixo
 *   `0001`) e se associa a ela.
 *
 * CPF (sem raiz de CNPJ) e cliente sem candidata correspondente são no-op. Best-effort:
 * nunca lança — ver `tentarVincular`. Quando o próprio `cliente` (filial) é vinculado,
 * `cliente.holding_id` é atualizado em memória além de persistido, para o chamador que
 * já carrega essa referência (ex.: `createCliente`) devolver o valor atualizado.
 */
export async function sincronizarGrupoEconomicoPorCnpj(
  manager: EntityManager,
  escritorioId: string,
  cliente: Cliente,
): Promise<void> {
  const raiz = raizCnpjMascarado(cliente.cnpj);
  if (!raiz) return;

  const prefixo = prefixoMascaradoDaRaiz(raiz);
  const repo = manager.getRepository(Cliente);

  if (ehMatrizMascarada(cliente.cnpj)) {
    const candidatas = await repo.find({
      where: { escritorio_id: escritorioId, holding_id: IsNull(), cnpj: Like(`${prefixo}%`) },
    });
    for (const candidata of candidatas) {
      if (candidata.id === cliente.id || ehMatrizMascarada(candidata.cnpj)) continue;
      await tentarVincular(manager, escritorioId, candidata.id, cliente.id);
    }
    return;
  }

  if (cliente.holding_id) return;

  const matriz = await repo.findOne({
    where: { escritorio_id: escritorioId, cnpj: Like(`${prefixo}0001-%`) },
    order: { created_at: "ASC" },
  });
  if (!matriz || matriz.id === cliente.id) return;

  const vinculado = await tentarVincular(manager, escritorioId, cliente.id, matriz.id);
  if (vinculado) cliente.holding_id = matriz.id;
}
