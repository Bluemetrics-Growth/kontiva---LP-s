import { AppDataSource } from "../../database/data-source.js";
import { NcmReferencia } from "../../database/modules/public/entities/ncm-referencia.entity.js";
import { type Repository } from "typeorm";
import type { QueryDeepPartialEntity } from "typeorm/query-builder/QueryPartialEntity.js";
import { NcmIndisponivelError, NcmNaoEncontradoError, requisitarNcm } from "../../infrastructure/external-services/brasilapi-ncm.client.js";
import { somenteDigitos } from "../texto.js";

export { NcmIndisponivelError, NcmNaoEncontradoError };

type NcmBaseArmazenado = Pick<NcmReferencia,
  "codigo" | "descricao" | "descricoes_hierarquia" | "data_inicio" | "data_fim" |
  "tipo_ato" | "numero_ato" | "ano_ato"
>;
type NcmArmazenado = NcmBaseArmazenado & Partial<Pick<NcmReferencia,
  "fator_ibs" | "fator_cbs" | "fatores_configurados" | "aplicacao_automatica" |
  "fundamento_legal_fatores" | "condicoes_aplicacao_fatores" | "origem_configuracao_fatores"
>>;
export type NcmReferenciaListada = Omit<NcmArmazenado, "descricoes_hierarquia"> & { descricao_oficial: string; descricao: string; descricoes_hierarquia: string[] };
export type FatoresNcmResolvidos = {
  ncm: string;
  codigo_regra: string | null;
  fator_ibs_sugerido: number;
  fator_cbs_sugerido: number;
  fator_ibs_automatico: number;
  fator_cbs_automatico: number;
  aplicacao_automatica: boolean;
  requer_confirmacao: boolean;
  fundamento_legal: string | null;
  condicoes_aplicacao: string | null;
};

function normalizarNcm(codigoBruto: unknown): string | null {
  const codigo = somenteDigitos(codigoBruto);
  return codigo.length === 8 ? codigo : null;
}

async function garantirBanco(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

function apresentarNcm(ncm: NcmArmazenado): NcmReferenciaListada {
  const descricoesHierarquia = ncm.descricoes_hierarquia ?? [];
  return {
    ...ncm,
    descricao_oficial: ncm.descricao,
    descricao: [...descricoesHierarquia, ncm.descricao.replace(/^[-\s]+/, "")].join(" — "),
    descricoes_hierarquia: descricoesHierarquia,
    fator_ibs: Number(ncm.fator_ibs ?? 1),
    fator_cbs: Number(ncm.fator_cbs ?? 1),
    fatores_configurados: ncm.fatores_configurados ?? false,
    // Regra configurada é sempre automática: o escopo hierárquico do código decide o fator, e
    // eventual exclusão precisa existir como regra filha mais específica com fator 1.
    aplicacao_automatica: ncm.fatores_configurados ? true : ncm.aplicacao_automatica ?? true,
    fundamento_legal_fatores: ncm.fundamento_legal_fatores ?? null,
    condicoes_aplicacao_fatores: ncm.condicoes_aplicacao_fatores ?? null,
    origem_configuracao_fatores: ncm.origem_configuracao_fatores ?? null,
  };
}

async function apresentarNcmComRegra(ncm: NcmArmazenado): Promise<NcmReferenciaListada> {
  const apresentado = apresentarNcm(ncm);
  if (ncm.codigo.length !== 8) return apresentado;
  const regra = await resolverFatoresPorNcm(ncm.codigo);
  if (!regra?.codigo_regra) return apresentado;
  return {
    ...apresentado,
    fator_ibs: regra.fator_ibs_sugerido,
    fator_cbs: regra.fator_cbs_sugerido,
    fatores_configurados: true,
    aplicacao_automatica: regra.aplicacao_automatica,
    fundamento_legal_fatores: regra.fundamento_legal,
    condicoes_aplicacao_fatores: regra.condicoes_aplicacao,
    origem_configuracao_fatores: `regra:${regra.codigo_regra}`,
  };
}

const CAMPOS_NCM = [
  "ncm.codigo", "ncm.descricao", "ncm.descricoes_hierarquia", "ncm.data_inicio", "ncm.data_fim",
  "ncm.tipo_ato", "ncm.numero_ato", "ncm.ano_ato", "ncm.fator_ibs", "ncm.fator_cbs",
  "ncm.fatores_configurados", "ncm.aplicacao_automatica", "ncm.fundamento_legal_fatores",
  "ncm.condicoes_aplicacao_fatores", "ncm.origem_configuracao_fatores",
] as const;

/** Resolve somente o catálogo local: ausência de regra configurada significa NCM padrão de 100%. */
export async function resolverFatoresPorNcm(codigoBruto: unknown): Promise<FatoresNcmResolvidos | null> {
  const ncm = normalizarNcm(codigoBruto);
  if (!ncm) return null;
  await garantirBanco();
  const regra = await AppDataSource.getRepository(NcmReferencia)
    .createQueryBuilder("ncm")
    .where("ncm.fatores_configurados = true")
    .andWhere(":ncm LIKE ncm.codigo || '%'", { ncm })
    .orderBy("length(ncm.codigo)", "DESC")
    .addOrderBy("ncm.codigo", "ASC")
    .getOne();
  const sugeridoIbs = Number(regra?.fator_ibs ?? 1);
  const sugeridoCbs = Number(regra?.fator_cbs ?? 1);
  return {
    ncm,
    codigo_regra: regra?.codigo ?? null,
    fator_ibs_sugerido: sugeridoIbs,
    fator_cbs_sugerido: sugeridoCbs,
    fator_ibs_automatico: sugeridoIbs,
    fator_cbs_automatico: sugeridoCbs,
    aplicacao_automatica: true,
    requer_confirmacao: false,
    fundamento_legal: regra?.fundamento_legal_fatores ?? null,
    condicoes_aplicacao: regra?.condicoes_aplicacao_fatores ?? null,
  };
}

async function hierarquiaCacheada(repositorio: Repository<NcmReferencia>, codigo: string): Promise<string[]> {
  const registros = await repositorio.find();
  return registros
    .filter((ncm) => ncm.codigo.length < codigo.length && codigo.startsWith(ncm.codigo))
    .sort((a, b) => a.codigo.length - b.codigo.length)
    .map((ncm) => ncm.descricao.replace(/^[-\s]+/, "").replace(/:\s*$/, ""));
}

export async function consultarNcm(codigoBruto: unknown): Promise<NcmReferenciaListada | null> {
  const codigo = normalizarNcm(codigoBruto);
  if (!codigo) return null;
  await garantirBanco();
  const repositorio = AppDataSource.getRepository(NcmReferencia);
  const cacheado = await repositorio.findOneBy({ codigo });
  // Registros criados antes da árvore são enriquecidos sob demanda, sem um backfill global.
  if (cacheado && cacheado.descricoes_hierarquia !== null) return apresentarNcmComRegra(cacheado);
  try {
    const descricoesCacheadas = await hierarquiaCacheada(repositorio, codigo);
    const resultado = await requisitarNcm(codigo, descricoesCacheadas.length === 0);
    if (descricoesCacheadas.length > 0) resultado.descricoes_hierarquia = descricoesCacheadas;
    const { nos_intermediarios, ...ncmFinal } = resultado;
    await repositorio.upsert([...nos_intermediarios, ncmFinal] as QueryDeepPartialEntity<NcmReferencia>[], ["codigo"]);
    return apresentarNcmComRegra(resultado);
  } catch (erro) {
    if (erro instanceof NcmNaoEncontradoError) return null;
    throw erro;
  }
}

export async function listarNcmsReferencia(opcoes: { pagina?: unknown; tamanho?: unknown; busca?: unknown } = {}) {
  const pagina = Math.max(1, Number.parseInt(String(opcoes.pagina ?? "1"), 10) || 1);
  const tamanho = Math.min(100, Math.max(1, Number.parseInt(String(opcoes.tamanho ?? "25"), 10) || 25));
  const busca = typeof opcoes.busca === "string" ? opcoes.busca.trim().slice(0, 100) : "";
  await garantirBanco();
  const consulta = AppDataSource.getRepository(NcmReferencia)
    .createQueryBuilder("ncm")
    .select([...CAMPOS_NCM])
    .orderBy("ncm.codigo", "ASC")
    .skip((pagina - 1) * tamanho)
    .take(tamanho);
  if (busca) consulta.where("ncm.codigo ILIKE :busca OR ncm.descricao ILIKE :busca", { busca: `%${somenteDigitos(busca) || busca}%` });
  const [items, total] = await consulta.getManyAndCount();
  return { items: await Promise.all((items as NcmArmazenado[]).map(apresentarNcmComRegra)), pagina, tamanho, total, total_paginas: Math.max(1, Math.ceil(total / tamanho)) };
}

export async function atualizarFatoresNcm(codigoBruto: unknown, input: Record<string, unknown>): Promise<NcmReferenciaListada | null> {
  const codigo = somenteDigitos(codigoBruto);
  if (codigo.length < 2 || codigo.length > 8) return null;
  await garantirBanco();
  const repositorio = AppDataSource.getRepository(NcmReferencia);
  const ncm = await repositorio.findOneBy({ codigo });
  if (!ncm) return null;
  for (const campo of ["fator_ibs", "fator_cbs"] as const) {
    if (!(campo in input)) continue;
    const valor = Number(input[campo]);
    if (!Number.isFinite(valor) || valor < 0 || valor > 1) throw new Error(`${campo} deve estar entre 0 e 1.`);
    ncm[campo] = valor;
  }
  // Invariante do catálogo: toda regra configurada aplica seu fator. Não existe modo condicionado;
  // uma exceção legal deve ser cadastrada no código filho com fator integral.
  ncm.aplicacao_automatica = true;
  if ("fundamento_legal_fatores" in input) ncm.fundamento_legal_fatores = typeof input.fundamento_legal_fatores === "string" ? input.fundamento_legal_fatores.trim() || null : null;
  if ("condicoes_aplicacao_fatores" in input) ncm.condicoes_aplicacao_fatores = typeof input.condicoes_aplicacao_fatores === "string" ? input.condicoes_aplicacao_fatores.trim() || null : null;
  ncm.fatores_configurados = true;
  ncm.origem_configuracao_fatores = "admin-plataforma";
  return apresentarNcm(await repositorio.save(ncm));
}
