import { AppDataSource } from "../../database/data-source.js";
import { CnaeReferencia } from "../../database/modules/public/entities/cnae-referencia.entity.js";
import type { QueryDeepPartialEntity } from "typeorm/query-builder/QueryPartialEntity.js";
import {
  requisitarCnae,
  CnaeNaoEncontradoError,
  CnaeIndisponivelError,
} from "../../infrastructure/external-services/ibge-cnae.client.js";
import { somenteDigitos } from "../texto.js";

export { CnaeNaoEncontradoError, CnaeIndisponivelError };

export type CnaeReferenciaListada = Pick<CnaeReferencia,
  "codigo" | "descricao" | "grupo_codigo" | "grupo_descricao" | "classe_codigo" | "classe_descricao" | "atividades" | "observacoes">;

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

/**
 * Consulta a classificação de um código CNAE, com cache compartilhado (sem TTL) em
 * `cnaes_referencia`.
 *
 * Devolve `null` quando o código normalizado não existe na classificação do IBGE — nunca lança para
 * esse caso, para o chamador tratar como "não encontrado" (404) sem precisar de try/catch. Devolve
 * `null` também quando o valor de entrada não tem nenhum dígito (nada para consultar), sem tocar rede
 * nem banco. Já indisponibilidade transitória (`CnaeIndisponivelError`) É relançada — nunca é
 * confundida com "não encontrado", para não ensinar ao frontend que um código válido não existe só
 * porque o IBGE estava fora do ar.
 *
 * Resultado negativo nunca é cacheado: uma futura revisão do IBGE pode passar a reconhecer um código
 * que hoje não existe.
 */
export async function consultarCnae(codigoBruto: unknown): Promise<{ codigo: string; descricao: string } | null> {
  const digitos = somenteDigitos(codigoBruto);
  if (!digitos) return null;

  const codigo = digitos.padStart(7, "0").slice(0, 7);

  await ensureDatabase();
  const repo = AppDataSource.getRepository(CnaeReferencia);

  const cacheado = await repo.findOneBy({ codigo });
  if (cacheado?.resposta_ibge) {
    return { codigo: cacheado.codigo, descricao: cacheado.descricao };
  }

  try {
    const resultado = await requisitarCnae(codigo);
    // O DeepPartial do TypeORM não aceita `Record<string, unknown>` numa coluna jsonb; o resultado
    // já corresponde exatamente ao shape persistido de CnaeReferencia.
    await repo.upsert(resultado as QueryDeepPartialEntity<CnaeReferencia>, ["codigo"]);
    return { codigo: resultado.codigo, descricao: resultado.descricao };
  } catch (err) {
    if (err instanceof CnaeNaoEncontradoError) return null;
    throw err;
  }
}

/** Lista o conhecimento CNAE já coletado, sem expor o snapshot bruto do IBGE. */
export async function listarCnaesReferencia(opcoes: { pagina?: unknown; tamanho?: unknown; busca?: unknown } = {}) {
  const pagina = Math.max(1, Number.parseInt(String(opcoes.pagina ?? "1"), 10) || 1);
  const tamanho = Math.min(100, Math.max(1, Number.parseInt(String(opcoes.tamanho ?? "25"), 10) || 25));
  const busca = typeof opcoes.busca === "string" ? opcoes.busca.trim().slice(0, 100) : "";

  await ensureDatabase();
  const consulta = AppDataSource.getRepository(CnaeReferencia)
    .createQueryBuilder("cnae")
    .select([
      "cnae.codigo", "cnae.descricao", "cnae.grupo_codigo", "cnae.grupo_descricao",
      "cnae.classe_codigo", "cnae.classe_descricao", "cnae.atividades", "cnae.observacoes",
    ])
    .orderBy("cnae.codigo", "ASC")
    .skip((pagina - 1) * tamanho)
    .take(tamanho);

  if (busca) {
    consulta.where("cnae.codigo ILIKE :busca OR cnae.descricao ILIKE :busca OR cnae.grupo_descricao ILIKE :busca", { busca: `%${busca}%` });
  }

  const [items, total] = await consulta.getManyAndCount();
  return { items: items as CnaeReferenciaListada[], pagina, tamanho, total, total_paginas: Math.max(1, Math.ceil(total / tamanho)) };
}
