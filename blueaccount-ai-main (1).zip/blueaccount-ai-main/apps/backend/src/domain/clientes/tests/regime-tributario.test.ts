import { describe, expect, it } from "vitest";
import {
  REGIMES_TRIBUTARIOS,
  REGIME_PESSOA_FISICA,
  RegimeTributarioInvalidoError,
  normalizarRegimeParaDocumento,
  normalizarRegimeTributario,
  regimesPermitidosParaDocumento,
  validarRegimeComDocumento,
} from "../regime-tributario.js";

const CNPJ = "12.345.678/0001-90";
const CPF = "046.318.779-52";

describe("REGIMES_TRIBUTARIOS", () => {
  it("é exatamente a lista canônica esperada", () => {
    // Trava a lista: divergência com as cópias do MCP/frontend/prompts quebra aqui.
    expect([...REGIMES_TRIBUTARIOS]).toEqual([
      "Simples Nacional",
      "Lucro Presumido",
      "Lucro Real",
      "MEI",
      "Pessoa Física",
    ]);
  });
});

describe("normalizarRegimeTributario", () => {
  it("devolve null para ausência", () => {
    expect(normalizarRegimeTributario(null)).toBeNull();
    expect(normalizarRegimeTributario(undefined)).toBeNull();
    expect(normalizarRegimeTributario("")).toBeNull();
    expect(normalizarRegimeTributario("   ")).toBeNull();
  });

  it("é idempotente nos valores canônicos", () => {
    for (const regime of REGIMES_TRIBUTARIOS) {
      expect(normalizarRegimeTributario(regime)).toBe(regime);
    }
  });

  it.each([
    ["Simples", "Simples Nacional"],
    ["simples", "Simples Nacional"],
    ["SIMPLES NACIONAL", "Simples Nacional"],
    ["  simples   nacional  ", "Simples Nacional"],
    ["SN", "Simples Nacional"],
    ["lucro presumido", "Lucro Presumido"],
    ["Presumido", "Lucro Presumido"],
    ["LUCRO REAL", "Lucro Real"],
    ["real", "Lucro Real"],
    ["mei", "MEI"],
    ["Microempreendedor Individual", "MEI"],
    ["pessoa fisica", "Pessoa Física"],
    ["Pessoa Fisica", "Pessoa Física"],
    ["PESSOA FÍSICA", "Pessoa Física"],
    ["PF", "Pessoa Física"],
    ["autônomo", "Pessoa Física"],
    ["autonomo", "Pessoa Física"],
    ["Profissional Liberal", "Pessoa Física"],
  ])("normaliza %j para %j", (entrada, esperado) => {
    expect(normalizarRegimeTributario(entrada)).toBe(esperado);
  });

  it("lança em valor irreconhecível em vez de devolver null", () => {
    // Silenciar aqui apagaria o sinal de que a extração errou.
    for (const invalido of ["Foo", "Simples Nac.", "Lucro", "MEI 2", "pessoa juridica"]) {
      expect(() => normalizarRegimeTributario(invalido)).toThrow(RegimeTributarioInvalidoError);
    }
  });
});

describe("validarRegimeComDocumento", () => {
  const pessoaJuridica = REGIMES_TRIBUTARIOS.filter((r) => r !== REGIME_PESSOA_FISICA);

  it("aceita Pessoa Física com CPF", () => {
    expect(() => validarRegimeComDocumento(REGIME_PESSOA_FISICA, CPF)).not.toThrow();
    expect(() => validarRegimeComDocumento(REGIME_PESSOA_FISICA, "04631877952")).not.toThrow();
  });

  it.each(pessoaJuridica)("aceita %s com CNPJ", (regime) => {
    expect(() => validarRegimeComDocumento(regime, CNPJ)).not.toThrow();
    expect(() => validarRegimeComDocumento(regime, "12345678000190")).not.toThrow();
  });

  it("rejeita Pessoa Física com CNPJ", () => {
    expect(() => validarRegimeComDocumento(REGIME_PESSOA_FISICA, CNPJ)).toThrow(RegimeTributarioInvalidoError);
  });

  it.each(pessoaJuridica)("rejeita %s com CPF", (regime) => {
    expect(() => validarRegimeComDocumento(regime, CPF)).toThrow(RegimeTributarioInvalidoError);
  });

  it("não valida quando falta um dos dois", () => {
    expect(() => validarRegimeComDocumento(null, CPF)).not.toThrow();
    expect(() => validarRegimeComDocumento(REGIME_PESSOA_FISICA, null)).not.toThrow();
    expect(() => validarRegimeComDocumento(REGIME_PESSOA_FISICA, undefined)).not.toThrow();
  });

  it("não valida documento de comprimento indefinido", () => {
    // Fixtures antigas e dado sujo têm documento fora de 11/14; não é aqui que se
    // reclama disso (normalizarCnpj já faz), então o par não é checado.
    expect(() => validarRegimeComDocumento("Lucro Real", "123")).not.toThrow();
  });

  it("cita os dois campos na mensagem, para o agente saber o que revisar", () => {
    expect(() => validarRegimeComDocumento("Lucro Real", CPF)).toThrow(/Lucro Real/);
    expect(() => validarRegimeComDocumento("Lucro Real", CPF)).toThrow(/046\.318\.779-52/);
    expect(() => validarRegimeComDocumento("Lucro Real", CPF)).toThrow(/11 dígitos/);
  });
});

describe("normalizarRegimeParaDocumento", () => {
  it("normaliza e valida numa passada", () => {
    expect(normalizarRegimeParaDocumento("simples", CNPJ)).toBe("Simples Nacional");
    expect(normalizarRegimeParaDocumento("PF", CPF)).toBe("Pessoa Física");
    expect(normalizarRegimeParaDocumento(null, CNPJ)).toBeNull();
  });

  it("propaga o erro do par inconsistente", () => {
    expect(() => normalizarRegimeParaDocumento("simples", CPF)).toThrow(RegimeTributarioInvalidoError);
  });
});

describe("regimesPermitidosParaDocumento", () => {
  it("CPF permite só Pessoa Física", () => {
    expect(regimesPermitidosParaDocumento(CPF)).toEqual([REGIME_PESSOA_FISICA]);
  });

  it("CNPJ permite os outros quatro", () => {
    expect(regimesPermitidosParaDocumento(CNPJ)).toEqual([
      "Simples Nacional",
      "Lucro Presumido",
      "Lucro Real",
      "MEI",
    ]);
  });

  it("documento ausente ou indefinido permite todos", () => {
    expect(regimesPermitidosParaDocumento(null)).toEqual([...REGIMES_TRIBUTARIOS]);
    expect(regimesPermitidosParaDocumento("123")).toEqual([...REGIMES_TRIBUTARIOS]);
  });
});
