import { beforeEach, describe, expect, it, vi } from "vitest";

// Só `createCliente` é dublado. `normalizarCnpj` e as classes de erro continuam
// reais: é a validação de CNPJ e o `instanceof ClienteJaExisteError` de verdade que
// decidem o resultado de cada item.
const criar = vi.hoisted(() => vi.fn());

vi.mock("../cliente.service.js", async (importOriginal) => {
  const original = await importOriginal<typeof import("../cliente.service.js")>();
  return { ...original, createCliente: criar };
});

const { ClienteJaExisteError } = await import("../cliente.service.js");
const { LIMITE_LOTE_CLIENTES, importarClientesEmLote } = await import(
  "../importar-clientes-lote.js"
);

const ESCRITORIO = "11111111-1111-1111-1111-111111111111";

function clienteCriado(cnpj: string, razaoSocial = "RAZAO DA API LTDA") {
  return { ok: true as const, cliente: { id: `id-${cnpj}`, cnpj, razao_social: razaoSocial } };
}

describe("importarClientesEmLote", () => {
  beforeEach(() => {
    criar.mockReset();
  });

  it("cria cada empresa reusando createCliente", async () => {
    criar.mockImplementation((_e: string, input: { cnpj: string }) =>
      Promise.resolve(clienteCriado(input.cnpj)),
    );

    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101", razao_social: "ALFA", dominio_empresa_id: 1234 },
      { cnpj: "22222222000202", razao_social: "BETA", dominio_empresa_id: 1235 },
    ]);

    expect(criar).toHaveBeenCalledTimes(2);
    expect(resumo).toMatchObject({ total: 2, criados: 2, ja_existentes: 0, com_erro: 0 });
    expect(resumo.resultados[0]).toMatchObject({
      indice: 0,
      dominio_empresa_id: 1234,
      situacao: "criado",
      cliente_id: "id-11111111000101",
    });
  });

  it("devolve a razao_social gravada, nao a enviada", async () => {
    // Em `createCliente` a consulta pública de CNPJ vence sobre o nome enviado.
    criar.mockResolvedValue(clienteCriado("11111111000101", "NOME OFICIAL DA RECEITA SA"));

    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101", razao_social: "NOME DO DOMINIO" },
    ]);

    expect(resumo.resultados[0].razao_social).toBe("NOME OFICIAL DA RECEITA SA");
  });

  it("envia razao_social do Dominio apenas como fallback", async () => {
    criar.mockResolvedValue(clienteCriado("11111111000101"));

    await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101", razao_social: "ALFA", nome_fantasia: "AL", uf: "SP" },
    ]);

    expect(criar).toHaveBeenCalledWith(ESCRITORIO, {
      cnpj: "11111111000101",
      razao_social: "ALFA",
      nome_fantasia: "AL",
      uf: "SP",
    });
  });

  it("cliente existente volta como ja_existe, nao como erro", async () => {
    // É o que torna seguro reenviar uma página que falhou no meio.
    criar.mockRejectedValue(new ClienteJaExisteError("Já existe um cliente com este identificador."));

    const resumo = await importarClientesEmLote(ESCRITORIO, [{ cnpj: "11111111000101" }]);

    expect(resumo).toMatchObject({ criados: 0, ja_existentes: 1, com_erro: 0 });
    expect(resumo.resultados[0].situacao).toBe("ja_existe");
    expect(resumo.resultados[0].erro).toBeNull();
  });

  it("sinaliza CNPJ repetido dentro do mesmo lote sem chamar createCliente de novo", async () => {
    // `geempre` tem o mesmo CNPJ em codi_emp diferentes (matriz e filial).
    criar.mockResolvedValue(clienteCriado("22222222000202"));

    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "22222222000202", dominio_empresa_id: 1235 },
      { cnpj: "22.222.222/0002-02", dominio_empresa_id: 1236 },
    ]);

    expect(criar).toHaveBeenCalledTimes(1);
    expect(resumo).toMatchObject({ criados: 1, duplicados_no_lote: 1 });
    expect(resumo.resultados[1]).toMatchObject({
      situacao: "duplicado_no_lote",
      dominio_empresa_id: 1236,
    });
  });

  it("um item ruim nao descarta os bons", async () => {
    criar.mockImplementation((_e: string, input: { cnpj: string }) =>
      input.cnpj === "33333333000303"
        ? Promise.reject(new Error("falha de rede na consulta de CNPJ"))
        : Promise.resolve(clienteCriado(input.cnpj)),
    );

    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101" },
      { cnpj: "33333333000303" },
      { cnpj: "22222222000202" },
    ]);

    expect(resumo).toMatchObject({ total: 3, criados: 2, com_erro: 1 });
    expect(resumo.resultados.map((r) => r.situacao)).toEqual(["criado", "erro", "criado"]);
    expect(resumo.resultados[1].erro).toContain("falha de rede");
  });

  it("cnpj ausente ou invalido vira erro do item, sem chamar createCliente", async () => {
    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "" },
      { cnpj: "123" },
      { cnpj: null },
    ]);

    expect(criar).not.toHaveBeenCalled();
    expect(resumo).toMatchObject({ total: 3, com_erro: 3 });
    expect(resumo.resultados[0].erro).toContain("cnpj é obrigatório");
    expect(resumo.resultados[1].erro).toContain("14 dígitos");
  });

  it("processa sequencialmente", async () => {
    // Cada item faz uma consulta de CNPJ na rede, e criações concorrentes do mesmo
    // CNPJ correriam entre si.
    let emVoo = 0;
    let maximoEmVoo = 0;
    criar.mockImplementation(async (_e: string, input: { cnpj: string }) => {
      emVoo += 1;
      maximoEmVoo = Math.max(maximoEmVoo, emVoo);
      await new Promise((resolve) => setTimeout(resolve, 5));
      emVoo -= 1;
      return clienteCriado(input.cnpj);
    });

    await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101" },
      { cnpj: "22222222000202" },
      { cnpj: "33333333000303" },
    ]);

    expect(maximoEmVoo).toBe(1);
  });

  it("aceita dominio_empresa_id em string e ignora valor nao numerico", async () => {
    criar.mockResolvedValue(clienteCriado("11111111000101"));

    const resumo = await importarClientesEmLote(ESCRITORIO, [
      { cnpj: "11111111000101", dominio_empresa_id: "1234" },
      { cnpj: "22222222000202", dominio_empresa_id: "abc" },
    ]);

    expect(resumo.resultados[0].dominio_empresa_id).toBe(1234);
    expect(resumo.resultados[1].dominio_empresa_id).toBeNull();
  });

  it("expoe o teto de itens por requisicao", () => {
    expect(LIMITE_LOTE_CLIENTES).toBe(100);
  });
});
