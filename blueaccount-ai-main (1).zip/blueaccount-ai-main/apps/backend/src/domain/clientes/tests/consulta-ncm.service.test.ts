import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const consulta = { select: vi.fn(), orderBy: vi.fn(), addOrderBy: vi.fn(), skip: vi.fn(), take: vi.fn(), where: vi.fn(), andWhere: vi.fn(), getOne: vi.fn(), getManyAndCount: vi.fn() };
  consulta.select.mockReturnValue(consulta); consulta.orderBy.mockReturnValue(consulta); consulta.addOrderBy.mockReturnValue(consulta); consulta.skip.mockReturnValue(consulta); consulta.take.mockReturnValue(consulta); consulta.where.mockReturnValue(consulta); consulta.andWhere.mockReturnValue(consulta);
  const ncmRepo = { findOneBy: vi.fn(), find: vi.fn(), upsert: vi.fn(), save: vi.fn(async (ncm) => ncm), createQueryBuilder: vi.fn(() => consulta) };
  return { ncmRepo, consulta, requisitarNcm: vi.fn(), AppDataSource: { isInitialized: true, initialize: vi.fn(), getRepository: vi.fn(() => ncmRepo) } };
});
vi.mock("../../../database/data-source.js", () => ({ AppDataSource: mocks.AppDataSource }));
vi.mock("../../../infrastructure/external-services/brasilapi-ncm.client.js", async () => ({
  ...(await vi.importActual<typeof import("../../../infrastructure/external-services/brasilapi-ncm.client.js")>("../../../infrastructure/external-services/brasilapi-ncm.client.js")),
  requisitarNcm: mocks.requisitarNcm,
}));
const { atualizarFatoresNcm, consultarNcm, resolverFatoresPorNcm } = await import("../consulta-ncm.service.js");
const { NcmNaoEncontradoError, NcmIndisponivelError } = await import("../../../infrastructure/external-services/brasilapi-ncm.client.js");
const resultado = { codigo: "33051000", descricao: "- Xampus", descricoes_hierarquia: ["Preparações capilares"], data_inicio: "2022-04-01", data_fim: "9999-12-31", tipo_ato: "Res Camex", numero_ato: "000272", ano_ato: "2021", resposta_brasilapi: { codigo: "3305.10.00" }, resposta_arvore_brasilapi: [], nos_intermediarios: [{ codigo: "3305", descricao: "Preparações capilares", descricoes_hierarquia: [], data_inicio: null, data_fim: null, tipo_ato: null, numero_ato: null, ano_ato: null, resposta_brasilapi: { codigo: "33.05" } }] };

describe("domain/clientes/consultarNcm", () => {
  beforeEach(() => { vi.clearAllMocks(); mocks.ncmRepo.find.mockResolvedValue([]); });
  it("usa cache sem TTL", async () => {
    mocks.ncmRepo.findOneBy.mockResolvedValue(resultado);
    await expect(consultarNcm("3305.10.00")).resolves.toMatchObject({ codigo: "33051000", descricao: "Preparações capilares — Xampus", descricao_oficial: "- Xampus" });
    expect(mocks.requisitarNcm).not.toHaveBeenCalled();
  });
  it("persiste o primeiro resultado da fonte", async () => {
    mocks.ncmRepo.findOneBy.mockResolvedValue(null); mocks.requisitarNcm.mockResolvedValue(resultado);
    await expect(consultarNcm("3305.10.00")).resolves.toMatchObject({ codigo: "33051000" });
    expect(mocks.requisitarNcm).toHaveBeenCalledWith("33051000", true);
    expect(mocks.ncmRepo.upsert).toHaveBeenCalledWith(expect.arrayContaining([expect.objectContaining({ codigo: "3305" }), expect.objectContaining({ codigo: "33051000" })]), ["codigo"]);
  });
  it("persiste os nós intermediários e evita nova busca de árvore para a mesma família", async () => {
    const intermediarios = [
      { codigo: "8411", descricao: "Turborreatores", descricoes_hierarquia: [], data_inicio: null, data_fim: null, tipo_ato: null, numero_ato: null, ano_ato: null, resposta_brasilapi: {} },
      { codigo: "84112", descricao: "- Turbopropulsores:", descricoes_hierarquia: ["Turborreatores"], data_inicio: null, data_fim: null, tipo_ato: null, numero_ato: null, ano_ato: null, resposta_brasilapi: {} },
    ];
    mocks.ncmRepo.findOneBy.mockResolvedValue(null);
    mocks.requisitarNcm.mockResolvedValue({ ...resultado, codigo: "84112100", descricao: "-- De potência não superior a 1.100 kW", descricoes_hierarquia: [], nos_intermediarios: [] });
    mocks.ncmRepo.find.mockResolvedValue(intermediarios);
    await expect(consultarNcm("84112100")).resolves.toMatchObject({ descricao: "Turborreatores — Turbopropulsores — De potência não superior a 1.100 kW" });
    expect(mocks.requisitarNcm).toHaveBeenCalledWith("84112100", false);
  });
  it("não consulta código inválido, não cacheia 404 e relança indisponibilidade", async () => {
    await expect(consultarNcm("3305")).resolves.toBeNull();
    expect(mocks.AppDataSource.getRepository).not.toHaveBeenCalled();
    mocks.ncmRepo.findOneBy.mockResolvedValue(null); mocks.requisitarNcm.mockRejectedValue(new NcmNaoEncontradoError("99999999"));
    await expect(consultarNcm("99999999")).resolves.toBeNull();
    expect(mocks.ncmRepo.upsert).not.toHaveBeenCalled();
    mocks.requisitarNcm.mockRejectedValue(new NcmIndisponivelError("timeout"));
    await expect(consultarNcm("33051000")).rejects.toBeInstanceOf(NcmIndisponivelError);
  });
  it("lista o cache por código, com busca e paginação limitada", async () => {
    mocks.consulta.getManyAndCount.mockResolvedValue([[resultado], 1]);
    const { listarNcmsReferencia } = await import("../consulta-ncm.service.js");
    await expect(listarNcmsReferencia({ pagina: "2", tamanho: "200", busca: "xampus" })).resolves.toMatchObject({ pagina: 2, tamanho: 100, total: 1, total_paginas: 1 });
    expect(mocks.consulta.orderBy).toHaveBeenCalledWith("ncm.codigo", "ASC");
    expect(mocks.consulta.where).toHaveBeenCalledWith("ncm.codigo ILIKE :busca OR ncm.descricao ILIKE :busca", { busca: "%xampus%" });
    expect(mocks.consulta.skip).toHaveBeenCalledWith(100);
  });
  it("aplica automaticamente a regra mais específica mesmo em registro legado marcado como condicionado", async () => {
    mocks.consulta.getOne.mockResolvedValue({
      codigo: "33051000", fator_ibs: 0.4, fator_cbs: 0, aplicacao_automatica: false,
      fundamento_legal_fatores: "LC 214/2025", condicoes_aplicacao_fatores: "Confirmar descrição legal",
    });
    await expect(resolverFatoresPorNcm("3305.10.00")).resolves.toMatchObject({
      codigo_regra: "33051000", fator_ibs_sugerido: 0.4, fator_cbs_sugerido: 0,
      fator_ibs_automatico: 0.4, fator_cbs_automatico: 0, aplicacao_automatica: true,
      requer_confirmacao: false,
    });
    expect(mocks.consulta.orderBy).toHaveBeenCalledWith("length(ncm.codigo)", "DESC");
  });
  it("aplica posição legal completa e deixa a exceção filha mais específica vencer", async () => {
    mocks.consulta.getOne.mockResolvedValueOnce({
      codigo: "0207", fator_ibs: 0, fator_cbs: 0, aplicacao_automatica: true,
      fundamento_legal_fatores: "LC 214/2025, Anexo I", condicoes_aplicacao_fatores: null,
    });
    await expect(resolverFatoresPorNcm("02071400")).resolves.toMatchObject({
      codigo_regra: "0207", fator_ibs_automatico: 0, fator_cbs_automatico: 0,
      aplicacao_automatica: true, requer_confirmacao: false,
    });

    mocks.consulta.getOne.mockResolvedValueOnce({
      codigo: "02074300", fator_ibs: 1, fator_cbs: 1, aplicacao_automatica: true,
      fundamento_legal_fatores: "LC 214/2025, exclusão expressa", condicoes_aplicacao_fatores: null,
    });
    await expect(resolverFatoresPorNcm("02074300")).resolves.toMatchObject({
      codigo_regra: "02074300", fator_ibs_automatico: 1, fator_cbs_automatico: 1,
      aplicacao_automatica: true, requer_confirmacao: false,
    });
  });
  it("faz NCM sem regra específica prevalecer com fatores de 100%", async () => {
    mocks.consulta.getOne.mockResolvedValue(null);
    await expect(resolverFatoresPorNcm("84713012")).resolves.toMatchObject({
      codigo_regra: null, fator_ibs_automatico: 1, fator_cbs_automatico: 1, requer_confirmacao: false,
    });
  });
  it("não permite que a manutenção administrativa desative a herança automática", async () => {
    mocks.ncmRepo.findOneBy.mockResolvedValue({
      ...resultado,
      fator_ibs: 0.4,
      fator_cbs: 0.4,
      fatores_configurados: true,
      aplicacao_automatica: false,
    });

    await expect(atualizarFatoresNcm("33051000", { aplicacao_automatica: false })).resolves.toMatchObject({
      aplicacao_automatica: true,
    });
    expect(mocks.ncmRepo.save).toHaveBeenCalledWith(expect.objectContaining({ aplicacao_automatica: true }));
  });
});
