# `src/domain/complexidades-cobranca`

Domínio dos níveis de complexidade usados para cobrança.

## Responsabilidades

- manter o catálogo admin de complexidades de cobrança
- expor a lista pública usada na revisão de contratos
- resolver a `complexidade_cobranca` a persistir: se o nível pedido estiver inativo, `assertBillingComplexityActive` degrada para a MAIOR complexidade ativa MENOR que a pedida (nunca sobe); sem inferiores ativos, usa a menor complexidade ativa. Só lança quando não há nenhuma ativa. A regra pura vive em `escolherComplexidadeAtiva`
- resolver o nível ativo que define `inference_profile_id` e preço mensal do agente de cobrança

## Arquivos

- `complexidade-cobranca.service.ts` - CRUD do catálogo, validação e resolução de runtime

## Consumidores

- `src/domain/contratos` valida a complexidade ao salvar contratos.
- `src/domain/valores-a-cobrar` resolve o modelo do agente de cobrança.
- `src/modules/escritorios` expõe os endpoints admin `billing-complexities`.
- `src/modules/valores-a-cobrar` expõe a lista pública `GET /api/billing-complexities`.

Os slugs HTTP continuam em inglês por compatibilidade com o frontend e clientes existentes; a padronização PT aqui é interna ao domínio.
