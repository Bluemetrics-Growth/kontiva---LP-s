import { AppDataSource } from "../../database/data-source.js";
import { BillingComplexity } from "../../database/modules/public/entities/billing-complexity.entity.js";

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

export type BillingComplexityInput = {
  nivel?: number;
  nome?: string;
  descricao?: string | null;
  inference_profile_id?: string | null;
  preco_mensal_por_contrato?: number;
  ativo?: boolean;
};

function normalizeNivel(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  if (!Number.isInteger(parsed) || parsed < 1) return null;
  return parsed;
}

function normalizePrice(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

function normalizeText(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

async function seedDefaultsIfMissing(): Promise<void> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(BillingComplexity);
  const count = await repo.count();
  if (count > 0) return;

  await repo.save([
    repo.create({
      nivel: 1,
      nome: "Standard billing",
      descricao: "Modelo padrao para contratos com regras simples de cobranca.",
      inference_profile_id: null,
      preco_mensal_por_contrato: 0,
      ativo: true,
    }),
    repo.create({
      nivel: 2,
      nome: "Level 2 billing complexity",
      descricao: "Modelo para contratos com estruturas mais complexas de cobranca.",
      inference_profile_id: null,
      preco_mensal_por_contrato: 0,
      ativo: true,
    }),
  ]);
}

export async function listBillingComplexities(includeInactive = true): Promise<BillingComplexity[]> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(BillingComplexity);
  return repo.find({
    where: includeInactive ? {} : { ativo: true },
    order: { nivel: "ASC" },
  });
}

export async function listPublicBillingComplexities() {
  const rows = await listBillingComplexities(false);
  return rows.map((row) => ({
    nivel: row.nivel,
    nome: row.nome,
    descricao: row.descricao,
  }));
}

export async function createBillingComplexity(input: BillingComplexityInput): Promise<BillingComplexity> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(BillingComplexity);
  const nivel = normalizeNivel(input.nivel);
  const nome = normalizeText(input.nome);
  const preco = normalizePrice(input.preco_mensal_por_contrato ?? 0);

  if (!nivel) throw new Error("nivel deve ser um inteiro positivo.");
  if (!nome) throw new Error("nome é obrigatório.");
  if (preco == null) throw new Error("preco_mensal_por_contrato deve ser maior ou igual a zero.");

  const existing = await repo.findOne({ where: { nivel } });
  if (existing) throw new Error(`Já existe uma complexidade de cobrança para o nível ${nivel}.`);

  return repo.save(
    repo.create({
      nivel,
      nome,
      descricao: normalizeText(input.descricao),
      inference_profile_id: normalizeText(input.inference_profile_id),
      preco_mensal_por_contrato: preco,
      ativo: input.ativo ?? true,
    }),
  );
}

export async function updateBillingComplexity(
  nivelInput: number | string,
  input: BillingComplexityInput,
): Promise<BillingComplexity> {
  await seedDefaultsIfMissing();
  const repo = AppDataSource.getRepository(BillingComplexity);
  const nivel = normalizeNivel(nivelInput);
  if (!nivel) throw new Error("nivel inválido.");

  const existing = await repo.findOne({ where: { nivel } });
  if (!existing) throw new Error("Complexidade de cobrança não encontrada.");

  const nextAtivo = "ativo" in input ? Boolean(input.ativo) : existing.ativo;
  if (existing.ativo && !nextAtivo) {
    const activeCount = await repo.count({ where: { ativo: true } });
    if (activeCount <= 1) throw new Error("Não é possível desativar a última complexidade ativa.");
  }

  if ("nome" in input) {
    const nome = normalizeText(input.nome);
    if (!nome) throw new Error("nome é obrigatório.");
    existing.nome = nome;
  }
  if ("descricao" in input) existing.descricao = normalizeText(input.descricao);
  if ("inference_profile_id" in input) existing.inference_profile_id = normalizeText(input.inference_profile_id);
  if ("preco_mensal_por_contrato" in input) {
    const preco = normalizePrice(input.preco_mensal_por_contrato);
    if (preco == null) throw new Error("preco_mensal_por_contrato deve ser maior ou igual a zero.");
    existing.preco_mensal_por_contrato = preco;
  }
  existing.ativo = nextAtivo;

  return repo.save(existing);
}

export async function deactivateBillingComplexity(nivelInput: number | string): Promise<BillingComplexity> {
  return updateBillingComplexity(nivelInput, { ativo: false });
}

/**
 * Resolve a complexidade de cobrança a persistir. Se o nível pedido estiver ativo,
 * usa-o. Se não estiver, cai para a MAIOR complexidade ativa MENOR que a pedida
 * (degradação para baixo, nunca para cima); na falta de níveis inferiores ativos,
 * usa a menor complexidade ativa. Só lança quando não há nenhuma complexidade
 * ativa configurada ou o input é inválido.
 */
/**
 * Regra de degradação: nível pedido ativo → usa-o; senão, a MAIOR complexidade
 * ativa MENOR que a pedida; na falta de inferiores ativos, a menor complexidade
 * ativa. Recebe os níveis ativos ordenados ASC. `null` se não há ativos.
 */
export function escolherComplexidadeAtiva(nivelPedido: number, niveisAtivosAsc: number[]): number | null {
  if (niveisAtivosAsc.length === 0) return null;
  if (niveisAtivosAsc.includes(nivelPedido)) return nivelPedido;
  const menores = niveisAtivosAsc.filter((n) => n < nivelPedido);
  if (menores.length > 0) return menores[menores.length - 1];
  return niveisAtivosAsc[0];
}

export async function assertBillingComplexityActive(nivelInput: unknown): Promise<number> {
  const nivel = normalizeNivel(nivelInput ?? 1);
  if (!nivel) throw new Error("complexidade_cobranca deve ser um inteiro positivo.");

  const ativos = await listBillingComplexities(false); // ordenado por nivel ASC
  const escolhido = escolherComplexidadeAtiva(nivel, ativos.map((row) => row.nivel));
  if (escolhido == null) {
    throw new Error("Nenhuma complexidade de cobrança ativa configurada.");
  }
  return escolhido;
}

export async function resolveBillingComplexityForRuntime(nivelInput: unknown): Promise<BillingComplexity> {
  const rows = await listBillingComplexities(false);
  if (rows.length === 0) {
    throw new Error("Nenhuma complexidade de cobrança ativa configurada.");
  }

  const nivel = normalizeNivel(nivelInput);
  return rows.find((row) => row.nivel === nivel) ?? rows[0];
}
