import { describe, expect, it } from "vitest";
import { escolherComplexidadeAtiva } from "../complexidade-cobranca.service.js";

describe("escolherComplexidadeAtiva", () => {
  it("usa o nível pedido quando está ativo", () => {
    expect(escolherComplexidadeAtiva(2, [1, 2, 3])).toBe(2);
  });

  it("cai para o maior nível ativo menor que o pedido", () => {
    // Pediu 4 (inativo), ativos 1 e 3 → 3.
    expect(escolherComplexidadeAtiva(4, [1, 3])).toBe(3);
  });

  it("ignora níveis ativos maiores que o pedido", () => {
    // Pediu 2 (inativo), ativos 1 e 5 → 1 (nunca sobe para 5).
    expect(escolherComplexidadeAtiva(2, [1, 5])).toBe(1);
  });

  it("usa a menor complexidade ativa quando não há inferiores", () => {
    // Pediu 1 (inativo), só 3 e 4 ativos → 3.
    expect(escolherComplexidadeAtiva(1, [3, 4])).toBe(3);
  });

  it("retorna null quando não há complexidade ativa", () => {
    expect(escolherComplexidadeAtiva(2, [])).toBeNull();
  });
});
