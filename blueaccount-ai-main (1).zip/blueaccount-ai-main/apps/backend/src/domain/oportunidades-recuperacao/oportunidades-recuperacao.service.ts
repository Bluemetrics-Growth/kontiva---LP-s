import { runQueryWithRls } from "../../database/data-source.js";
import { OportunidadeRecuperacao, type PrioridadeOportunidade, type StatusOportunidade } from "../../database/modules/tenant/entities/oportunidade-recuperacao.entity.js";

export async function listOportunidades(escritorioId: string, clienteId?: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    let qb = manager.getRepository(OportunidadeRecuperacao).createQueryBuilder("o")
      .where("o.escritorio_id = :escritorio_id", { escritorio_id: escritorioId });

    if (clienteId) {
      qb = qb.andWhere("o.cliente_id = :cliente_id", { cliente_id: clienteId });
    }

    return qb.orderBy("o.created_at", "DESC").getMany();
  });
}

export async function getOportunidadeById(id: string, escritorioId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.getRepository(OportunidadeRecuperacao).findOne({
      where: { id, escritorio_id: escritorioId },
    });
  });
}

export async function createOportunidade(
  escritorioId: string,
  clienteId: string,
  competencia: string,
  valorDelta: number,
  descricao?: string,
  prioridade: PrioridadeOportunidade = "media",
  responsavel?: string,
  prazo?: string,
  valoresACobrarId?: string,
) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(OportunidadeRecuperacao);
    const oportunidade = repo.create({
      escritorio_id: escritorioId,
      cliente_id: clienteId,
      valores_a_cobrar_id: valoresACobrarId,
      competencia,
      valor_delta: valorDelta,
      descricao,
      prioridade,
      status: "aberta",
      responsavel,
      prazo,
    });

    return repo.save(oportunidade);
  });
}

export async function updateOportunidade(
  id: string,
  escritorioId: string,
  input: {
    descricao?: string;
    prioridade?: PrioridadeOportunidade;
    status?: StatusOportunidade;
    responsavel?: string;
    prazo?: string;
    resultado_final?: string;
  },
) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(OportunidadeRecuperacao);
    const oportunidade = await repo.findOne({
      where: { id, escritorio_id: escritorioId },
    });

    if (!oportunidade) {
      throw new Error(`Oportunidade não encontrada: ${id}`);
    }

    if (input.descricao !== undefined) oportunidade.descricao = input.descricao;
    if (input.prioridade !== undefined) oportunidade.prioridade = input.prioridade;
    if (input.status !== undefined) oportunidade.status = input.status;
    if (input.responsavel !== undefined) oportunidade.responsavel = input.responsavel;
    if (input.prazo !== undefined) oportunidade.prazo = input.prazo;
    if (input.resultado_final !== undefined) oportunidade.resultado_final = input.resultado_final;

    return repo.save(oportunidade);
  });
}

export async function deleteOportunidade(id: string, escritorioId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(OportunidadeRecuperacao);
    const result = await repo.delete({ id, escritorio_id: escritorioId });
    return result.affected ?? 0;
  });
}
