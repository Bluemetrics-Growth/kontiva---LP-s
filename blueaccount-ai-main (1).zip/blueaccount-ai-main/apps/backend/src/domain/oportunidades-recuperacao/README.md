# `src/domain/oportunidades-recuperacao`

Regra de negócio das **oportunidades de recuperação** (valores/serviços a recuperar por cliente).

## Responsabilidades

- listar oportunidades por escritório (opcionalmente filtradas por cliente)
- consultar oportunidade por id
- criar, atualizar e deletar oportunidade

## Arquivos

- `oportunidades-recuperacao.service.ts`: CRUD por escritório sob RLS

## Regra prática

Se a lógica decide como uma oportunidade de recuperação é persistida ou consultada, ela pertence aqui; o controller (`modules/oportunidades-recuperacao`) só faz a borda HTTP.
