export interface EdicaoManual {
  campo: string;
  valor_original: unknown;
  valor_editado: unknown;
  usuario_nome?: string | null;
  motivo?: unknown;
}

export type EdicoesManuais = Record<string, EdicaoManual>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function normalizeEdicoes(value: unknown): EdicoesManuais {
  if (!isRecord(value)) return {};

  const normalized: EdicoesManuais = {};
  for (const [campo, edicao] of Object.entries(value)) {
    if (!isRecord(edicao)) continue;
    const usuarioNome = typeof edicao.usuario_nome === "string" && edicao.usuario_nome.trim()
      ? edicao.usuario_nome.trim()
      : null;
    const motivo = edicao.motivo != null ? edicao.motivo : undefined;
    normalized[campo] = {
      campo: typeof edicao.campo === "string" ? edicao.campo : campo,
      valor_original: edicao.valor_original,
      valor_editado: edicao.valor_editado,
      ...(usuarioNome ? { usuario_nome: usuarioNome } : {}),
      ...(motivo ? { motivo } : {}),
    };
  }
  return normalized;
}

export function registrarEdicoesManuais(params: {
  edicoesAtuais: unknown;
  edicoesRecebidas: unknown;
  usuarioNome?: string | null;
}): EdicoesManuais | null {
  const edicoes = normalizeEdicoes(params.edicoesAtuais);
  const recebidas = normalizeEdicoes(params.edicoesRecebidas);

  for (const [campo, edicaoRecebida] of Object.entries(recebidas)) {
    const usuarioNome = params.usuarioNome?.trim() || edicaoRecebida.usuario_nome || null;
    const motivo = edicaoRecebida.motivo != null ? edicaoRecebida.motivo : undefined;
    edicoes[campo] = {
      campo,
      valor_original: Object.prototype.hasOwnProperty.call(edicoes, campo)
        ? edicoes[campo].valor_original
        : edicaoRecebida.valor_original,
      valor_editado: edicaoRecebida.valor_editado,
      ...(usuarioNome ? { usuario_nome: usuarioNome } : {}),
      ...(motivo ? { motivo } : {}),
    };
  }

  return Object.keys(edicoes).length > 0 ? edicoes : null;
}
