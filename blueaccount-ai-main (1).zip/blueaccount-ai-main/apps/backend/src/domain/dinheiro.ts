/** Arredonda para 2 casas decimais, compensando erro de ponto flutuante. */
export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

/**
 * Arredonda para 4 casas decimais, compensando erro de ponto flutuante. Usado em frações
 * (percentuais) que o frontend exibe com 2 casas decimais do valor em %: `round2` aplicado direto
 * na fração perde essa precisão (0.1370 e 0.1443 colapsam ambos em 0.14).
 */
export function round4(value: number): number {
  return Math.round((value + Number.EPSILON) * 10000) / 10000;
}
