import { runQueryWithRls } from "../../database/data-source.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import { consolidarCompetencia } from "../valores-a-cobrar/consolidar.service.js";
import { Brackets } from "typeorm";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginationInput,
} from "../pagination.js";

function scheduleConsolidacaoFaturamento(escritorioId: string, faturamento: Pick<Faturamento, "cliente_id" | "competencia">): void {
  if (!faturamento.cliente_id || !faturamento.competencia) {
    return;
  }

  const { cliente_id: clienteId, competencia } = faturamento;
  setImmediate(() => {
    consolidarCompetencia(escritorioId, clienteId, competencia).catch((err) => {
      console.error("[consolidarCompetencia] erro em background:", err);
    });
  });
}

function scheduleConsolidacaoChaveAnterior(input: {
  escritorioId: string;
  clienteId: string | null | undefined;
  competencia: string | null | undefined;
  savedClienteId: string | null | undefined;
  savedCompetencia: string | null | undefined;
}): void {
  if (!input.clienteId || !input.competencia) {
    return;
  }

  if (input.clienteId === input.savedClienteId && input.competencia === input.savedCompetencia) {
    return;
  }

  setImmediate(() => {
    consolidarCompetencia(input.escritorioId, input.clienteId!, input.competencia!).catch((err) => {
      console.error("[consolidarCompetencia] erro em background:", err);
    });
  });
}

const stringOrNull = (value: unknown): string | null => {
  if (typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  return trimmed || null;
};

const requiredString = (value: unknown, field: string): string => {
  const parsed = stringOrNull(value);
  if (!parsed) {
    throw new Error(`${field} deve ser uma string não vazia.`);
  }

  return parsed;
};

const numberOrNull = (value: unknown): number | null => {
  if (value === null || value === undefined || value === "") {
    return null;
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === "string") {
    const normalized = value.trim().replace(/\./g, "").replace(",", ".");
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
};

const normalizeCompetencia = (value: unknown): string => {
  const parsed = requiredString(value, "competencia");
  const yyyyMm = parsed.match(/^(\d{4})-(\d{2})$/);
  if (yyyyMm) {
    return `${yyyyMm[2]}/${yyyyMm[1]}`;
  }

  const mmYyyy = parsed.match(/^(\d{2})\/(\d{4})$/);
  if (mmYyyy) {
    return parsed;
  }

  throw new Error("competencia deve estar no formato MM/AAAA.");
};

export async function listFaturamentos(escritorioId: string): Promise<Faturamento[]> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Faturamento);
    return repo.find({
      relations: ["cliente"],
      order: { created_at: "DESC" },
    });
  });
}

export async function listFaturamentosPaginated(
  escritorioId: string,
  input: PaginationInput & { query?: string } = {},
) {
  const { page, pageSize, skip } = normalizePagination(input);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Faturamento)
      .createQueryBuilder("faturamento")
      .innerJoin("faturamento.cliente", "cliente")
      .select("faturamento.id", "id")
      .addSelect("faturamento.cliente_id", "cliente_id")
      .addSelect("faturamento.competencia", "competencia")
      .addSelect("faturamento.razao_social", "razao_social")
      .addSelect("faturamento.valor_cobrado", "valor_cobrado")
      .addSelect("faturamento.discriminacao", "discriminacao")
      .addSelect("faturamento.arquivo_origem", "arquivo_origem")
      .addSelect("faturamento.faturamento_ativo", "faturamento_ativo")
      .addSelect("faturamento.created_at", "created_at")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .where("faturamento.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("cliente.ativo = true");
    if (input.query?.trim()) {
      qb.andWhere(
        new Brackets((sub) => {
          sub
            .where("cliente.razao_social ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("cliente.cnpj ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("faturamento.competencia ILIKE :query", { query: `%${input.query!.trim()}%` });
        }),
      );
    }
    const total = await qb.clone().getCount();
    const rows = await qb.orderBy("faturamento.created_at", "DESC").offset(skip).limit(pageSize)
      .getRawMany<Record<string, unknown>>();
    return buildPaginatedResult(rows.map((row) => ({
      id: String(row.id),
      cliente_id: String(row.cliente_id),
      competencia: row.competencia == null ? null : String(row.competencia),
      razao_social: row.razao_social == null ? null : String(row.razao_social),
      valor_cobrado: row.valor_cobrado == null ? null : Number(row.valor_cobrado),
      discriminacao: row.discriminacao == null ? null : String(row.discriminacao),
      arquivo_origem: row.arquivo_origem == null ? null : String(row.arquivo_origem),
      faturamento_ativo: row.faturamento_ativo === true,
      created_at: row.created_at,
      cliente: {
        id: String(row.cliente_id),
        razao_social: String(row.cliente_razao_social),
        cnpj: row.cliente_cnpj == null ? null : String(row.cliente_cnpj),
      },
    })), total, page, pageSize);
  });
}

export async function getFaturamento(id: string, escritorioId: string): Promise<Faturamento | null> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Faturamento);
    return repo.findOne({
      where: { id, escritorio_id: escritorioId },
      relations: ["cliente"],
    });
  });
}

export async function createFaturamento(
  input: Record<string, unknown>,
  escritorioId: string,
): Promise<Faturamento> {
  const clienteId = requiredString(input.cliente_id, "cliente_id");
  const competencia = normalizeCompetencia(input.competencia);
  const valorCobrado = numberOrNull(input.valor_cobrado);

  if (valorCobrado === null) {
    throw new Error("valor_cobrado deve ser um número válido.");
  }

  const faturamentoSalvo = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Faturamento);
    const faturamento = repo.create({
      escritorio_id: escritorioId,
      cliente_id: clienteId,
      competencia,
      razao_social: stringOrNull(input.razao_social),
      valor_cobrado: valorCobrado,
      discriminacao: stringOrNull(input.discriminacao),
      arquivo_origem: stringOrNull(input.arquivo_origem) ?? "Cadastro manual",
      extracao_bruta: input.extracao_bruta && typeof input.extracao_bruta === "object" ? input.extracao_bruta : null,
      payload_normalizado_ui: input.payload_normalizado_ui && typeof input.payload_normalizado_ui === "object"
        ? input.payload_normalizado_ui
        : { origem: "manual" },
      faturamento_ativo: true,
    });

    return repo.save(faturamento);
  });

  scheduleConsolidacaoFaturamento(escritorioId, faturamentoSalvo);

  return faturamentoSalvo;
}

export async function updateFaturamento(
  id: string,
  input: Record<string, unknown>,
  escritorioId: string,
): Promise<Faturamento | null> {
  const normalizedInput = {
    ...input,
    ...("competencia" in input ? { competencia: normalizeCompetencia(input.competencia) } : {}),
  };

  const { salvo, chaveAnterior } = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Faturamento);
    const faturamento = await repo.findOne({
      where: { id, escritorio_id: escritorioId },
    });

    if (!faturamento) {
      return { salvo: null, chaveAnterior: null };
    }

    const chaveAnterior = {
      clienteId: faturamento.cliente_id,
      competencia: faturamento.competencia,
    };

    Object.assign(faturamento, normalizedInput);
    const salvo = await repo.save(faturamento);
    return { salvo, chaveAnterior };
  });

  if (!salvo) {
    return null;
  }

  scheduleConsolidacaoFaturamento(escritorioId, salvo);
  scheduleConsolidacaoChaveAnterior({
    escritorioId,
    clienteId: chaveAnterior?.clienteId,
    competencia: chaveAnterior?.competencia,
    savedClienteId: salvo.cliente_id,
    savedCompetencia: salvo.competencia,
  });

  return salvo;
}

export async function archiveFaturamento(
  id: string,
  escritorioId: string,
): Promise<Faturamento | null> {
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Faturamento);
    const faturamento = await repo.findOne({
      where: { id, escritorio_id: escritorioId },
    });

    if (!faturamento) {
      return null;
    }

    faturamento.faturamento_ativo = false;
    return repo.save(faturamento);
  });
}
