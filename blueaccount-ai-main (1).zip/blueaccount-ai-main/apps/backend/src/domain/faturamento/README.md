# Domínio: Faturamento

Regras de negócio e persistência de faturamento observado por cliente e
competência.

## Responsabilidades

- listar, criar, atualizar e arquivar registros de `faturamento`
- normalizar competência (`MM/AAAA`) e valores monetários de entrada
- buscar dados paginados para a UI
- disparar reconsolidação de `valores_a_cobrar` quando o faturamento observado muda

## Fronteira

- Consulta ativa ao provedor externo é orquestrada por `domain/cobrancas` porque
  depende da plataforma configurada e do provider.
- O domínio de faturamento apenas grava o resultado observado e aciona
  `consolidarCompetencia` em background.

## Arquivos

- `faturamento.service.ts`
- `tests/faturamento.service.test.ts`
