import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const faturamentoMocks = vi.hoisted(() => {
  const faturamentoRepo = {
    create: vi.fn((input) => input),
    save: vi.fn(async (input) => ({ id: "fat-1", ...input })),
    findOne: vi.fn(),
  };

  const runQueryWithRls = vi.fn(async (_ctx, callback) => {
    const manager = {
      getRepository: vi.fn(() => faturamentoRepo),
    };
    return callback(manager);
  });

  return { faturamentoRepo, runQueryWithRls, consolidarCompetencia: vi.fn() };
});

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: faturamentoMocks.runQueryWithRls,
}));

vi.mock("../../valores-a-cobrar/consolidar.service.js", () => ({
  consolidarCompetencia: faturamentoMocks.consolidarCompetencia,
}));

const { createFaturamento, updateFaturamento } = await import("../faturamento.service.js");

describe("faturamento service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal("setImmediate", ((callback: () => void) => {
      callback();
      return undefined;
    }) as typeof setImmediate);
    faturamentoMocks.consolidarCompetencia.mockResolvedValue({ ok: true, valoresACobrarId: "vac-1" });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("creates a manual billing record with sanitized fields", async () => {
    const result = await createFaturamento({
      cliente_id: " cliente-1 ",
      competencia: " 05/2026 ",
      valor_cobrado: "1.234,56",
      discriminacao: " Mensalidade ",
      arquivo_origem: "",
      unknown_field: "ignored",
    }, "office-1");

    expect(result).toEqual(expect.objectContaining({
      id: "fat-1",
      escritorio_id: "office-1",
      cliente_id: "cliente-1",
      competencia: "05/2026",
      valor_cobrado: 1234.56,
      discriminacao: "Mensalidade",
      arquivo_origem: "Cadastro manual",
      payload_normalizado_ui: { origem: "manual" },
      faturamento_ativo: true,
    }));
    expect(faturamentoMocks.faturamentoRepo.create).toHaveBeenCalledWith(expect.not.objectContaining({
      unknown_field: "ignored",
    }));
    expect(faturamentoMocks.consolidarCompetencia).toHaveBeenCalledWith("office-1", "cliente-1", "05/2026");
  });

  it("rejects records without a valid charged amount", async () => {
    await expect(createFaturamento({
      cliente_id: "cliente-1",
      competencia: "2026-05",
      valor_cobrado: "abc",
    }, "office-1")).rejects.toThrow("valor_cobrado deve ser um número válido.");
  });

  it("normalizes legacy YYYY-MM competence input", async () => {
    const result = await createFaturamento({
      cliente_id: "cliente-1",
      competencia: "2026-05",
      valor_cobrado: 100,
    }, "office-1");

    expect(result).toEqual(expect.objectContaining({
      competencia: "05/2026",
    }));
  });

  it("consolidates after updating a billing record", async () => {
    faturamentoMocks.faturamentoRepo.findOne.mockResolvedValue({
      id: "fat-1",
      escritorio_id: "office-1",
      cliente_id: "cliente-1",
      competencia: "05/2026",
      valor_cobrado: 100,
    });
    faturamentoMocks.faturamentoRepo.save.mockImplementationOnce(async (input) => ({ ...input, valor_cobrado: 200 }));

    const result = await updateFaturamento("fat-1", { valor_cobrado: 200 }, "office-1");

    expect(result).toEqual(expect.objectContaining({
      id: "fat-1",
      valor_cobrado: 200,
    }));
    expect(faturamentoMocks.consolidarCompetencia).toHaveBeenCalledWith("office-1", "cliente-1", "05/2026");
  });

  it("also reconsolidates the previous key when a billing update moves competence", async () => {
    faturamentoMocks.faturamentoRepo.findOne.mockResolvedValue({
      id: "fat-1",
      escritorio_id: "office-1",
      cliente_id: "cliente-1",
      competencia: "05/2026",
      valor_cobrado: 100,
    });
    faturamentoMocks.faturamentoRepo.save.mockImplementationOnce(async (input) => input);

    await updateFaturamento("fat-1", { competencia: "2026-06" }, "office-1");

    expect(faturamentoMocks.consolidarCompetencia).toHaveBeenCalledWith("office-1", "cliente-1", "06/2026");
    expect(faturamentoMocks.consolidarCompetencia).toHaveBeenCalledWith("office-1", "cliente-1", "05/2026");
  });
});
