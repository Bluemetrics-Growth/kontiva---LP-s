import { describe, expect, it } from "vitest";
import { getTiposRelatorioPeriodicos } from "../tipos-relatorio.js";

describe("catálogo de tipos de relatório", () => {
  it("expõe as referências normalizadas dos tipos escalares", () => {
    const { tipos } = getTiposRelatorioPeriodicos();

    expect(tipos.find((tipo) => tipo.tipo === "resumo_folha")?.referencias_metricas).toEqual([
      "colaboradores",
      "prolabores",
      "admissao",
      "rescisao",
      "afastados",
    ]);
    expect(tipos.find((tipo) => tipo.tipo === "numero_notas_fiscais")?.referencias_metricas).toContain("notas fiscais");
    expect(tipos.find((tipo) => tipo.tipo === "numero_de_documentos")?.referencias_metricas).toContain("documentos");
    expect(tipos.find((tipo) => tipo.tipo === "lancamentos_contabeis")?.referencias_metricas).toContain("lancamentos contabeis");
  });

  it("não inventa métricas escalares para excedentes e multas", () => {
    const { tipos } = getTiposRelatorioPeriodicos();

    expect(tipos.find((tipo) => tipo.tipo === "relatorio_excedente")?.referencias_metricas).toEqual([]);
    expect(tipos.find((tipo) => tipo.tipo === "multa")?.referencias_metricas).toEqual([]);
  });

  it("expõe outro como fallback informativo sem referências de cobrança", () => {
    const { tipos } = getTiposRelatorioPeriodicos();
    const outro = tipos.find((tipo) => tipo.tipo === "outro");

    expect(outro?.campos_metricos).toEqual(["other_metrics"]);
    expect(outro?.referencias_metricas).toEqual([]);
  });
});
