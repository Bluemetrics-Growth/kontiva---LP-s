import { beforeEach, describe, expect, it, vi } from "vitest";
import { Brackets } from "typeorm";

const relatoriosMocks = vi.hoisted(() => {
  const queryBuilder = {
    update: vi.fn(),
    set: vi.fn(),
    where: vi.fn(),
    andWhere: vi.fn(),
    leftJoin: vi.fn(),
    innerJoin: vi.fn(),
    select: vi.fn(),
    addSelect: vi.fn(),
    orderBy: vi.fn(),
    addOrderBy: vi.fn(),
    groupBy: vi.fn(),
    addGroupBy: vi.fn(),
    offset: vi.fn(),
    limit: vi.fn(),
    clone: vi.fn(),
    execute: vi.fn(),
    getExists: vi.fn(),
    getCount: vi.fn(),
    getRawOne: vi.fn(),
    getRawMany: vi.fn(),
  };
  const relatorioRepo = {
    findOne: vi.fn(),
    findOneBy: vi.fn(),
    create: vi.fn((input) => input),
    save: vi.fn(),
    createQueryBuilder: vi.fn(() => queryBuilder),
  };
  const faturamentoRepo = {
    create: vi.fn((input) => input),
    save: vi.fn(),
  };
  const documentoRepo = {
    findOne: vi.fn(),
    update: vi.fn(),
  };
  const estatisticaRepo = {
    find: vi.fn(async () => []),
  };
  const contratoRepo = {
    findOne: vi.fn(),
  };
  const AppDataSource = {
    isInitialized: false,
    initialize: vi.fn(),
    getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Relatorio") return relatorioRepo;
      if (entity?.name === "Faturamento") return faturamentoRepo;
      if (entity?.name === "Documento") return documentoRepo;
      if (entity?.name === "RelatorioEstatisticaCliente") return estatisticaRepo;
      if (entity?.name === "Contrato") return contratoRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
    }),
  };

  const runQueryWithRls = vi.fn(async (_ctx, callback) => {
    const manager = {
      getRepository: AppDataSource.getRepository,
      createQueryBuilder: vi.fn(() => queryBuilder),
    };
    return await callback(manager);
  });

  return { queryBuilder, relatorioRepo, faturamentoRepo, documentoRepo, estatisticaRepo, contratoRepo, AppDataSource, runQueryWithRls };
});

const domainMocks = vi.hoisted(() => ({
  findOrCreateClienteByCnpj: vi.fn(),
  getDocumentoById: vi.fn(),
  consolidarCompetencia: vi.fn(),
  resolverAlvoConsolidacao: vi.fn(),
  s3Send: vi.fn(),
  normalizarCnpj: vi.fn((value: unknown) => String(value)),
}));

vi.mock("../../../database/data-source.js", () => ({
  AppDataSource: relatoriosMocks.AppDataSource,
  runQueryWithRls: relatoriosMocks.runQueryWithRls,
}));

vi.mock("../../clientes/cliente.service.js", () => ({
  findOrCreateClienteByCnpj: domainMocks.findOrCreateClienteByCnpj,
  normalizarCnpj: domainMocks.normalizarCnpj,
}));

vi.mock("../../documentos/documentos.service.js", () => ({
  getDocumentoById: domainMocks.getDocumentoById,
  updateDocumentoPayloadNormalizadoUi: vi.fn(),
}));

vi.mock("../../valores-a-cobrar/consolidar.service.js", () => ({
  consolidarCompetencia: domainMocks.consolidarCompetencia,
}));

vi.mock("../../clientes/grupo.service.js", () => ({
  resolverAlvoConsolidacao: domainMocks.resolverAlvoConsolidacao,
}));

vi.mock("../../../agent/index.js", () => ({
  IngestaoPayloadAgent: class {
    prepararPayloadFrontend = vi.fn(async () => ({ tipo: "payload_frontend" }));
  },
}));

vi.mock("@aws-sdk/client-s3", () => ({
  GetObjectCommand: vi.fn(),
  S3Client: vi.fn(function S3Client() {
    return { send: domainMocks.s3Send };
  }),
}));

const {
  confirmarRelatorioExtracted,
  updateRelatorio,
  createRelatorioManual,
  getRelatorio,
  listarRelatoriosPorDocumento,
  contarRelatoriosAtivosPorDocumento,
  inserirRelatorioAutomatico,
  finalizarIngestaoRelatoriosPlanilha,
  listClientesComRelatorios,
} = await import("../relatorio.service.js");

describe("relatorio service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    relatoriosMocks.queryBuilder.update.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.set.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.where.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.andWhere.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.leftJoin.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.innerJoin.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.select.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.addSelect.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.orderBy.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.addOrderBy.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.groupBy.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.addGroupBy.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.offset.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.limit.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.clone.mockReturnValue(relatoriosMocks.queryBuilder);
    relatoriosMocks.queryBuilder.execute.mockResolvedValue({ affected: 1 });
    relatoriosMocks.queryBuilder.getExists.mockResolvedValue(false);
    relatoriosMocks.queryBuilder.getCount.mockResolvedValue(0);
    relatoriosMocks.queryBuilder.getRawOne.mockResolvedValue(undefined);
    relatoriosMocks.queryBuilder.getRawMany.mockResolvedValue([]);
    domainMocks.findOrCreateClienteByCnpj.mockResolvedValue({ id: "cliente-1" });
    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "relatorio.pdf",
      dados_extraidos_contrato: {
        campos: [
          { campo: "cnpj_cliente", valor_extraido: "12345678000199", id: "p1_t1_l1" },
          { campo: "tipo_relatorio", valor_extraido: "resumo_folha", id: "p1_t2_l1" },
          { campo: "competencia", valor_extraido: "2024-01", id: "p1_t3_l1" },
          { campo: "razao_social", valor_extraido: "Cliente Teste", id: "p1_t4_l1" },
          { campo: "colaboradores_ativos", valor_extraido: "12", id: "p1_t5_l1" },
        ],
      },
    });
    relatoriosMocks.documentoRepo.findOne.mockResolvedValue(null);
    relatoriosMocks.documentoRepo.update.mockResolvedValue({ affected: 1 });
    relatoriosMocks.contratoRepo.findOne.mockResolvedValue(null);
    domainMocks.consolidarCompetencia.mockResolvedValue(undefined);
    domainMocks.resolverAlvoConsolidacao.mockImplementation(async (_manager, _escritorioId, clienteId) => ({
      clienteIdAlvo: clienteId,
      redirecionado: false,
      grupoConsolidado: false,
    }));
    domainMocks.s3Send.mockRejectedValue(new Error("S3 indisponível no teste"));
  });

  it("lists every report generated by a document and counts them in one grouped query", async () => {
    relatoriosMocks.queryBuilder.getRawMany
      .mockResolvedValueOnce([
        {
          id: "rel-1", cliente_id: "cliente-1", cliente_razao_social: "Cliente A", cliente_nome_fantasia: null,
          tipo_relatorio: "resumo_folha", competencia: "01/2026", relatorio_ativo: true, created_at: "2026-01-10T10:00:00.000Z",
        },
        {
          id: "rel-2", cliente_id: "cliente-2", cliente_razao_social: "Cliente B", cliente_nome_fantasia: "B Ltda.",
          tipo_relatorio: "numero_notas_fiscais", competencia: "01/2026", relatorio_ativo: false, created_at: "2026-01-09T10:00:00.000Z",
        },
      ])
      .mockResolvedValueOnce([{ documento_id: "doc-1", quantidade: "2" }]);

    await expect(listarRelatoriosPorDocumento("doc-1", "escritorio-1")).resolves.toEqual([
      expect.objectContaining({ id: "rel-1", cliente_id: "cliente-1", relatorio_ativo: true }),
      expect.objectContaining({ id: "rel-2", cliente_id: "cliente-2", relatorio_ativo: false }),
    ]);
    await expect(contarRelatoriosAtivosPorDocumento("escritorio-1", ["doc-1", "doc-2"])).resolves.toEqual(new Map([["doc-1", 2]]));
    expect(relatoriosMocks.queryBuilder.groupBy).toHaveBeenCalledWith("relatorio.arquivo_origem");
  });

  it("updates report fields", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue({ id: "report-1", competencia: "2023-12", total_notas_fiscais: 7 });

    const result = await updateRelatorio("report-1", {
      competencia: "2024-01",
      total_notas_fiscais: 9,
      edicoes: {
        competencia: { campo: "competencia", valor_original: "2023-12", valor_editado: "2024-01" },
        total_notas_fiscais: { campo: "total_notas_fiscais", valor_original: 7, valor_editado: 9 },
      },
    }, "escritorio-1");

    expect(result).toEqual(expect.objectContaining({ ok: true, relatorioId: "report-1" }));
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      id: "report-1",
      competencia: "2024-01",
      total_notas_fiscais: 9,
      edicoes: expect.objectContaining({
        competencia: {
          campo: "competencia",
          valor_original: "2023-12",
          valor_editado: "2024-01",
        },
        total_notas_fiscais: {
          campo: "total_notas_fiscais",
          valor_original: 7,
          valor_editado: 9,
        },
      }),
    }));
  });

  it("updates typed other_metrics and preserves the free metrics outside billing vocabulary", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue({
      id: "report-outro",
      escritorio_id: "escritorio-1",
      cliente_id: "cliente-1",
      tipo_relatorio: "outro",
      competencia: "2024-01",
      arquivo_origem: "Cadastro manual",
      relatorio_ativo: true,
      other_metrics: { predios: { value: 10 } },
    });

    await updateRelatorio(
      "report-outro",
      { other_metrics: { predios: { value: 12, unit: "unidade", label: "Prédios" } } },
      "escritorio-1",
    );

    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        other_metrics: { predios: { value: 12, unit: "unidade", label: "Prédios" } },
        metricas_observadas: [],
      }),
    );
    expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
  });

  it("preserves the original report value when a field is edited again", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue({
      id: "report-1",
      competencia: "2024-02",
      edicoes: {
        competencia: {
          campo: "competencia",
          valor_original: "2023-12",
          valor_editado: "2024-02",
        },
      },
    });

    await updateRelatorio("report-1", {
      competencia: "2024-03",
      edicoes: {
        competencia: {
          campo: "competencia",
          valor_original: "2024-02",
          valor_editado: "2024-03",
        },
      },
    }, "escritorio-1");

    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      edicoes: expect.objectContaining({
        competencia: {
          campo: "competencia",
          valor_original: "2023-12",
          valor_editado: "2024-03",
        },
      }),
    }));
  });

  it("inactivates another active report when update moves to an existing active key", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue({
      id: "report-1",
      escritorio_id: "escritorio-1",
      cliente_id: "cliente-1",
      tipo_relatorio: "resumo_folha",
      relatorio_ativo: true,
    });

    await updateRelatorio("report-1", { competencia: "2024-01" }, "escritorio-1");

    expect(relatoriosMocks.queryBuilder.update).toHaveBeenCalled();
    expect(relatoriosMocks.queryBuilder.set).toHaveBeenCalledWith({ relatorio_ativo: false });
    expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("id <> :exceptRelatorioId", { exceptRelatorioId: "report-1" });
    expect(relatoriosMocks.queryBuilder.execute).toHaveBeenCalled();
  });

  it("returns null when the report does not exist", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue(null);

    const result = await updateRelatorio("missing", {}, "escritorio-1");

    expect(result).toBeNull();
  });

  it("syncs edited report values into payload and raw extraction snapshots", async () => {
    relatoriosMocks.relatorioRepo.findOneBy.mockResolvedValue({
      id: "report-1",
      escritorio_id: "escritorio-1",
      cliente_id: "cliente-1",
      tipo_relatorio: "resumo_folha",
      competencia: "2024-01",
      relatorio_ativo: true,
      colaboradores_ativos: 12,
      extracao_bruta: {
        idArquivo: "documento-1",
        campos: [
          { campo: "colaboradores_ativos", valor_extraido: 12 },
        ],
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          tipo_relatorio: "resumo_folha",
          competencia: "2024-01",
          colaboradores_ativos: 12,
          arquivo_origem: "documento-1",
          extracao_bruta: {
            idArquivo: "documento-1",
            campos: [
              { campo: "colaboradores_ativos", valor_extraido: 12 },
            ],
          },
        },
      },
    });

    const result = await updateRelatorio("report-1", {
      campos_editados: {
        colaboradores_ativos: "31",
      },
    }, "escritorio-1");

    expect(result).toEqual(expect.objectContaining({ ok: true, relatorioId: "report-1" }));
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      id: "report-1",
      colaboradores_ativos: 31,
      extracao_bruta: expect.objectContaining({
        campos: expect.arrayContaining([
          expect.objectContaining({ campo: "colaboradores_ativos", valor_extraido: 31 }),
        ]),
      }),
      payload_normalizado_ui: expect.objectContaining({
        payloadInsercaoDb: expect.objectContaining({
          colaboradores_ativos: 31,
          extracao_bruta: expect.objectContaining({
            campos: expect.arrayContaining([
              expect.objectContaining({ campo: "colaboradores_ativos", valor_extraido: 31 }),
            ]),
          }),
        }),
      }),
    }));
  });

  it("replaces the previous active report for the same client, type and competencia", async () => {
    relatoriosMocks.relatorioRepo.save.mockResolvedValue({
      id: "report-new",
      cliente_id: "cliente-1",
      competencia: "2024-01",
    });

    const result = await confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      cnpj_cliente: "12345678000199",
      tipo_relatorio: "resumo_folha",
      competencia: "2024-01",
      razao_social: "Cliente Teste",
      colaboradores_ativos: "99",
      campos_editados: {
        colaboradores_ativos: "12",
      },
    });

    expect(result).toEqual({ ok: true, relatorioId: "report-new", clienteId: "cliente-1" });
    expect(relatoriosMocks.queryBuilder.set).toHaveBeenCalledWith({ relatorio_ativo: false });
    expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("cliente_id = :clienteId", { clienteId: "cliente-1" });
    expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("tipo_relatorio = :tipoRelatorio", { tipoRelatorio: "resumo_folha" });
    expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("competencia = :competencia", { competencia: "2024-01" });
    expect(relatoriosMocks.queryBuilder.execute).toHaveBeenCalledBefore(relatoriosMocks.relatorioRepo.save);
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      cliente_id: "cliente-1",
      competencia: "2024-01",
      relatorio_ativo: true,
      colaboradores_ativos: 12,
      arquivo_origem: "documento-1",
    }));
  });

  it("confirms a report using traceable campos from the extraction schema", async () => {
    relatoriosMocks.relatorioRepo.save.mockResolvedValue({
      id: "report-new",
      cliente_id: "cliente-1",
      competencia: "2024-01",
    });

    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "relatorio.pdf",
      dados_extraidos_contrato: {
        campos: [
        { campo: "cnpj_cliente", fonte: "CNPJ 12345678000199", valor_extraido: "12345678000199", id: "p1_t1_l1" },
        { campo: "tipo_relatorio", fonte: "Resumo folha", valor_extraido: "resumo_folha", id: "p1_t2_l1" },
        { campo: "competencia", fonte: "Janeiro/2024", valor_extraido: "2024-01", id: "p1_t3_l1" },
        { campo: "razao_social", fonte: "Cliente Teste", valor_extraido: "Cliente Teste", id: "p1_t4_l1" },
        { campo: "colaboradores_ativos", fonte: "Ativos 0", valor_extraido: 0, id: "p1_t5_l1" },
        { campo: "admissoes", fonte: "Admissoes 3", valor_extraido: "3", id: "p1_t6_l1" },
      ],
      },
    });

    const result = await confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      campos_editados: {},
    });

    expect(result).toEqual({ ok: true, relatorioId: "report-new", clienteId: "cliente-1" });
    expect(domainMocks.findOrCreateClienteByCnpj).toHaveBeenCalledWith({
      escritorioId: "escritorio-1",
      cnpj: "12345678000199",
      razaoSocial: "Cliente Teste",
    });
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      tipo_relatorio: "resumo_folha",
      competencia: "2024-01",
      colaboradores_ativos: 0,
      admissoes: 3,
    }));
  });

  it("stores report data quality when confirming a report", async () => {
    relatoriosMocks.relatorioRepo.save.mockResolvedValue({
      id: "report-new",
      cliente_id: "cliente-1",
      competencia: "2024-01",
    });
    const qualidade = {
      status: "suspeito",
      confirmacao_obrigatoria: true,
      campos: [{ campo: "colaboradores_ativos", severidade: "warning" }],
    };
    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "relatorio.pdf",
      dados_extraidos_contrato: {
        relatorios: [
          {
            tipo_relatorio: "resumo_folha",
            cnpj_cliente: "12345678000199",
            competencia: "2024-01",
            colaboradores_ativos: 99,
          },
        ],
      },
      payload_normalizado_ui: {
        relatorio_qualidade_de_dados: qualidade,
        payloadInsercaoDb: {
          tipo_relatorio: "resumo_folha",
          competencia: "2024-01",
          colaboradores_ativos: 99,
          arquivo_origem: "documento-1",
        },
      },
    });

    await confirmarRelatorioExtracted("escritorio-1", "documento-1", { campos_editados: {} });

    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      relatorio_qualidade_de_dados: qualidade,
    }));
  });

  it("blocks confirmation when report data quality is critical", async () => {
    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "relatorio.pdf",
      dados_extraidos_contrato: {
        relatorios: [
          {
            tipo_relatorio: "resumo_folha",
            cnpj_cliente: "12345678000199",
            competencia: "2024-01",
            colaboradores_ativos: -1,
          },
        ],
      },
      payload_normalizado_ui: {
        relatorio_qualidade_de_dados: {
          status: "critico",
          bloqueia_confirmacao: true,
          campos: [{ campo: "colaboradores_ativos", severidade: "critical" }],
        },
      },
    });

    await expect(confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      campos_editados: {},
    })).rejects.toThrow("inconsistências críticas");

    expect(relatoriosMocks.relatorioRepo.save).not.toHaveBeenCalled();
  });

  it("confirms a report from the state machine wrapped output using reportIdentification", async () => {
    relatoriosMocks.relatorioRepo.save.mockResolvedValue({
      id: "report-new",
      cliente_id: "cliente-1",
      competencia: "2024-01",
    });

    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "folha.pdf",
      dados_extraidos_contrato: {
        reportIdentification: {
          tipo_relatorio: "resumo_folha",
          cnpj_cliente: "12345678000199",
          competencia: "2024-01",
          razao_social: "Cliente Teste",
        },
        reportExtraction: {
          payload: {
            relatorios: [
              {
                tipo_relatorio: "desconhecido",
                colaboradores_ativos: "12",
              },
            ],
          },
        },
      },
    });

    const result = await confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      campos_editados: {},
    });

    expect(result).toEqual({ ok: true, relatorioId: "report-new", clienteId: "cliente-1" });
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      tipo_relatorio: "resumo_folha",
      competencia: "2024-01",
      colaboradores_ativos: 12,
    }));
  });

  it("stores faturamento in its own table instead of relatorios", async () => {
    relatoriosMocks.faturamentoRepo.save.mockResolvedValue({
      id: "fat-new",
      cliente_id: "cliente-1",
      competencia: "2024-01",
    });

    domainMocks.getDocumentoById.mockResolvedValue({
      id: "documento-1",
      filename_original: "faturamento.pdf",
      dados_extraidos_contrato: {
        relatorios: [
          {
            tipo_relatorio: "faturamento",
            cnpj_cliente: "74.838.226/0001-00",
            competencia: "05/2026",
            campos: [
              { campo: "cnpj_cliente", valor_extraido: "74.838.226/0001-00", id: "p1_t1_l1" },
              { campo: "competencia", valor_extraido: "05/2026", id: "p1_t3_l1" },
              { campo: "valor_cobrado", valor_extraido: 9200, id: "p1_t5_l1" },
              { campo: "discriminacao", valor_extraido: "Honorários contábeis", id: "p1_t6_l1" },
            ],
            valor_cobrado: 9200,
            discriminacao: "Honorários contábeis",
          },
        ],
      },
    });

    const result = await confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      campos_editados: {},
    });

    expect(result).toEqual({ ok: true, faturamentoId: "fat-new", clienteId: "cliente-1" });
    expect(domainMocks.findOrCreateClienteByCnpj).toHaveBeenCalledWith({
      escritorioId: "escritorio-1",
      cnpj: "74.838.226/0001-00",
      razaoSocial: null,
    });
    expect(relatoriosMocks.queryBuilder.set).toHaveBeenCalledWith({ faturamento_ativo: false });
    expect(relatoriosMocks.relatorioRepo.save).not.toHaveBeenCalled();
    expect(relatoriosMocks.faturamentoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      cliente_id: "cliente-1",
      escritorio_id: "escritorio-1",
      competencia: "05/2026",
      valor_cobrado: 9200,
      discriminacao: "Honorários contábeis",
      arquivo_origem: "documento-1",
      faturamento_ativo: true,
    }));
  });

  it("creates the report for the client resolved or created from the extracted CNPJ", async () => {
    domainMocks.findOrCreateClienteByCnpj.mockResolvedValue({ id: "cliente-novo" });
    relatoriosMocks.relatorioRepo.save.mockResolvedValue({
      id: "report-new",
      cliente_id: "cliente-novo",
      competencia: "2024-01",
    });

    await expect(confirmarRelatorioExtracted("escritorio-1", "documento-1", {
      campos_editados: {},
    })).resolves.toEqual({ ok: true, relatorioId: "report-new", clienteId: "cliente-novo" });

    expect(domainMocks.findOrCreateClienteByCnpj).toHaveBeenCalledWith({
      escritorioId: "escritorio-1",
      cnpj: "12345678000199",
      razaoSocial: "Cliente Teste",
    });
    expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ cliente_id: "cliente-novo", relatorio_ativo: true }),
    );
  });

  describe("createRelatorioManual + server-side QA gate", () => {
    beforeEach(() => {
      relatoriosMocks.relatorioRepo.save.mockImplementation(async (r) => ({ ...r, id: "rel-new" }));
      relatoriosMocks.estatisticaRepo.find.mockResolvedValue([]);
    });

    it("resolves or creates the client before applying QA and persists an eligible report as active", async () => {
      domainMocks.findOrCreateClienteByCnpj.mockResolvedValue({ id: "cliente-criado" });

      const result = await createRelatorioManual("escritorio-1", {
        tipo_relatorio: "resumo_folha",
        competencia: "11/2099",
        cnpj_cliente: "12345678000199",
        razao_social: "Empresa do Relatório",
        colaboradores_ativos: 11,
        prolabores_ativos: 2,
        admissoes: 1,
      });

      expect(domainMocks.findOrCreateClienteByCnpj).toHaveBeenCalledWith({
        escritorioId: "escritorio-1",
        cnpj: "12345678000199",
        razaoSocial: "Empresa do Relatório",
      });
      expect(result).toEqual(expect.objectContaining({
        ok: true,
        clienteId: "cliente-criado",
        relatorio_ativo: true,
      }));
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
        expect.objectContaining({ cliente_id: "cliente-criado", relatorio_ativo: true }),
      );
    });

    it("blocks (em revisão, inactive) on impossible subtotal and keeps the previous active record", async () => {
      // total_notas_fiscais (1) < entrada+saida+servico (15) => critical
      const result = await createRelatorioManual("escritorio-1", {
        tipo_relatorio: "numero_notas_fiscais",
        competencia: "12/2099",
        cnpj_cliente: "12345678000199",
        total_notas_fiscais: 1,
        notas_entrada: 5,
        notas_saida: 5,
        notas_servico: 5,
      });

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: false }));
      expect((result as { relatorio_qualidade_de_dados: { status: string } }).relatorio_qualidade_de_dados.status).toBe("critico");
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({ relatorio_ativo: false }));
      // blocked draft must NOT archive the previous active record
      expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
    });

    it.each(["00/0000", "13/2026", "01/0000"])(
      "forces review with QA score zero when competencia is invalid: %s",
      async (competencia) => {
        const result = await createRelatorioManual("escritorio-1", {
          tipo_relatorio: "resumo_folha",
          competencia,
          cnpj_cliente: "12345678000199",
          colaboradores_ativos: 11,
          prolabores_ativos: 2,
          admissoes: 1,
        });

        expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: false }));
        expect(result.relatorio_qualidade_de_dados).toEqual(expect.objectContaining({
          status: "critico",
          score: 0,
          bloqueia_confirmacao: true,
          confirmacao_obrigatoria: true,
          campos: expect.arrayContaining([
            expect.objectContaining({ campo: "competencia", severidade: "critical" }),
          ]),
        }));
        expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
          expect.objectContaining({ competencia, relatorio_ativo: false }),
        );
        expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
      },
    );

    it("keeps a QA-zero AI extraction only on the document, without creating a report", async () => {
      const result = await createRelatorioManual(
        "escritorio-1",
        {
          tipo_relatorio: "resumo_folha",
          competencia: "00/0000",
          cnpj_cliente: "12345678000199",
          colaboradores_ativos: 11,
          prolabores_ativos: 2,
          admissoes: 1,
        },
        null,
        "doc-qa-zero",
      );

      expect(result).toEqual(expect.objectContaining({
        ok: true,
        relatorioId: null,
        documentoId: "doc-qa-zero",
        relatorio_ativo: false,
        relatorio_qualidade_de_dados: expect.objectContaining({ score: 0 }),
      }));
      expect(relatoriosMocks.relatorioRepo.create).not.toHaveBeenCalled();
      expect(relatoriosMocks.relatorioRepo.save).not.toHaveBeenCalled();
      expect(relatoriosMocks.documentoRepo.update).toHaveBeenCalledWith(
        { id: "doc-qa-zero", escritorio_id: "escritorio-1" },
        expect.objectContaining({
          status_extracao: "concluido",
          erro_extracao: null,
          dados_extraidos_contrato: expect.objectContaining({
            competencia: "00/0000",
            relatorio_qualidade_de_dados: expect.objectContaining({ score: 0 }),
          }),
        }),
      );
      expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
    });

    it("creates active with status ok when data is consistent", async () => {
      const result = await createRelatorioManual("escritorio-1", {
        tipo_relatorio: "resumo_folha",
        competencia: "11/2099",
        cnpj_cliente: "12345678000199",
        // fill >half of the 5 expected fields so null-count does not flag suspeito
        colaboradores_ativos: 11,
        prolabores_ativos: 2,
        admissoes: 1,
      });

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: true }));
      expect((result as { relatorio_qualidade_de_dados: { status: string } }).relatorio_qualidade_de_dados.status).toBe("ok");
      // active report archives the previous active record on the same key
      expect(relatoriosMocks.queryBuilder.set).toHaveBeenCalledWith({ relatorio_ativo: false });
    });

    it("flags suspeito (but stays active) when more than half the expected fields are null", async () => {
      const result = await createRelatorioManual("escritorio-1", {
        tipo_relatorio: "resumo_folha",
        competencia: "10/2099",
        cnpj_cliente: "12345678000199",
        colaboradores_ativos: 11, // 1 of 5 filled => 4 null > 2.5 => suspeito
      });

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: true }));
      expect((result as { relatorio_qualidade_de_dados: { status: string } }).relatorio_qualidade_de_dados.status).toBe("suspeito");
    });

    it("creates independent active manual outro reports without archiving another record", async () => {
      const result = await createRelatorioManual("escritorio-1", {
        tipo_relatorio: "outro",
        competencia: "08/2099",
        cnpj_cliente: "12345678000199",
        other_metrics: {
          receita_bruta: { value: 125000.5, unit: "BRL", label: "Receita bruta" },
          saldo: { value: -10 },
        },
      });

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: true }));
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
        expect.objectContaining({
          tipo_relatorio: "outro",
          arquivo_origem: "Cadastro manual",
          other_metrics: {
            receita_bruta: { value: 125000.5, unit: "BRL", label: "Receita bruta" },
            saldo: { value: -10 },
          },
        }),
      );
      expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
    });

    it.each([{}, { receita: { value: "10" } }, { receita: null }])(
      "rejects malformed other_metrics in manual outro: %j",
      async (otherMetrics) => {
        await expect(
          createRelatorioManual("escritorio-1", {
            tipo_relatorio: "outro",
            competencia: "08/2099",
            cnpj_cliente: "12345678000199",
            other_metrics: otherMetrics,
          }),
        ).rejects.toThrow();

        expect(relatoriosMocks.relatorioRepo.save).not.toHaveBeenCalled();
      },
    );

    it("links + finalizes the documento when a documentoId is provided (AI text channel)", async () => {
      const result = await createRelatorioManual(
        "escritorio-1",
        {
          tipo_relatorio: "resumo_folha",
          competencia: "09/2099",
          cnpj_cliente: "12345678000199",
          colaboradores_ativos: 11,
          prolabores_ativos: 2,
          admissoes: 1,
        },
        null,
        "doc-xyz",
      );

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: true, documentoId: "doc-xyz" }));
      // relatório referencia o documento
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({ arquivo_origem: "doc-xyz" }));
      // documento finalizado na mesma transação
      expect(relatoriosMocks.documentoRepo.update).toHaveBeenCalledWith(
        { id: "doc-xyz", escritorio_id: "escritorio-1" },
        expect.objectContaining({ status_extracao: "concluido" }),
      );
    });

    it("rejects a second active outro for the same document and client without altering the existing report", async () => {
      relatoriosMocks.queryBuilder.getExists.mockResolvedValueOnce(true);

      await expect(
        createRelatorioManual(
          "escritorio-1",
          {
            tipo_relatorio: "outro",
            competencia: "09/2099",
            cnpj_cliente: "12345678000199",
            other_metrics: { predios: { value: 12, unit: "unidade" } },
          },
          null,
          "doc-outro",
        ),
      ).rejects.toThrow("Este documento já possui um relatório do tipo outro ativo para este cliente e competência.");

      expect(relatoriosMocks.relatorioRepo.save).not.toHaveBeenCalled();
      expect(relatoriosMocks.queryBuilder.update).not.toHaveBeenCalled();
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.cliente_id = :clienteId", { clienteId: "cliente-1" });
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.competencia = :competencia", { competencia: "09/2099" });
    });

    it("allows a second active outro for the same document and client when the competencia differs", async () => {
      relatoriosMocks.queryBuilder.getExists.mockResolvedValueOnce(false);

      const result = await createRelatorioManual(
        "escritorio-1",
        {
          tipo_relatorio: "outro",
          competencia: "10/2099",
          cnpj_cliente: "12345678000199",
          other_metrics: { predios: { value: 12, unit: "unidade" } },
        },
        null,
        "doc-outro",
      );

      expect(result).toEqual(expect.objectContaining({ ok: true, relatorio_ativo: true }));
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.competencia = :competencia", { competencia: "10/2099" });
    });

    it("allows an active outro for a different client in the same document", async () => {
      domainMocks.findOrCreateClienteByCnpj.mockResolvedValueOnce({ id: "cliente-2" });

      await expect(
        createRelatorioManual(
          "escritorio-1",
          {
            tipo_relatorio: "outro",
            competencia: "09/2099",
            cnpj_cliente: "98765432000199",
            other_metrics: { predios: { value: 8, unit: "unidade" } },
          },
          null,
          "doc-outro",
        ),
      ).resolves.toEqual(expect.objectContaining({ ok: true, clienteId: "cliente-2" }));

      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.cliente_id = :clienteId", { clienteId: "cliente-2" });
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(expect.objectContaining({
        arquivo_origem: "doc-outro",
        cliente_id: "cliente-2",
        tipo_relatorio: "outro",
      }));
    });
  });

  describe("inserirRelatorioAutomatico (shared insertion primitive)", () => {
    beforeEach(() => {
      relatoriosMocks.relatorioRepo.save.mockImplementation(async (r) => ({ ...r, id: "rel-auto" }));
      relatoriosMocks.estatisticaRepo.find.mockResolvedValue([]);
    });

    it("inserts an active report with the default minimal payload_normalizado_ui when no factory is given", async () => {
      const resultado = await relatoriosMocks.runQueryWithRls({ escritorio_id: "escritorio-1" }, async (manager: unknown) =>
        inserirRelatorioAutomatico({
          manager: manager as never,
          escritorioId: "escritorio-1",
          cliente: { id: "cliente-9" } as never,
          tipoRelatorio: "resumo_folha",
          dadosTipados: {
            tipo_relatorio: "resumo_folha",
            competencia: "01/2026",
            cnpj_cliente: "12345678000199",
            razao_social: "Cliente planilha",
            colaboradores_ativos: 5,
            prolabores_ativos: 1,
            admissoes: 0,
          },
          arquivoOrigem: "doc-planilha",
        }),
      );

      expect(resultado.relatorioId).toBe("rel-auto");
      expect(resultado.relatorioAtivo).toBe(true);
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledWith(
        expect.objectContaining({
          cliente_id: "cliente-9",
          relatorio_ativo: true,
          arquivo_origem: "doc-planilha",
          payload_normalizado_ui: expect.objectContaining({ origem: "planilha_bulk" }),
        }),
      );
      // reaproveita o mesmo arquivamento do ativo anterior usado por createRelatorioManual
      expect(relatoriosMocks.queryBuilder.set).toHaveBeenCalledWith({ relatorio_ativo: false });
    });
  });

  describe("finalizarIngestaoRelatoriosPlanilha (bulk spreadsheet ingestion)", () => {
    beforeEach(() => {
      relatoriosMocks.relatorioRepo.save.mockImplementation(async (r) => ({ ...r, id: `rel-${relatoriosMocks.relatorioRepo.save.mock.calls.length}` }));
      relatoriosMocks.estatisticaRepo.find.mockResolvedValue([]);
      domainMocks.getDocumentoById.mockResolvedValue({ id: "doc-planilha", escritorio_id: "escritorio-1" });
    });

    it("returns null (mapped to 404 by the caller) when the documento does not exist", async () => {
      domainMocks.getDocumentoById.mockResolvedValueOnce(null);

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-inexistente",
        relatorios: [{ cnpj: "11111111000111", tipoRelatorio: "outro", otherMetrics: { predios: { value: 1 } } }],
      });

      expect(resultado).toBeNull();
    });

    it("inserts one relatorio per tuple across multiple clients and marks the documento concluido", async () => {
      domainMocks.findOrCreateClienteByCnpj
        .mockResolvedValueOnce({ id: "cliente-a" })
        .mockResolvedValueOnce({ id: "cliente-b" });

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        totalLinhas: 2,
        relatorios: [
          { cnpj: "11111111000111", competencia: "01/2026", tipoRelatorio: "resumo_folha", colaboradoresAtivos: 5, prolaboresAtivos: 1, admissoes: 0 },
          { cnpj: "22222222000122", competencia: "01/2026", tipoRelatorio: "numero_notas_fiscais", totalNotasFiscais: 10, notasEntrada: 5, notasSaida: 5, notasServico: 0 },
        ],
      });

      expect(resultado).toEqual({ ok: true, totalRelatoriosCriados: 2, totalClientes: 2, erros: [] });
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledTimes(2);
      // Regressão: a Lambda de planilha devolve as tuplas em camelCase
      // (colaboradoresAtivos, totalNotasFiscais, ...) — sem a conversão para o
      // nome de coluna snake_case, esses valores entrariam como null.
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenNthCalledWith(
        1,
        expect.objectContaining({ colaboradores_ativos: 5, prolabores_ativos: 1, admissoes: 0 }),
      );
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenNthCalledWith(
        2,
        expect.objectContaining({ total_notas_fiscais: 10, notas_entrada: 5, notas_saida: 5, notas_servico: 0 }),
      );
      expect(relatoriosMocks.documentoRepo.update).toHaveBeenCalledWith(
        { id: "doc-planilha", escritorio_id: "escritorio-1" },
        expect.objectContaining({ status_extracao: "concluido", erro_extracao: null }),
      );
    });

    it("records an error for an invalid-cnpj tuple and still commits the other valid tuples", async () => {
      domainMocks.normalizarCnpj.mockImplementationOnce(() => {
        throw new Error("cnpj deve conter 11 dígitos (CPF) ou 14 dígitos (CNPJ).");
      });
      domainMocks.findOrCreateClienteByCnpj.mockResolvedValueOnce({ id: "cliente-ok" });

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        relatorios: [
          { cnpj: "abc", tipoRelatorio: "resumo_folha", colaboradoresAtivos: 1 },
          { cnpj: "11111111000111", competencia: "01/2026", tipoRelatorio: "resumo_folha", colaboradoresAtivos: 3, prolaboresAtivos: 1, admissoes: 0 },
        ],
      });

      expect(resultado?.totalRelatoriosCriados).toBe(1);
      expect(resultado?.totalClientes).toBe(1);
      expect(resultado?.erros).toEqual([expect.objectContaining({ codigo: "cnpj_invalido", cnpj: "abc" })]);
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledTimes(1);
      // erro de linha da própria Lambda (planilha estruturalmente inválida) é preservado junto
      const resultadoComErroDaLambda = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        relatorios: [],
        erros: [{ codigo: "coluna_cnpj_ausente", mensagem: "coluna cnpj não encontrada" }],
      });
      expect(resultadoComErroDaLambda?.erros).toEqual([
        expect.objectContaining({ codigo: "coluna_cnpj_ausente" }),
      ]);
    });

    it("keeps a QA-critical tuple inactive without blocking the other tuples in the same file (outlier gate)", async () => {
      domainMocks.findOrCreateClienteByCnpj
        .mockResolvedValueOnce({ id: "cliente-critico" })
        .mockResolvedValueOnce({ id: "cliente-ok" });

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        relatorios: [
          // totalNotasFiscais (1) < entrada+saida+servico (15) => crítico => QA gate desativa
          { cnpj: "11111111000111", competencia: "01/2026", tipoRelatorio: "numero_notas_fiscais", totalNotasFiscais: 1, notasEntrada: 5, notasSaida: 5, notasServico: 5 },
          { cnpj: "22222222000122", competencia: "01/2026", tipoRelatorio: "numero_notas_fiscais", totalNotasFiscais: 10, notasEntrada: 5, notasSaida: 5, notasServico: 0 },
        ],
      });

      // crítico ainda INSERE (inativo), nunca aborta a tupla — mesmo gate de todo outro canal
      expect(resultado?.totalRelatoriosCriados).toBe(2);
      expect(resultado?.erros).toEqual([]);
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenNthCalledWith(
        1,
        expect.objectContaining({ cliente_id: "cliente-critico", relatorio_ativo: false }),
      );
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenNthCalledWith(
        2,
        expect.objectContaining({ cliente_id: "cliente-ok", relatorio_ativo: true }),
      );
    });

    it("fans out 'outro' rows across clients while a duplicate active outro for the SAME client on this document is recorded as an error, not aborted", async () => {
      domainMocks.findOrCreateClienteByCnpj
        .mockResolvedValueOnce({ id: "cliente-x" })
        .mockResolvedValueOnce({ id: "cliente-y" });
      // A 1ª tupla ("outro" para cliente-x) colide com um outro ativo já existente
      // para o MESMO documento+cliente (garantirOutroIneditoPorDocumento).
      relatoriosMocks.queryBuilder.getExists.mockResolvedValueOnce(true);

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        relatorios: [
          { cnpj: "11111111000111", tipoRelatorio: "outro", otherMetrics: { predios: { value: 3 } } },
          { cnpj: "22222222000122", tipoRelatorio: "outro", otherMetrics: { predios: { value: 4 } } },
        ],
      });

      expect(resultado?.totalRelatoriosCriados).toBe(1);
      expect(resultado?.totalClientes).toBe(1);
      expect(resultado?.erros).toEqual([expect.objectContaining({ codigo: "insercao_falhou" })]);
      // a checagem de dedupe é escopada por cliente — os dois clientes foram checados independentemente
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.cliente_id = :clienteId", { clienteId: "cliente-x" });
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.cliente_id = :clienteId", { clienteId: "cliente-y" });
    });

    it("inserts 'outro' for the SAME client in TWO different competências from the same document (regression: garantirOutroIneditoPorDocumento must scope by competência too)", async () => {
      // Um único arquivo bulk usa o MESMO documentoId (arquivo_origem) para
      // todo cliente/competência dele — sem escopar por competência aqui, o
      // 2º período do mesmo cliente colidiria com o 1º e nunca seria inserido.
      domainMocks.findOrCreateClienteByCnpj
        .mockResolvedValueOnce({ id: "cliente-z" })
        .mockResolvedValueOnce({ id: "cliente-z" });
      relatoriosMocks.queryBuilder.getExists.mockResolvedValue(false);

      const resultado = await finalizarIngestaoRelatoriosPlanilha({
        escritorioId: "escritorio-1",
        documentoId: "doc-planilha",
        relatorios: [
          { cnpj: "11111111000111", competencia: "01/2026", tipoRelatorio: "outro", otherMetrics: { predios: { value: 100 } } },
          { cnpj: "11111111000111", competencia: "02/2026", tipoRelatorio: "outro", otherMetrics: { predios: { value: 20 } } },
        ],
      });

      expect(resultado?.erros).toEqual([]);
      expect(resultado?.totalRelatoriosCriados).toBe(2);
      expect(relatoriosMocks.relatorioRepo.save).toHaveBeenCalledTimes(2);
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.competencia = :competencia", { competencia: "01/2026" });
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("relatorio.competencia = :competencia", { competencia: "02/2026" });
    });
  });

  describe("getRelatorio", () => {
    it("flags cadastro_ia as true when the linked documento came from the AI text channel", async () => {
      relatoriosMocks.relatorioRepo.findOne.mockResolvedValue({
        id: "report-1",
        escritorio_id: "escritorio-1",
        cliente_id: "cliente-1",
        arquivo_origem: "11111111-1111-1111-1111-111111111111",
        extracao_bruta: null,
      });
      relatoriosMocks.documentoRepo.findOne.mockResolvedValue({
        id: "11111111-1111-1111-1111-111111111111",
        escritorio_id: "escritorio-1",
        mime_type: "text/plain",
        dados_extraidos_contrato: null,
      });

      const result = await getRelatorio("report-1", "escritorio-1");

      expect(result).toEqual(expect.objectContaining({ cadastro_ia: true }));
    });

    it("flags cadastro_ia as false for a report linked to a regular PDF documento", async () => {
      relatoriosMocks.relatorioRepo.findOne.mockResolvedValue({
        id: "report-1",
        escritorio_id: "escritorio-1",
        cliente_id: "cliente-1",
        arquivo_origem: "22222222-2222-2222-2222-222222222222",
        extracao_bruta: null,
      });
      relatoriosMocks.documentoRepo.findOne.mockResolvedValue({
        id: "22222222-2222-2222-2222-222222222222",
        escritorio_id: "escritorio-1",
        mime_type: "application/pdf",
        dados_extraidos_contrato: null,
      });

      const result = await getRelatorio("report-1", "escritorio-1");

      expect(result).toEqual(expect.objectContaining({ cadastro_ia: false }));
    });

    it("flags cadastro_ia as false when the report has no linked documento", async () => {
      relatoriosMocks.relatorioRepo.findOne.mockResolvedValue({
        id: "report-1",
        escritorio_id: "escritorio-1",
        cliente_id: "cliente-1",
        arquivo_origem: null,
        extracao_bruta: null,
      });

      const result = await getRelatorio("report-1", "escritorio-1");

      expect(result).toEqual(expect.objectContaining({ cadastro_ia: false }));
    });
  });

  describe("listClientesComRelatorios", () => {
    it("aggregates multiple relatórios per cliente: count, distinct tipos, most recent created_at and no critical flag", async () => {
      relatoriosMocks.queryBuilder.getRawOne.mockResolvedValueOnce({ total: "1" });
      relatoriosMocks.queryBuilder.getRawMany.mockResolvedValueOnce([
        {
          cliente_id: "cliente-1",
          cliente_razao_social: "Cliente A",
          cliente_cnpj: "12345678000199",
          total_relatorios: "3",
          tipos_relatorio: ["resumo_folha", "numero_notas_fiscais"],
          ultima_atualizacao: "2026-02-10T10:00:00.000Z",
          tem_relatorio_critico: false,
        },
      ]);

      const result = await listClientesComRelatorios("escritorio-1", {});

      expect(result).toEqual({
        items: [
          {
            cliente: { id: "cliente-1", razao_social: "Cliente A", cnpj: "12345678000199" },
            total_relatorios: 3,
            tipos_relatorio: ["resumo_folha", "numero_notas_fiscais"],
            ultima_atualizacao: "2026-02-10T10:00:00.000Z",
            tem_relatorio_critico: false,
          },
        ],
        page: 1,
        page_size: 25,
        total: 1,
        total_pages: 1,
      });
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith("cliente.ativo = true");
      expect(relatoriosMocks.queryBuilder.groupBy).toHaveBeenCalledWith("cliente.id");
    });

    it("flags tem_relatorio_critico true when at least one relatório of the cliente is critical, false otherwise", async () => {
      relatoriosMocks.queryBuilder.getRawOne.mockResolvedValueOnce({ total: "2" });
      relatoriosMocks.queryBuilder.getRawMany.mockResolvedValueOnce([
        {
          cliente_id: "cliente-critico",
          cliente_razao_social: "Cliente Crítico",
          cliente_cnpj: "11111111000111",
          total_relatorios: "2",
          tipos_relatorio: ["resumo_folha"],
          ultima_atualizacao: "2026-02-10T10:00:00.000Z",
          tem_relatorio_critico: true,
        },
        {
          cliente_id: "cliente-ok",
          cliente_razao_social: "Cliente OK",
          cliente_cnpj: "22222222000122",
          total_relatorios: "1",
          tipos_relatorio: ["numero_notas_fiscais"],
          ultima_atualizacao: "2026-02-09T10:00:00.000Z",
          tem_relatorio_critico: false,
        },
      ]);

      const result = await listClientesComRelatorios("escritorio-1", {});

      expect(result.items[0]).toEqual(expect.objectContaining({ tem_relatorio_critico: true }));
      expect(result.items[1]).toEqual(expect.objectContaining({ tem_relatorio_critico: false }));
    });

    it("scopes the aggregation to the escritório via runQueryWithRls (tenant isolation)", async () => {
      relatoriosMocks.queryBuilder.getRawOne.mockResolvedValueOnce({ total: "0" });
      relatoriosMocks.queryBuilder.getRawMany.mockResolvedValueOnce([]);

      await listClientesComRelatorios("escritorio-2", {});

      expect(relatoriosMocks.runQueryWithRls).toHaveBeenCalledWith(
        { escritorio_id: "escritorio-2" },
        expect.any(Function),
      );
      expect(relatoriosMocks.queryBuilder.where).toHaveBeenCalledWith(
        "relatorio.escritorio_id = :escritorioId",
        { escritorioId: "escritorio-2" },
      );
    });

    it("paginates by cliente (not by relatório row): page/page_size slice the grouped result and total reflects distinct clientes", async () => {
      relatoriosMocks.queryBuilder.getRawOne.mockResolvedValueOnce({ total: "5" });
      relatoriosMocks.queryBuilder.getRawMany.mockResolvedValueOnce([
        {
          cliente_id: "cliente-2",
          cliente_razao_social: "Cliente B",
          cliente_cnpj: "22222222000122",
          total_relatorios: "1",
          tipos_relatorio: ["resumo_folha"],
          ultima_atualizacao: "2026-02-08T10:00:00.000Z",
          tem_relatorio_critico: false,
        },
      ]);

      const result = await listClientesComRelatorios("escritorio-1", { page: 2, pageSize: 1 });

      expect(result.page).toBe(2);
      expect(result.page_size).toBe(1);
      expect(result.total).toBe(5);
      expect(result.total_pages).toBe(5);
      expect(result.items).toHaveLength(1);
      expect(relatoriosMocks.queryBuilder.offset).toHaveBeenCalledWith(1);
      expect(relatoriosMocks.queryBuilder.limit).toHaveBeenCalledWith(1);
    });

    it("filters by free-text query against cliente razão social / CNPJ", async () => {
      relatoriosMocks.queryBuilder.getRawOne.mockResolvedValueOnce({ total: "1" });
      relatoriosMocks.queryBuilder.getRawMany.mockResolvedValueOnce([
        {
          cliente_id: "cliente-1",
          cliente_razao_social: "Empresa Filtrada",
          cliente_cnpj: "12345678000199",
          total_relatorios: "1",
          tipos_relatorio: ["resumo_folha"],
          ultima_atualizacao: "2026-02-10T10:00:00.000Z",
          tem_relatorio_critico: false,
        },
      ]);

      const result = await listClientesComRelatorios("escritorio-1", { query: "Filtrada" });

      expect(result.items).toHaveLength(1);
      expect(relatoriosMocks.queryBuilder.andWhere).toHaveBeenCalledWith(expect.any(Brackets));
    });
  });
});
