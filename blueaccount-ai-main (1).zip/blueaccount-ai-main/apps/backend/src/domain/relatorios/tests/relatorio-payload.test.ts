import { describe, expect, it } from "vitest";
import {
  buildLeanExtracaoBruta,
  buildRastreabilidadePorCampo,
  buildRelatorioPersistenceDraft,
  normalizeOtherMetrics,
} from "../relatorio-payload.js";

describe("normalizeOtherMetrics", () => {
  it("aceita valores finitos positivos, zero e negativos e normaliza textos", () => {
    expect(
      normalizeOtherMetrics({
        " receita_bruta ": { value: 125000.5, unit: " BRL ", label: " Receita bruta " },
        saldo: { value: -10 },
        predios: { value: 0, unit: "" },
      }),
    ).toEqual({
      receita_bruta: { value: 125000.5, unit: "BRL", label: "Receita bruta" },
      saldo: { value: -10 },
      predios: { value: 0 },
    });
  });

  it.each([
    [null],
    [{}],
    [{ receita: { value: "10" } }],
    [{ receita: { value: Number.POSITIVE_INFINITY } }],
    [{ receita: null }],
    [{ "  ": { value: 10 } }],
  ])("rejeita mapas vazios ou métricas malformadas: %j", (value) => {
    expect(() => normalizeOtherMetrics(value)).toThrow();
  });
});

describe("buildRastreabilidadePorCampo", () => {
  it("indexa id/fonte por campo a partir de report.campos", () => {
    const map = buildRastreabilidadePorCampo({
      campos: [
        { campo: "colaboradores_ativos", valor_extraido: 73, id: "p1_t0.1958_l0.0476" },
        { campo: "admissoes", valor_extraido: 2, fonte: "Admissões: 2" },
        { campo: "  ", valor_extraido: 1, id: "x" }, // campo vazio ignorado
        { campo: "rescisoes", valor_extraido: 0 }, // sem id/fonte → ignorado
      ],
    });

    expect(map.get("colaboradores_ativos")).toEqual({ id: "p1_t0.1958_l0.0476" });
    expect(map.get("admissoes")).toEqual({ fonte: "Admissões: 2" });
    expect(map.has("rescisoes")).toBe(false);
    expect(map.size).toBe(2);
  });

  it("retorna mapa vazio quando não há campos (canal texto puro)", () => {
    expect(buildRastreabilidadePorCampo({ tipo_relatorio: "resumo_folha" }).size).toBe(0);
    expect(buildRastreabilidadePorCampo(null).size).toBe(0);
  });
});

describe("buildLeanExtracaoBruta", () => {
  const normalized = { colaboradores_ativos: 73, admissoes: 2 };

  it("reanexa id/fonte quando há rastreabilidade (canal IA/agente)", () => {
    const rastreabilidade = buildRastreabilidadePorCampo({
      campos: [{ campo: "colaboradores_ativos", valor_extraido: 73, id: "p1_t0.1958_l0.0476" }],
    });
    const out = buildLeanExtracaoBruta("doc-1", normalized, rastreabilidade);
    const campos = out.campos as Array<Record<string, unknown>>;

    const colaboradores = campos.find((c) => c.campo === "colaboradores_ativos");
    expect(colaboradores).toMatchObject({ valor_extraido: 73, id: "p1_t0.1958_l0.0476" });
    // Campo sem rastreabilidade permanece enxuto.
    const admissoes = campos.find((c) => c.campo === "admissoes");
    expect(admissoes).toEqual({ campo: "admissoes", valor_extraido: 2 });
  });

  it("mantém o formato enxuto quando não há rastreabilidade", () => {
    const out = buildLeanExtracaoBruta("doc-1", normalized);
    const campos = out.campos as Array<Record<string, unknown>>;
    for (const c of campos) {
      expect(Object.keys(c).sort()).toEqual(["campo", "valor_extraido"]);
    }
  });
});

describe("buildRelatorioPersistenceDraft", () => {
  it("propaga id/fonte de rawPayload.campos para extracao_bruta.campos", () => {
    const draft = buildRelatorioPersistenceDraft({
      documentoId: "doc-1",
      rawPayload: {
        tipo_relatorio: "resumo_folha",
        competencia: "03/2026",
        colaboradores_ativos: 73,
        campos: [{ campo: "colaboradores_ativos", valor_extraido: 73, id: "p1_t0.1958_l0.0476" }],
      },
    });

    const extracao = draft.extracao_bruta as { campos: Array<Record<string, unknown>> };
    const colaboradores = extracao.campos.find((c) => c.campo === "colaboradores_ativos");
    expect(colaboradores).toMatchObject({ id: "p1_t0.1958_l0.0476" });
  });

  it("preserva other_metrics tipado na persistência e extração bruta de outro", () => {
    const draft = buildRelatorioPersistenceDraft({
      documentoId: "doc-outro",
      rawPayload: {
        tipo_relatorio: "outro",
        competencia: "03/2026",
        other_metrics: { predios: { value: 12, unit: "unidade", label: "Prédios" } },
      },
    });

    expect(draft.other_metrics).toEqual({
      predios: { value: 12, unit: "unidade", label: "Prédios" },
    });
    const extracao = draft.extracao_bruta as { campos: Array<Record<string, unknown>> };
    expect(extracao.campos).toContainEqual({
      campo: "other_metrics",
      valor_extraido: { predios: { value: 12, unit: "unidade", label: "Prédios" } },
    });
  });
});
