import { pl } from "nodejs-polars";
import type { FindOptionsWhere } from "typeorm";
import { AppDataSource, runQueryWithRls } from "../../database/data-source.js";
import { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import { RelatorioEstatisticaCliente } from "../../database/modules/tenant/entities/relatorio-estatistica-cliente.entity.js";

const RELATORIO_NUMERIC_FIELDS = [
  "colaboradores_ativos",
  "prolabores_ativos",
  "admissoes",
  "rescisoes",
  "afastados",
  "total_notas_fiscais",
  "notas_entrada",
  "notas_saida",
  "notas_servico",
  "total_lancamentos",
  "lancamentos_debito",
  "lancamentos_credito",
] as const;

type EstatisticaRecord = {
  cliente_id: string;
  tipo_relatorio: string;
  campo: string;
  quantidade_amostras: number;
  media: number | null;
  mediana: number | null;
  desvio_padrao: number | null;
  minimo: number | null;
  maximo: number | null;
  competencia_inicial: string | null;
  competencia_final: string | null;
};

function toFiniteNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeOptionalString(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function buildMetricRows(relatorios: Relatorio[]) {
  const rows: Array<{
    cliente_id: string;
    tipo_relatorio: string;
    campo: string;
    valor: number;
    competencia: string | null;
  }> = [];

  for (const relatorio of relatorios) {
    if (!relatorio.cliente_id || !relatorio.tipo_relatorio) continue;

    const record = relatorio as unknown as Record<string, unknown>;
    for (const campo of RELATORIO_NUMERIC_FIELDS) {
      const valor = toFiniteNumber(record[campo]);
      if (valor === null) continue;

      rows.push({
        cliente_id: relatorio.cliente_id,
        tipo_relatorio: relatorio.tipo_relatorio,
        campo,
        valor,
        competencia: normalizeOptionalString(relatorio.competencia),
      });
    }
  }

  return rows;
}

function buildEstatisticas(rows: ReturnType<typeof buildMetricRows>): EstatisticaRecord[] {
  if (rows.length === 0) return [];

  const df = pl.DataFrame({
    cliente_id: rows.map((row) => row.cliente_id),
    tipo_relatorio: rows.map((row) => row.tipo_relatorio),
    campo: rows.map((row) => row.campo),
    valor: rows.map((row) => row.valor),
    competencia: rows.map((row) => row.competencia),
  });
  const valor = pl.col("valor");
  const competencia = pl.col("competencia");

  return df
    .groupBy("cliente_id", "tipo_relatorio", "campo")
    .agg(
      valor.count().as("quantidade_amostras"),
      valor.mean().as("media"),
      valor.median().as("mediana"),
      valor.std().as("desvio_padrao"),
      valor.min().as("minimo"),
      valor.max().as("maximo"),
      competencia.min().as("competencia_inicial"),
      competencia.max().as("competencia_final"),
    )
    .toRecords() as EstatisticaRecord[];
}

function roundOrNull(value: unknown): number | null {
  const parsed = toFiniteNumber(value);
  return parsed === null ? null : Number(parsed.toFixed(4));
}

export async function recalcularRelatoriosEstatisticasCliente(input: {
  escritorioId: string;
  clienteId?: string;
}) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const relatorioRepo = manager.getRepository(Relatorio);
    const estatisticaRepo = manager.getRepository(RelatorioEstatisticaCliente);

    const where: FindOptionsWhere<Relatorio> = {
      escritorio_id: input.escritorioId,
      relatorio_ativo: true,
    };
    if (input.clienteId) {
      where.cliente_id = input.clienteId;
    }

    const relatorios = await relatorioRepo.find({ where });
    const rows = buildMetricRows(relatorios);
    const estatisticas = buildEstatisticas(rows);

    const deleteQuery = estatisticaRepo
      .createQueryBuilder()
      .delete()
      .where("escritorio_id = :escritorioId", { escritorioId: input.escritorioId });

    if (input.clienteId) {
      deleteQuery.andWhere("cliente_id = :clienteId", { clienteId: input.clienteId });
    }

    await deleteQuery.execute();

    if (estatisticas.length > 0) {
      const calculadoEm = new Date();
      await estatisticaRepo.save(
        estatisticas.map((item) =>
          estatisticaRepo.create({
            escritorio_id: input.escritorioId,
            cliente_id: item.cliente_id,
            tipo_relatorio: item.tipo_relatorio,
            campo: item.campo,
            quantidade_amostras: Number(item.quantidade_amostras ?? 0),
            media: roundOrNull(item.media),
            mediana: roundOrNull(item.mediana),
            desvio_padrao: roundOrNull(item.desvio_padrao),
            minimo: roundOrNull(item.minimo),
            maximo: roundOrNull(item.maximo),
            competencia_inicial: normalizeOptionalString(item.competencia_inicial),
            competencia_final: normalizeOptionalString(item.competencia_final),
            calculado_em: calculadoEm,
            metadados: {
              versao: 1,
              fonte: "relatorios_ativos",
            },
          }),
        ),
      );
    }

    return {
      ok: true as const,
      relatorios_considerados: relatorios.length,
      valores_considerados: rows.length,
      estatisticas_calculadas: estatisticas.length,
      calculado_em: new Date().toISOString(),
    };
  });
}

export async function listRelatoriosEstatisticasCliente(input: {
  escritorioId: string;
  clienteId?: string;
  tipoRelatorio?: string;
}) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const where: FindOptionsWhere<RelatorioEstatisticaCliente> = {
      escritorio_id: input.escritorioId,
    };
    if (input.clienteId) {
      where.cliente_id = input.clienteId;
    }
    if (input.tipoRelatorio) {
      where.tipo_relatorio = input.tipoRelatorio;
    }

    return await manager.getRepository(RelatorioEstatisticaCliente).find({
      where,
      relations: ["cliente"],
      order: {
        calculado_em: "DESC",
        tipo_relatorio: "ASC",
        campo: "ASC",
      },
    });
  });
}
