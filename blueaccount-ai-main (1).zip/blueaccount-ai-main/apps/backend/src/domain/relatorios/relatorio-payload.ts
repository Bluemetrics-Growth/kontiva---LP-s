import type { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";

export const RELATORIO_DB_FIELDS = [
  "tipo_relatorio", "competencia", "razao_social",
  "colaboradores_ativos", "prolabores_ativos", "admissoes", "rescisoes", "afastados",
  "total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico",
  "total_lancamentos", "lancamentos_debito", "lancamentos_credito",
  "itens_excedentes", "itens_multa", "other_metrics",
] as const;

export type RelatorioQualidadeDeDados = {
  status?: "ok" | "suspeito" | "critico" | string;
  score?: number;
  bloqueia_confirmacao?: boolean;
  confirmacao_obrigatoria?: boolean;
  campos?: Array<Record<string, unknown>>;
  warnings?: unknown[];
  erros?: unknown[];
};

export const RELATORIO_FIELDS = [
  "competencia", "razao_social",
  "colaboradores_ativos", "prolabores_ativos", "admissoes", "rescisoes", "afastados",
  "total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico",
  "total_lancamentos", "lancamentos_debito", "lancamentos_credito",
  "itens_excedentes", "itens_multa", "other_metrics",
] as const;

export const RELATORIO_LEAN_CAMPOS = RELATORIO_DB_FIELDS;

const RELATORIO_INTEGER_FIELDS = new Set<string>([
  "colaboradores_ativos",
  "prolabores_ativos",
  "admissoes",
  "rescisoes",
  "afastados",
  "total_notas_fiscais",
  "notas_entrada",
  "notas_saida",
  "notas_servico",
  "total_lancamentos",
  "lancamentos_debito",
  "lancamentos_credito",
]);

export function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

export function getRelatorioQualidadeDeDados(input: unknown): RelatorioQualidadeDeDados | null {
  if (!isRecord(input)) return null;

  const direct = input.relatorio_qualidade_de_dados ?? input.qualidade_de_dados;
  if (isRecord(direct)) return direct as RelatorioQualidadeDeDados;

  const payloadInsercaoDb = input.payloadInsercaoDb;
  if (isRecord(payloadInsercaoDb)) {
    const nested = payloadInsercaoDb.relatorio_qualidade_de_dados ?? payloadInsercaoDb.qualidade_de_dados;
    if (isRecord(nested)) return nested as RelatorioQualidadeDeDados;
  }

  return null;
}

export function relatorioQualidadeBloqueiaConfirmacao(qualidade: RelatorioQualidadeDeDados | null): boolean {
  if (!qualidade) return false;
  return qualidade.bloqueia_confirmacao === true || qualidade.status === "critico";
}

export function firstReportFromPayload(input: Record<string, unknown>): Record<string, unknown> {
  const consolidated = isRecord(input.relatorioCompleto) ? input.relatorioCompleto : input;

  const reportExtraction = isRecord(input.reportExtraction) ? input.reportExtraction : null;
  const reportExtractionPayload = isRecord(reportExtraction?.payload) ? reportExtraction.payload : null;
  if (reportExtractionPayload && Array.isArray(reportExtractionPayload.relatorios) && isRecord(reportExtractionPayload.relatorios[0])) {
    return reportExtractionPayload.relatorios[0];
  }

  if (Array.isArray(consolidated.relatorios) && isRecord(consolidated.relatorios[0])) {
    return consolidated.relatorios[0];
  }

  const consolidatedExtraction = consolidated.extraction;
  if (isRecord(consolidatedExtraction)) {
    const payload = consolidatedExtraction.payload;
    if (isRecord(payload) && Array.isArray(payload.relatorios) && isRecord(payload.relatorios[0])) {
      return payload.relatorios[0];
    }
  }

  if (Array.isArray(input.relatorios) && isRecord(input.relatorios[0])) {
    return input.relatorios[0];
  }

  const extraction = input.extraction;
  if (isRecord(extraction)) {
    const payload = extraction.payload;
    if (isRecord(payload) && Array.isArray(payload.relatorios) && isRecord(payload.relatorios[0])) {
      return payload.relatorios[0];
    }
  }

  return input;
}

export function normalizeRelatorioInput(input: Record<string, unknown>): Record<string, unknown> {
  const consolidated = isRecord(input.relatorioCompleto) ? input.relatorioCompleto : input;
  const report = firstReportFromPayload(input);
  const normalized: Record<string, unknown> = { ...report };
  const identificacao =
    (isRecord(consolidated.identificacao) ? consolidated.identificacao : null) ??
    (isRecord(input.reportIdentification) ? input.reportIdentification : null);

  if (identificacao) {
    for (const campo of ["tipo_relatorio", "cnpj_cliente", "competencia", "razao_social"]) {
      const value = normalized[campo];
      normalized[campo] = value === undefined || value === null || value === "" || value === "desconhecido"
        ? identificacao[campo] ?? null
        : value;
    }
  }

  const campos = Array.isArray(report.campos) ? report.campos : [];

  for (const campoExtraido of campos) {
    if (!isRecord(campoExtraido) || typeof campoExtraido.campo !== "string") continue;
    const campo = campoExtraido.campo.trim();
    if (!campo || campo in normalized) continue;
    normalized[campo] = "valor_extraido" in campoExtraido ? campoExtraido.valor_extraido : null;
  }

  return normalized;
}

export function getCamposEditados(input: Record<string, unknown>): Record<string, unknown> {
  const edited = input.campos_editados;
  if (!isRecord(edited)) return {};
  return edited;
}

export function applyCamposEditados(normalizedInput: Record<string, unknown>, input: Record<string, unknown>): Record<string, unknown> {
  return {
    ...normalizedInput,
    ...getCamposEditados(input),
  };
}

export function applyCamposEditadosToPayloadInsercaoDb(
  payloadInsercaoDb: Record<string, unknown>,
  camposEditados: Record<string, unknown>,
): Record<string, unknown> {
  const next = { ...payloadInsercaoDb };
  for (const [campo, valor] of Object.entries(camposEditados)) {
    if (Object.prototype.hasOwnProperty.call(next, campo)) {
      next[campo] = RELATORIO_INTEGER_FIELDS.has(campo)
        ? parseNullableInteger(valor)
        : campo === "other_metrics"
          ? normalizeOtherMetrics(valor)
          : valor;
    }
    next.extracao_bruta = updateLeanExtracaoBrutaCampo(next.extracao_bruta, campo, next[campo] ?? valor);
  }
  return next;
}

function updateLeanExtracaoBrutaCampo(extracaoBruta: unknown, campo: string, valor: unknown): unknown {
  if (!isRecord(extracaoBruta) || !Array.isArray(extracaoBruta.campos)) return extracaoBruta;
  let changed = false;
  const campos = extracaoBruta.campos.map((item) => {
    if (!isRecord(item) || item.campo !== campo) return item;
    changed = true;
    return { ...item, valor_extraido: valor };
  });
  return changed ? { ...extracaoBruta, campos } : extracaoBruta;
}

// Rastreabilidade por campo (id do bloco de OCR anotado + fonte) vinda do payload
// bruto (canal IA/agente: report.campos[]). Indexada por nome canônico do campo
// para reanexar id/fonte ao extracao_bruta enxuto. Vazia no canal sem OCR.
type RastreabilidadeCampo = { id?: string; fonte?: string };

export function buildRastreabilidadePorCampo(rawPayload: unknown): Map<string, RastreabilidadeCampo> {
  const map = new Map<string, RastreabilidadeCampo>();
  if (!isRecord(rawPayload)) return map;
  const report = firstReportFromPayload(rawPayload);
  const campos = Array.isArray(report.campos) ? report.campos : [];
  for (const item of campos) {
    if (!isRecord(item) || typeof item.campo !== "string") continue;
    const campo = item.campo.trim();
    if (!campo) continue;
    const entry: RastreabilidadeCampo = {};
    if (typeof item.id === "string" && item.id.trim()) entry.id = item.id.trim();
    if (typeof item.fonte === "string" && item.fonte.trim()) entry.fonte = item.fonte.trim();
    if (entry.id || entry.fonte) map.set(campo, entry);
  }
  return map;
}

export function buildLeanExtracaoBruta(
  idArquivo: string,
  normalizedInput: Record<string, unknown>,
  rastreabilidadePorCampo?: Map<string, RastreabilidadeCampo>,
): Record<string, unknown> {
  const campos = RELATORIO_LEAN_CAMPOS
    .filter((campo) => normalizedInput[campo] !== undefined && normalizedInput[campo] !== null)
    .map((campo) => {
      const base: Record<string, unknown> = { campo, valor_extraido: normalizedInput[campo] };
      // Reanexa id/fonte quando o campo veio de um bloco de OCR anotado (canal
      // IA/agente). Mantém o formato enxuto quando não há rastreabilidade.
      const rastro = rastreabilidadePorCampo?.get(campo);
      if (rastro?.id) base.id = rastro.id;
      if (rastro?.fonte) base.fonte = rastro.fonte;
      return base;
    });
  return { idArquivo, campos };
}

export function parseNullableInteger(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number.parseInt(String(value), 10);
  return Number.isNaN(parsed) ? null : parsed;
}

export type OtherMetrics = Record<string, { value: number; unit?: string; label?: string }>;

export function normalizeOtherMetrics(value: unknown): OtherMetrics {
  if (!isRecord(value) || Object.keys(value).length === 0) {
    throw new Error("other_metrics deve conter pelo menos uma métrica.");
  }

  const normalized: OtherMetrics = {};
  for (const [rawKey, rawMetric] of Object.entries(value)) {
    const key = rawKey.trim();
    if (!key) throw new Error("As chaves de other_metrics não podem ser vazias.");
    if (Object.prototype.hasOwnProperty.call(normalized, key)) {
      throw new Error(`Chave duplicada em other_metrics após normalização: ${key}.`);
    }
    if (!isRecord(rawMetric)) {
      throw new Error(`other_metrics.${key} deve ser um objeto com value numérico.`);
    }
    if (typeof rawMetric.value !== "number" || !Number.isFinite(rawMetric.value)) {
      throw new Error(`other_metrics.${key}.value deve ser um número finito.`);
    }
    const metric: { value: number; unit?: string; label?: string } = { value: rawMetric.value };
    for (const field of ["unit", "label"] as const) {
      const raw = rawMetric[field];
      if (raw === undefined || raw === null || raw === "") continue;
      if (typeof raw !== "string") {
        throw new Error(`other_metrics.${key}.${field} deve ser texto.`);
      }
      const text = raw.trim();
      if (text) metric[field] = text;
    }
    normalized[key] = metric;
  }
  return normalized;
}

export function montarPayloadInsercaoDbRelatorio(relatorio: Relatorio | Record<string, unknown>): Record<string, unknown> {
  const record = relatorio as unknown as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  for (const field of RELATORIO_DB_FIELDS) {
    out[field] = record[field] ?? null;
  }
  return out;
}

export function buildRelatorioPersistenceDraft(input: {
  rawPayload: Record<string, unknown>;
  documentoId: string;
  camposEditados?: Record<string, unknown>;
}): Record<string, unknown> {
  const normalizedInput = applyCamposEditados(normalizeRelatorioInput(input.rawPayload), {
    campos_editados: input.camposEditados ?? {},
  });
  const rastreabilidade = buildRastreabilidadePorCampo(input.rawPayload);

  const tipoRelatorio = String(normalizedInput.tipo_relatorio || "desconhecido").trim();
  return {
    tipo_relatorio: tipoRelatorio,
    competencia: String(normalizedInput.competencia || "").trim() || null,
    razao_social: String(normalizedInput.razao_social || "").trim() || null,
    colaboradores_ativos: parseNullableInteger(normalizedInput.colaboradores_ativos),
    prolabores_ativos: parseNullableInteger(normalizedInput.prolabores_ativos),
    admissoes: parseNullableInteger(normalizedInput.admissoes),
    rescisoes: parseNullableInteger(normalizedInput.rescisoes),
    afastados: parseNullableInteger(normalizedInput.afastados),
    total_notas_fiscais: parseNullableInteger(normalizedInput.total_notas_fiscais),
    notas_entrada: parseNullableInteger(normalizedInput.notas_entrada),
    notas_saida: parseNullableInteger(normalizedInput.notas_saida),
    notas_servico: parseNullableInteger(normalizedInput.notas_servico),
    total_lancamentos: parseNullableInteger(normalizedInput.total_lancamentos),
    lancamentos_debito: parseNullableInteger(normalizedInput.lancamentos_debito),
    lancamentos_credito: parseNullableInteger(normalizedInput.lancamentos_credito),
    itens_excedentes: normalizedInput.itens_excedentes || null,
    itens_multa: normalizedInput.itens_multa || null,
    other_metrics: tipoRelatorio === "outro" ? normalizeOtherMetrics(normalizedInput.other_metrics) : null,
    relatorio_qualidade_de_dados: getRelatorioQualidadeDeDados(input.rawPayload) ?? null,
    arquivo_origem: input.documentoId,
    extracao_bruta: buildLeanExtracaoBruta(input.documentoId, normalizedInput, rastreabilidade),
  };
}
