import type { RelatorioQualidadeDeDados } from "./relatorio-payload.js";

// QA determinística de relatórios periódicos. Espelha as regras da skill
// normalizar-relatorio (apps/services/agents/ingestao_payload/skills/normalizar-relatorio/SKILL.md)
// mas roda no backend, onde vivem as estatísticas históricas e o gate de
// confirmação — sem LLM, sem AgentCore. Consumidores: createRelatorioManual (e,
// futuramente, o callback de ingestão de arquivo).

// Mínimo de amostras para aplicar regra de outlier (z-score / mediana). Abaixo
// disso a estatística é apenas contexto informativo, nunca bloqueio.
const MIN_AMOSTRAS = 5;

// Campos numéricos esperados por tipo (mesma fonte de CAMPOS_INTEIROS_POR_TIPO em
// relatorio.service.ts; duplicado aqui para evitar ciclo de import).
const CAMPOS_POR_TIPO: Record<string, string[]> = {
  resumo_folha: ["colaboradores_ativos", "prolabores_ativos", "admissoes", "rescisoes", "afastados"],
  numero_notas_fiscais: ["total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico"],
  numero_de_documentos: ["total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico"],
  lancamentos_contabeis: ["total_lancamentos", "lancamentos_debito", "lancamentos_credito"],
};

export type EstatisticaCampo = {
  campo: string;
  quantidade_amostras: number | string;
  media: number | string | null;
  mediana: number | string | null;
  desvio_padrao: number | string | null;
};

type CampoQa = {
  campo: string;
  severidade: "info" | "warning" | "critical";
  motivo: string;
  valor: number | null;
  estatistica_referencia?: {
    media: number | null;
    mediana: number | null;
    desvio_padrao: number | null;
    quantidade_amostras: number;
  };
};

function num(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function competenciaValidaMmAaaa(value: unknown): boolean {
  if (typeof value !== "string") return false;
  const match = value.trim().match(/^(\d{2})\/(\d{4})$/);
  if (!match) return false;
  const mes = Number(match[1]);
  const ano = Number(match[2]);
  return mes >= 1 && mes <= 12 && ano >= 1;
}

export function avaliarQualidadeRelatorio(input: {
  tipoRelatorio: string;
  dados: Record<string, unknown>;
  estatisticas?: EstatisticaCampo[];
}): RelatorioQualidadeDeDados {
  const { tipoRelatorio, dados } = input;
  const estatisticas = input.estatisticas ?? [];
  const campos: CampoQa[] = [];
  const warnings: string[] = [];
  const erros: string[] = [];

  const esperados = CAMPOS_POR_TIPO[tipoRelatorio] ?? [];
  const valor = (campo: string) => num(dados[campo]);

  // --- Crítico com score zero: competência semanticamente inválida ---
  // O formato MM/AAAA sozinho aceita sentinelas inventadas pelo modelo, como
  // 00/0000. Esses relatórios devem ser persistidos apenas para revisão e nunca
  // ativados/consolidados automaticamente.
  const competenciaInvalida = !competenciaValidaMmAaaa(dados.competencia);
  if (competenciaInvalida) {
    const motivo = "competencia inválida: informe um mês entre 01 e 12 e um ano diferente de 0000.";
    campos.push({ campo: "competencia", severidade: "critical", motivo, valor: null });
    erros.push(motivo);
  }

  // --- Crítico: subtotais impossíveis ---
  const totalNf = valor("total_notas_fiscais");
  const nfEntrada = valor("notas_entrada");
  const nfSaida = valor("notas_saida");
  const nfServico = valor("notas_servico");
  if ([totalNf, nfEntrada, nfSaida, nfServico].every((v) => v !== null)) {
    const soma = (nfEntrada as number) + (nfSaida as number) + (nfServico as number);
    if ((totalNf as number) < soma) {
      const motivo = `total_notas_fiscais (${totalNf}) menor que a soma entrada+saída+serviço (${soma}).`;
      campos.push({ campo: "total_notas_fiscais", severidade: "critical", motivo, valor: totalNf });
      erros.push(motivo);
    }
  }

  const totalLanc = valor("total_lancamentos");
  const lancDebito = valor("lancamentos_debito");
  const lancCredito = valor("lancamentos_credito");
  if ([totalLanc, lancDebito, lancCredito].every((v) => v !== null)) {
    const soma = (lancDebito as number) + (lancCredito as number);
    if ((totalLanc as number) < soma) {
      const motivo = `total_lancamentos (${totalLanc}) menor que a soma débito+crédito (${soma}).`;
      campos.push({ campo: "total_lancamentos", severidade: "critical", motivo, valor: totalLanc });
      erros.push(motivo);
    }
  }

  // --- Suspeito: mais da metade dos campos esperados nulos ---
  if (esperados.length > 0) {
    const nulos = esperados.filter((campo) => valor(campo) === null).length;
    if (nulos > esperados.length / 2) {
      const motivo = `Mais da metade dos campos esperados estão vazios (${nulos}/${esperados.length}).`;
      campos.push({ campo: "(múltiplos)", severidade: "warning", motivo, valor: null });
      warnings.push(motivo);
    }
  }

  // --- Suspeito: outliers vs estatística histórica (>= MIN_AMOSTRAS) ---
  const statByCampo = new Map<string, EstatisticaCampo>();
  for (const stat of estatisticas) {
    if (num(stat.quantidade_amostras) !== null && (num(stat.quantidade_amostras) as number) >= MIN_AMOSTRAS) {
      statByCampo.set(stat.campo, stat);
    }
  }
  for (const campo of esperados) {
    const v = valor(campo);
    if (v === null) continue;
    const stat = statByCampo.get(campo);
    if (!stat) continue;
    const media = num(stat.media);
    const mediana = num(stat.mediana);
    const desvio = num(stat.desvio_padrao);
    const ref = {
      media,
      mediana,
      desvio_padrao: desvio,
      quantidade_amostras: num(stat.quantidade_amostras) as number,
    };
    if (media !== null && desvio !== null && desvio > 0 && Math.abs(v - media) > 3 * desvio) {
      const motivo = `${campo} (${v}) está a mais de 3 desvios-padrão da média histórica (${media}).`;
      campos.push({ campo, severidade: "warning", motivo, valor: v, estatistica_referencia: ref });
      warnings.push(motivo);
    } else if (mediana !== null && mediana > 0 && Math.abs(v - mediana) / mediana > 0.5) {
      const motivo = `${campo} (${v}) difere mais de 50% da mediana histórica (${mediana}).`;
      campos.push({ campo, severidade: "warning", motivo, valor: v, estatistica_referencia: ref });
      warnings.push(motivo);
    }
  }
  // Sem estatística suficiente para comparar: registro informativo, nunca bloqueio.
  if (esperados.length > 0 && statByCampo.size === 0) {
    campos.push({
      campo: "(estatística)",
      severidade: "info",
      motivo: `Sem estatística histórica suficiente (mín. ${MIN_AMOSTRAS} amostras) para comparação de outliers.`,
      valor: null,
    });
  }

  const criticas = campos.filter((c) => c.severidade === "critical").length;
  const avisos = campos.filter((c) => c.severidade === "warning").length;
  const infos = campos.filter((c) => c.severidade === "info").length;

  const status: RelatorioQualidadeDeDados["status"] = criticas > 0 ? "critico" : avisos > 0 ? "suspeito" : "ok";
  const score = competenciaInvalida
    ? 0
    : Math.max(0, 1 - 0.03 * infos - 0.12 * avisos - 0.3 * criticas);

  return {
    status,
    score: Number(score.toFixed(2)),
    bloqueia_confirmacao: criticas > 0,
    confirmacao_obrigatoria: criticas > 0 || avisos > 0,
    campos,
    warnings,
    erros,
  };
}
