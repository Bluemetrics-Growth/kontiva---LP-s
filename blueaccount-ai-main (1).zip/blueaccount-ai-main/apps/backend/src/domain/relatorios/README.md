# `src/domain/relatorios`

Esta pasta concentra a regra de negócio relacionada a relatórios.

## Responsabilidades

- confirmar relatório extraído: cria cliente (se necessário), salva novo `Relatorio` no banco
- criar relatório manual (sem documento de origem) a partir de payload tipado por `tipo_relatorio`
- atualizar campos permitidos de relatórios
- preservar as regras de atualização por tipo de dado
- servir como camada de caso de uso para a API HTTP
- expor no catálogo as referências normalizadas de métricas escalares usadas pela UI
- manter a lógica de atualização fora do controller Nest/Express

## Fluxo de confirmação

`POST /relatorios/:documentoId/confirmar` → `confirmarRelatorioExtracted()` → TypeORM direto:

1. `findOrCreateClienteByCnpj()` — localiza ou cria o cliente pelo CNPJ
2. tenta buscar `extracao_bruta` completa do S3 (fallback para o input recebido)
3. cria novo `Relatorio` com os dados extraídos e o vínculo ao documento

O fluxo legado de persistência direta não faz parte do backend atual.

## Fluxo de cadastro manual

`POST /api/relatorios` → `createRelatorioManual()`:

1. Valida `tipo_relatorio`, `competencia` (MM/AAAA) e `cnpj_cliente`
2. `findOrCreateClienteByCnpj()` — localiza o cliente pelo CNPJ ou cria um novo com a razão social extraída (quando disponível)
3. Valida campos esperados por tipo (inteiros ≥0 para os tipos numéricos; listas para excedente/multa; para `outro`, `other_metrics` não vazio no formato `{chave: {value: número finito, unit?: texto, label?: texto}}`, aceitando zero e negativos)
4. Roda a **QA determinística** (`avaliarQualidadeRelatorio`, ver abaixo) usando as estatísticas históricas do cliente (`RelatorioEstatisticaCliente`) e grava o bloco em `relatorio_qualidade_de_dados` + `payload_normalizado_ui`
5. Reutiliza `buildRelatorioPersistenceDraft` para gerar o payload de inserção e força `arquivo_origem = "Cadastro manual"`
6. **Gate:** no cadastro manual, se a QA bloqueia, salva como inativo. No canal de ingestão ligado a um documento, QA com `score=0` grava somente a extração bruta no documento e encaminha para revisão documental, sem criar uma linha em `relatorios`. Tipos padrão válidos inativam o ativo anterior da mesma chave `(cliente, tipo, competência)`; `outro` não usa essa chave. Um documento admite um `outro` ativo por cliente, permitindo múltiplos clientes no mesmo arquivo e rejeitando duplicatas do mesmo cliente; cadastros manuais (`arquivo_origem="Cadastro manual"`) coexistem.
7. Retorna `{ ok, relatorioId, clienteId, documentoId, relatorio_ativo, relatorio_qualidade_de_dados }`

`createRelatorioManual` aceita um `documentoId` opcional (4º arg). Com ele (canal de ingestão por IA —
`POST /api/documentos/:id/ingestao-ai/extrair-relatorio`, ver `modules/documentos`), o relatório referencia
o documento (`arquivo_origem = documentoId`) e o documento é finalizado na MESMA transação
(`status_extracao="concluido"`, `dados_extraidos_contrato`, `payload_normalizado_ui`). Sem ele = cadastro
manual (`arquivo_origem="Cadastro manual"`). No canal IA, QA `score=0` conclui o documento com o payload
bruto para `/revisar-relatorio/:documentoId`, sem criar relatório; nos demais casos, QA `critico` cria
um relatório inativo e `ok`/`suspeito` ativam.

`other_metrics` permanece fora de `metricas_observadas` e, portanto, não alimenta automaticamente o vocabulário de cobrança.

## `inserirRelatorioAutomatico` — primitiva de inserção compartilhada

Extraída da cauda de `createRelatorioManual` (QA → `buildRelatorioPersistenceDraft` →
dedupe de `outro` → arquivamento do ativo anterior → `metricas_observadas` →
`scheduleConsolidacaoCompetencia`), reaproveitada por qualquer canal que insere um
`Relatorio` sem revisão humana prévia. Propositalmente **não toca a tabela `documentos`** —
isso fica com quem chama, porque cada canal finaliza o documento de origem de um jeito
diferente (1 documento : 1 relatório no cadastro manual/IA; 1 documento : N relatórios de
N clientes na ingestão em lote via planilha).

`payloadNormalizadoUiFactory` e `camposAdicionaisEntidade` existem só para o cadastro
manual/IA poder preservar o shape histórico de `payload_normalizado_ui`
(`{origem, payloadInsercaoDb, relatorio_qualidade_de_dados}`) e o campo `edicoes` — que a
primitiva propositalmente não constrói — sem precisar de um `save` extra depois da
inserção. `pularInsercaoSeQualidadeZero` também é exclusivo desse canal: só ele tem a regra
de "QA zero + documento de origem → nem cria a linha em `relatorios`, finaliza só o
documento". A ingestão em lote nunca usa essas três opções: usa o shape mínimo default
(`{origem:"planilha_bulk", relatorio_qualidade_de_dados}`) e sempre insere, mesmo quando a
QA classifica como `critico` (inativo, pendente de revisão).

## Ingestão em lote via planilha (`finalizarIngestaoRelatoriosPlanilha`)

Um único arquivo Excel/CSV pode trazer linhas de MUITOS clientes (por CNPJ) e múltiplos
tipos de relatório por cliente — já agregado e validado estruturalmente pela Lambda
`apps/services/relatorios/planilha`, que publica o resultado via
`POST /api/internal/documentos/:id/ingestao/relatorios-planilha`
(`modules/documentos/documentos-internal.controller.ts`). Sem gate de revisão humana por
linha (decisão de produto): cada tupla `{cnpj, tipoRelatorio, competencia, ...}` é
resolvida para um cliente (`findOrCreateClienteByCnpj`) e inserida via
`inserirRelatorioAutomatico`, reaproveitando a MESMA QA determinística de todo outro
canal — uma tupla `critico` ainda insere, só que `relatorio_ativo:false`.

Cada tupla roda **sequencialmente** (nunca `Promise.all`, para não correr
`findOrCreateClienteByCnpj` do mesmo CNPJ em paralelo) na SUA PRÓPRIA transação curta
(`runQueryWithRls` por tupla) — se uma tupla estourar um erro inesperado de constraint, o
Postgres marca a transação inteira como abortada mesmo com o `catch` em JS; transações por
tupla impedem que um cliente ruim derrube clientes que já comitaram antes dele no mesmo
loop. CNPJ inválido ou `tipo_relatorio` fora do catálogo suportado (`resumo_folha`,
`numero_notas_fiscais`, `lancamentos_contabeis`, `outro` — `relatorio_excedente`/`multa`
não são alcançáveis por colunas de planilha, ver limitação conhecida no plano) entram em
`erros[]` e não abortam as demais tuplas. A linha de `documentos` é atualizada UMA única
vez para o arquivo inteiro (nunca por tupla, para não sobrescrever `cliente_id`/
`dados_extraidos_contrato` com os dados da última tupla); `cliente_id` do documento
permanece `null` de propósito.

## QA de qualidade de dados (`avaliarQualidadeRelatorio`)

QA **determinística no servidor** (sem LLM/AgentCore) — porta as regras da skill
`normalizar-relatorio` (`apps/services/agents/ingestao_payload/skills/normalizar-relatorio/SKILL.md`)
para onde vivem as estatísticas históricas e o gate. Entrada: `{ tipoRelatorio, dados, estatisticas }`.
Saída: `RelatorioQualidadeDeDados` (`relatorio-payload.ts`).

Regras:

- **`critico`** (`bloqueia_confirmacao=true`, `confirmacao_obrigatoria=true`): subtotal impossível —
  `total_notas_fiscais < entrada+saida+servico` ou `total_lancamentos < debito+credito` (quando todos presentes);
  ou competência semanticamente inválida (mês fora de `01..12` ou ano `0000`). Competência inválida força
  `score=0`, mantém o relatório inativo para revisão e nunca arquiva o registro ativo anterior. Campos ausentes
  obrigatórios (cnpj/tipo/competência), formato diferente de MM/AAAA e contagens negativas continuam barrados
  antes, na validação de `createRelatorioManual`.
- **`suspeito`** (`confirmacao_obrigatoria=true`, sem bloqueio): mais da metade dos campos esperados do tipo nulos;
  ou outlier vs histórico — `|valor − média| > 3·desvio_padrão`, ou `|valor − mediana| / mediana > 50%`. Outliers só valem
  com `quantidade_amostras ≥ 5`; sem estatística suficiente vira `info`, nunca bloqueio.
- **`ok`**: nada disparado.
- **`score`**: competência inválida força `0`; nos demais casos começa em `1.0`, com `−0.03` por `info`,
  `−0.12` por `warning`, `−0.30` por `critical` e mínimo `0`.

Gate de confirmação reutilizado por `updateRelatorio` e `confirmarRelatorio` via
`relatorioQualidadeBloqueiaConfirmacao` (`relatorio-payload.ts`): bloqueia salvar/confirmar quando
`status="critico"` ou `bloqueia_confirmacao=true`.

Consumo: o frontend renderiza `relatorio_qualidade_de_dados` (`RelatorioQaReport.tsx`); o MCP
`kontiva_criar_relatorio_manual` devolve o bloco (`status`, `score`, `bloqueia_confirmacao`,
`confirmacao_obrigatoria`, `campos`, `warnings`, `erros`) + `status` (`ativo`/`em_revisao`) + `review_url`.

## Arquivos

- `relatorio.service.ts`: coordena confirmação, atualização, cadastro manual e listagem de relatórios
- `relatorio-qa.ts`: `avaliarQualidadeRelatorio` — QA determinística (subtotais, nulos, outliers históricos, score)
- `relatorio-payload.ts`: shape de persistência, tipo `RelatorioQualidadeDeDados` e gate `relatorioQualidadeBloqueiaConfirmacao`
- `relatorio-estatisticas.service.ts`: cálculo/leitura das estatísticas históricas (`RelatorioEstatisticaCliente`)
- `tipos-relatorio.ts`: catálogo de tipos, campos persistidos e referências de `metricas_observadas`

## Testes

- `tests/relatorio.service.test.ts`

## Regra prática

Controllers não devem conhecer os detalhes de quais campos um relatório aceita. Essa decisão fica aqui.
