import { AppDataSource, runQueryWithRls } from "../../database/data-source.js";
import { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import { Documento } from "../../database/modules/tenant/entities/documento.entity.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import type { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { RelatorioEstatisticaCliente } from "../../database/modules/tenant/entities/relatorio-estatistica-cliente.entity.js";
import { avaliarQualidadeRelatorio } from "./relatorio-qa.js";
import { computeMetricasObservadas } from "./vocabulary.js";
import { consolidarCompetencia } from "../valores-a-cobrar/consolidar.service.js";
import { resolverAlvoConsolidacao } from "../clientes/grupo.service.js";
import { findOrCreateClienteByCnpj, normalizarCnpj } from "../clientes/cliente.service.js";
import { getDocumentoById } from "../documentos/documentos.service.js";
import { isAiSubmittedTextDocumento } from "../documentos/documentos-ocr.js";
import { registrarEdicoesManuais } from "../edicoes.js";
import { Brackets, type EntityManager } from "typeorm";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginationInput,
} from "../pagination.js";
import {
  applyCamposEditados,
  applyCamposEditadosToPayloadInsercaoDb,
  buildRelatorioPersistenceDraft,
  getCamposEditados,
  getRelatorioQualidadeDeDados,
  isRecord,
  montarPayloadInsercaoDbRelatorio,
  normalizeRelatorioInput,
  normalizeOtherMetrics,
  parseNullableInteger,
  relatorioQualidadeBloqueiaConfirmacao,
  RELATORIO_FIELDS,
  type RelatorioQualidadeDeDados,
} from "./relatorio-payload.js";

const TIPOS_RELATORIO_MANUAIS = new Set([
  "resumo_folha",
  "relatorio_excedente",
  "numero_notas_fiscais",
  "numero_de_documentos",
  "lancamentos_contabeis",
  "multa",
  "outro",
]);

const CAMPOS_INTEIROS_POR_TIPO: Record<string, string[]> = {
  resumo_folha: ["colaboradores_ativos", "prolabores_ativos", "admissoes", "rescisoes", "afastados"],
  numero_notas_fiscais: ["total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico"],
  numero_de_documentos: ["total_notas_fiscais", "notas_entrada", "notas_saida", "notas_servico"],
  lancamentos_contabeis: ["total_lancamentos", "lancamentos_debito", "lancamentos_credito"],
};

function normalizeCompetenciaMmAaaa(value: unknown): string {
  if (typeof value !== "string") throw new Error("competencia deve estar no formato MM/AAAA.");
  const trimmed = value.trim();
  const yyyyMm = trimmed.match(/^(\d{4})-(\d{2})$/);
  if (yyyyMm) return `${yyyyMm[2]}/${yyyyMm[1]}`;
  if (/^\d{2}\/\d{4}$/.test(trimmed)) return trimmed;
  throw new Error("competencia deve estar no formato MM/AAAA.");
}

function normalizeItensExcedentes(input: unknown): Array<Record<string, unknown>> {
  if (!Array.isArray(input) || input.length === 0) {
    throw new Error("itens_excedentes deve conter pelo menos um item.");
  }
  return input.map((raw, index) => {
    if (!isRecord(raw)) throw new Error(`itens_excedentes[${index}] inválido.`);
    const referencia = typeof raw.referencia === "string" ? raw.referencia.trim() : "";
    if (!referencia) throw new Error(`itens_excedentes[${index}].referencia é obrigatório.`);
    const num = (v: unknown): number | null => {
      if (v === null || v === undefined || v === "") return null;
      const parsed = typeof v === "string"
        ? Number(v.includes(",") ? v.replace(/\./g, "").replace(",", ".") : v)
        : Number(v);
      return Number.isFinite(parsed) ? parsed : null;
    };
    return {
      referencia,
      quantidade_contratada: parseNullableInteger(raw.quantidade_contratada),
      quantidade_realizada: parseNullableInteger(raw.quantidade_realizada),
      quantidade_excedente: parseNullableInteger(raw.quantidade_excedente),
      valor_unitario: num(raw.valor_unitario),
      valor_total: num(raw.valor_total),
    };
  });
}

function normalizeItensMulta(input: unknown): Array<Record<string, unknown>> {
  if (!Array.isArray(input) || input.length === 0) {
    throw new Error("itens_multa deve conter pelo menos um item.");
  }
  return input.map((raw, index) => {
    if (!isRecord(raw)) throw new Error(`itens_multa[${index}] inválido.`);
    const valor = parseNullableDecimal(raw.valor);
    if (valor === null || valor <= 0) {
      throw new Error(`itens_multa[${index}].valor é obrigatório e deve ser maior que zero.`);
    }
    const motivo = typeof raw.motivo === "string" ? raw.motivo.trim() : "";
    if (!motivo) throw new Error(`itens_multa[${index}].motivo é obrigatório.`);
    const data = typeof raw.data === "string" && raw.data.trim() ? raw.data.trim() : null;
    const responsavel =
      typeof raw.responsavel === "string" && raw.responsavel.trim() ? raw.responsavel.trim() : null;
    return { valor, motivo, data, responsavel };
  });
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isUuid(v: unknown): v is string {
  return typeof v === "string" && UUID_RE.test(v);
}

function getPayloadInsercaoDb(payloadNormalizadoUi: unknown): Record<string, unknown> | null {
  if (!isRecord(payloadNormalizadoUi)) return null;
  return isRecord(payloadNormalizadoUi.payloadInsercaoDb) ? payloadNormalizadoUi.payloadInsercaoDb : null;
}

function withPayloadInsercaoDb(
  payloadNormalizadoUi: unknown,
  payloadInsercaoDb: Record<string, unknown>,
): Record<string, unknown> | null {
  if (!isRecord(payloadNormalizadoUi)) return null;
  return {
    ...payloadNormalizadoUi,
    payloadInsercaoDb,
  };
}

function applyPersistencePayload(relatorio: Relatorio, payload: Record<string, unknown>): void {
  const relAny = relatorio as unknown as Record<string, unknown>;
  for (const field of RELATORIO_FIELDS) {
    relAny[field] = payload[field] ?? null;
  }
  relatorio.tipo_relatorio = String(payload.tipo_relatorio || relatorio.tipo_relatorio || "desconhecido") as any;
  relatorio.arquivo_origem = (payload.arquivo_origem as string | null | undefined) ?? relatorio.arquivo_origem ?? null;
  relatorio.extracao_bruta = (payload.extracao_bruta as Record<string, unknown> | null | undefined) ?? relatorio.extracao_bruta ?? null;
  relatorio.relatorio_qualidade_de_dados =
    getRelatorioQualidadeDeDados(payload) ??
    relatorio.relatorio_qualidade_de_dados ??
    null;
}

function parseNullableDecimal(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const normalized = typeof value === "string"
    ? (value.includes(",") ? value.replace(/\./g, "").replace(",", ".") : value)
    : value;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function buildLeanFaturamentoExtracaoBruta(idArquivo: string, normalizedInput: Record<string, unknown>): Record<string, unknown> {
  const campos = ["tipo_relatorio", "competencia", "razao_social", "valor_cobrado", "discriminacao"]
    .filter((campo) => normalizedInput[campo] !== undefined && normalizedInput[campo] !== null)
    .map((campo) => ({ campo, valor_extraido: normalizedInput[campo] }));
  return { idArquivo, campos };
}

function buildFaturamentoPersistenceDraft(input: {
  rawPayload: Record<string, unknown>;
  documentoId: string;
  camposEditados?: Record<string, unknown>;
}): Record<string, unknown> {
  const normalizedInput = applyCamposEditados(normalizeRelatorioInput(input.rawPayload), {
    campos_editados: input.camposEditados ?? {},
  });

  const discriminacao = String(normalizedInput.discriminacao || "").trim();
  return {
    tipo_relatorio: "faturamento",
    competencia: String(normalizedInput.competencia || "").trim() || null,
    razao_social: String(normalizedInput.razao_social || "").trim() || null,
    valor_cobrado: parseNullableDecimal(normalizedInput.valor_cobrado),
    discriminacao: discriminacao || "Honorarios contabeis",
    arquivo_origem: input.documentoId,
    extracao_bruta: buildLeanFaturamentoExtracaoBruta(input.documentoId, normalizedInput),
  };
}

function applyCamposEditadosToFaturamentoPayload(
  payloadInsercaoDb: Record<string, unknown>,
  camposEditados: Record<string, unknown>,
): Record<string, unknown> {
  const next = {
    ...buildFaturamentoPersistenceDraft({
      rawPayload: payloadInsercaoDb,
      documentoId: String(payloadInsercaoDb.arquivo_origem || ""),
    }),
    ...payloadInsercaoDb,
  };

  for (const [campo, valor] of Object.entries(camposEditados)) {
    if (["competencia", "razao_social", "valor_cobrado", "discriminacao"].includes(campo)) {
      next[campo] = campo === "valor_cobrado" ? parseNullableDecimal(valor) : valor;
    }
  }

  return next;
}

async function inativarRelatoriosAtivosDaMesmaChave(input: {
  manager: EntityManager;
  escritorioId: string;
  clienteId: string;
  tipoRelatorio: string;
  competencia: string | null;
  exceptRelatorioId?: string;
}) {
  let query = input.manager
    .createQueryBuilder()
    .update(Relatorio)
    .set({ relatorio_ativo: false })
    .where("escritorio_id = :escritorioId", { escritorioId: input.escritorioId })
    .andWhere("cliente_id = :clienteId", { clienteId: input.clienteId })
    .andWhere("tipo_relatorio = :tipoRelatorio", { tipoRelatorio: input.tipoRelatorio })
    .andWhere("relatorio_ativo = true");

  query = input.competencia === null
    ? query.andWhere("competencia IS NULL")
    : query.andWhere("competencia = :competencia", { competencia: input.competencia });

  if (input.exceptRelatorioId) {
    query = query.andWhere("id <> :exceptRelatorioId", { exceptRelatorioId: input.exceptRelatorioId });
  }

  await query.execute();
}

async function garantirOutroIneditoPorDocumento(input: {
  manager: EntityManager;
  escritorioId: string;
  arquivoOrigem: string;
  clienteId: string;
  competencia: string | null;
  exceptRelatorioId?: string;
}): Promise<void> {
  if (!input.arquivoOrigem || input.arquivoOrigem === "Cadastro manual") return;
  let query = input.manager
    .getRepository(Relatorio)
    .createQueryBuilder("relatorio")
    .where("relatorio.escritorio_id = :escritorioId", { escritorioId: input.escritorioId })
    .andWhere("relatorio.tipo_relatorio = 'outro'")
    .andWhere("relatorio.arquivo_origem = :arquivoOrigem", { arquivoOrigem: input.arquivoOrigem })
    .andWhere("relatorio.cliente_id = :clienteId", { clienteId: input.clienteId })
    .andWhere("relatorio.relatorio_ativo = true");
  // Escopado tb por competência: a ingestão em lote via planilha usa o MESMO
  // arquivo_origem (o documento) p/ todos os clientes/competências do
  // arquivo — sem isso, o 2º período do mesmo cliente no mesmo upload seria
  // tratado como duplicata do 1º.
  query = input.competencia === null
    ? query.andWhere("relatorio.competencia IS NULL")
    : query.andWhere("relatorio.competencia = :competencia", { competencia: input.competencia });
  if (input.exceptRelatorioId) {
    query = query.andWhere("relatorio.id <> :exceptRelatorioId", { exceptRelatorioId: input.exceptRelatorioId });
  }
  if (await query.getExists()) {
    throw new Error("Este documento já possui um relatório do tipo outro ativo para este cliente e competência.");
  }
}

async function inativarFaturamentosAtivosDaMesmaChave(input: {
  manager: EntityManager;
  escritorioId: string;
  clienteId: string;
  competencia: string | null;
}) {
  let query = input.manager
    .createQueryBuilder()
    .update(Faturamento)
    .set({ faturamento_ativo: false })
    .where("escritorio_id = :escritorioId", { escritorioId: input.escritorioId })
    .andWhere("cliente_id = :clienteId", { clienteId: input.clienteId })
    .andWhere("faturamento_ativo = true");

  query = input.competencia === null
    ? query.andWhere("competencia IS NULL")
    : query.andWhere("competencia = :competencia", { competencia: input.competencia });

  await query.execute();
}

function scheduleConsolidacaoCompetencia(escritorioId: string, clienteId: string | null | undefined, competencia: string | null | undefined): void {
  if (!clienteId || !competencia) {
    return;
  }

  setImmediate(() => {
    consolidarCompetencia(escritorioId, clienteId, competencia).catch((err) => {
      console.error("[consolidarCompetencia] erro em background:", err);
    });
  });
}

export async function listRelatorios(escritorioId: string, clienteId?: string) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const relatorioRepo = manager.getRepository(Relatorio);
    const relatorios = await relatorioRepo.find({
      where: clienteId ? { cliente_id: clienteId, escritorio_id: escritorioId } : { escritorio_id: escritorioId },
      relations: ["cliente"],
      order: { created_at: "DESC" },
    });
    return relatorios;
  });
}

export async function listRelatoriosPaginated(
  escritorioId: string,
  input: PaginationInput & { clienteId?: string; query?: string } = {},
) {
  const { page, pageSize, skip } = normalizePagination(input);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Relatorio)
      .createQueryBuilder("relatorio")
      .innerJoin("relatorio.cliente", "cliente")
      .select("relatorio.id", "id")
      .addSelect("relatorio.competencia", "competencia")
      .addSelect("relatorio.razao_social", "razao_social")
      .addSelect("relatorio.tipo_relatorio", "tipo_relatorio")
      .addSelect("relatorio.arquivo_origem", "arquivo_origem")
      .addSelect("relatorio.relatorio_ativo", "relatorio_ativo")
      .addSelect("relatorio.created_at", "created_at")
      .addSelect("relatorio.relatorio_qualidade_de_dados ->> 'status'", "qualidade_status")
      .addSelect("cliente.id", "cliente_id")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .where("relatorio.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("cliente.ativo = true");

    if (input.clienteId) qb.andWhere("relatorio.cliente_id = :clienteId", { clienteId: input.clienteId });
    if (input.query?.trim()) {
      qb.andWhere(
        new Brackets((sub) => {
          sub
            .where("cliente.razao_social ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("cliente.cnpj ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("relatorio.tipo_relatorio ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("relatorio.competencia ILIKE :query", { query: `%${input.query!.trim()}%` });
        }),
      );
    }

    const total = await qb.clone().getCount();
    const rows = await qb
      .orderBy("relatorio.created_at", "DESC")
      .offset(skip)
      .limit(pageSize)
      .getRawMany<Record<string, unknown>>();

    return buildPaginatedResult(rows.map((row) => ({
      id: String(row.id),
      competencia: row.competencia == null ? null : String(row.competencia),
      razao_social: row.razao_social == null ? null : String(row.razao_social),
      tipo_relatorio: String(row.tipo_relatorio),
      arquivo_origem: row.arquivo_origem == null ? null : String(row.arquivo_origem),
      relatorio_ativo: row.relatorio_ativo === true,
      relatorio_qualidade_de_dados: row.qualidade_status ? { status: String(row.qualidade_status) } : null,
      created_at: row.created_at,
      cliente: {
        id: String(row.cliente_id),
        razao_social: String(row.cliente_razao_social),
        cnpj: String(row.cliente_cnpj),
      },
    })), total, page, pageSize);
  });
}

export type ClienteComRelatorios = {
  cliente: { id: string; razao_social: string; cnpj: string };
  total_relatorios: number;
  tipos_relatorio: string[];
  ultima_atualizacao: string | Date | null;
  tem_relatorio_critico: boolean;
};

// Rollup por cliente da tela "clientes com relatórios": quantos relatórios,
// quais tipos, quando foi o mais recente e se algum está com QA crítico.
// Mesmo padrão de listRelatoriosPaginated (RLS + innerJoin + Brackets no
// filtro livre), mas agregado por cliente — por isso o total da paginação
// tem de contar clientes distintos, não linhas de relatório.
export async function listClientesComRelatorios(
  escritorioId: string,
  input: PaginationInput & { query?: string } = {},
) {
  const { page, pageSize, skip } = normalizePagination(input);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const baseQb = manager
      .getRepository(Relatorio)
      .createQueryBuilder("relatorio")
      .innerJoin("relatorio.cliente", "cliente")
      .where("relatorio.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("cliente.ativo = true");

    if (input.query?.trim()) {
      baseQb.andWhere(
        new Brackets((sub) => {
          sub
            .where("cliente.razao_social ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("cliente.cnpj ILIKE :query", { query: `%${input.query!.trim()}%` });
        }),
      );
    }

    // Conta clientes distintos que casam com o filtro, SEM aplicar o groupBy
    // usado na página de dados — getCount() nativo do TypeORM contaria por
    // alias principal (relatorio), não por cliente, e derrubaria o total.
    const totalRow = await baseQb
      .clone()
      .select("COUNT(DISTINCT cliente.id)", "total")
      .getRawOne<{ total: string }>();
    const total = Number(totalRow?.total ?? 0);

    const rows = await baseQb
      .clone()
      .select("cliente.id", "cliente_id")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .addSelect("COUNT(relatorio.id)", "total_relatorios")
      .addSelect("array_agg(DISTINCT relatorio.tipo_relatorio)", "tipos_relatorio")
      .addSelect("MAX(relatorio.created_at)", "ultima_atualizacao")
      .addSelect(
        "bool_or(relatorio.relatorio_qualidade_de_dados ->> 'status' = 'critico')",
        "tem_relatorio_critico",
      )
      .groupBy("cliente.id")
      .addGroupBy("cliente.razao_social")
      .addGroupBy("cliente.cnpj")
      // Ordena pela expressão de agregação (não pelo alias "ultima_atualizacao")
      // para não depender de o driver/versão do Postgres aceitar output-column
      // reference no ORDER BY de uma query com GROUP BY.
      .orderBy("MAX(relatorio.created_at)", "DESC")
      .offset(skip)
      .limit(pageSize)
      .getRawMany<Record<string, unknown>>();

    const items: ClienteComRelatorios[] = rows.map((row) => ({
      cliente: {
        id: String(row.cliente_id),
        razao_social: String(row.cliente_razao_social),
        cnpj: String(row.cliente_cnpj),
      },
      total_relatorios: Number(row.total_relatorios ?? 0),
      // array_agg(text) já chega como array nativo via driver pg; Array.isArray
      // cobre o raro caso de vir como literal `{a,b}` (ex.: outro client/pool sem
      // os type parsers padrão do pg habilitados).
      tipos_relatorio: Array.isArray(row.tipos_relatorio)
        ? row.tipos_relatorio.filter((tipo): tipo is string => tipo != null).map(String)
        : typeof row.tipos_relatorio === "string"
          ? row.tipos_relatorio.replace(/^\{|\}$/g, "").split(",").filter(Boolean)
          : [],
      ultima_atualizacao: (row.ultima_atualizacao as string | Date | null) ?? null,
      tem_relatorio_critico: row.tem_relatorio_critico === true,
    }));

    return buildPaginatedResult(items, total, page, pageSize);
  });
}

export async function getRelatoriosDataQualitySummary(escritorioId: string) {
  const relatorios = await listRelatorios(escritorioId);

  const summary = {
    total: relatorios.length,
    ok: 0,
    suspeito: 0,
    critico: 0,
    sem_dados: 0,
    score_medio: null as number | null,
    com_bloqueio: 0,
  };

  let scoreSum = 0;
  let scoreCount = 0;

  for (const rel of relatorios) {
    const qualidade = rel.relatorio_qualidade_de_dados as any;
    if (!qualidade) {
      summary.sem_dados++;
      continue;
    }

    const status = qualidade.status || "sem_dados";
    if (status === "ok") summary.ok++;
    else if (status === "suspeito") summary.suspeito++;
    else if (status === "critico") summary.critico++;
    else summary.sem_dados++;

    if (typeof qualidade.score === "number" && qualidade.score > 0) {
      scoreSum += qualidade.score;
      scoreCount++;
    }

    if (qualidade.bloqueia_confirmacao === true) {
      summary.com_bloqueio++;
    }
  }

  if (scoreCount > 0) {
    summary.score_medio = Math.round((scoreSum / scoreCount) * 100) / 100;
  }

  return summary;
}

export async function getRelatorio(relatorioId: string, escritorioId: string) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const relatorioRepo = manager.getRepository(Relatorio);
    const relatorio = await relatorioRepo.findOne({
      where: { id: relatorioId, escritorio_id: escritorioId },
      relations: ["cliente"],
    });
    if (!relatorio) return null;

    const candidatoDocumentoId =
      (isUuid(relatorio.arquivo_origem) ? relatorio.arquivo_origem : null) ||
      (relatorio.extracao_bruta?.idArquivo as string | undefined) ||
      (relatorio.extracao_bruta?.documentoId as string | undefined) ||
      null;
    const documentoId = isUuid(candidatoDocumentoId) ? candidatoDocumentoId : null;
    const documento = documentoId
      ? await manager.getRepository(Documento).findOne({
          where: { id: documentoId, escritorio_id: escritorioId },
        })
      : null;

    // A consolidação só gera valor a cobrar quando o ALVO (o próprio cliente, ou
    // a holding em grupo consolidado) tem contrato ativo. Mesma porta de entrada
    // de consolidarCompetencia/consolidarGrupoConsolidado.
    const alvo = await resolverAlvoConsolidacao(manager, escritorioId, relatorio.cliente_id);
    const contratoAlvo = await manager.getRepository(Contrato).findOne({
      where: { cliente_id: alvo.clienteIdAlvo, escritorio_id: escritorioId, contrato_ativo: true },
    });

    return {
      ...relatorio,
      dados_extraidos_contrato: documento?.dados_extraidos_contrato ?? null,
      cadastro_ia: documento ? isAiSubmittedTextDocumento(documento) : false,
      gera_valor_a_cobrar: !!contratoAlvo,
      // true quando a cobrança deste relatório sai pela holding do grupo consolidado.
      cobranca_via_holding: alvo.grupoConsolidado && alvo.redirecionado,
    };
  });
}

export async function getRelatorioByDocumento(documentoId: string, escritorioId: string) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const row = await manager
      .getRepository(Relatorio)
      .createQueryBuilder("relatorio")
      .select("relatorio.id", "id")
      .addSelect("relatorio.relatorio_ativo", "relatorio_ativo")
      .where("relatorio.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("relatorio.arquivo_origem = :documentoId", { documentoId })
      // Se houver mais de um, prefere o ativo e o mais recente.
      .orderBy("relatorio.relatorio_ativo", "DESC")
      .addOrderBy("relatorio.created_at", "DESC")
      .getRawOne<{ id: string; relatorio_ativo: boolean }>();

    if (!row) return null;
    return { id: String(row.id), relatorio_ativo: row.relatorio_ativo === true };
  });
}

export async function listarRelatoriosPorDocumento(documentoId: string, escritorioId: string) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const rows = await manager
      .getRepository(Relatorio)
      .createQueryBuilder("relatorio")
      .leftJoin("relatorio.cliente", "cliente")
      .select("relatorio.id", "id")
      .addSelect("relatorio.cliente_id", "cliente_id")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.nome_fantasia", "cliente_nome_fantasia")
      .addSelect("relatorio.tipo_relatorio", "tipo_relatorio")
      .addSelect("relatorio.competencia", "competencia")
      .addSelect("relatorio.relatorio_ativo", "relatorio_ativo")
      .addSelect("relatorio.created_at", "created_at")
      .where("relatorio.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("relatorio.arquivo_origem = :documentoId", { documentoId })
      .orderBy("relatorio.relatorio_ativo", "DESC")
      .addOrderBy("relatorio.created_at", "DESC")
      .getRawMany<Record<string, unknown>>();

    return rows.map((row) => ({
      id: String(row.id),
      cliente_id: String(row.cliente_id),
      cliente: {
        razao_social: row.cliente_razao_social == null ? null : String(row.cliente_razao_social),
        nome_fantasia: row.cliente_nome_fantasia == null ? null : String(row.cliente_nome_fantasia),
      },
      tipo_relatorio: String(row.tipo_relatorio),
      competencia: row.competencia == null ? null : String(row.competencia),
      relatorio_ativo: row.relatorio_ativo === true,
      created_at: row.created_at,
    }));
  });
}

export async function contarRelatoriosAtivosPorDocumento(escritorioId: string, documentoIds: string[]) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
  const ids = [...new Set(documentoIds.map((id) => id.trim()).filter(Boolean))];
  if (ids.length === 0) return new Map<string, number>();

  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const rows = await manager
      .getRepository(Relatorio)
      .createQueryBuilder("relatorio")
      .select("relatorio.arquivo_origem", "documento_id")
      .addSelect("COUNT(*)", "quantidade")
      .where("relatorio.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("relatorio.arquivo_origem IN (:...ids)", { ids })
      .groupBy("relatorio.arquivo_origem")
      .getRawMany<{ documento_id: string; quantidade: string }>();

    return new Map(rows.map((row) => [String(row.documento_id), Number(row.quantidade)]));
  });
}

export async function updateRelatorio(relatorioId: string, input: Record<string, unknown>, escritorioId: string, usuarioNome?: string | null) {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  const result = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const relatorioRepo = manager.getRepository(Relatorio);
    const relatorio = await relatorioRepo.findOneBy({ id: relatorioId });
    if (!relatorio) return null;

    const chaveAnterior = {
      clienteId: relatorio.cliente_id,
      competencia: relatorio.competencia,
    };

    const candidatoDocumentoId =
      (isUuid(relatorio.arquivo_origem) ? relatorio.arquivo_origem : null) ||
      (relatorio.extracao_bruta?.idArquivo as string | undefined) ||
      (relatorio.extracao_bruta?.documentoId as string | undefined) ||
      null;
    const documentoId = isUuid(candidatoDocumentoId) ? candidatoDocumentoId : null;
    const documento = documentoId
      ? await manager.getRepository(Documento).findOne({
          where: { id: documentoId, escritorio_id: escritorioId },
        })
      : null;
    const rawPayloadValidacao = (documento?.dados_extraidos_contrato ?? relatorio.extracao_bruta) as Record<string, unknown> | null;
    const camposEditados = {
      ...Object.fromEntries(
        Object.entries(input).filter(([key]) => (RELATORIO_FIELDS as readonly string[]).includes(key)),
      ),
      ...getCamposEditados(input),
    };
    const payloadInsercaoDbBase =
      getPayloadInsercaoDb(documento?.payload_normalizado_ui) ??
      getPayloadInsercaoDb(relatorio.payload_normalizado_ui) ??
      (rawPayloadValidacao
        ? buildRelatorioPersistenceDraft({ rawPayload: rawPayloadValidacao, documentoId: documentoId ?? relatorio.id })
        : montarPayloadInsercaoDbRelatorio(relatorio));
    const payloadInsercaoDb = applyCamposEditadosToPayloadInsercaoDb(payloadInsercaoDbBase, camposEditados);
    const tipoRelatorioFinal = String(payloadInsercaoDb.tipo_relatorio ?? relatorio.tipo_relatorio);
    payloadInsercaoDb.other_metrics = tipoRelatorioFinal === "outro"
      ? normalizeOtherMetrics(payloadInsercaoDb.other_metrics)
      : null;
    relatorio.edicoes = registrarEdicoesManuais({
      edicoesAtuais: relatorio.edicoes,
      edicoesRecebidas: input.edicoes,
      usuarioNome,
    });
    const qualidade =
      getRelatorioQualidadeDeDados(input) ??
      getRelatorioQualidadeDeDados(documento?.payload_normalizado_ui) ??
      getRelatorioQualidadeDeDados(relatorio.payload_normalizado_ui) ??
      getRelatorioQualidadeDeDados(payloadInsercaoDb);
    if (relatorioQualidadeBloqueiaConfirmacao(qualidade)) {
      throw new Error("Relatório possui inconsistências críticas e não pode ser salvo antes da revisão.");
    }
    applyPersistencePayload(relatorio, payloadInsercaoDb);
    relatorio.relatorio_qualidade_de_dados = qualidade ?? relatorio.relatorio_qualidade_de_dados ?? null;
    relatorio.payload_normalizado_ui =
      withPayloadInsercaoDb(documento?.payload_normalizado_ui, payloadInsercaoDb) ??
      withPayloadInsercaoDb(relatorio.payload_normalizado_ui, payloadInsercaoDb);

    relatorio.metricas_observadas = computeMetricasObservadas(relatorio);

    if (relatorio.relatorio_ativo !== false && relatorio.tipo_relatorio === "outro" && relatorio.arquivo_origem) {
      await garantirOutroIneditoPorDocumento({
        manager,
        escritorioId,
        arquivoOrigem: relatorio.arquivo_origem,
        clienteId: relatorio.cliente_id,
        competencia: relatorio.competencia,
        exceptRelatorioId: relatorio.id,
      });
    } else if (relatorio.relatorio_ativo !== false && relatorio.cliente_id) {
      await inativarRelatoriosAtivosDaMesmaChave({
        manager,
        escritorioId,
        clienteId: relatorio.cliente_id,
        tipoRelatorio: relatorio.tipo_relatorio,
        competencia: relatorio.competencia ?? null,
        exceptRelatorioId: relatorio.id,
      });
    }

    const relatorioSalvo = (await relatorioRepo.save(relatorio)) ?? relatorio;

    return { ok: true as const, relatorioSalvo, chaveAnterior };
  });

  if (!result) {
    return null;
  }

  scheduleConsolidacaoCompetencia(escritorioId, result.relatorioSalvo.cliente_id, result.relatorioSalvo.competencia);
  if (
    result.chaveAnterior.clienteId !== result.relatorioSalvo.cliente_id ||
    result.chaveAnterior.competencia !== result.relatorioSalvo.competencia
  ) {
    scheduleConsolidacaoCompetencia(escritorioId, result.chaveAnterior.clienteId, result.chaveAnterior.competencia);
  }

  return {
    ok: true as const,
    relatorioId: result.relatorioSalvo.id,
    relatorio: result.relatorioSalvo,
  };
}

export async function confirmarRelatorioExtracted(
  escritorioId: string,
  documentoId: string,
  input: Record<string, unknown>,
  usuarioNome?: string | null,
) {
  const documento = await getDocumentoById(escritorioId, documentoId);
  if (!documento) throw new Error("Documento não encontrado");
  const rawPayload = documento.dados_extraidos_contrato as Record<string, unknown> | null;
  if (!rawPayload) throw new Error("Documento não possui extração bruta de relatório");

  const camposEditados = getCamposEditados(input);
  const normalizedInput = applyCamposEditados(normalizeRelatorioInput(rawPayload), input);
  const cnpj = normalizarCnpj(normalizedInput.cnpj_cliente);
  normalizedInput.cnpj_cliente = cnpj;
  const tipo_relatorio = String(normalizedInput.tipo_relatorio || "desconhecido").trim();
  const competencia = String(normalizedInput.competencia || "").trim() || null;
  const razao_social = String(normalizedInput.razao_social || "").trim() || null;

  const cliente = await findOrCreateClienteByCnpj({
    escritorioId,
    cnpj,
    razaoSocial: razao_social,
  });

  if (documento.cliente_id && documento.cliente_id !== cliente.id) {
    throw new Error("Este documento já está vinculado a outro cliente e não pode ser alterado.");
  }

  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const documentoRepo = manager.getRepository(Documento);

    if (tipo_relatorio === "faturamento") {
      const faturamentoRepo = manager.getRepository(Faturamento);
      const payloadInsercaoDbBase =
        getPayloadInsercaoDb(documento.payload_normalizado_ui) ??
        buildFaturamentoPersistenceDraft({ rawPayload, documentoId, camposEditados });
      const payloadInsercaoDb = applyCamposEditadosToFaturamentoPayload(payloadInsercaoDbBase, camposEditados);

      await inativarFaturamentosAtivosDaMesmaChave({
        manager,
        escritorioId,
        clienteId: cliente.id,
        competencia,
      });

      const novoFaturamento = faturamentoRepo.create({
        competencia,
        razao_social: (payloadInsercaoDb.razao_social as string | null | undefined) ?? razao_social,
        valor_cobrado: parseNullableDecimal(payloadInsercaoDb.valor_cobrado),
        discriminacao: (payloadInsercaoDb.discriminacao as string | null | undefined) ?? null,
        arquivo_origem: documentoId,
        extracao_bruta: (payloadInsercaoDb.extracao_bruta as Record<string, unknown> | null | undefined) ?? null,
        payload_normalizado_ui: withPayloadInsercaoDb(documento.payload_normalizado_ui, payloadInsercaoDb),
        cliente_id: cliente.id,
        escritorio_id: escritorioId,
        faturamento_ativo: true,
      });

      const faturamentoSalvo = await faturamentoRepo.save(novoFaturamento);

      await documentoRepo.update(
        { id: documentoId, escritorio_id: escritorioId },
        { cliente_id: cliente.id },
      );

      scheduleConsolidacaoCompetencia(escritorioId, faturamentoSalvo.cliente_id, faturamentoSalvo.competencia);

      return { ok: true, faturamentoId: faturamentoSalvo.id, clienteId: cliente.id };
    }

    const relatorioRepo = manager.getRepository(Relatorio);

    const payloadInsercaoDbBase =
      getPayloadInsercaoDb(documento.payload_normalizado_ui) ??
      buildRelatorioPersistenceDraft({ rawPayload, documentoId, camposEditados });
    const payloadInsercaoDb = applyCamposEditadosToPayloadInsercaoDb(payloadInsercaoDbBase, camposEditados);
    const edicoes = registrarEdicoesManuais({
      edicoesAtuais: null,
      edicoesRecebidas: input.edicoes,
      usuarioNome,
    });
    const qualidade =
      getRelatorioQualidadeDeDados(input) ??
      getRelatorioQualidadeDeDados(documento.payload_normalizado_ui) ??
      getRelatorioQualidadeDeDados(payloadInsercaoDb);
    if (relatorioQualidadeBloqueiaConfirmacao(qualidade)) {
      throw new Error("Relatório possui inconsistências críticas e não pode ser confirmado antes da revisão.");
    }

    const novoRelatorio = relatorioRepo.create({
      ...payloadInsercaoDb,
      cliente_id: cliente.id,
      escritorio_id: escritorioId,
      relatorio_ativo: true,
      relatorio_qualidade_de_dados: qualidade,
      edicoes,
      payload_normalizado_ui: withPayloadInsercaoDb(documento.payload_normalizado_ui, payloadInsercaoDb),
    });

    novoRelatorio.metricas_observadas = computeMetricasObservadas(novoRelatorio);

    if (tipo_relatorio === "outro") {
      await garantirOutroIneditoPorDocumento({ manager, escritorioId, arquivoOrigem: documentoId, clienteId: cliente.id, competencia });
    } else {
      await inativarRelatoriosAtivosDaMesmaChave({
        manager,
        escritorioId,
        clienteId: cliente.id,
        tipoRelatorio: tipo_relatorio,
        competencia,
      });
    }

    const relatorioSalvo = await relatorioRepo.save(novoRelatorio);

    await documentoRepo.update(
      { id: documentoId, escritorio_id: escritorioId },
      { cliente_id: cliente.id },
    );

    scheduleConsolidacaoCompetencia(escritorioId, relatorioSalvo.cliente_id, relatorioSalvo.competencia);

    return { ok: true, relatorioId: relatorioSalvo.id, clienteId: cliente.id };
  });
}

export type ResultadoInsercaoRelatorioAutomatico = {
  relatorioId: string | null;
  relatorioAtivo: boolean;
  qualidade: RelatorioQualidadeDeDados;
  relatorioSalvo: Relatorio | null;
  payloadInsercaoDb: Record<string, unknown>;
};

/**
 * Primitiva de inserção compartilhada por todos os canais que gravam um
 * `Relatorio` sem revisão humana prévia: cadastro manual/ingestão por IA
 * (`createRelatorioManual`) e a ingestão em lote via planilha
 * (`finalizarIngestaoRelatoriosPlanilha`). Reúne exatamente a lógica que já
 * existia na cauda de `createRelatorioManual`: QA determinística
 * (`avaliarQualidadeRelatorio`), montagem do payload de persistência
 * (`buildRelatorioPersistenceDraft`), dedupe de `outro` por documento
 * (`garantirOutroIneditoPorDocumento`), arquivamento do ativo anterior da
 * mesma chave (`inativarRelatoriosAtivosDaMesmaChave`), cálculo de
 * `metricas_observadas` e agendamento de `consolidarCompetencia`.
 *
 * Propositalmente NÃO toca a tabela `documentos`: quem chama decide como e
 * quando finalizar o documento de origem (por tupla ou uma única vez para o
 * arquivo inteiro, no caso do lote).
 *
 * `payloadNormalizadoUiFactory` e `camposAdicionaisEntidade` existem para o
 * cadastro manual/IA poder preservar o shape de `payload_normalizado_ui`
 * (com `payloadInsercaoDb` embutido) e o campo `edicoes` — que esta função
 * propositalmente não constrói — sem precisar de um `save` extra: a fábrica
 * roda aqui dentro, depois que `payloadInsercaoDb` já foi calculado, e o
 * resultado entra na MESMA criação/gravação da entidade.
 */
export async function inserirRelatorioAutomatico(input: {
  manager: EntityManager;
  escritorioId: string;
  cliente: Cliente;
  tipoRelatorio: string;
  dadosTipados: Record<string, unknown>;
  arquivoOrigem: string;
  // Só o cadastro manual/ingestão por IA usa: quando a QA zera o score (competência
  // semanticamente inválida) E há um documento de origem, a extração não é confiável
  // o bastante para virar uma linha em `relatorios` — quem chama trata isso no
  // documento. A ingestão em lote nunca usa essa flag (outlier ainda cria linha inativa).
  pularInsercaoSeQualidadeZero?: boolean;
  payloadNormalizadoUiFactory?: (ctx: {
    payloadInsercaoDb: Record<string, unknown>;
    qualidade: RelatorioQualidadeDeDados;
  }) => Record<string, unknown>;
  camposAdicionaisEntidade?: Record<string, unknown>;
}): Promise<ResultadoInsercaoRelatorioAutomatico> {
  const { manager, escritorioId, cliente, tipoRelatorio, dadosTipados, arquivoOrigem } = input;
  const relatorioRepo = manager.getRepository(Relatorio);

  // QA determinística no servidor (sem LLM). Usa estatísticas históricas do
  // cliente para outliers.
  const estatisticas = await manager.getRepository(RelatorioEstatisticaCliente).find({
    where: { escritorio_id: escritorioId, cliente_id: cliente.id, tipo_relatorio: tipoRelatorio },
  });
  const qualidade = avaliarQualidadeRelatorio({
    tipoRelatorio,
    dados: dadosTipados,
    estatisticas,
  });
  dadosTipados.relatorio_qualidade_de_dados = qualidade;
  const relatorioAtivo = !relatorioQualidadeBloqueiaConfirmacao(qualidade);

  const payloadInsercaoDb = buildRelatorioPersistenceDraft({
    rawPayload: dadosTipados,
    documentoId: arquivoOrigem,
    camposEditados: {},
  });
  payloadInsercaoDb.arquivo_origem = arquivoOrigem;

  // No canal de ingestão por IA, QA zero representa uma extração documental que
  // não é confiável o bastante para virar uma entidade de relatório — quem chama
  // finaliza o documento sozinho com este `payloadInsercaoDb`/`qualidade` e não
  // insere em `relatorios`.
  if (input.pularInsercaoSeQualidadeZero && qualidade.score === 0) {
    return { relatorioId: null, relatorioAtivo: false, qualidade, relatorioSalvo: null, payloadInsercaoDb };
  }

  const payloadNormalizadoUi = input.payloadNormalizadoUiFactory
    ? input.payloadNormalizadoUiFactory({ payloadInsercaoDb, qualidade })
    : { origem: "planilha_bulk", relatorio_qualidade_de_dados: qualidade };

  if (tipoRelatorio === "outro") {
    await garantirOutroIneditoPorDocumento({
      manager,
      escritorioId,
      arquivoOrigem,
      clienteId: cliente.id,
      competencia: (dadosTipados.competencia as string | null | undefined) ?? null,
    });
  }

  const novoRelatorio = relatorioRepo.create({
    ...payloadInsercaoDb,
    cliente_id: cliente.id,
    escritorio_id: escritorioId,
    relatorio_ativo: relatorioAtivo,
    relatorio_qualidade_de_dados: qualidade,
    payload_normalizado_ui: payloadNormalizadoUi,
    ...input.camposAdicionaisEntidade,
  });

  novoRelatorio.metricas_observadas = computeMetricasObservadas(novoRelatorio);

  // Só arquiva o ativo anterior e consolida quando o novo entra ativo. Um
  // rascunho bloqueado por QA fica em revisão sem derrubar o registro vigente.
  if (relatorioAtivo && tipoRelatorio !== "outro") {
    await inativarRelatoriosAtivosDaMesmaChave({
      manager,
      escritorioId,
      clienteId: cliente.id,
      tipoRelatorio,
      competencia: (dadosTipados.competencia as string | null | undefined) ?? null,
    });
  }

  const relatorioSalvo = await relatorioRepo.save(novoRelatorio);

  if (relatorioAtivo) {
    scheduleConsolidacaoCompetencia(escritorioId, relatorioSalvo.cliente_id, relatorioSalvo.competencia);
  }

  return { relatorioId: relatorioSalvo.id, relatorioAtivo, qualidade, relatorioSalvo, payloadInsercaoDb };
}

export async function createRelatorioManual(
  escritorioId: string,
  input: Record<string, unknown>,
  usuarioNome?: string | null,
  documentoId?: string | null,
) {
  // Quando ligado a um documento (canal de ingestão por IA), o relatório referencia
  // o documento em arquivo_origem e o documento é finalizado na mesma transação.
  // Sem documento (cadastro manual/form) → arquivo_origem = "Cadastro manual".
  const documentoRef = typeof documentoId === "string" && documentoId.trim() ? documentoId.trim() : null;
  const arquivoOrigem = documentoRef ?? "Cadastro manual";
  const origem = documentoRef ? "ai_submitted_text" : "manual";
  const tipo_relatorio = String(input.tipo_relatorio || "").trim();
  if (!TIPOS_RELATORIO_MANUAIS.has(tipo_relatorio)) {
    throw new Error(
      `tipo_relatorio inválido. Use um dos: ${Array.from(TIPOS_RELATORIO_MANUAIS).join(", ")}.`,
    );
  }

  const competencia = normalizeCompetenciaMmAaaa(input.competencia);
  const cnpj = normalizarCnpj(input.cnpj_cliente);
  const razao_social = typeof input.razao_social === "string" && input.razao_social.trim()
    ? input.razao_social.trim()
    : null;
  const cliente = await findOrCreateClienteByCnpj({
    escritorioId,
    cnpj,
    razaoSocial: razao_social,
  });

  const dadosTipados: Record<string, unknown> = {
    tipo_relatorio,
    competencia,
    cnpj_cliente: cnpj,
    razao_social,
  };

  if (tipo_relatorio === "relatorio_excedente") {
    dadosTipados.itens_excedentes = normalizeItensExcedentes(input.itens_excedentes);
  } else if (tipo_relatorio === "multa") {
    dadosTipados.itens_multa = normalizeItensMulta(input.itens_multa);
  } else if (tipo_relatorio === "outro") {
    dadosTipados.other_metrics = normalizeOtherMetrics(input.other_metrics);
  } else {
    const camposEsperados = CAMPOS_INTEIROS_POR_TIPO[tipo_relatorio] ?? [];
    let algumPreenchido = false;
    for (const campo of camposEsperados) {
      const valor = parseNullableInteger(input[campo]);
      if (valor !== null) {
        if (valor < 0) throw new Error(`${campo} deve ser um inteiro maior ou igual a zero.`);
        algumPreenchido = true;
      }
      dadosTipados[campo] = valor;
    }
    if (!algumPreenchido) {
      throw new Error(
        `Para o tipo ${tipo_relatorio} é necessário preencher pelo menos um dos campos: ${camposEsperados.join(", ")}.`,
      );
    }
  }

  // Rastreabilidade por campo (canal IA/agente): propaga campos[] (campo + id do
  // bloco de OCR anotado + fonte) para o payload bruto, de onde buildLeanExtracaoBruta
  // reanexa id/fonte ao extracao_bruta persistido — é o que o comparador da tela de
  // detalhe do relatório lê. Sem OCR (texto puro), campos vem ausente e nada muda.
  if (Array.isArray((input as Record<string, unknown>).campos)) {
    dadosTipados.campos = (input as Record<string, unknown>).campos;
  }

  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    // edicoes é específico do canal manual/UI-editing — a primitiva compartilhada
    // não sabe construir isso, então calcula aqui e injeta via camposAdicionaisEntidade.
    const edicoes = registrarEdicoesManuais({
      edicoesAtuais: null,
      edicoesRecebidas: input.edicoes,
      usuarioNome,
    });

    const resultado = await inserirRelatorioAutomatico({
      manager,
      escritorioId,
      cliente,
      tipoRelatorio: tipo_relatorio,
      dadosTipados,
      arquivoOrigem,
      // Só este canal (ligado a um documento) pode pular a inserção quando a QA
      // zera o score; a fábrica de payload_normalizado_ui roda dentro da
      // primitiva (depois que payloadInsercaoDb é calculado) para preservar o
      // shape histórico { origem, payloadInsercaoDb, relatorio_qualidade_de_dados }
      // num único save, sem precisar de um update extra depois.
      pularInsercaoSeQualidadeZero: !!documentoRef,
      payloadNormalizadoUiFactory: ({ payloadInsercaoDb, qualidade }) => ({
        origem,
        payloadInsercaoDb,
        relatorio_qualidade_de_dados: qualidade,
      }),
      camposAdicionaisEntidade: edicoes !== null ? { edicoes } : undefined,
    });

    const payloadNormalizadoUi = {
      origem,
      payloadInsercaoDb: resultado.payloadInsercaoDb,
      relatorio_qualidade_de_dados: resultado.qualidade,
    };

    // No canal de ingestão, QA zero representa uma extração documental que não é
    // confiável o bastante para virar uma entidade de relatório. Preserva o raw e
    // conclui o documento para a tela de revisão, mas não insere em `relatorios`.
    // O cadastro manual mantém o comportamento histórico de salvar como inativo
    // (nesse caso resultado.relatorioId nunca é null, porque pularInsercaoSeQualidadeZero
    // só é true quando há documentoRef).
    if (documentoRef && resultado.relatorioId === null) {
      await manager.getRepository(Documento).update(
        { id: documentoRef, escritorio_id: escritorioId },
        {
          status_extracao: "concluido" as Documento["status_extracao"],
          erro_extracao: null,
          cliente_id: cliente.id,
          dados_extraidos_contrato: dadosTipados as unknown as Documento["dados_extraidos_contrato"],
          payload_normalizado_ui: payloadNormalizadoUi as unknown as Documento["payload_normalizado_ui"],
          processed_at: new Date(),
        } as Parameters<ReturnType<typeof manager.getRepository<Documento>>["update"]>[1],
      );

      return {
        ok: true,
        relatorioId: null,
        clienteId: cliente.id,
        documentoId: documentoRef,
        relatorio_ativo: false,
        relatorio_qualidade_de_dados: resultado.qualidade,
      };
    }

    const relatorioSalvo = resultado.relatorioSalvo!;

    // Canal de ingestão por IA: finaliza o documento de origem na mesma transação
    // (paridade com o fluxo de contrato), gravando o raw e o payload normalizado.
    if (documentoRef) {
      await manager.getRepository(Documento).update(
        { id: documentoRef, escritorio_id: escritorioId },
        {
          status_extracao: "concluido" as Documento["status_extracao"],
          erro_extracao: null,
          cliente_id: cliente.id,
          // jsonb columns: cast to bypass TypeORM's QueryDeepPartialEntity mapping.
          dados_extraidos_contrato: dadosTipados as unknown as Documento["dados_extraidos_contrato"],
          payload_normalizado_ui: payloadNormalizadoUi as unknown as Documento["payload_normalizado_ui"],
          processed_at: new Date(),
        } as Parameters<ReturnType<typeof manager.getRepository<Documento>>["update"]>[1],
      );
    }

    return {
      ok: true,
      relatorioId: relatorioSalvo.id,
      clienteId: cliente.id,
      documentoId: documentoRef,
      relatorio_ativo: relatorioSalvo.relatorio_ativo,
      relatorio_qualidade_de_dados: relatorioSalvo.relatorio_qualidade_de_dados ?? null,
    };
  });
}

// ── Ingestão em lote via planilha (Excel/CSV) ──────────────────────────────
// Um único arquivo pode trazer linhas de MUITOS clientes (identificados por
// CNPJ) e múltiplos tipos de relatório por cliente — já agregado/validado
// estruturalmente pela Lambda de processamento de planilha
// (`apps/services/relatorios/planilha`). Sem gate de revisão humana por linha
// (decisão de produto): cada tupla é inserida diretamente via
// `inserirRelatorioAutomatico`, reaproveitando a MESMA QA determinística de
// todo outro canal — uma tupla outlier ainda vira `relatorio_ativo:false`,
// pendente de revisão, como qualquer outro canal.

const TIPOS_RELATORIO_PLANILHA = new Set(["resumo_folha", "numero_notas_fiscais", "lancamentos_contabeis", "outro"]);

function campoSnakeParaCamel(campo: string): string {
  return campo.replace(/_([a-z])/g, (_match, letra: string) => letra.toUpperCase());
}

export type RelatorioPlanilhaErro = {
  linha?: number;
  coluna?: string;
  codigo: string;
  mensagem?: string;
  cnpj?: string;
  tipoRelatorio?: string;
};

export type ResultadoIngestaoRelatoriosPlanilha = {
  ok: true;
  totalRelatoriosCriados: number;
  totalClientes: number;
  erros: RelatorioPlanilhaErro[];
};

export async function finalizarIngestaoRelatoriosPlanilha(input: {
  escritorioId: string;
  documentoId: string;
  totalLinhas?: number | null;
  relatorios: Array<Record<string, unknown>>;
  erros?: Array<Record<string, unknown>>;
}): Promise<ResultadoIngestaoRelatoriosPlanilha | null> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();

  const documento = await getDocumentoById(input.escritorioId, input.documentoId);
  if (!documento) return null;

  const erros: RelatorioPlanilhaErro[] = [];
  const clientesAfetados = new Set<string>();
  let criados = 0;

  // Sequencial (não Promise.all): evita corrida de findOrCreateClienteByCnpj
  // para o mesmo CNPJ dentro do mesmo escritório. Cada tupla roda na SUA
  // PRÓPRIA transação curta — se uma tupla estourar um erro inesperado de
  // constraint, o Postgres marcaria a transação inteira como abortada mesmo
  // com o catch em JS; transações por tupla impedem que um cliente ruim
  // derrube clientes bons que já comitaram antes dele neste mesmo loop.
  for (const tupla of input.relatorios) {
    const tipoRelatorio = String(tupla.tipoRelatorio ?? "").trim();
    let cnpj: string;
    try {
      cnpj = normalizarCnpj(tupla.cnpj);
    } catch (err) {
      erros.push({
        codigo: "cnpj_invalido",
        mensagem: err instanceof Error ? err.message : String(err),
        cnpj: typeof tupla.cnpj === "string" ? tupla.cnpj : String(tupla.cnpj ?? ""),
        tipoRelatorio,
      });
      continue;
    }

    if (!TIPOS_RELATORIO_PLANILHA.has(tipoRelatorio)) {
      erros.push({
        codigo: "tipo_relatorio_invalido",
        mensagem: `tipo_relatorio inválido: ${tipoRelatorio || "(vazio)"}.`,
        cnpj,
        tipoRelatorio,
      });
      continue;
    }

    try {
      const razaoSocial = typeof tupla.razaoSocial === "string" && tupla.razaoSocial.trim()
        ? tupla.razaoSocial.trim()
        : null;
      const competencia = typeof tupla.competencia === "string" && tupla.competencia.trim()
        ? tupla.competencia.trim()
        : null;

      const cliente = await findOrCreateClienteByCnpj({
        escritorioId: input.escritorioId,
        cnpj,
        razaoSocial,
      });

      const dadosTipados: Record<string, unknown> = {
        tipo_relatorio: tipoRelatorio,
        competencia,
        cnpj_cliente: cnpj,
        razao_social: razaoSocial,
      };

      if (tipoRelatorio === "outro") {
        dadosTipados.other_metrics = normalizeOtherMetrics(tupla.otherMetrics ?? {});
      } else {
        const camposEsperados = CAMPOS_INTEIROS_POR_TIPO[tipoRelatorio] ?? [];
        for (const campo of camposEsperados) {
          // A Lambda de planilha (apps/services/relatorios/planilha) devolve as
          // tuplas em camelCase; RELATORIO_DB_FIELDS/CAMPOS_INTEIROS_POR_TIPO são
          // snake_case (nome de coluna). Sem essa conversão, tupla[campo] nunca
          // bate com nada e todo valor numérico entra como null.
          dadosTipados[campo] = parseNullableInteger(tupla[campoSnakeParaCamel(campo)]);
        }
      }

      await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
        await inserirRelatorioAutomatico({
          manager,
          escritorioId: input.escritorioId,
          cliente,
          tipoRelatorio,
          dadosTipados,
          arquivoOrigem: input.documentoId,
        });
      });

      criados += 1;
      clientesAfetados.add(cliente.id);
    } catch (err) {
      erros.push({
        codigo: "insercao_falhou",
        mensagem: err instanceof Error ? err.message : String(err),
        cnpj,
        tipoRelatorio,
      });
    }
  }

  const errosCombinados: RelatorioPlanilhaErro[] = [
    ...((input.erros ?? []) as RelatorioPlanilhaErro[]),
    ...erros,
  ];

  // Atualiza a linha de `documentos` UMA única vez para o arquivo inteiro —
  // ao contrário do canal de ingestão por IA (1 documento : 1 relatório), aqui
  // 1 documento pode gerar N relatórios de N clientes; repetir esse update por
  // tupla sobrescreveria cliente_id/dados_extraidos_contrato com os dados da
  // última tupla. `cliente_id` do documento fica null de propósito: o arquivo
  // não pertence a um único cliente.
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    await manager.getRepository(Documento).update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      {
        status_extracao: (criados > 0 ? "concluido" : "erro") as Documento["status_extracao"],
        erro_extracao: criados > 0 ? null : "Nenhum relatório pôde ser inserido a partir da planilha.",
        processed_at: new Date(),
        payload_normalizado_ui: {
          origem: "planilha_bulk",
          totalLinhas: input.totalLinhas ?? null,
          totalClientes: clientesAfetados.size,
          totalRelatoriosCriados: criados,
          erros: errosCombinados,
        } as unknown as Documento["payload_normalizado_ui"],
      } as Parameters<ReturnType<typeof manager.getRepository<Documento>>["update"]>[1],
    );
  });

  return {
    ok: true,
    totalRelatoriosCriados: criados,
    totalClientes: clientesAfetados.size,
    erros: errosCombinados,
  };
}
