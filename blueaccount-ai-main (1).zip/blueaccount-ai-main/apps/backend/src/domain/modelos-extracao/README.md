# `src/domain/modelos-extracao`

Configuração global (singleton) dos modelos Bedrock usados pelas state machines de extração com OCR (`contratos` e `relatorios`).

- `modelo-extracao-config.service.ts`
  - `getExtractionModelConfig()` — lê/cria a linha singleton de `extraction_model_config`. Campo `null` significa usar o default do stack SAM (env vars dos `template.yaml`).
  - `updateExtractionModelConfig(input)` — atualização parcial; string vazia/null limpa o campo (volta ao default).
  - `AVAILABLE_MODELS` — lista curada exibida no dropdown da área Admin (o admin pode informar um ID/ARN customizado).

Consumidores:

- `modules/escritorios` — endpoints `GET/PUT /api/admin/extraction-models` (AdminGuard).
- `modules/documentos` — injeta `inferenceProfileId` no input do `StartExecution` das SMs de extração.

Os slugs HTTP continuam em inglês (`extraction-models`) por compatibilidade com o frontend e clientes existentes; a padronização PT aqui é interna ao domínio.

Fonte da verdade sobre resolução de modelo por etapa: `docs/MODELOS.md`.
