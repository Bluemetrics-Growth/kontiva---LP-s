import { AppDataSource } from "../../database/data-source.js";
import { ExtractionModelConfig } from "../../database/modules/public/entities/extraction-model-config.entity.js";

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

export type ExtractionModelConfigInput = {
  contratos_inference_profile_id?: string | null;
  relatorios_inference_profile_id?: string | null;
};

export type AvailableModel = {
  id: string;
  label: string;
};

/**
 * Lista curada de modelos/inference profiles oferecidos no dropdown do admin.
 * O admin também pode informar um model ID/ARN customizado (campo livre).
 */
export const AVAILABLE_MODELS: AvailableModel[] = [
  {
    id: "arn:aws:bedrock:us-east-1:218485539717:inference-profile/global.amazon.nova-2-lite-v1:0",
    label: "Amazon Nova 2 Lite (inference profile global)",
  },
  {
    id: "arn:aws:bedrock:us-east-1:218485539717:inference-profile/global.amazon.nova-2-pro-v1:0",
    label: "Amazon Nova 2 Pro (inference profile global)",
  },
  { id: "amazon.nova-lite-v1:0", label: "Amazon Nova Lite" },
  { id: "deepseek.v3.2", label: "DeepSeek v3.2" },
  {
    id: "global.anthropic.claude-haiku-4-5-20251001-v1:0",
    label: "Claude Haiku 4.5 (inference profile global)",
  },
  {
    id: "global.anthropic.claude-sonnet-4-6",
    label: "Claude Sonnet 4.6 (inference profile global)",
  },
];

function normalizeModelId(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/**
 * Configuração vigente dos modelos das SMs de extração com OCR (singleton).
 * Lê a linha de `extraction_model_config`; se não existir, cria uma com os
 * campos nulos (null = usar o default do stack SAM). Edição via `updateExtractionModelConfig`.
 */
export async function getExtractionModelConfig(): Promise<ExtractionModelConfig> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(ExtractionModelConfig);
  const existing = await repo.findOne({ where: {}, order: { updated_at: "DESC" } });
  if (existing) return existing;

  return repo.save(
    repo.create({
      contratos_inference_profile_id: null,
      relatorios_inference_profile_id: null,
    }),
  );
}

/**
 * Atualiza a configuração vigente. Campos omitidos são preservados;
 * string vazia ou null limpam o campo (volta ao default do stack).
 */
export async function updateExtractionModelConfig(
  input: ExtractionModelConfigInput,
): Promise<ExtractionModelConfig> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(ExtractionModelConfig);
  const current = await getExtractionModelConfig();

  const next = {
    contratos_inference_profile_id:
      "contratos_inference_profile_id" in input
        ? normalizeModelId(input.contratos_inference_profile_id)
        : current.contratos_inference_profile_id,
    relatorios_inference_profile_id:
      "relatorios_inference_profile_id" in input
        ? normalizeModelId(input.relatorios_inference_profile_id)
        : current.relatorios_inference_profile_id,
  };

  await repo.update(current.id, next);
  return { ...current, ...next, updated_at: new Date() };
}
