# Privacidade operacional

Este domínio mantém a fila de direitos dos titulares, o registro de incidentes e tombstones de
eliminação. Os registros vivem no schema público para sobreviver ao offboarding de tenants.

Regras:

- conteúdo exportado nunca é persistido na solicitação; somente checksum/referência;
- consulta pública exige protocolo e token de acesso armazenado apenas como hash, comparado em tempo
  constante (`timingSafeEqual`) — o endpoint é público e sem sessão, então comparação
  curto-circuitada vazaria o prefixo do hash;
- incidentes são preservados por no mínimo cinco anos;
- tombstones guardam identificadores em hash e apenas o manifesto técnico necessário para repetir
  uma limpeza interrompida.

## Retenção em dois prazos

`RETENCAO_TELEMETRIA_DIAS` (30) e `RETENCAO_AUDITORIA_DIAS` (365) separam duas coisas que moram na
mesma tabela `public.agent_logs`:

- telemetria de agente: 30 dias, por minimização — é o volume que carrega risco;
- trilha administrativa (`agent_name` em `AGENTES_TRILHA_AUDITORIA`, hoje `admin-usuarios`): 1 ano.
  É o registro de quem criou, moveu, promoveu ou removeu usuário. Purgar em 30 dias apagaria o
  controle de acesso junto com a telemetria, o oposto do que uma auditoria pede.

Os mesmos prazos estão no job pg_cron das migrations `1788400000000` / `1788500000000`. Mudar aqui
exige mudar lá — não há mecanismo que force isso, só esta nota.

`agent_logs` também guarda `input_tokens`/`output_tokens`/`total_tokens` — e esses somem no purge de
30 dias junto com o resto da telemetria. O agregado sem PII (contagem de tokens, `model_id`,
`agent_name`) é espelhado em `public.usage_events` (`event_type = 'llm_tokens'`) por `AgentLogger`
no momento da gravação, então billing (`domain/usage`) não perde histórico mesmo depois do purge.
Só a granularidade de trace (prompt/context/execution_arn) é que é minimizada aos 30 dias.

`executarRetencaoPrivacidade` roda os dois prazos numa transação e é o caminho manual quando pg_cron
não está disponível (o agendamento falha com WARNING, nunca derruba o deploy).
