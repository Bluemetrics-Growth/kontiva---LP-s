import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  let stored: Record<string, unknown> | null = null;
  const repo = {
    create: vi.fn((input: Record<string, unknown>) => input),
    save: vi.fn(async (input: Record<string, unknown>) => { stored = { id: "req-1", ...input }; return stored; }),
    findOneBy: vi.fn(async (where: Record<string, unknown>) => {
      if (!stored) return null;
      return Object.entries(where).every(([key, value]) => stored?.[key] === value) ? stored : null;
    }),
  };
  return {
    repo,
    reset: () => { stored = null; },
    appDataSource: { isInitialized: true, initialize: vi.fn(), getRepository: vi.fn(() => repo) },
  };
});

vi.mock("../../../database/data-source.js", () => ({ AppDataSource: mocks.appDataSource }));

const {
  criarSolicitacaoPrivacidade,
  consultarSolicitacaoPrivacidade,
  DadosPrivacidadeInvalidosError,
  hashPrivacidade,
} = await import("../privacidade.service.js");
const { TIPOS_SOLICITACAO_PRIVACIDADE } = await import("../../../database/modules/public/entities/solicitacao-privacidade.entity.js");

describe("privacidade service", () => {
  beforeEach(() => { vi.clearAllMocks(); mocks.reset(); });

  it.each(TIPOS_SOLICITACAO_PRIVACIDADE)("accepts the supported right %s without storing the public token", async (tipo) => {
    const result = await criarSolicitacaoPrivacidade({
      tipo,
      nome_titular: " Maria Silva ",
      email_titular: "MARIA@example.com",
    });
    const persisted = mocks.repo.save.mock.calls.at(-1)?.[0] as Record<string, unknown>;
    expect(result.protocolo).toMatch(/^KPV-\d{8}-[A-F0-9]{10}$/);
    expect(result.token_acesso).toBeTruthy();
    expect(persisted).not.toHaveProperty("token_acesso");
    expect(persisted.token_acesso_hash).toBe(hashPrivacidade(result.token_acesso));
    expect(persisted.email_titular).toBe("maria@example.com");
  });

  it("requires the token to consult and never returns the subject email", async () => {
    const created = await criarSolicitacaoPrivacidade({ tipo: "acesso", nome_titular: "Maria", email_titular: "maria@example.com" });
    expect(await consultarSolicitacaoPrivacidade(created.protocolo, "wrong")).toBeNull();
    const found = await consultarSolicitacaoPrivacidade(created.protocolo, created.token_acesso);
    expect(found).toMatchObject({ protocolo: created.protocolo, tipo: "acesso", status: "identidade_pendente" });
    expect(found).not.toHaveProperty("email_titular");
  });

  it("rejects invalid type and email", async () => {
    await expect(criarSolicitacaoPrivacidade({ tipo: "download", nome_titular: "Maria", email_titular: "maria@example.com" }))
      .rejects.toBeInstanceOf(DadosPrivacidadeInvalidosError);
    await expect(criarSolicitacaoPrivacidade({ tipo: "acesso", nome_titular: "Maria", email_titular: "invalid" }))
      .rejects.toBeInstanceOf(DadosPrivacidadeInvalidosError);
  });
});
