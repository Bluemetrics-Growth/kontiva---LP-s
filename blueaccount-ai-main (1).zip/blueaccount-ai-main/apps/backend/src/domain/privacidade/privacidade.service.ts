import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { AppDataSource } from "../../database/data-source.js";
import {
  SolicitacaoPrivacidade,
  TIPOS_SOLICITACAO_PRIVACIDADE,
  type StatusSolicitacaoPrivacidade,
  type TipoSolicitacaoPrivacidade,
} from "../../database/modules/public/entities/solicitacao-privacidade.entity.js";
import {
  IncidenteDadosPessoais,
  type StatusIncidenteDadosPessoais,
} from "../../database/modules/public/entities/incidente-dados-pessoais.entity.js";
import {
  TombstonePrivacidade,
  type EscopoTombstonePrivacidade,
} from "../../database/modules/public/entities/tombstone-privacidade.entity.js";
import { Escritorio } from "../../database/modules/public/entities/escritorio.entity.js";
import { Usuario } from "../../database/modules/public/entities/usuario.entity.js";

const PRAZO_RESPOSTA_DIAS = 15;

/**
 * Retenção de `public.agent_logs`, em dois prazos:
 *
 * - telemetria de agente: 30 dias (minimização — é o volume que carrega risco);
 * - trilha de auditoria administrativa: 1 ano.
 *
 * A trilha de quem criou/moveu/promoveu/removeu usuário e quem alterou escritório
 * grava nesta mesma tabela via `adminAuditLogger` (`AgentLogger("admin-usuarios")`).
 * Purgar tudo em 30 dias apagaria o registro de controle de acesso junto com a
 * telemetria — o oposto do que a LGPD e uma auditoria pedem.
 *
 * Estes valores estão espelhados no job pg_cron da migration
 * `1788400000000-create-operacao-privacidade`: mudar aqui exige mudar lá.
 */
export const RETENCAO_TELEMETRIA_DIAS = 30;
export const RETENCAO_AUDITORIA_DIAS = 365;
export const AGENTES_TRILHA_AUDITORIA = ["admin-usuarios"] as const;
const STATUS_SOLICITACAO = new Set<StatusSolicitacaoPrivacidade>([
  "recebida", "identidade_pendente", "em_analise", "em_execucao", "concluida", "negada",
]);
const STATUS_INCIDENTE = new Set<StatusIncidenteDadosPessoais>([
  "triagem", "contencao", "avaliacao_risco", "comunicacao", "encerrado",
]);

export class DadosPrivacidadeInvalidosError extends Error {}

export function hashPrivacidade(value: string): string {
  return createHash("sha256").update(value.trim().toLowerCase()).digest("hex");
}

/**
 * Compara hashes em tempo constante. O endpoint de acompanhamento por protocolo é
 * público e sem sessão, então comparação curto-circuitada vazaria o prefixo do hash
 * do token de acesso.
 */
function hashesIguais(esperado: string, informado: string): boolean {
  const a = Buffer.from(esperado, "utf8");
  const b = Buffer.from(informado, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

export function isTipoSolicitacaoPrivacidade(value: unknown): value is TipoSolicitacaoPrivacidade {
  return typeof value === "string" && (TIPOS_SOLICITACAO_PRIVACIDADE as readonly string[]).includes(value);
}

function textoObrigatorio(value: unknown, campo: string, max = 500): string {
  if (typeof value !== "string" || !value.trim()) throw new DadosPrivacidadeInvalidosError(`${campo} é obrigatório.`);
  const normalized = value.trim();
  if (normalized.length > max) throw new DadosPrivacidadeInvalidosError(`${campo} excede ${max} caracteres.`);
  return normalized;
}

function textoOpcional(value: unknown, max = 4_000): string | null {
  if (value == null || value === "") return null;
  if (typeof value !== "string") throw new DadosPrivacidadeInvalidosError("Texto opcional inválido.");
  const normalized = value.trim();
  if (normalized.length > max) throw new DadosPrivacidadeInvalidosError(`Texto excede ${max} caracteres.`);
  return normalized || null;
}

function emailValido(value: unknown): string {
  const email = textoObrigatorio(value, "email", 320).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new DadosPrivacidadeInvalidosError("E-mail inválido.");
  return email;
}

function protocolo(): string {
  const date = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  return `KPV-${date}-${randomBytes(5).toString("hex").toUpperCase()}`;
}

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

export async function criarSolicitacaoPrivacidade(input: {
  tipo: unknown;
  nome_titular: unknown;
  email_titular: unknown;
  descricao?: unknown;
  escritorio_id?: string | null;
  usuario_id?: string | null;
  identidade_verificada?: boolean;
}) {
  await ensureDatabase();
  if (!isTipoSolicitacaoPrivacidade(input.tipo)) {
    throw new DadosPrivacidadeInvalidosError("Tipo de solicitação inválido.");
  }
  const nome = textoObrigatorio(input.nome_titular, "nome_titular", 200);
  const email = emailValido(input.email_titular);
  const tokenAcesso = randomBytes(32).toString("base64url");
  const prazo = new Date();
  prazo.setUTCDate(prazo.getUTCDate() + PRAZO_RESPOSTA_DIAS);
  const repo = AppDataSource.getRepository(SolicitacaoPrivacidade);
  const entity = repo.create({
    protocolo: protocolo(),
    token_acesso_hash: hashPrivacidade(tokenAcesso),
    tipo: input.tipo,
    status: input.identidade_verificada ? "recebida" : "identidade_pendente",
    nome_titular: nome,
    email_titular: email,
    email_hash: hashPrivacidade(email),
    descricao: textoOpcional(input.descricao),
    escritorio_id: input.escritorio_id?.trim() || null,
    usuario_id: input.usuario_id?.trim() || null,
    identidade_verificada_em: input.identidade_verificada ? new Date() : null,
    prazo_resposta_em: prazo,
    evidencias: [{ tipo: "recebimento", em: new Date().toISOString(), canal: input.usuario_id ? "autenticado" : "publico" }],
  });
  const saved = await repo.save(entity);
  return {
    protocolo: saved.protocolo,
    token_acesso: tokenAcesso,
    status: saved.status,
    prazo_resposta_em: saved.prazo_resposta_em,
  };
}

export async function consultarSolicitacaoPrivacidade(protocoloInput: string, token: string) {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(SolicitacaoPrivacidade);
  const found = await repo.findOneBy({ protocolo: protocoloInput.trim().toUpperCase() });
  if (!found || !hashesIguais(found.token_acesso_hash, hashPrivacidade(token))) return null;
  return {
    protocolo: found.protocolo,
    tipo: found.tipo,
    status: found.status,
    prazo_resposta_em: found.prazo_resposta_em,
    concluida_em: found.concluida_em,
    updated_at: found.updated_at,
  };
}

export async function listarSolicitacoesPrivacidade(input: { status?: string; page?: number; pageSize?: number }) {
  await ensureDatabase();
  const page = Math.max(1, input.page || 1);
  const pageSize = Math.min(100, Math.max(1, input.pageSize || 25));
  const qb = AppDataSource.getRepository(SolicitacaoPrivacidade).createQueryBuilder("s");
  if (input.status && STATUS_SOLICITACAO.has(input.status as StatusSolicitacaoPrivacidade)) {
    qb.andWhere("s.status = :status", { status: input.status });
  }
  const [items, total] = await qb.orderBy("s.prazo_resposta_em", "ASC").skip((page - 1) * pageSize).take(pageSize).getManyAndCount();
  return { data: items.map(sanitizarSolicitacaoAdmin), total, page, pageSize };
}

export async function atualizarSolicitacaoPrivacidade(id: string, patch: Record<string, unknown>) {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(SolicitacaoPrivacidade);
  const found = await repo.findOneBy({ id });
  if (!found) return null;
  if (patch.status !== undefined) {
    if (typeof patch.status !== "string" || !STATUS_SOLICITACAO.has(patch.status as StatusSolicitacaoPrivacidade)) {
      throw new DadosPrivacidadeInvalidosError("Status inválido.");
    }
    found.status = patch.status as StatusSolicitacaoPrivacidade;
  }
  if (patch.identidade_verificada === true && !found.identidade_verificada_em) found.identidade_verificada_em = new Date();
  if (patch.responsavel !== undefined) found.responsavel = textoOpcional(patch.responsavel, 200);
  if (patch.decisao !== undefined) found.decisao = textoOpcional(patch.decisao);
  if (patch.fundamento !== undefined) found.fundamento = textoOpcional(patch.fundamento);
  if (patch.evidencia && typeof patch.evidencia === "object" && !Array.isArray(patch.evidencia)) {
    const raw = patch.evidencia as Record<string, unknown>;
    found.evidencias = [...found.evidencias, {
      tipo: textoObrigatorio(raw.tipo, "evidencia.tipo", 100),
      em: new Date().toISOString(),
      responsavel: found.responsavel,
      checksum: textoOpcional(raw.checksum, 128),
      referencia: textoOpcional(raw.referencia, 500),
    }];
  }
  if (["concluida", "negada"].includes(found.status)) found.concluida_em ??= new Date();
  else found.concluida_em = null;
  return sanitizarSolicitacaoAdmin(await repo.save(found));
}

export async function gerarManifestoExportacaoPrivacidade(id: string) {
  await ensureDatabase();
  const found = await AppDataSource.getRepository(SolicitacaoPrivacidade).findOneBy({ id });
  if (!found) return null;
  const usuario = found.usuario_id ? await AppDataSource.getRepository(Usuario).findOneBy({ id: found.usuario_id }) : null;
  const escritorio = found.escritorio_id ? await AppDataSource.getRepository(Escritorio).findOneBy({ id: found.escritorio_id }) : null;
  return {
    gerado_em: new Date().toISOString(),
    protocolo: found.protocolo,
    escopo: "manifesto_operacional",
    titular: { nome: found.nome_titular, email: found.email_titular },
    conta: usuario ? { id: usuario.id, nome: usuario.nome, email: usuario.email, ativo: usuario.ativo, created_at: usuario.created_at } : null,
    escritorio: escritorio ? { id: escritorio.id, nome: escritorio.nome, ativo: escritorio.ativo } : null,
    aviso: "Documentos e dados de negócio são entregues somente após localização e validação manual registrada como evidência.",
  };
}

export async function criarIncidenteDadosPessoais(input: Record<string, unknown>) {
  await ensureDatabase();
  const detectadoEm = new Date(String(input.detectado_em || ""));
  if (Number.isNaN(detectadoEm.getTime())) throw new DadosPrivacidadeInvalidosError("detectado_em inválido.");
  const repo = AppDataSource.getRepository(IncidenteDadosPessoais);
  if (input.status !== undefined && !STATUS_INCIDENTE.has(input.status as StatusIncidenteDadosPessoais)) {
    throw new DadosPrivacidadeInvalidosError("Status de incidente inválido.");
  }
  return repo.save(repo.create({
    titulo: textoObrigatorio(input.titulo, "titulo", 200),
    descricao_resumida: textoObrigatorio(input.descricao_resumida, "descricao_resumida", 4_000),
    detectado_em: detectadoEm,
    categorias_dados: textoOpcional(input.categorias_dados),
    titulares_afetados_estimativa: textoOpcional(input.titulares_afetados_estimativa, 500),
    // `status`, `avaliacao_risco` e `medidas_contencao` eram descartados em silêncio
    // na criação: quem abre o incidente já na contenção perdia o que preencheu.
    ...(input.status !== undefined ? { status: input.status as StatusIncidenteDadosPessoais } : {}),
    avaliacao_risco: textoOpcional(input.avaliacao_risco),
    medidas_contencao: textoOpcional(input.medidas_contencao),
    responsavel: textoOpcional(input.responsavel, 200),
    evidencias: [],
  }));
}

export async function listarIncidentesDadosPessoais() {
  await ensureDatabase();
  return AppDataSource.getRepository(IncidenteDadosPessoais).find({ order: { detectado_em: "DESC" } });
}

export async function atualizarIncidenteDadosPessoais(id: string, patch: Record<string, unknown>) {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(IncidenteDadosPessoais);
  const found = await repo.findOneBy({ id });
  if (!found) return null;
  if (patch.status !== undefined) {
    if (typeof patch.status !== "string" || !STATUS_INCIDENTE.has(patch.status as StatusIncidenteDadosPessoais)) {
      throw new DadosPrivacidadeInvalidosError("Status de incidente inválido.");
    }
    found.status = patch.status as StatusIncidenteDadosPessoais;
  }
  for (const key of ["avaliacao_risco", "medidas_contencao", "responsavel"] as const) {
    if (patch[key] !== undefined) found[key] = textoOpcional(patch[key]);
  }
  for (const key of ["comunicado_controlador_em", "comunicado_anpd_em", "comunicado_titulares_em"] as const) {
    if (patch[key] !== undefined) {
      if (patch[key] === null || patch[key] === "") found[key] = null;
      else {
        const date = new Date(String(patch[key]));
        if (Number.isNaN(date.getTime())) throw new DadosPrivacidadeInvalidosError(`${key} inválido.`);
        found[key] = date;
      }
    }
  }
  found.encerrado_em = found.status === "encerrado" ? (found.encerrado_em ?? new Date()) : null;
  return repo.save(found);
}

export async function registrarTombstonePrivacidade(input: {
  escopo: EscopoTombstonePrivacidade;
  identificador: string;
  escritorio_id?: string | null;
  manifesto?: Record<string, unknown>;
  motivo: string;
}) {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(TombstonePrivacidade);
  const identificadorHash = hashPrivacidade(`${input.escopo}:${input.identificador}`);
  const existing = await repo.findOneBy({ escopo: input.escopo, identificador_hash: identificadorHash });
  if (existing) {
    existing.manifesto = input.manifesto ?? existing.manifesto;
    existing.motivo = input.motivo;
    existing.concluido_em = null;
    return repo.save(existing);
  }
  return repo.save(repo.create({
    escopo: input.escopo,
    identificador_hash: identificadorHash,
    escritorio_id: input.escritorio_id?.trim() || null,
    manifesto: input.manifesto ?? {},
    motivo: input.motivo,
  }));
}

export async function obterTombstonePrivacidade(escopo: EscopoTombstonePrivacidade, identificador: string) {
  await ensureDatabase();
  return AppDataSource.getRepository(TombstonePrivacidade).findOneBy({
    escopo,
    identificador_hash: hashPrivacidade(`${escopo}:${identificador}`),
  });
}

export async function concluirTombstonePrivacidade(id: string, error?: unknown) {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(TombstonePrivacidade);
  const found = await repo.findOneBy({ id });
  if (!found) return null;
  found.tentativas += 1;
  if (error) {
    found.concluido_em = null;
    found.ultimo_erro = error instanceof Error ? error.name.slice(0, 200) : "erro_desconhecido";
    found.proxima_tentativa_em = new Date(Date.now() + Math.min(24, 2 ** found.tentativas) * 60 * 60 * 1_000);
  } else {
    found.ultimo_erro = null;
    found.proxima_tentativa_em = null;
    found.concluido_em = new Date();
  }
  return repo.save(found);
}

export async function obterResumoRetencaoPrivacidade() {
  await ensureDatabase();
  const [vencidos] = await AppDataSource.query(`
    SELECT
      (SELECT count(*)::int FROM public.contexto WHERE created_at < now() - ($1 || ' days')::interval) AS contextos_vencidos,
      (SELECT count(*)::int FROM public.agent_logs
        WHERE created_at < now() - ($1 || ' days')::interval
          AND agent_name <> ALL($3::text[])) AS logs_agente_vencidos,
      (SELECT count(*)::int FROM public.agent_logs
        WHERE created_at < now() - ($2 || ' days')::interval
          AND agent_name = ANY($3::text[])) AS logs_auditoria_vencidos,
      (SELECT count(*)::int FROM public.solicitacoes_privacidade
        WHERE concluida_em IS NULL AND prazo_resposta_em < now()) AS solicitacoes_atrasadas,
      (SELECT count(*)::int FROM public.tombstones_privacidade
        WHERE concluido_em IS NULL AND (proxima_tentativa_em IS NULL OR proxima_tentativa_em <= now())) AS tombstones_pendentes
  `, [RETENCAO_TELEMETRIA_DIAS, RETENCAO_AUDITORIA_DIAS, [...AGENTES_TRILHA_AUDITORIA]]);
  let falhas_job_24h: number | null = null;
  try {
    const [cron] = await AppDataSource.query(`
      SELECT count(*)::int AS falhas
      FROM cron.job_run_details
      WHERE status = 'failed'
        AND start_time >= now() - interval '24 hours'
        AND command LIKE '%public.contexto%'
    `);
    falhas_job_24h = Number(cron?.falhas ?? 0);
  } catch {
    // pg_cron é opcional em desenvolvimento; null diferencia ausência de zero falhas.
  }
  return { ...vencidos, falhas_job_24h, consultado_em: new Date().toISOString() };
}

export async function executarRetencaoPrivacidade() {
  await ensureDatabase();
  const agentesAuditoria = [...AGENTES_TRILHA_AUDITORIA];
  return AppDataSource.transaction(async (manager) => {
    const contexto = await manager.query(`
      WITH removidos AS (
        DELETE FROM public.contexto WHERE created_at < now() - ($1 || ' days')::interval RETURNING 1
      ) SELECT count(*)::int AS quantidade FROM removidos
    `, [RETENCAO_TELEMETRIA_DIAS]);
    const logs = await manager.query(`
      WITH removidos AS (
        DELETE FROM public.agent_logs
        WHERE created_at < now() - ($1 || ' days')::interval
          AND agent_name <> ALL($2::text[])
        RETURNING 1
      ) SELECT count(*)::int AS quantidade FROM removidos
    `, [RETENCAO_TELEMETRIA_DIAS, agentesAuditoria]);
    // Trilha administrativa sai só depois de 1 ano (ver RETENCAO_AUDITORIA_DIAS).
    const auditoria = await manager.query(`
      WITH removidos AS (
        DELETE FROM public.agent_logs
        WHERE created_at < now() - ($1 || ' days')::interval
          AND agent_name = ANY($2::text[])
        RETURNING 1
      ) SELECT count(*)::int AS quantidade FROM removidos
    `, [RETENCAO_AUDITORIA_DIAS, agentesAuditoria]);
    return {
      contextos_removidos: Number(contexto?.[0]?.quantidade ?? 0),
      logs_agente_removidos: Number(logs?.[0]?.quantidade ?? 0),
      logs_auditoria_removidos: Number(auditoria?.[0]?.quantidade ?? 0),
      executado_em: new Date().toISOString(),
    };
  });
}

function sanitizarSolicitacaoAdmin(item: SolicitacaoPrivacidade) {
  const { token_acesso_hash: _token, ...safe } = item;
  return safe;
}
