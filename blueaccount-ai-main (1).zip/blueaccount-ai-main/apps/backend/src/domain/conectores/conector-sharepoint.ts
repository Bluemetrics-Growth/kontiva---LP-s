import { ConflictException } from "@nestjs/common";
import { LessThan } from "typeorm";
import { runQueryWithRls } from "../../database/data-source.js";
import { ConectorSharePointConexao } from "../../database/modules/tenant/entities/conector-sharepoint-conexao.entity.js";
import { ConectorSharePointExecucao, type ConectorSharePointExecucaoStatus } from "../../database/modules/tenant/entities/conector-sharepoint-execucao.entity.js";
import { ConectorSharePointArquivo, type ConectorSharePointArquivoStatus } from "../../database/modules/tenant/entities/conector-sharepoint-arquivo.entity.js";
import type { DocumentoModulo } from "../../database/modules/tenant/entities/documento.entity.js";
import { CHAVE_WATERMARK, IDADE_MAXIMA_ERRO_MS } from "./janela-sincronizacao.js";

const PG_UNIQUE_VIOLATION = "23505";
const STALE_EXECUCAO_MS = 60 * 60 * 1000;

export type ArquivoSharePointInventario = {
  itemId: string;
  hashAlgorithm: string;
  hashValue: string;
  nome: string;
  mimeType: string | null;
  size: number | null;
  modifiedTime: string | null;
  modulo: Exclude<DocumentoModulo, "simulation_data">;
  s3Key: string;
};

export async function obterConexaoSharePoint(escritorioId: string): Promise<ConectorSharePointConexao | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) =>
    await manager.getRepository(ConectorSharePointConexao).findOne({ where: { escritorio_id: escritorioId } }),
  );
}

export async function salvarOauthPendente(input: {
  escritorioId: string;
  urlPasta: string;
  nonceHash: string;
  verifier: { ciphertext: string; iv: string; tag: string };
  expiresAt: Date;
}): Promise<void> {
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorSharePointConexao);
    let row = await repo.findOne({ where: { escritorio_id: input.escritorioId } });
    row ??= repo.create({ escritorio_id: input.escritorioId, status: "erro", ativo: false });
    row.oauth_url_pasta = input.urlPasta;
    row.oauth_nonce_hash = input.nonceHash;
    row.oauth_pkce_verifier_encrypted = input.verifier.ciphertext;
    row.oauth_pkce_verifier_iv = input.verifier.iv;
    row.oauth_pkce_verifier_tag = input.verifier.tag;
    row.oauth_expires_at = input.expiresAt;
    await repo.save(row);
    return null;
  });
}

export async function carregarOauthPendente(escritorioId: string): Promise<ConectorSharePointConexao | null> {
  return await obterConexaoSharePoint(escritorioId);
}

export async function concluirConexaoSharePoint(input: {
  escritorioId: string;
  usuarioId: string;
  urlPasta: string;
  siteId: string;
  driveId: string;
  rootItemId: string;
  tenantId: string | null;
  accountId: string | null;
  accountEmail: string | null;
  accessToken: { ciphertext: string; iv: string; tag: string };
  refreshToken: { ciphertext: string; iv: string; tag: string };
  expiresAt: Date;
}): Promise<void> {
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorSharePointConexao);
    const row = await repo.findOne({ where: { escritorio_id: input.escritorioId } });
    if (!row) throw new Error("Fluxo OAuth do SharePoint não encontrado.");
    const eraAtiva = row.ativo;
    Object.assign(row, {
      url_pasta: input.urlPasta,
      site_id: input.siteId,
      drive_id: input.driveId,
      root_item_id: input.rootItemId,
      microsoft_tenant_id: input.tenantId,
      microsoft_account_id: input.accountId,
      microsoft_account_email: input.accountEmail,
      status: "conectado",
      ativo: true,
      access_token_encrypted: input.accessToken.ciphertext,
      access_token_iv: input.accessToken.iv,
      access_token_tag: input.accessToken.tag,
      refresh_token_encrypted: input.refreshToken.ciphertext,
      refresh_token_iv: input.refreshToken.iv,
      refresh_token_tag: input.refreshToken.tag,
      access_token_expires_at: input.expiresAt,
      conectado_por_usuario_id: eraAtiva ? row.conectado_por_usuario_id : input.usuarioId,
      reconectado_por_usuario_id: eraAtiva ? input.usuarioId : null,
      ultimo_erro: null,
      oauth_nonce_hash: null,
      oauth_pkce_verifier_encrypted: null,
      oauth_pkce_verifier_iv: null,
      oauth_pkce_verifier_tag: null,
      oauth_expires_at: null,
      oauth_url_pasta: null,
    });
    await repo.save(row);
    return null;
  });
}

export async function desconectarSharePoint(escritorioId: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    await manager.getRepository(ConectorSharePointConexao).update({ escritorio_id: escritorioId }, {
      ativo: false, status: "revogado", access_token_encrypted: null, access_token_iv: null,
      access_token_tag: null, refresh_token_encrypted: null, refresh_token_iv: null,
      refresh_token_tag: null, access_token_expires_at: null,
    });
    return null;
  });
}

export async function atualizarTokensSharePoint(input: {
  escritorioId: string;
  accessToken: { ciphertext: string; iv: string; tag: string };
  refreshToken?: { ciphertext: string; iv: string; tag: string };
  expiresAt: Date;
}): Promise<void> {
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const patch: Partial<ConectorSharePointConexao> = {
      access_token_encrypted: input.accessToken.ciphertext, access_token_iv: input.accessToken.iv,
      access_token_tag: input.accessToken.tag, access_token_expires_at: input.expiresAt,
      status: "conectado", ultimo_erro: null,
    };
    if (input.refreshToken) Object.assign(patch, {
      refresh_token_encrypted: input.refreshToken.ciphertext,
      refresh_token_iv: input.refreshToken.iv,
      refresh_token_tag: input.refreshToken.tag,
    });
    await manager.getRepository(ConectorSharePointConexao).update({ escritorio_id: input.escritorioId }, patch);
    return null;
  });
}

export async function marcarReconexaoNecessaria(escritorioId: string, erro: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    await manager.getRepository(ConectorSharePointConexao).update({ escritorio_id: escritorioId }, {
      status: "reconexao_necessaria", ultimo_erro: erro.slice(0, 1000),
    });
    return null;
  });
}

export async function varrerExecucoesSharePointStale(escritorioId: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    await manager.getRepository(ConectorSharePointExecucao).update(
      { escritorio_id: escritorioId, status: "executando", started_at: LessThan(new Date(Date.now() - STALE_EXECUCAO_MS)) },
      { status: "erro", erro: "stale", finished_at: new Date() },
    );
    return null;
  });
}

export async function criarExecucaoSharePoint(escritorioId: string, usuarioId: string | null): Promise<ConectorSharePointExecucao> {
  try {
    return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => await manager.getRepository(ConectorSharePointExecucao).save({
      escritorio_id: escritorioId, status: "executando", execution_arn: null, iniciada_por_usuario_id: usuarioId,
    }));
  } catch (error) {
    if (error && typeof error === "object" && (error as { code?: string }).code === PG_UNIQUE_VIOLATION) {
      throw new ConflictException("Já existe uma sincronização do SharePoint em andamento para este escritório.");
    }
    throw error;
  }
}

export async function salvarExecutionArnSharePoint(escritorioId: string, runId: string, arn: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    await manager.getRepository(ConectorSharePointExecucao).update({ id: runId, escritorio_id: escritorioId }, { execution_arn: arn });
    return null;
  });
}

export async function listarExecucoesSharePoint(escritorioId: string, limit = 20): Promise<ConectorSharePointExecucao[]> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => await manager.getRepository(ConectorSharePointExecucao).find({
    where: { escritorio_id: escritorioId }, order: { started_at: "DESC" }, take: limit,
  }));
}

export async function carregarExecucaoSharePoint(escritorioId: string, runId: string): Promise<ConectorSharePointExecucao | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => await manager.getRepository(ConectorSharePointExecucao).findOne({ where: { id: runId, escritorio_id: escritorioId } }));
}

export async function registrarArquivosSharePoint(escritorioId: string, runId: string, arquivos: ArquivoSharePointInventario[], failedKeys: Set<string>) {
  let sincronizados = 0, erros = 0, ignorados = 0;
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    for (const arquivo of arquivos) {
      const status: ConectorSharePointArquivoStatus = failedKeys.has(arquivo.s3Key) ? "erro" : "sincronizado";
      const rows: Array<{ id: string }> = await manager.query(`INSERT INTO "conector_sharepoint_arquivos"
        ("escritorio_id","execucao_id","sharepoint_item_id","hash_algorithm","hash_value","nome_arquivo","mime_type","size_bytes","sharepoint_modified_time","modulo","s3_key","documento_id","status","motivo")
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NULL,$12,$13) ON CONFLICT DO NOTHING RETURNING id`, [
        escritorioId, runId, arquivo.itemId, arquivo.hashAlgorithm, arquivo.hashValue, arquivo.nome, arquivo.mimeType,
        arquivo.size == null ? null : String(arquivo.size), arquivo.modifiedTime ? new Date(arquivo.modifiedTime) : null,
        arquivo.modulo, arquivo.s3Key, status, status === "erro" ? "falha_download" : null,
      ]);
      if (!rows.length) ignorados += 1; else if (status === "erro") erros += 1; else sincronizados += 1;
    }
    return null;
  });
  return { total_listados: arquivos.length, sincronizados, erros, ignorados };
}

/**
 * Espelha `obterMarcoArquivosComErro` do Drive: menor `sharepoint_modified_time`
 * entre os arquivos ainda presos em `erro` (fora do índice parcial de dedup,
 * logo nada os retenta), sem irmã `sincronizado` para o mesmo
 * `(modulo, hash_algorithm, hash_value)` e com tentativa recente.
 */
export async function obterMarcoArquivosSharePointComErro(escritorioId: string, agora: Date = new Date()): Promise<Date | null> {
  const limite = new Date(agora.getTime() - IDADE_MAXIMA_ERRO_MS);
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const rows: Array<{ pino: Date | string | null }> = await manager.query(
      `SELECT MIN(erro.sharepoint_modified_time) AS pino
         FROM "conector_sharepoint_arquivos" erro
        WHERE erro.escritorio_id = $1
          AND erro.status = 'erro'
          AND erro.sharepoint_modified_time IS NOT NULL
          AND erro.created_at > $2
          AND NOT EXISTS (
            SELECT 1
              FROM "conector_sharepoint_arquivos" ok
             WHERE ok.escritorio_id = erro.escritorio_id
               AND ok.modulo = erro.modulo
               AND ok.hash_algorithm = erro.hash_algorithm
               AND ok.hash_value = erro.hash_value
               AND ok.status = 'sincronizado')`,
      [escritorioId, limite],
    );
    const pino = rows[0]?.pino;
    return pino ? new Date(pino) : null;
  });
}

/**
 * `options.watermarkAte` grava em `detalhes.watermark_ate` (merge jsonb) o
 * instante que esta run cobriu, base da janela incremental da próxima
 * execução. Ver `janela-sincronizacao.ts`.
 */
export async function finalizarExecucaoSharePoint(escritorioId: string, runId: string, options?: {
  statusForcado?: ConectorSharePointExecucaoStatus; erro?: string | null;
  contadores?: { total_listados?: number; sincronizados: number; erros: number; ignorados: number; truncada?: boolean };
  watermarkAte?: string | null;
}) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    let contadores = options?.contadores;
    if (!contadores) {
      const repo = manager.getRepository(ConectorSharePointArquivo);
      const [sincronizados, erros] = await Promise.all([
        repo.count({ where: { escritorio_id: escritorioId, execucao_id: runId, status: "sincronizado" } }),
        repo.count({ where: { escritorio_id: escritorioId, execucao_id: runId, status: "erro" } }),
      ]);
      contadores = { sincronizados, erros, ignorados: 0 };
    }
    const status = options?.statusForcado ?? (contadores.erros ? "concluida_com_erros" : "concluida");
    await manager.getRepository(ConectorSharePointExecucao).update({ id: runId, escritorio_id: escritorioId }, {
      status, total_listados: contadores.total_listados ?? contadores.sincronizados + contadores.erros + contadores.ignorados,
      sincronizados: contadores.sincronizados, erros: contadores.erros, ignorados: contadores.ignorados,
      truncada: contadores.truncada ?? false, erro: options?.erro ?? null, finished_at: new Date(),
    });
    if (options?.watermarkAte) {
      await manager.query(
        `UPDATE "conector_sharepoint_execucoes"
            SET "detalhes" = COALESCE("detalhes", '{}'::jsonb) || $3::jsonb
          WHERE "id" = $1 AND "escritorio_id" = $2`,
        [runId, escritorioId, JSON.stringify({ [CHAVE_WATERMARK]: options.watermarkAte })],
      );
    }
    return { status, sincronizados: contadores.sincronizados, erros: contadores.erros, ignorados: contadores.ignorados };
  });
}

export async function listarArquivosSharePoint(escritorioId: string): Promise<ConectorSharePointArquivo[]> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => await manager.getRepository(ConectorSharePointArquivo).find({ where: { escritorio_id: escritorioId }, order: { created_at: "DESC" } }));
}

export async function carregarArquivoSharePoint(escritorioId: string, id: string): Promise<ConectorSharePointArquivo | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => await manager.getRepository(ConectorSharePointArquivo).findOne({ where: { id, escritorio_id: escritorioId } }));
}

export async function marcarArquivoSharePointProcessado(escritorioId: string, id: string, documentoId: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    await manager.getRepository(ConectorSharePointArquivo).update({ id, escritorio_id: escritorioId }, { documento_id: documentoId });
    return null;
  });
}
