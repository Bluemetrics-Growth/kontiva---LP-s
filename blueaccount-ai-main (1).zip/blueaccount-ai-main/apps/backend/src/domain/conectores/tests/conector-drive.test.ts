import { beforeEach, describe, expect, it, vi } from "vitest";
import { ConflictException } from "@nestjs/common";

const dataSourceMocks = vi.hoisted(() => ({
  runQueryWithRls: vi.fn(),
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: dataSourceMocks.runQueryWithRls,
}));

const { criarExecucao, registrarArquivosSincronizados, finalizarExecucao } = await import("../conector-drive.js");

function criarManagerComRepo(repoPorEntidade: Record<string, unknown>, queryImpl?: (...args: unknown[]) => unknown) {
  return {
    getRepository: (entity: { name?: string }) => {
      const repo = repoPorEntidade[entity?.name ?? ""];
      if (!repo) throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
      return repo;
    },
    query: queryImpl ?? vi.fn(),
  };
}

function arquivoInventario(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    driveFileId: "drive-1",
    nome: "contrato.pdf",
    md5: "md5-abc",
    mimeType: "application/pdf",
    size: 1000,
    modifiedTime: "2026-01-01T00:00:00Z",
    modulo: "contratos" as const,
    s3Key: "arquivos/esc-1/run-1/drive-1_contrato.pdf",
    ...overrides,
  };
}

describe("domain/conectores/conector-drive", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("criarExecucao propaga ConflictException (409) quando já há execução ativa (violação do índice único)", async () => {
    const execucaoRepo = {
      create: vi.fn((value: unknown) => value),
      save: vi.fn().mockRejectedValue({ code: "23505" }),
    };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveExecucao: execucaoRepo })),
    );

    await expect(
      criarExecucao({ escritorioId: "office-1", iniciadaPorUsuarioId: null }),
    ).rejects.toBeInstanceOf(ConflictException);
  });

  it("criarExecucao propaga erros que não são violação de unicidade", async () => {
    const execucaoRepo = {
      create: vi.fn((value: unknown) => value),
      save: vi.fn().mockRejectedValue(new Error("db down")),
    };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveExecucao: execucaoRepo })),
    );

    await expect(
      criarExecucao({ escritorioId: "office-1", iniciadaPorUsuarioId: null }),
    ).rejects.toThrow("db down");
  });

  it("registrarArquivosSincronizados grava sincronizado para arquivos fora de failedKeys", async () => {
    const query = vi.fn().mockResolvedValue([{ id: "ledger-1" }]);
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({}, query)),
    );

    const resultado = await registrarArquivosSincronizados(
      "office-1",
      "run-1",
      [arquivoInventario()],
      new Set<string>(),
    );

    expect(resultado).toEqual({ total_listados: 1, sincronizados: 1, erros: 0, ignorados: 0 });
    expect(query).toHaveBeenCalledWith(
      expect.stringContaining("INSERT INTO"),
      expect.arrayContaining(["office-1", "run-1", "drive-1", "md5-abc"]),
    );
  });

  it("registrarArquivosSincronizados marca erro para s3Key presente em failedKeys", async () => {
    const query = vi.fn().mockResolvedValue([{ id: "ledger-1" }]);
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({}, query)),
    );
    const arquivo = arquivoInventario({ s3Key: "arquivos/esc-1/run-1/falhou.pdf" });

    const resultado = await registrarArquivosSincronizados(
      "office-1",
      "run-1",
      [arquivo],
      new Set([arquivo.s3Key]),
    );

    expect(resultado).toEqual({ total_listados: 1, sincronizados: 0, erros: 1, ignorados: 0 });
  });

  it("registrarArquivosSincronizados conta como ignorado (dedup) quando o INSERT ... ON CONFLICT DO NOTHING não retorna linha, sem lançar", async () => {
    const query = vi.fn().mockResolvedValue([]);
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({}, query)),
    );

    const resultado = await registrarArquivosSincronizados(
      "office-1",
      "run-1",
      [arquivoInventario()],
      new Set<string>(),
    );

    expect(resultado).toEqual({ total_listados: 1, sincronizados: 0, erros: 0, ignorados: 1 });
  });

  it("registrarArquivosSincronizados processa múltiplos arquivos numa única transação (uma chamada a runQueryWithRls)", async () => {
    const query = vi
      .fn()
      .mockResolvedValueOnce([{ id: "ledger-1" }])
      .mockResolvedValueOnce([]) // dedup
      .mockResolvedValueOnce([{ id: "ledger-3" }]);
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({}, query)),
    );
    const arquivos = [
      arquivoInventario({ driveFileId: "d1", md5: "md5-1", s3Key: "k1" }),
      arquivoInventario({ driveFileId: "d2", md5: "md5-2", s3Key: "k2" }),
      arquivoInventario({ driveFileId: "d3", md5: "md5-3", s3Key: "k3-falhou" }),
    ];

    const resultado = await registrarArquivosSincronizados(
      "office-1",
      "run-1",
      arquivos,
      new Set(["k3-falhou"]),
    );

    expect(dataSourceMocks.runQueryWithRls).toHaveBeenCalledTimes(1);
    expect(query).toHaveBeenCalledTimes(3);
    expect(resultado).toEqual({ total_listados: 3, sincronizados: 1, erros: 1, ignorados: 1 });
  });

  it("finalizarExecucao usa os contadores explícitos e marca concluida_com_erros quando há erro", async () => {
    const execucaoRepo = { update: vi.fn() };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveExecucao: execucaoRepo })),
    );

    const resultado = await finalizarExecucao("office-1", "run-1", {
      contadores: { total_listados: 6, sincronizados: 3, erros: 1, ignorados: 2 },
    });

    expect(resultado).toEqual({ status: "concluida_com_erros", sincronizados: 3, erros: 1, ignorados: 2 });
    expect(execucaoRepo.update).toHaveBeenCalledWith(
      { id: "run-1", escritorio_id: "office-1" },
      expect.objectContaining({
        status: "concluida_com_erros",
        sincronizados: 3,
        erros: 1,
        ignorados: 2,
        total_listados: 6,
      }),
    );
  });

  it("finalizarExecucao marca concluida quando os contadores explícitos não têm erro", async () => {
    const execucaoRepo = { update: vi.fn() };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveExecucao: execucaoRepo })),
    );

    const resultado = await finalizarExecucao("office-1", "run-1", {
      contadores: { sincronizados: 5, erros: 0, ignorados: 0 },
    });

    expect(resultado.status).toBe("concluida");
  });

  it("finalizarExecucao respeita statusForcado mesmo sem contadores explícitos (falha ao disparar a SM)", async () => {
    const arquivoRepo = { count: vi.fn().mockResolvedValue(0) };
    const execucaoRepo = { update: vi.fn() };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveArquivo: arquivoRepo, ConectorDriveExecucao: execucaoRepo })),
    );

    const resultado = await finalizarExecucao("office-1", "run-1", { statusForcado: "erro", erro: "falha ao iniciar" });

    expect(resultado.status).toBe("erro");
    expect(execucaoRepo.update).toHaveBeenCalledWith(
      { id: "run-1", escritorio_id: "office-1" },
      expect.objectContaining({ status: "erro", erro: "falha ao iniciar" }),
    );
  });

  it("finalizarExecucao sem contadores explícitos os deriva contando o ledger (sincronizado/erro)", async () => {
    const arquivoRepo = {
      count: vi.fn().mockResolvedValueOnce(4).mockResolvedValueOnce(0),
    };
    const execucaoRepo = { update: vi.fn() };
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback(criarManagerComRepo({ ConectorDriveArquivo: arquivoRepo, ConectorDriveExecucao: execucaoRepo })),
    );

    const resultado = await finalizarExecucao("office-1", "run-1");

    expect(resultado).toEqual({ status: "concluida", sincronizados: 4, erros: 0, ignorados: 0 });
  });
});
