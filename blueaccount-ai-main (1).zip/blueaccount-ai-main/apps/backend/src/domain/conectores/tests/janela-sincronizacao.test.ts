import { describe, expect, it } from "vitest";
import {
  calcularJanelaSincronizacao,
  calcularWatermarkDaRun,
  ehJanelaRetroativa,
  LIMITE_RETROATIVO_MS,
  SOBREPOSICAO_MS,
  type ExecucaoParaJanela,
} from "../janela-sincronizacao.js";

const AGORA = new Date("2026-07-27T12:00:00.000Z");

function execucao(overrides: Partial<ExecucaoParaJanela> = {}): ExecucaoParaJanela {
  return {
    id: "run-1",
    status: "concluida",
    started_at: new Date("2026-07-27T11:00:00.000Z"),
    truncada: false,
    detalhes: null,
    ...overrides,
  };
}

describe("calcularJanelaSincronizacao", () => {
  it("devolve null quando não há execução concluída anterior (varredura completa)", () => {
    expect(calcularJanelaSincronizacao({ execucoes: [], agora: AGORA })).toBeNull();
    expect(
      calcularJanelaSincronizacao({
        execucoes: [execucao({ status: "executando" }), execucao({ id: "run-0", status: "erro" })],
        agora: AGORA,
      }),
    ).toBeNull();
  });

  it("ignora a run recém-criada ao escolher a base", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ id: "run-nova", status: "concluida", started_at: new Date("2026-07-27T11:50:00.000Z") }), execucao()],
      execucaoAtualId: "run-nova",
      agora: AGORA,
    });
    expect(resultado).toBe(new Date(new Date("2026-07-27T11:00:00.000Z").getTime() - SOBREPOSICAO_MS).toISOString());
  });

  it("parte do started_at menos a sobreposição, não do finished_at (fecha a janela cega)", () => {
    const resultado = calcularJanelaSincronizacao({ execucoes: [execucao()], agora: AGORA });
    expect(resultado).toBe("2026-07-27T10:45:00.000Z");
  });

  it("prefere o watermark_ate gravado pela run quando existe", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ detalhes: { watermark_ate: "2026-07-27T11:30:00.000Z" } })],
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T11:15:00.000Z");
  });

  it("cai para started_at quando a run anterior é de antes do watermark_ate existir", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ detalhes: { outra_coisa: true } })],
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T10:45:00.000Z");
  });

  it("usa o watermark de keyset da run truncada sem aplicar a sobreposição", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ truncada: true, detalhes: { watermark_ate: "2026-07-27T11:29:59.000Z" } })],
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T11:29:59.000Z");
  });

  it("aplica a sobreposição quando a run truncada não conseguiu gravar watermark", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ truncada: true, detalhes: null })],
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T10:45:00.000Z");
  });

  it("rebaixa o marco até antes do arquivo em erro mais antigo", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao()],
      pinErro: new Date("2026-07-27T09:00:00.000Z"),
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T08:59:59.000Z");
  });

  it("não sobe o marco quando o erro é mais novo que a base", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao()],
      pinErro: new Date("2026-07-27T11:55:00.000Z"),
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-27T10:45:00.000Z");
  });

  it("aplica a retroação pedida pelo usuário", () => {
    expect(calcularJanelaSincronizacao({ execucoes: [execucao()], janelaSolicitada: "dia", agora: AGORA })).toBe(
      "2026-07-26T12:00:00.000Z",
    );
    expect(calcularJanelaSincronizacao({ execucoes: [execucao()], janelaSolicitada: "semana", agora: AGORA })).toBe(
      "2026-07-20T12:00:00.000Z",
    );
  });

  it("mantém o marco mais antigo quando a base já é anterior à retroação pedida", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao({ started_at: new Date("2026-07-24T00:00:00.000Z") })],
      janelaSolicitada: "dia",
      agora: AGORA,
    });
    expect(resultado).toBe("2026-07-23T23:45:00.000Z");
  });

  it("segura o piso de 7 dias mesmo com erro muito antigo prendendo o marco", () => {
    const resultado = calcularJanelaSincronizacao({
      execucoes: [execucao()],
      pinErro: new Date("2026-01-01T00:00:00.000Z"),
      agora: AGORA,
    });
    expect(resultado).toBe(new Date(AGORA.getTime() - LIMITE_RETROATIVO_MS).toISOString());
  });

  it("nunca transforma um pedido de retroação em varredura completa", () => {
    expect(calcularJanelaSincronizacao({ execucoes: [], janelaSolicitada: "semana", agora: AGORA })).toBeNull();
    expect(calcularJanelaSincronizacao({ execucoes: [execucao()], janelaSolicitada: "semana", agora: AGORA })).not.toBeNull();
  });
});

describe("calcularWatermarkDaRun", () => {
  it("usa o started_at numa run normal", () => {
    expect(
      calcularWatermarkDaRun({ startedAt: new Date("2026-07-27T11:00:00.000Z"), truncada: false, modifiedTimes: [] }),
    ).toBe("2026-07-27T11:00:00.000Z");
  });

  it("ignora os modifiedTime numa run normal (não avança além do que foi listado)", () => {
    expect(
      calcularWatermarkDaRun({
        startedAt: new Date("2026-07-27T11:00:00.000Z"),
        truncada: false,
        modifiedTimes: ["2026-07-27T11:59:00.000Z"],
      }),
    ).toBe("2026-07-27T11:00:00.000Z");
  });

  it("avança por keyset numa run truncada, com 1s de desempate", () => {
    expect(
      calcularWatermarkDaRun({
        startedAt: new Date("2026-07-27T11:00:00.000Z"),
        truncada: true,
        modifiedTimes: ["2026-07-01T00:00:00.000Z", "2026-07-05T10:00:00.000Z", null],
      }),
    ).toBe("2026-07-05T09:59:59.000Z");
  });

  it("cai para started_at quando a run truncada não tem modifiedTime utilizável", () => {
    expect(
      calcularWatermarkDaRun({
        startedAt: new Date("2026-07-27T11:00:00.000Z"),
        truncada: true,
        modifiedTimes: [null, undefined, "nao-e-data"],
      }),
    ).toBe("2026-07-27T11:00:00.000Z");
  });
});

describe("ehJanelaRetroativa", () => {
  it("aceita apenas dia e semana", () => {
    expect(ehJanelaRetroativa("dia")).toBe(true);
    expect(ehJanelaRetroativa("semana")).toBe(true);
    expect(ehJanelaRetroativa("mes")).toBe(false);
    expect(ehJanelaRetroativa(undefined)).toBe(false);
    expect(ehJanelaRetroativa(null)).toBe(false);
  });
});
