/**
 * Regras de negócio do conector de Google Drive: ciclo de vida da execução
 * (`conector_drive_execucoes`) e ledger de arquivos sincronizados
 * (`conector_drive_arquivos`). Toda persistência passa por `runQueryWithRls`
 * (dados de tenant); nenhuma chamada ao Google Drive, S3 ou Step Functions
 * acontece aqui — isso fica em `ConectoresDriveService`/Lambdas da SM.
 */
import { ConflictException } from "@nestjs/common";
import { LessThan } from "typeorm";
import { runQueryWithRls } from "../../database/data-source.js";
import {
  ConectorDriveExecucao,
  type ConectorDriveExecucaoStatus,
} from "../../database/modules/tenant/entities/conector-drive-execucao.entity.js";
import {
  ConectorDriveArquivo,
  type ConectorDriveArquivoStatus,
} from "../../database/modules/tenant/entities/conector-drive-arquivo.entity.js";
import type { DocumentoModulo } from "../../database/modules/tenant/entities/documento.entity.js";
import { CHAVE_WATERMARK, IDADE_MAXIMA_ERRO_MS } from "./janela-sincronizacao.js";

const PG_UNIQUE_VIOLATION = "23505";
// Execução "executando" iniciada há mais de 1h é considerada travada (SM morreu
// sem chamar o callback de finalização) — não deve bloquear novos disparos.
const STALE_EXECUCAO_MS = 60 * 60 * 1000;

/** Marca como `erro` execuções "executando" iniciadas há mais de 1h (guarda contra SM travada). */
export async function varrerExecucoesStale(escritorioId: string): Promise<void> {
  const limite = new Date(Date.now() - STALE_EXECUCAO_MS);
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveExecucao);
    await repo.update(
      { escritorio_id: escritorioId, status: "executando", started_at: LessThan(limite) },
      { status: "erro", erro: "stale", finished_at: new Date() },
    );
    return null;
  });
}

/**
 * Cria uma nova execução (status `executando`). O índice parcial único em
 * `(escritorio_id) WHERE status='executando'` garante execução única por
 * escritório; colisão vira `ConflictException` (409) para o chamador.
 */
export async function criarExecucao(input: {
  escritorioId: string;
  iniciadaPorUsuarioId: string | null;
}): Promise<ConectorDriveExecucao> {
  try {
    return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
      const repo = manager.getRepository(ConectorDriveExecucao);
      const execucao = repo.create({
        escritorio_id: input.escritorioId,
        status: "executando" as ConectorDriveExecucaoStatus,
        execution_arn: null,
        iniciada_por_usuario_id: input.iniciadaPorUsuarioId,
      });
      return await repo.save(execucao);
    });
  } catch (err: unknown) {
    if (err && typeof err === "object" && (err as { code?: string }).code === PG_UNIQUE_VIOLATION) {
      throw new ConflictException("Já existe uma execução do conector de Google Drive em andamento para este escritório.");
    }
    throw err;
  }
}

export async function salvarExecutionArn(escritorioId: string, runId: string, executionArn: string): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveExecucao);
    await repo.update({ id: runId, escritorio_id: escritorioId }, { execution_arn: executionArn });
    return null;
  });
}

export async function carregarExecucao(escritorioId: string, runId: string): Promise<ConectorDriveExecucao | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveExecucao);
    return await repo.findOne({ where: { id: runId, escritorio_id: escritorioId } });
  });
}

export async function listarExecucoes(escritorioId: string, limit: number = 20): Promise<ConectorDriveExecucao[]> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveExecucao);
    return await repo.find({
      where: { escritorio_id: escritorioId },
      order: { started_at: "DESC" },
      take: limit,
    });
  });
}

/** Um item do inventário lido de `inventory/${runId}.json` (gravado pela Lambda ListarArquivos). */
export type ArquivoInventario = {
  driveFileId: string;
  nome: string;
  md5: string;
  mimeType: string | null;
  size: number | null;
  modifiedTime: string | null;
  modulo: Exclude<DocumentoModulo, "simulation_data">;
  s3Key: string;
};

export type RegistrarArquivosSincronizadosResult = {
  total_listados: number;
  sincronizados: number;
  erros: number;
  ignorados: number;
};

/**
 * Grava uma linha de ledger por arquivo do inventário, numa única transação
 * (`runQueryWithRls`). `status` vem de `failedKeys` (a chave S3 que a Lambda
 * BaixarArquivo não conseguiu baixar) — os demais arquivos viram
 * `sincronizado`. Dedup por `(escritorio_id, modulo, md5_checksum) WHERE
 * status='sincronizado'` via `INSERT ... ON CONFLICT DO NOTHING`: não lança
 * exceção e não aborta a transação (diferente de deixar a violação de
 * unicidade estourar, que invalidaria as inserções seguintes no mesmo
 * `BEGIN`/`COMMIT`) — um arquivo cujo insert foi ignorado por dedup conta
 * como `ignorados`.
 */
export async function registrarArquivosSincronizados(
  escritorioId: string,
  runId: string,
  arquivos: ArquivoInventario[],
  failedKeys: Set<string>,
): Promise<RegistrarArquivosSincronizadosResult> {
  let sincronizados = 0;
  let erros = 0;
  let ignorados = 0;

  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    for (const arquivo of arquivos) {
      const status: ConectorDriveArquivoStatus = failedKeys.has(arquivo.s3Key) ? "erro" : "sincronizado";
      const rows: Array<{ id: string }> = await manager.query(
        `INSERT INTO "conector_drive_arquivos"
           ("escritorio_id","execucao_id","drive_file_id","md5_checksum","nome_arquivo","mime_type","size_bytes","drive_modified_time","modulo","s3_key","documento_id","status","motivo")
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,NULL,$11,$12)
         ON CONFLICT DO NOTHING
         RETURNING id`,
        [
          escritorioId,
          runId,
          arquivo.driveFileId,
          arquivo.md5,
          arquivo.nome,
          arquivo.mimeType,
          arquivo.size != null ? String(arquivo.size) : null,
          arquivo.modifiedTime ? new Date(arquivo.modifiedTime) : null,
          arquivo.modulo,
          arquivo.s3Key,
          status,
          status === "erro" ? "falha_download" : null,
        ],
      );

      if (rows.length === 0) {
        // Violação do índice parcial de dedup (mesmo escritorio/modulo/checksum
        // já sincronizado) — a linha não foi inserida, conta como ignorado.
        ignorados += 1;
        continue;
      }
      if (status === "erro") {
        erros += 1;
      } else {
        sincronizados += 1;
      }
    }
    return null;
  });

  return { total_listados: arquivos.length, sincronizados, erros, ignorados };
}

/**
 * Menor `drive_modified_time` entre os arquivos ainda presos em `erro`: linhas
 * `erro` ficam de fora do índice parcial de dedup e nada as retenta, então elas
 * precisam segurar o marco d'água até entrarem de verdade. Só contam as que
 * ainda não têm uma irmã `sincronizado` para o mesmo `(modulo, md5)` e cuja
 * tentativa é recente, porque um arquivo apagado na origem nunca mais será listado e
 * não pode travar o conector para sempre.
 */
export async function obterMarcoArquivosComErro(escritorioId: string, agora: Date = new Date()): Promise<Date | null> {
  const limite = new Date(agora.getTime() - IDADE_MAXIMA_ERRO_MS);
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const rows: Array<{ pino: Date | string | null }> = await manager.query(
      `SELECT MIN(erro.drive_modified_time) AS pino
         FROM "conector_drive_arquivos" erro
        WHERE erro.escritorio_id = $1
          AND erro.status = 'erro'
          AND erro.drive_modified_time IS NOT NULL
          AND erro.created_at > $2
          AND NOT EXISTS (
            SELECT 1
              FROM "conector_drive_arquivos" ok
             WHERE ok.escritorio_id = erro.escritorio_id
               AND ok.modulo = erro.modulo
               AND ok.md5_checksum = erro.md5_checksum
               AND ok.status = 'sincronizado')`,
      [escritorioId, limite],
    );
    const pino = rows[0]?.pino;
    return pino ? new Date(pino) : null;
  });
}

/** Todas as linhas do ledger de um escritório, mais recentes primeiro. */
export async function listarArquivos(escritorioId: string): Promise<ConectorDriveArquivo[]> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveArquivo);
    return await repo.find({
      where: { escritorio_id: escritorioId },
      order: { created_at: "DESC" },
    });
  });
}

/** Uma linha do ledger por id, escopada ao escritório (RLS). */
export async function carregarArquivo(escritorioId: string, arquivoId: string): Promise<ConectorDriveArquivo | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveArquivo);
    return await repo.findOne({ where: { id: arquivoId, escritorio_id: escritorioId } });
  });
}

/** Marca a linha do ledger como processada, associando o `documento_id` gerado pelo pipeline de ingestão existente. */
export async function marcarArquivoProcessado(
  escritorioId: string,
  arquivoId: string,
  documentoId: string,
): Promise<void> {
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(ConectorDriveArquivo);
    await repo.update({ id: arquivoId, escritorio_id: escritorioId }, { documento_id: documentoId });
    return null;
  });
}

export type FinalizarExecucaoContadores = {
  total_listados?: number;
  sincronizados: number;
  erros: number;
  ignorados: number;
  truncada?: boolean;
};

export type FinalizarExecucaoResult = {
  status: ConectorDriveExecucaoStatus;
  sincronizados: number;
  erros: number;
  ignorados: number;
};

/**
 * Fecha a execução: grava os contadores, `status` (forçado ou derivado —
 * `erros > 0` vira `concluida_com_erros`, senão `concluida`) e `finished_at`.
 * Quando `options.contadores` não é informado (ex.: falha ao disparar a SM,
 * antes de qualquer arquivo existir), os contadores são computados a partir
 * do ledger (`sincronizado`/`erro` já gravados nesta execução).
 *
 * `options.watermarkAte` grava em `detalhes.watermark_ate` (merge, nunca
 * sobrescrevendo o objeto inteiro) o instante que esta run cobriu. É o que a
 * próxima execução usa como base da janela incremental. Ver
 * `janela-sincronizacao.ts`.
 */
export async function finalizarExecucao(
  escritorioId: string,
  runId: string,
  options?: {
    statusForcado?: ConectorDriveExecucaoStatus;
    erro?: string | null;
    contadores?: FinalizarExecucaoContadores;
    watermarkAte?: string | null;
  },
): Promise<FinalizarExecucaoResult> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    let contadores = options?.contadores;
    if (!contadores) {
      const arquivoRepo = manager.getRepository(ConectorDriveArquivo);
      const [sincronizados, erros] = await Promise.all([
        arquivoRepo.count({ where: { escritorio_id: escritorioId, execucao_id: runId, status: "sincronizado" } }),
        arquivoRepo.count({ where: { escritorio_id: escritorioId, execucao_id: runId, status: "erro" } }),
      ]);
      contadores = { sincronizados, erros, ignorados: 0 };
    }

    const status: ConectorDriveExecucaoStatus =
      options?.statusForcado ?? (contadores.erros > 0 ? "concluida_com_erros" : "concluida");

    const execucaoRepo = manager.getRepository(ConectorDriveExecucao);
    const updatePayload: Record<string, unknown> = {
      sincronizados: contadores.sincronizados,
      erros: contadores.erros,
      ignorados: contadores.ignorados,
      status,
      finished_at: new Date(),
    };
    if (contadores.total_listados !== undefined) updatePayload.total_listados = contadores.total_listados;
    if (contadores.truncada !== undefined) updatePayload.truncada = contadores.truncada;
    if (options?.erro !== undefined) updatePayload.erro = options.erro;

    await execucaoRepo.update({ id: runId, escritorio_id: escritorioId }, updatePayload);

    if (options?.watermarkAte) {
      // Merge em jsonb para preservar qualquer outra chave que `detalhes` venha
      // a carregar no futuro.
      await manager.query(
        `UPDATE "conector_drive_execucoes"
            SET "detalhes" = COALESCE("detalhes", '{}'::jsonb) || $3::jsonb
          WHERE "id" = $1 AND "escritorio_id" = $2`,
        [runId, escritorioId, JSON.stringify({ [CHAVE_WATERMARK]: options.watermarkAte })],
      );
    }

    return {
      status,
      sincronizados: contadores.sincronizados,
      erros: contadores.erros,
      ignorados: contadores.ignorados,
    };
  });
}
