/**
 * Regra compartilhada de janela incremental dos conectores de arquivos externos
 * (Google Drive e SharePoint). Pura: não toca banco, S3, Google nem Graph. Os
 * serviços carregam os dados e passam para cá.
 *
 * O valor devolvido alimenta o `lastExecutionDate` do input da State Machine, que
 * vira o filtro `modifiedTime > lastExecutionDate` na Lambda de listagem. `null`
 * significa varredura completa (primeira sincronização do escritório).
 *
 * ## Por que não é o `finished_at` da run anterior
 *
 * A listagem acontece no *começo* da run, mas o `finished_at` só é gravado no
 * fim (depois de baixar todos os arquivos). Usar `finished_at` como marco d'água
 * cria uma janela cega `[listagem, fim da run]`: um arquivo enviado ao Drive
 * enquanto a run baixava tem `modifiedTime` menor que o `finished_at`, então
 * nunca mais é listado. É exatamente o caso de "subiu o arquivo e clicou
 * sincronizar cedo demais". Aqui o marco parte do `started_at` (gravado antes do
 * `StartExecution`, portanto antes da listagem) e ainda recua `SOBREPOSICAO_MS`
 * para absorver skew de relógio entre nós e o provedor, além do lag de indexação
 * do próprio provedor (o `files.list` do Drive é eventualmente consistente).
 *
 * Re-listar é barato e seguro: os dois ledgers têm índice parcial único
 * (`WHERE status='sincronizado'`) e inserem com `ON CONFLICT DO NOTHING`, então
 * o que já veio é descartado no insert e contado como `ignorados`. O marco
 * d'água é otimização de custo, não correção.
 */

/** Recuo aplicado ao marco d'água: skew de relógio + lag de indexação do provedor. */
export const SOBREPOSICAO_MS = 15 * 60 * 1000;

/**
 * Teto duro de retroação. Nenhum cálculo devolve um marco mais antigo que isto
 * quando já existe run anterior. Recuperação mais profunda é operação manual do
 * time Kontiva, não self-serve (varredura completa numa pasta grande custa uma
 * releitura inteira do Drive/Graph).
 */
export const LIMITE_RETROATIVO_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * Idade máxima de um arquivo em `erro` que ainda segura o marco d'água. Passado
 * isso a linha para de prender a janela. Caso contrário, um arquivo apagado na
 * origem (que nunca mais vai ser listado) travaria o conector em varredura
 * quase completa para sempre.
 */
export const IDADE_MAXIMA_ERRO_MS = 7 * 24 * 60 * 60 * 1000;

/** Empurrão de 1s usado para não perder empates de `modifiedTime` na borda de um corte. */
const DESEMPATE_MS = 1000;

export type JanelaRetroativa = "dia" | "semana";

const DURACAO_JANELA_MS: Record<JanelaRetroativa, number> = {
  dia: 24 * 60 * 60 * 1000,
  semana: 7 * 24 * 60 * 60 * 1000,
};

export function ehJanelaRetroativa(valor: unknown): valor is JanelaRetroativa {
  return valor === "dia" || valor === "semana";
}

/** Chave gravada em `execucoes.detalhes` com o instante que a run efetivamente cobriu. */
export const CHAVE_WATERMARK = "watermark_ate";

/** Forma mínima de uma execução para o cálculo, comum a Drive e SharePoint. */
export type ExecucaoParaJanela = {
  id: string;
  status: string;
  started_at: Date | string;
  truncada: boolean;
  detalhes: Record<string, unknown> | null;
};

function paraData(valor: Date | string | null | undefined): Date | null {
  if (!valor) return null;
  const data = valor instanceof Date ? valor : new Date(valor);
  return Number.isNaN(data.getTime()) ? null : data;
}

function lerWatermark(execucao: ExecucaoParaJanela): Date | null {
  const bruto = execucao.detalhes?.[CHAVE_WATERMARK];
  return typeof bruto === "string" ? paraData(bruto) : null;
}

/**
 * Marco d'água que uma run cobriu, para gravar em `detalhes.watermark_ate` ao
 * finalizá-la.
 *
 * - Run normal: o próprio `started_at`. Tudo modificado a partir daí ainda pode
 *   não ter sido visto, e a folga é aplicada na leitura.
 * - Run **truncada** (a listagem estourou o teto por módulo): o `modifiedTime`
 *   mais novo que de fato entrou no inventário, menos 1s de desempate. Vira
 *   paginação por keyset: cada run avança pela cauda do backlog em vez de
 *   re-listar eternamente os mesmos primeiros N arquivos. Depende de a Lambda
 *   listar do mais antigo para o mais novo.
 */
export function calcularWatermarkDaRun(input: {
  startedAt: Date | string;
  truncada: boolean;
  modifiedTimes: Array<string | null | undefined>;
}): string | null {
  const startedAt = paraData(input.startedAt);

  if (input.truncada) {
    const maiores = input.modifiedTimes
      .map((valor) => paraData(valor ?? null))
      .filter((data): data is Date => data !== null)
      .map((data) => data.getTime());
    if (maiores.length > 0) {
      return new Date(Math.max(...maiores) - DESEMPATE_MS).toISOString();
    }
    // Truncada sem nenhum `modifiedTime` utilizável: não dá para avançar por
    // keyset. Cai no `started_at`, que com a folga da leitura mantém a cauda
    // acessível na próxima run em vez de pulá-la.
  }

  return startedAt ? startedAt.toISOString() : null;
}

export type EntradaJanelaSincronizacao = {
  /** Execuções do escritório, mais recentes primeiro (o que `listarExecucoes` já devolve). */
  execucoes: ExecucaoParaJanela[];
  /** Run recém-criada, que precisa ficar de fora da escolha da base. */
  execucaoAtualId?: string | null;
  /**
   * Menor `modified_time` entre os arquivos ainda em `erro` que continuam sem
   * uma versão sincronizada. Rebaixa o marco para que downloads que falharam
   * voltem a ser listados (linhas `erro` ficam fora do índice de dedup, então
   * nada mais as retenta).
   */
  pinErro?: Date | string | null;
  /** Retroação pedida pelo usuário na hora de disparar a sincronização. */
  janelaSolicitada?: JanelaRetroativa | null;
  agora?: Date;
};

/**
 * Calcula o `lastExecutionDate` da próxima execução. `null` = varredura completa.
 */
export function calcularJanelaSincronizacao(entrada: EntradaJanelaSincronizacao): string | null {
  const agora = entrada.agora ?? new Date();

  const base = entrada.execucoes.find(
    (execucao) =>
      execucao.id !== entrada.execucaoAtualId &&
      (execucao.status === "concluida" || execucao.status === "concluida_com_erros"),
  );

  // Nenhuma run concluída ainda: varredura completa é o comportamento correto e
  // a retroação pedida não tem por que estreitá-la.
  if (!base) return null;

  const watermark = lerWatermark(base);
  const startedAt = paraData(base.started_at);
  const referencia = watermark ?? startedAt;
  if (!referencia) return null;

  // Marco de keyset (run truncada com watermark próprio) já vem recuado de 1s;
  // recuar mais 15min a cada passo rebobinaria o avanço pela cauda. Nos demais
  // casos a folga é o que fecha a janela cega.
  const usaKeyset = base.truncada && watermark !== null;
  let candidato = referencia.getTime() - (usaKeyset ? 0 : SOBREPOSICAO_MS);

  const pinErro = paraData(entrada.pinErro ?? null);
  if (pinErro) {
    candidato = Math.min(candidato, pinErro.getTime() - DESEMPATE_MS);
  }

  if (entrada.janelaSolicitada) {
    candidato = Math.min(candidato, agora.getTime() - DURACAO_JANELA_MS[entrada.janelaSolicitada]);
  }

  candidato = Math.max(candidato, agora.getTime() - LIMITE_RETROATIVO_MS);

  return new Date(candidato).toISOString();
}
