import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { Request } from "express";
import type { OAuthAuthorizeParams } from "../oauth/oauth.service.js";
import { settings } from "../../settings.js";

const GOOGLE_AUTHORIZATION_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const GOOGLE_USERINFO_ENDPOINT = "https://openidconnect.googleapis.com/v1/userinfo";
const GOOGLE_SCOPE = "openid email profile";
const STATE_TTL_MS = 10 * 60 * 1000;

export type GoogleOAuthState =
  | {
      mode: "app";
      returnTo?: string;
      iat: number;
      nonce: string;
    }
  | {
      mode: "oauth";
      oauth: OAuthAuthorizeParams;
      iat: number;
      nonce: string;
    };

type GoogleOAuthStateInput =
  | {
      mode: "app";
      returnTo?: string;
    }
  | {
      mode: "oauth";
      oauth: OAuthAuthorizeParams;
    };

export type GoogleUserInfo = {
  sub: string;
  email: string;
  email_verified: boolean;
  name?: string;
  picture?: string;
};

export function getGoogleOAuthConfig(kind: "app" | "oauth", req: Request): {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
} {
  const clientId = settings.GOOGLE_OAUTH_CLIENT_ID.trim();
  const clientSecret = settings.GOOGLE_OAUTH_CLIENT_SECRET.trim();
  if (!clientId || !clientSecret) {
    throw new Error("GOOGLE_OAUTH_CLIENT_ID e GOOGLE_OAUTH_CLIENT_SECRET precisam estar configurados.");
  }

  const explicitRedirectUri = kind === "oauth"
    ? settings.GOOGLE_OAUTH_MCP_REDIRECT_URI.trim()
    : settings.GOOGLE_OAUTH_REDIRECT_URI.trim();

  return {
    clientId,
    clientSecret,
    redirectUri: explicitRedirectUri || `${publicBaseUrl(req)}${kind === "oauth" ? "/oauth/google/callback" : "/api/auth/google/callback"}`,
  };
}

export function buildGoogleAuthorizationUrl(input: {
  clientId: string;
  redirectUri: string;
  state: GoogleOAuthState;
  loginHint?: string | null;
}): string {
  const url = new URL(GOOGLE_AUTHORIZATION_ENDPOINT);
  url.searchParams.set("client_id", input.clientId);
  url.searchParams.set("redirect_uri", input.redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", GOOGLE_SCOPE);
  url.searchParams.set("state", signGoogleOAuthState(input.state));
  url.searchParams.set("prompt", "select_account");
  if (input.loginHint) {
    url.searchParams.set("login_hint", input.loginHint);
  }
  return url.toString();
}

export async function exchangeGoogleAuthorizationCode(input: {
  code: string;
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}): Promise<{ access_token: string; id_token?: string; expires_in?: number; token_type?: string }> {
  const params = new URLSearchParams();
  params.set("code", input.code);
  params.set("client_id", input.clientId);
  params.set("client_secret", input.clientSecret);
  params.set("redirect_uri", input.redirectUri);
  params.set("grant_type", "authorization_code");

  const response = await fetch(GOOGLE_TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });

  const payload = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok || typeof payload.access_token !== "string") {
    const description = typeof payload.error_description === "string" ? payload.error_description : "Falha ao trocar código OAuth do Google.";
    throw new Error(description);
  }

  return {
    access_token: payload.access_token,
    id_token: typeof payload.id_token === "string" ? payload.id_token : undefined,
    expires_in: typeof payload.expires_in === "number" ? payload.expires_in : undefined,
    token_type: typeof payload.token_type === "string" ? payload.token_type : undefined,
  };
}

export async function fetchGoogleUserInfo(accessToken: string): Promise<GoogleUserInfo> {
  const response = await fetch(GOOGLE_USERINFO_ENDPOINT, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const payload = await response.json().catch(() => ({})) as Record<string, unknown>;

  if (!response.ok) {
    throw new Error("Falha ao buscar perfil do Google.");
  }
  if (typeof payload.sub !== "string" || typeof payload.email !== "string") {
    throw new Error("Perfil do Google sem e-mail/sub.");
  }
  if (payload.email_verified !== true) {
    throw new Error("O e-mail da conta Google ainda não está verificado.");
  }

  return {
    sub: payload.sub,
    email: payload.email,
    email_verified: true,
    name: typeof payload.name === "string" ? payload.name : undefined,
    picture: typeof payload.picture === "string" ? payload.picture : undefined,
  };
}

export function createGoogleOAuthState(payload: GoogleOAuthStateInput): GoogleOAuthState {
  return {
    ...payload,
    iat: Date.now(),
    nonce: randomBytes(16).toString("base64url"),
  } as GoogleOAuthState;
}

export function verifyGoogleOAuthState(value: string): GoogleOAuthState {
  const [encodedPayload, signature] = value.split(".");
  if (!encodedPayload || !signature) {
    throw new Error("State OAuth do Google inválido.");
  }

  const expected = signPayload(encodedPayload);
  const actual = Buffer.from(signature, "base64url");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    throw new Error("State OAuth do Google inválido.");
  }

  const payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8")) as GoogleOAuthState;
  if (!payload || typeof payload !== "object" || typeof payload.iat !== "number") {
    throw new Error("State OAuth do Google inválido.");
  }
  if (Date.now() - payload.iat > STATE_TTL_MS) {
    throw new Error("State OAuth do Google expirado.");
  }
  if (payload.mode !== "app" && payload.mode !== "oauth") {
    throw new Error("State OAuth do Google inválido.");
  }

  return payload;
}

export function safeLocalReturnPath(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) return "/home";
  const trimmed = value.trim();
  if (!trimmed.startsWith("/") || trimmed.startsWith("//")) return "/home";
  return trimmed;
}

/** Monta o retorno ao frontend depois do callback OAuth, sem aceitar destino informado pelo usuário. */
export function resolverUrlFrontend(value: unknown): string {
  const path = safeLocalReturnPath(value);
  const configuredBaseUrl = settings.FRONTEND_BASE_URL.trim().replace(/\/+$/, "");
  if (!configuredBaseUrl) return path;

  try {
    const url = new URL(configuredBaseUrl);
    if (url.protocol !== "http:" && url.protocol !== "https:") return path;
    return `${configuredBaseUrl}${path}`;
  } catch {
    return path;
  }
}

/** Alias mantido para os callers do login Google do aplicativo. */
export function resolverUrlRetornoGoogle(value: unknown): string {
  return resolverUrlFrontend(value);
}

export function publicBaseUrl(req: Request): string {
  const configured = settings.PUBLIC_BASE_URL.trim() || settings.API_PUBLIC_BASE_URL.trim();
  if (configured) return configured.replace(/\/+$/g, "");

  const headers = req?.headers ?? {};
  const forwardedProto = String(headers["x-forwarded-proto"] ?? "").split(",")[0].trim();
  const proto = forwardedProto || req?.protocol || "http";
  const host = typeof req?.get === "function" ? req.get("host") : undefined;
  return `${proto}://${host ?? ""}`;
}

function signGoogleOAuthState(state: GoogleOAuthState): string {
  const encodedPayload = Buffer.from(JSON.stringify(state)).toString("base64url");
  return `${encodedPayload}.${signPayload(encodedPayload).toString("base64url")}`;
}

function signPayload(encodedPayload: string): Buffer {
  const secret =
    settings.GOOGLE_OAUTH_STATE_SECRET.trim() ||
    settings.GOOGLE_OAUTH_CLIENT_SECRET.trim() ||
    "blueaccount-dev-google-oauth-state";
  return createHmac("sha256", secret).update(encodedPayload).digest();
}
