import { describe, expect, it } from "vitest";
import { gerarSegredoTotp, validarCodigoTotp } from "../mfa.service.js";

describe("TOTP MFA", () => {
  const segredoRfc6238 = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ";

  it("gera segredos Base32 de 160 bits", () => {
    expect(gerarSegredoTotp()).toMatch(/^[A-Z2-7]{32}$/);
  });

  it("valida o vetor SHA-1 de seis dígitos e devolve o passo aceito", () => {
    expect(validarCodigoTotp(segredoRfc6238, "287082", 59_000)).toBe(1);
  });

  it("aceita somente a janela de um período para cada lado", () => {
    expect(validarCodigoTotp(segredoRfc6238, "287082", 89_000)).toBe(1);
    expect(validarCodigoTotp(segredoRfc6238, "287082", 120_000)).toBeNull();
  });

  it("rejeita replay do mesmo passo ou de um passo anterior", () => {
    expect(validarCodigoTotp(segredoRfc6238, "287082", 59_000, "1")).toBeNull();
    expect(validarCodigoTotp(segredoRfc6238, "287082", 89_000, "2")).toBeNull();
  });

  it("rejeita códigos malformados", () => {
    expect(validarCodigoTotp(segredoRfc6238, "12345", 59_000)).toBeNull();
    expect(validarCodigoTotp(segredoRfc6238, "abcdef", 59_000)).toBeNull();
  });
});
