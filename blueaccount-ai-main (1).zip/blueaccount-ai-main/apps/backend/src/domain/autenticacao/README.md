# `src/domain/autenticacao`

Esta pasta concentra a regra de negócio de autenticação e sessão.

## Responsabilidades

- normalizar e-mail
- gerar e resolver sessões da aplicação
- construir e limpar cookies `HttpOnly`
- autenticar e completar fluxo de senha usando o adaptador Cognito de infraestrutura
- autenticar e resolver a sessão do admin local
- exigir TOTP da Kontiva após todo login humano por senha, Google OAuth ou admin local
- criar desafios pré-auth de uso único sem emitir a sessão normal antes do segundo fator
- impedir replay do mesmo passo TOTP e revogar sessões/tokens ao resetar um fator
- resolver o `usuario` local a partir de `email` ou `sub`
- derivar o `schema_name` do escritório para consumo da camada de banco

## Arquivos

- `autenticacao.service.ts`: implementação central do domínio de autenticação
- `admin-auth.ts`: helpers da sessão admin local sem Cognito
- `google-oauth.ts`: helpers de OAuth Google para login app e recuperação do fluxo MCP/OAuth
- `mfa.service.ts`: enrollment/verificação TOTP, desafios pré-auth, cookies, replay lock e reset

## Infraestrutura

Chamadas diretas ao AWS SDK Cognito ficam em `src/infrastructure/security/cognito-auth.client.ts`.
O domínio decide sessão, usuário local e cookies; o client de infraestrutura só executa operações
Cognito (login, challenge, reset e CRUD de usuário). Configuração vem de `settings.ts`, não de
`process.env` direto dentro deste domínio.

## Testes

- `tests/autenticacao.service.test.ts`
- `tests/mfa.service.test.ts`

## MFA da aplicação

`MFA_REQUIRED=true` exige TOTP de seis dígitos, SHA-1, período de 30 segundos e janela de um
período para cada lado. O desafio expira em 10 minutos e é encerrado após cinco tentativas. O
segredo é AES-256-GCM; tokens de desafio ficam apenas como hash. Sessões AgentCore/MCP internas
não passam por login humano e permanecem fora do gate. O MFA nativo do Cognito deve continuar
`OFF`, inclusive para manter senha e Google sob uma única política Kontiva.

O rate limit HTTP separa `/mfa/context` de `/mfa/verify`: recarregar o contexto não consome uma
tentativa de código, e a verificação permite exatamente as cinco tentativas controladas pelo
desafio persistido. A chave do limite é o hash do cookie de desafio, com fallback por IP.

## Regra prática

Se a lógica decidir como a sessão da aplicação existe e como o usuário é resolvido, ela pertence aqui.
