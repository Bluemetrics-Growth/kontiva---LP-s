/**
 * Regra do step-up auth (reautenticação em ação crítica).
 *
 * Mora num módulo próprio, sem dependência de banco, porque é consumida pelos
 * guards (`AuthGuard`/`AdminGuard`) e por testes que fazem `vi.mock` do
 * `autenticacao.service` inteiro — mantendo a regra aqui, o gate continua sendo o
 * real e não uma função mockada.
 */

/**
 * Janela do step-up auth: uma ação crítica só passa se a senha foi confirmada
 * (no login ou em `POST /api/auth/reautenticar`) dentro dela.
 */
export const JANELA_REAUTENTICACAO_MS = 10 * 60 * 1000;

/**
 * True quando a ação crítica precisa de nova confirmação de senha.
 *
 * Vale o marco mais recente entre `reautenticado_em` e `created_at` — assim quem
 * acabou de logar não precisa digitar a senha de novo. Sem nenhum marco válido a
 * resposta é `true` (fail-closed): sessão sem data conhecida não passa.
 */
export function exigeReautenticacao(
  session: { created_at?: Date | null; reautenticado_em?: Date | null },
  agora = Date.now(),
): boolean {
  const marcos = [session.reautenticado_em, session.created_at]
    .filter((valor): valor is Date => valor instanceof Date)
    .map((valor) => valor.getTime());
  if (marcos.length === 0) return true;
  return Math.max(...marcos) < agora - JANELA_REAUTENTICACAO_MS;
}
