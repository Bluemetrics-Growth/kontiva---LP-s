/**
 * Layout das chaves S3 dos artefatos de extração de documentos (relatórios e contratos).
 * Compartilhado pelo pipeline Lambda e pelo canal IA/agente para que ambos gravem e leiam
 * exatamente as mesmas chaves.
 */

export type ModuloArtefatoDocumento = "relatorios" | "contratos";

/** `<modulo>/<escritorioId>/<documentoId>[/<arquivo>]`. */
export function montarChaveArtefatoDocumento(
  modulo: ModuloArtefatoDocumento,
  escritorioId: string,
  documentoId: string,
  arquivo?: string,
): string {
  const base = `${modulo}/${escritorioId}/${documentoId}`;
  return arquivo ? `${base}/${arquivo}` : base;
}

/**
 * Prefixo escritório-primeiro do Textract/upload bruto, distinto do layout módulo-primeiro
 * de `montarChaveArtefatoDocumento` (ver `docs` sobre convenção de prefixo S3 por bucket).
 */
export function montarPrefixoTextract(escritorioId: string, idCliente: string, documentoId: string): string {
  return `${escritorioId}/${idCliente}/${documentoId}`;
}
