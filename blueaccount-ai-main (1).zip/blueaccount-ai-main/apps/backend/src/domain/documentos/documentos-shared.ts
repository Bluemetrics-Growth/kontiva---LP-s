/**
 * Submódulo compartilhado de documentos: concentra validações pequenas que são
 * usadas por mais de um caso de uso do domínio.
 */
const ALLOWED_EXTENSIONS = new Set([".pdf", ".docx", ".doc", ".xlsx", ".xls", ".csv"]);

/**
 * Extrai a extensão normalizada de um nome de arquivo para validações de upload.
 */
export function getExtension(filename: string): string {
  const idx = filename.lastIndexOf(".");
  return idx >= 0 ? filename.slice(idx).toLowerCase() : "";
}

/**
 * Garante que o documento enviado usa uma extensão aceita pelo fluxo de ingestão.
 */
export function validateDocumentoFilename(filename: string): void {
  const ext = getExtension(filename);
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    throw new Error("Arquivo inválido. Use apenas PDF, DOCX ou CSV.");
  }
}
