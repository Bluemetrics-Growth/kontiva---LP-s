import { randomInt } from "node:crypto";
import type { EntityManager } from "typeorm";
import { AppDataSource } from "../../database/data-source.js";
import type {
  ModuloIngestaoConcorrencia,
  StatusTerminalIngestao,
} from "../../database/modules/public/entities/ingestao-permissao-processamento.entity.js";
import { settings } from "../../settings.js";

export type AdquirirPermissaoIngestaoInput = {
  executionArn: string;
  documentoId: string;
  modulo: ModuloIngestaoConcorrencia;
};

export type AdquirirPermissaoIngestaoResult =
  | { adquirida: true }
  | { adquirida: false; tentarNovamenteEmSegundos: number };

type PermissaoExistente = {
  documento_id: string;
  modulo: ModuloIngestaoConcorrencia;
  liberada_em: Date | string | null;
};

type ContagemPermissoes = {
  total_ativo: string | number;
  modulo_ativo: string | number;
};

async function inicializarBancoSeNecessario(): Promise<void> {
  if (!AppDataSource.isInitialized) {
    await AppDataSource.initialize();
  }
}

async function bloquearControle(manager: EntityManager): Promise<void> {
  const rows = await manager.query(
    `SELECT "id" FROM "public"."ingestao_controle_concorrencia" WHERE "id" = 1 FOR UPDATE`,
  ) as Array<{ id: number }>;
  if (rows.length !== 1) {
    throw new Error("Controle de concorrência de ingestão não inicializado.");
  }
}

export async function adquirirPermissaoProcessamentoIngestao(
  input: AdquirirPermissaoIngestaoInput,
): Promise<AdquirirPermissaoIngestaoResult> {
  await inicializarBancoSeNecessario();

  return AppDataSource.transaction(async (manager) => {
    await bloquearControle(manager);

    const existentes = await manager.query(
      `SELECT "documento_id", "modulo", "liberada_em"
       FROM "public"."ingestao_permissoes_processamento"
       WHERE "execution_arn" = $1`,
      [input.executionArn],
    ) as PermissaoExistente[];
    const existente = existentes[0];
    if (existente) {
      if (existente.documento_id !== input.documentoId || existente.modulo !== input.modulo) {
        throw new Error("executionArn já associado a outro documento ou módulo.");
      }
      if (existente.liberada_em === null) {
        return { adquirida: true };
      }
      return { adquirida: false, tentarNovamenteEmSegundos: randomInt(15, 46) };
    }

    const contagens = await manager.query(
      `SELECT
         COUNT(*) FILTER (WHERE "liberada_em" IS NULL) AS "total_ativo",
         COUNT(*) FILTER (WHERE "liberada_em" IS NULL AND "modulo" = $1) AS "modulo_ativo"
       FROM "public"."ingestao_permissoes_processamento"`,
      [input.modulo],
    ) as ContagemPermissoes[];
    const totalAtivo = Number(contagens[0]?.total_ativo ?? 0);
    const moduloAtivo = Number(contagens[0]?.modulo_ativo ?? 0);
    const limiteModulo = input.modulo === "contratos"
      ? settings.INGESTAO_CONCORRENCIA_LIMITE_CONTRATOS
      : settings.INGESTAO_CONCORRENCIA_LIMITE_RELATORIOS;

    if (totalAtivo >= settings.INGESTAO_CONCORRENCIA_LIMITE_GLOBAL || moduloAtivo >= limiteModulo) {
      return { adquirida: false, tentarNovamenteEmSegundos: randomInt(15, 46) };
    }

    await manager.query(
      `INSERT INTO "public"."ingestao_permissoes_processamento"
         ("execution_arn", "documento_id", "modulo")
       VALUES ($1, $2, $3)`,
      [input.executionArn, input.documentoId, input.modulo],
    );
    return { adquirida: true };
  });
}

export type LeaseAtivaIngestao = {
  executionArn: string;
  documentoId: string;
  modulo: ModuloIngestaoConcorrencia;
  adquiridaEm: string;
};

export type EstadoConcorrenciaIngestao = {
  limites: { global: number; contratos: number; relatorios: number };
  ativos: { total: number; contratos: number; relatorios: number };
  leases: LeaseAtivaIngestao[];
};

/**
 * Leitura somente-observabilidade do estado do gate: limites configurados, ocupação
 * atual e as leases ativas (`liberada_em IS NULL`). Sem lock — a contagem é derivada da
 * própria lista de leases ativas (índice parcial `IDX_ingestao_permissoes_ativas_modulo`).
 */
export async function obterEstadoConcorrenciaIngestao(): Promise<EstadoConcorrenciaIngestao> {
  await inicializarBancoSeNecessario();

  const linhas = await AppDataSource.query(
    `SELECT "execution_arn", "documento_id", "modulo", "adquirida_em"
     FROM "public"."ingestao_permissoes_processamento"
     WHERE "liberada_em" IS NULL
     ORDER BY "adquirida_em" ASC`,
  ) as Array<{
    execution_arn: string;
    documento_id: string;
    modulo: ModuloIngestaoConcorrencia;
    adquirida_em: Date | string;
  }>;

  const leases: LeaseAtivaIngestao[] = linhas.map((linha) => ({
    executionArn: linha.execution_arn,
    documentoId: linha.documento_id,
    modulo: linha.modulo,
    adquiridaEm: linha.adquirida_em instanceof Date
      ? linha.adquirida_em.toISOString()
      : new Date(linha.adquirida_em).toISOString(),
  }));

  const contratos = leases.filter((lease) => lease.modulo === "contratos").length;
  const relatorios = leases.filter((lease) => lease.modulo === "relatorios_periodicos").length;

  return {
    limites: {
      global: settings.INGESTAO_CONCORRENCIA_LIMITE_GLOBAL,
      contratos: settings.INGESTAO_CONCORRENCIA_LIMITE_CONTRATOS,
      relatorios: settings.INGESTAO_CONCORRENCIA_LIMITE_RELATORIOS,
    },
    ativos: { total: leases.length, contratos, relatorios },
    leases,
  };
}

export async function liberarPermissaoProcessamentoIngestao(input: {
  executionArn: string;
  statusTerminal: StatusTerminalIngestao;
}): Promise<{ liberada: true }> {
  await inicializarBancoSeNecessario();

  return AppDataSource.transaction(async (manager) => {
    await bloquearControle(manager);
    await manager.query(
      `UPDATE "public"."ingestao_permissoes_processamento"
       SET "liberada_em" = now(), "status_terminal" = $2
       WHERE "execution_arn" = $1 AND "liberada_em" IS NULL`,
      [input.executionArn, input.statusTerminal],
    );
    return { liberada: true };
  });
}
