/**
 * Submódulo de mutations de documentos: centraliza updates RLS de status,
 * metadados e payloads sem misturar leitura de artefatos ou upload.
 */
import { In, Not } from "typeorm";
import { runQueryWithRls } from "../../database/data-source.js";
import { Documento, type DocumentoStatusExtracao, type TipoDocumentoContratual } from "../../database/index.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import { Relatorio } from "../../database/modules/tenant/entities/relatorio.entity.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import { ServicosContratados } from "../../database/modules/tenant/entities/servicos-contratados.entity.js";
import { ConectorDriveArquivo } from "../../database/modules/tenant/entities/conector-drive-arquivo.entity.js";
import { ConectorSharePointArquivo } from "../../database/modules/tenant/entities/conector-sharepoint-arquivo.entity.js";
import { EnvelopeAssinaturaEletronica } from "../../database/modules/tenant/entities/envelope-assinatura-eletronica.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import { getDocumentoById } from "./documentos-queries.js";

// Status terminais da extração: uma vez atingidos, o reconcile da SM não pode
// rebaixá-los para um status intermediário (evita o clobber TOCTOU do poll).
const STATUS_TERMINAIS: readonly string[] = ["concluido", "erro"];

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function normalizarTipoDocumentoContratual(value: unknown): TipoDocumentoContratual | null {
  const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (["contrato_novo", "aditivo", "renovacao", "cancelamento", "correcao", "desconhecido"].includes(normalized)) {
    return normalized as TipoDocumentoContratual;
  }
  if (normalized === "anexo") return "aditivo";
  if (normalized === "nao_contrato" || normalized === "não_contrato") return "desconhecido";
  return null;
}

function extrairTipoDocumentoContratualLocal(source: Record<string, unknown>): TipoDocumentoContratual | null {
  const classificacao = isRecord(source.classificacao) ? source.classificacao : {};
  return (
    normalizarTipoDocumentoContratual(source.tipo_documento_contratual) ??
    normalizarTipoDocumentoContratual(source.tipoDocumentoContratual) ??
    normalizarTipoDocumentoContratual(classificacao.tipo_documento_contratual) ??
    normalizarTipoDocumentoContratual(classificacao.tipo)
  );
}

// A classificação pode chegar no topo (canal de texto MCP), em `contractExtraction`
// (callback final da SM de arquivo) ou em `agentResult` (resumo do ContractAgent).
function resolverFonteClassificacao(rawPayload: Record<string, unknown>): Record<string, unknown> {
  if (extrairTipoDocumentoContratualLocal(rawPayload)) return rawPayload;
  const contractExtraction = isRecord(rawPayload.contractExtraction) ? rawPayload.contractExtraction : rawPayload;
  if (extrairTipoDocumentoContratualLocal(contractExtraction)) return contractExtraction;
  const agentResult = isRecord(contractExtraction.agentResult) ? contractExtraction.agentResult : contractExtraction;
  return agentResult;
}

function extrairTipoDocumentoContratual(rawPayload: Record<string, unknown>): TipoDocumentoContratual | null {
  return extrairTipoDocumentoContratualLocal(resolverFonteClassificacao(rawPayload));
}

const TIPOS_ANEXO_CONTRATO: readonly TipoDocumentoContratual[] = ["aditivo", "renovacao", "cancelamento", "correcao"];

function montarAlteracaoPropostaContrato(input: {
  documentoId: string;
  rawPayload: Record<string, unknown>;
  payloadNormalizadoUi?: Record<string, unknown> | null;
  tipoDocumentoContratual: TipoDocumentoContratual | null;
}): Record<string, unknown> | null {
  // Só tipos de aditivo/anexo geram proposta de alteração; `contrato_novo` e
  // `desconhecido` seguem o fluxo padrão de revisão sem contrato base.
  if (!input.tipoDocumentoContratual || !TIPOS_ANEXO_CONTRATO.includes(input.tipoDocumentoContratual)) return null;

  const fonte = resolverFonteClassificacao(input.rawPayload);
  const classificacao = isRecord(fonte.classificacao) ? fonte.classificacao : {};
  const contratoBase = isRecord(fonte.contrato_base) ? fonte.contrato_base : {};
  const contratoBaseId =
    fonte.contrato_base_id ??
    fonte.contratoBaseId ??
    contratoBase.id ??
    null;

  return {
    documento_id: input.documentoId,
    tipo_documento_contratual: input.tipoDocumentoContratual,
    contrato_base_id: typeof contratoBaseId === "string" && contratoBaseId.trim() ? contratoBaseId.trim() : null,
    classificacao: {
      tipo: input.tipoDocumentoContratual,
      confianca: classificacao.confianca ?? fonte.classificacao_confianca ?? fonte.classificacaoConfianca ?? null,
      motivo: classificacao.motivo ?? fonte.classificacao_motivo ?? fonte.classificacaoMotivo ?? null,
    },
    deltas_extraidos: {
      termos_gerais: input.rawPayload.termosGerais ?? null,
      valores_contratados: input.rawPayload.valoresContratados ?? null,
      excedentes: input.rawPayload.excedentes ?? null,
    },
    payload_insercao_db: input.payloadNormalizadoUi?.payloadInsercaoDb ?? null,
  };
}

/**
 * Persiste o ARN da ingestão e as chaves dos artefatos OCR produzidos pelo pipeline.
 */
export async function updateDocumentoIngestionExecutionArn(input: {
  escritorioId: string;
  documentoId: string;
  ingestionExecutionArn: string | null;
  s3TextractPath?: string | null;
  ocrArtifacts?: {
    textractRawKey?: string | null;
    annotatedMarkdownKey?: string | null;
    cleanMarkdownKey?: string | null;
    blocksParquetKey?: string | null;
    ocrManifestKey?: string | null;
  };
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const ocrArtifacts = input.ocrArtifacts;
    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      {
        ingestion_execution_arn: input.ingestionExecutionArn,
        ...(input.s3TextractPath !== undefined ? { s3_textract_path: input.s3TextractPath } : {}),
        ...(ocrArtifacts?.textractRawKey !== undefined ? { textract_raw_key: ocrArtifacts.textractRawKey } : {}),
        ...(ocrArtifacts?.annotatedMarkdownKey !== undefined ? { annotated_markdown_key: ocrArtifacts.annotatedMarkdownKey } : {}),
        ...(ocrArtifacts?.cleanMarkdownKey !== undefined ? { clean_markdown_key: ocrArtifacts.cleanMarkdownKey } : {}),
        ...(ocrArtifacts?.blocksParquetKey !== undefined ? { blocks_parquet_key: ocrArtifacts.blocksParquetKey } : {}),
        ...(ocrArtifacts?.ocrManifestKey !== undefined ? { ocr_manifest_key: ocrArtifacts.ocrManifestKey } : {}),
      },
    );

    return await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
  });
}

/** Atualiza o bucket de origem após recuperar um registro legado de documento. */
export async function updateDocumentoStorageBucket(input: {
  escritorioId: string;
  documentoId: string;
  storageBucket: string;
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      { storage_bucket: input.storageBucket },
    );
    return await repo.findOneBy({ id: input.documentoId, escritorio_id: input.escritorioId });
  });
}

/**
 * Faz merge de campos em `metadados_ia_contrato.ingestion` preservando o restante do JSON.
 */
export async function updateDocumentoIngestionMetadata(input: {
  escritorioId: string;
  documentoId: string;
  ingestionPatch: Record<string, unknown>;
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const documento = await repo.findOneBy({ id: input.documentoId, escritorio_id: input.escritorioId });
    if (!documento) return null;
    const metadados = (documento.metadados_ia_contrato ?? {}) as Record<string, unknown>;
    const ingestion = (metadados.ingestion ?? {}) as Record<string, unknown>;
    const nextMetadados = { ...metadados, ingestion: { ...ingestion, ...input.ingestionPatch } };
    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      { metadados_ia_contrato: nextMetadados },
    );
    return null;
  });
}

/**
 * Grava o estado por seção da extração por IA e opcionalmente atualiza `status_extracao`.
 */
export async function updateDocumentoSecoesIA(input: {
  escritorioId: string;
  documentoId: string;
  secoes: Record<string, unknown>;
  statusExtracao?: DocumentoStatusExtracao;
  erroExtracao?: string | null;
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const documento = await repo.findOneBy({ id: input.documentoId, escritorio_id: input.escritorioId });
    if (!documento) return null;
    const metadados = (documento.metadados_ia_contrato ?? {}) as Record<string, unknown>;
    const nextMetadados = { ...metadados, secoes: input.secoes };
    const updatePayload: Record<string, unknown> = { metadados_ia_contrato: nextMetadados };
    if (input.statusExtracao !== undefined) {
      updatePayload.status_extracao = input.statusExtracao;
    }
    if (input.erroExtracao !== undefined) {
      updatePayload.erro_extracao = input.erroExtracao;
    }
    await repo.update({ id: input.documentoId, escritorio_id: input.escritorioId }, updatePayload);
    return null;
  });
}

/**
 * Remove um documento do escritório e informa se a operação afetou algum registro.
 */
export type DocumentoParaExclusao = Pick<Documento,
  "id" | "storage_provider" | "storage_bucket" | "storage_key" | "s3_textract_path" |
  "textract_raw_key" | "annotated_markdown_key" | "clean_markdown_key" | "blocks_parquet_key" |
  "ocr_manifest_key"
>;

export async function getDocumentoParaExclusao(escritorioId: string, docId: string): Promise<DocumentoParaExclusao | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.getRepository(Documento).findOne({
      where: { id: docId, escritorio_id: escritorioId },
      select: ["id", "storage_provider", "storage_bucket", "storage_key", "s3_textract_path", "textract_raw_key", "annotated_markdown_key", "clean_markdown_key", "blocks_parquet_key", "ocr_manifest_key"],
    });
  });
}

export async function deleteDocumento(escritorioId: string, docId: string): Promise<boolean> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    await manager.getRepository(ServicosContratados).update({ ultimo_documento_id: docId }, { ultimo_documento_id: null });
    await manager.getRepository(ConectorDriveArquivo).update({ documento_id: docId }, { documento_id: null });
    await manager.getRepository(ConectorSharePointArquivo).update({ documento_id: docId }, { documento_id: null });
    await manager.getRepository(EnvelopeAssinaturaEletronica).update({ documento_id: docId }, { documento_id: null });
    await manager.getRepository(Contrato).update({ arquivo_origem: docId }, { arquivo_origem: null });
    await manager.getRepository(Relatorio).update({ arquivo_origem: docId }, { arquivo_origem: null });
    await manager.getRepository(Faturamento).update({ arquivo_origem: docId }, { arquivo_origem: null });
    const result = await repo.delete({ id: docId, escritorio_id: escritorioId });
    return result.affected ? result.affected > 0 : false;
  });
}

/**
 * Atualiza o status geral de extração e campos opcionais de erro, processamento e output.
 */
export async function updateDocumentoExtracaoStatus(input: {
  escritorioId: string;
  documentoId: string;
  statusExtracao: DocumentoStatusExtracao;
  erroExtracao?: string | null;
  processedAt?: Date | null;
  dadosExtraidosExtracao?: Record<string, unknown> | null;
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);

    let updatePayload: { [key: string]: unknown } = { status_extracao: input.statusExtracao };

    if (input.erroExtracao !== undefined) {
      updatePayload["erro_extracao"] = input.erroExtracao;
    }

    if (input.processedAt !== undefined && input.processedAt !== null) {
      updatePayload["processed_at"] = input.processedAt;
    }

    if (input.dadosExtraidosExtracao !== undefined) {
      updatePayload["dados_extraidos_contrato"] = input.dadosExtraidosExtracao;
    }

    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      { ...updatePayload },
    );

    return await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
  });
}

/**
 * Atualiza o status da extração específica do módulo do documento.
 *
 * Usa `status_contrato` por compatibilidade com a coluna legada, mas o status
 * representa a etapa de extração pós-OCR do módulo atual (contratos ou relatórios).
 */
export async function updateDocumentoExtracaoModuloStatus(input: {
  escritorioId: string;
  documentoId: string;
  status: "em_fila" | "processando" | "concluido" | "erro";
  // Quando true, só aplica se o `status_contrato` atual NÃO for terminal
  // (concluido/erro). Usado pelo reconcile para não sobrescrever o `concluido`
  // que o agente já gravou enquanto a SM ainda está RUNNING.
  preservarTerminal?: boolean;
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    await repo.update(
      {
        id: input.documentoId,
        escritorio_id: input.escritorioId,
        ...(input.preservarTerminal ? { status_contrato: Not(In(STATUS_TERMINAIS)) } : {}),
      },
      { status_contrato: input.status },
    );

    return await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
  });
}

/**
 * Marca o documento como `erro` quando o run do agente termina falho.
 *
 * Rede de segurança do callback terminal do AgentCore: falha explícita,
 * exceção ou `complete=false` não podem deixar o documento em `processando`
 * nem reconciliá-lo como `concluido` sem dados persistidos.
 *
 * Module-aware e idempotente: NÃO sobrescreve uma inserção bem-sucedida do
 * agente — contratos usam `status_contrato` como sinal de conclusão do módulo
 * (o `status_extracao` já é `concluido` desde o OCR), relatórios usam
 * `status_extracao` (createRelatorioManual grava `concluido` ao vincular).
 */
export async function marcarDocumentoFalhaAgente(input: {
  escritorioId: string;
  documentoId: string;
  motivo?: string | null;
}): Promise<void> {
  const documento = await getDocumentoById(input.escritorioId, input.documentoId);
  if (!documento) return;

  const ehContrato = documento.modulo === "contratos";
  const sucessoTerminal = ehContrato
    ? documento.status_contrato === "concluido"
    : documento.status_extracao === "concluido";
  const jaErro = ehContrato ? documento.status_contrato === "erro" : documento.status_extracao === "erro";
  if (sucessoTerminal || jaErro) return;

  const motivo = input.motivo ?? "Falha na extração pelo agente.";
  await updateDocumentoExtracaoStatus({
    escritorioId: input.escritorioId,
    documentoId: input.documentoId,
    statusExtracao: "erro",
    erroExtracao: motivo,
    processedAt: new Date(),
  });
  if (ehContrato) {
    await updateDocumentoExtracaoModuloStatus({
      escritorioId: input.escritorioId,
      documentoId: input.documentoId,
      status: "erro",
    });
  }
}

/**
 * Salva o output de contratos extraído e marca a etapa de contrato como concluída.
 */
export async function updateDocumentoContratosOutput(input: {
  escritorioId: string;
  documentoId: string;
  output: Record<string, unknown>;
  processedAt?: Date | null;
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);

    const updatePayload: Record<string, unknown> = {
      dados_extraidos_contrato: input.output,
      status_contrato: "concluido",
    };

    if (input.processedAt) {
      updatePayload.contrato_processado_em = input.processedAt;
    }

    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      updatePayload,
    );

    return await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
  });
}

/**
 * Atualiza campos técnicos da extração do módulo, traduzindo para colunas legadas.
 */
export async function updateDocumentoExtracaoModuloFields(input: {
  escritorioId: string;
  documentoId: string;
  fields: {
    extractionExecutionArn?: string;
    status?: "em_fila" | "processando" | "concluido" | "erro";
  };
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const updatePayload: Record<string, unknown> = {};
    if (input.fields.extractionExecutionArn !== undefined) {
      updatePayload.contratos_execution_arn = input.fields.extractionExecutionArn;
    }
    if (input.fields.status !== undefined) {
      updatePayload.status_contrato = input.fields.status;
    }
    await manager.getRepository(Documento).update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      updatePayload,
    );
  });
}

/**
 * Marca ou desmarca o documento como ilegível para bloquear fluxos de confirmação.
 */
export async function setDocumentoIlegivel(input: {
  escritorioId: string;
  documentoId: string;
  ilegivel: boolean;
}): Promise<boolean> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const result = await manager.getRepository(Documento).update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      { documento_ilegivel: input.ilegivel },
    );
    return (result.affected ?? 0) > 0;
  });
}

/**
 * Vincula o documento a um cliente depois de uma identificação ou correção manual.
 */
export async function updateDocumentoClienteId(input: {
  escritorioId: string;
  documentoId: string;
  clienteId: string;
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    await manager.getRepository(Documento).update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      { cliente_id: input.clienteId },
    );
  });
}

/**
 * Reaplica o estado de reprocessamento por módulo sem reiniciar o OCR já existente.
 */
export async function updateDocumentoReprocessamento(input: {
  escritorioId: string;
  documentoId: string;
  modulo: string | null | undefined;
  executionArn: string;
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const updatePayload: Record<string, unknown> = {
      erro_extracao: null,
    };
    if (input.modulo === "contratos") {
      updatePayload.contratos_execution_arn = input.executionArn;
      updatePayload.status_contrato = "processando";
      updatePayload.erro_contrato = null;
      updatePayload.contrato_processado_em = null;
    } else if (input.modulo === "relatorios_periodicos") {
      updatePayload.contratos_execution_arn = input.executionArn;
      updatePayload.status_extracao = "concluido";
      updatePayload.erro_extracao = null;
      updatePayload.dados_extraidos_contrato = null;
      updatePayload.payload_normalizado_ui = null;
    }
    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      updatePayload,
    );
  });
}

/**
 * Atualiza o payload normalizado exibido na revisão da interface.
 */
export async function updateDocumentoPayloadNormalizadoUi(input: {
  escritorioId: string;
  documentoId: string;
  payloadNormalizadoUi: Record<string, unknown>;
}): Promise<void> {
  await ensureDatabase();
  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const updatePayload: Record<string, unknown> = {
      payload_normalizado_ui: input.payloadNormalizadoUi,
    };
    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      updatePayload,
    );
  });
}

/**
 * Salva o payload bruto de ingestão e sincroniza status derivados conforme o módulo.
 */
export async function updateDocumentoRawIngestionPayload(input: {
  escritorioId: string;
  documentoId: string;
  rawPayload: Record<string, unknown>;
  payloadNormalizadoUi?: Record<string, unknown> | null;
}): Promise<Documento | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const documento = await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });

    if (!documento) return null;

    const updatePayload: Record<string, unknown> = {
      dados_extraidos_contrato: input.rawPayload,
      erro_extracao: null,
    };

    const shouldUpdateStatus = documento.status_extracao !== "concluido";
    if (shouldUpdateStatus) {
      updatePayload.status_extracao = "concluido";
      updatePayload.processed_at = new Date();
    }

    if (documento.modulo === "contratos") {
      updatePayload.status_contrato = "concluido";
      updatePayload.erro_contrato = null;
      updatePayload.contrato_processado_em = new Date();

      const tipoDocumentoContratual = extrairTipoDocumentoContratual(input.rawPayload);
      if (tipoDocumentoContratual) {
        updatePayload.tipo_documento_contratual = tipoDocumentoContratual;
      }
      updatePayload.alteracao_proposta_contrato = montarAlteracaoPropostaContrato({
        documentoId: input.documentoId,
        rawPayload: input.rawPayload,
        payloadNormalizadoUi: input.payloadNormalizadoUi,
        tipoDocumentoContratual,
      });
    }

    if (input.payloadNormalizadoUi !== undefined) {
      updatePayload.payload_normalizado_ui = input.payloadNormalizadoUi;
    }

    await repo.update(
      { id: input.documentoId, escritorio_id: input.escritorioId },
      updatePayload,
    );

    return await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
  });
}
