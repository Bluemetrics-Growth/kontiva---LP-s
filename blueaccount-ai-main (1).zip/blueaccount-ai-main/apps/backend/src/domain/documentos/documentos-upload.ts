/**
 * Submódulo de criação de documentos: cria registros, aplica limites de trial,
 * grava conteúdo no storage e mantém status de upload coerente.
 */
import { runQueryWithRls } from "../../database/data-source.js";
import { Documento, type DocumentoModulo, type DocumentoStatusExtracao, type DocumentoStatusUpload } from "../../database/index.js";
import { convertAndCount } from "../../infrastructure/doc-convert-client.js";
import { buildDocumentStorageKey, createDocumentStorage } from "../../infrastructure/document-storage.js";
import { isOfficeFile, isSpreadsheetFile } from "../../infrastructure/file-converter.js";
import { settings } from "../../settings.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import {
  assertTrialDocumentoQuota,
  assertTrialPaginaLimite,
  getTrialConfig,
} from "../escritorios/trial-limits.js";
import { validateDocumentoFilename } from "./documentos-shared.js";

/**
 * Cria um documento a partir de arquivo enviado, grava o conteúdo no storage e persiste metadados.
 */
export async function uploadDocumento(input: {
  escritorioId: string;
  clienteId?: string | null;
  usuarioId: string | null;
  modulo: DocumentoModulo;
  filename: string;
  content: Buffer;
  contentType?: string | null;
  checksum?: string | null;
  sizeBytes?: number | null;
  competencia?: string | null;
}): Promise<Documento> {
  validateDocumentoFilename(input.filename);

  // Trial: teto de documentos (barato, antes de converter — rejeita cedo).
  const trial = await getTrialConfig(input.escritorioId);
  if (trial) {
    await assertTrialDocumentoQuota(input.escritorioId, trial);
  }

  const ehPlanilhaBulkRelatorios = input.modulo === "relatorios_periodicos" && isSpreadsheetFile(input.filename);

  let pageCount: number | null = null;
  if (ehPlanilhaBulkRelatorios) {
    // Bulk Excel/CSV de relatórios: a State Machine desvia p/ a Lambda
    // `planilha` (Polars) e nunca faz OCR — sem conversão, sem contagem de
    // página (não se aplica a um arquivo tabular, e o teto próprio é o cap de
    // 5000 linhas dentro da própria Lambda, não o limite de página do trial).
  } else if (isOfficeFile(input.filename)) {
    // Conversão Office→PDF em ambiente isolado (Lambda doc-convert); fallback
    // in-process quando DOC_CONVERT_FUNCTION_NAME não está configurado.
    const converted = await convertAndCount({ content: input.content, filename: input.filename });
    pageCount = converted.pageCount;
    input = {
      ...input,
      content: converted.content,
      filename: converted.filename,
      contentType: converted.contentType,
      sizeBytes: converted.content.length,
    };
  } else if (trial) {
    // PDF nativo em trial: conta páginas na Lambda isolada (não converte).
    const counted = await convertAndCount({ content: input.content, filename: input.filename });
    pageCount = counted.pageCount;
  }

  // Trial: teto de páginas por documento.
  if (trial && pageCount != null) {
    assertTrialPaginaLimite(trial, pageCount);
  }

  const storageKey = buildDocumentStorageKey({
    escritorioId: input.escritorioId,
    clienteId: input.clienteId ?? null,
    modulo: input.modulo,
    filename: input.filename,
    competencia: input.competencia,
  });

  await ensureDatabase();
  const created = await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const documento = repo.create({
      escritorio_id: input.escritorioId,
      cliente_id: input.clienteId?.trim() ? input.clienteId.trim() : null,
      uploaded_by_usuario_id: input.usuarioId,
      modulo: input.modulo,
      filename_original: input.filename,
      storage_provider: process.env.DOCUMENT_STORAGE_PROVIDER === "local" ? "local" : "s3",
      storage_bucket: settings.DOCUMENT_UPLOAD_FILE_SYSTEM_PATH,
      storage_key: storageKey,
      competencia: input.competencia ?? null,
      mime_type: input.contentType ?? null,
      size_bytes: input.sizeBytes != null ? String(input.sizeBytes) : null,
      checksum: input.checksum ?? null,
      status_upload: "pendente" as DocumentoStatusUpload,
      erro_upload: null,
      status_extracao: "pendente" as DocumentoStatusExtracao,
      erro_extracao: null,
      processed_at: null,
      ingestion_execution_arn: null,
    });
    return await repo.save(documento);
  });

  await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    await repo.update({ id: created.id, escritorio_id: input.escritorioId }, { status_upload: "uploadando", erro_upload: null });
    return null;
  });

  try {
    const documentStorage = createDocumentStorage();
    await documentStorage.put({
      key: storageKey,
      content: input.content,
      contentType: input.contentType ?? undefined,
      metadata: {
        escritorio_id: input.escritorioId,
        modulo: input.modulo,
        ...(input.clienteId?.trim() ? { cliente_id: input.clienteId.trim() } : {}),
      },
    });

    await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
      const repo = manager.getRepository(Documento);
      await repo.update(
        { id: created.id, escritorio_id: input.escritorioId },
        { status_upload: "sucesso", erro_upload: null },
      );
      return null;
    });
  } catch (uploadErr) {
    const message = uploadErr instanceof Error ? uploadErr.message : String(uploadErr);
    await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
      const repo = manager.getRepository(Documento);
      await repo.update(
        { id: created.id, escritorio_id: input.escritorioId },
        { status_upload: "erro", erro_upload: message, status_extracao: "erro", erro_extracao: "Upload falhou, extração cancelada" },
      );
      return null;
    });
    throw uploadErr;
  }

  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    return await repo.findOneOrFail({ where: { id: created.id, escritorio_id: input.escritorioId } });
  });
}

/**
 * Cria um documento a partir de texto enviado por IA, sem disparar OCR, SQS ou State Machine.
 */
export async function criarDocumentoTextoIA(input: {
  escritorioId: string;
  clienteId?: string | null;
  usuarioId: string | null;
  contractText: string;
  filename?: string | null;
  ingestion: Record<string, unknown>;
  modulo?: DocumentoModulo;
}): Promise<Documento> {
  const modulo: DocumentoModulo = input.modulo ?? "contratos";
  const defaultName = modulo === "relatorios_periodicos" ? "relatorio-ai" : "contrato-ai";
  const rawName = (input.filename?.trim() || defaultName).replace(/[^a-zA-Z0-9._-]+/g, "_");
  const filename = rawName.toLowerCase().endsWith(".txt") ? rawName : `${rawName}.txt`;
  const content = Buffer.from(input.contractText, "utf-8");

  const storageKey = buildDocumentStorageKey({
    escritorioId: input.escritorioId,
    clienteId: input.clienteId ?? null,
    modulo,
    filename,
  });

  // s3_input_key faz parte da rastreabilidade da ingestão; conhecido antes do save.
  const ingestion = { ...input.ingestion, s3_input_key: storageKey };

  await ensureDatabase();
  const created = await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const documento = repo.create({
      escritorio_id: input.escritorioId,
      cliente_id: input.clienteId?.trim() ? input.clienteId.trim() : null,
      uploaded_by_usuario_id: input.usuarioId,
      modulo,
      filename_original: filename,
      storage_provider: process.env.DOCUMENT_STORAGE_PROVIDER === "local" ? "local" : "s3",
      storage_bucket: settings.DOCUMENT_UPLOAD_FILE_SYSTEM_PATH,
      storage_key: storageKey,
      mime_type: "text/plain",
      size_bytes: String(content.length),
      status_upload: "uploadando" as DocumentoStatusUpload,
      erro_upload: null,
      // Aguardando a tool extract_document; sem fila/SM, então não usa "em_fila".
      status_extracao: "pendente" as DocumentoStatusExtracao,
      erro_extracao: null,
      ingestion_execution_arn: null,
      metadados_ia_contrato: { ingestion },
    });
    return await repo.save(documento);
  });

  try {
    const documentStorage = createDocumentStorage();
    await documentStorage.put({
      key: storageKey,
      content,
      contentType: "text/plain",
      metadata: {
        escritorio_id: input.escritorioId,
        modulo,
        source_type: "ai_submitted_text",
        ...(input.clienteId?.trim() ? { cliente_id: input.clienteId.trim() } : {}),
      },
    });
    await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
      const repo = manager.getRepository(Documento);
      await repo.update(
        { id: created.id, escritorio_id: input.escritorioId },
        { status_upload: "sucesso", erro_upload: null },
      );
      return null;
    });
  } catch (uploadErr) {
    const message = uploadErr instanceof Error ? uploadErr.message : String(uploadErr);
    await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
      const repo = manager.getRepository(Documento);
      await repo.update(
        { id: created.id, escritorio_id: input.escritorioId },
        { status_upload: "erro", erro_upload: message, status_extracao: "erro", erro_extracao: "Upload do texto falhou" },
      );
      return null;
    });
    throw uploadErr;
  }

  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    return await repo.findOneOrFail({ where: { id: created.id, escritorio_id: input.escritorioId } });
  });
}
