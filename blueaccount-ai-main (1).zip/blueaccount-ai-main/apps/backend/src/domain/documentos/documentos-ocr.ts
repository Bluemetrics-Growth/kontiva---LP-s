/**
 * Submódulo de artefatos OCR: resolve chaves S3/local e lê os markdowns usados
 * pela revisão, mantendo compatibilidade com documentos legados e texto via IA.
 */
import { runQueryWithRls } from "../../database/data-source.js";
import { Documento } from "../../database/index.js";
import { createDocumentStorage, readS3Object } from "../../infrastructure/document-storage.js";
import { settings } from "../../settings.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";

const documentStorage = createDocumentStorage();

/**
 * Busca o ARN da execução OCR associada ao documento para polling e callbacks.
 */
export async function getDocumentoOcrStateMachineExecutionArn(input: {
  escritorioId: string;
  documentoId: string;
}): Promise<string | null> {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: input.escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const doc = await repo.findOneBy({
      id: input.documentoId,
      escritorio_id: input.escritorioId,
    });
    return doc?.ingestion_execution_arn ?? null;
  });
}

/**
 * Identifica documentos criados pelo canal de texto por IA, que não geram OCR.
 */
export function isAiSubmittedTextDocumento(documento: Documento): boolean {
  const ingestion = (documento.metadados_ia_contrato as Record<string, unknown> | null | undefined)
    ?.ingestion as Record<string, unknown> | undefined;
  if (ingestion?.source_type === "ai_submitted_text") return true;
  return Boolean(documento.mime_type?.startsWith("text/"));
}

/**
 * Lê o texto bruto salvo em `storage_key` quando o documento veio do canal MCP.
 */
async function readAiSubmittedText(documento: Documento): Promise<string | null> {
  if (!isAiSubmittedTextDocumento(documento) || !documento.storage_key) return null;
  const buffer = await documentStorage.get(documento.storage_key).catch(() => null);
  return buffer ? buffer.toString("utf-8") : null;
}

/**
 * Retorna o markdown OCR anotado, caindo para texto submetido por IA quando não há OCR.
 */
export async function getDocumentoOcrMarkdown(escritorioId: string, documentoId: string) {
  await ensureDatabase();
  const documento = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const doc = await repo.findOneBy({
      id: documentoId,
      escritorio_id: escritorioId,
    });
    return doc ?? null;
  });

  if (!documento) {
    return null;
  }

  const artifactKey = documento.annotated_markdown_key?.trim();
  if (!artifactKey && !documento.s3_textract_path) {
    return await readAiSubmittedText(documento);
  }

  const { bucket, key } = artifactKey
    ? resolveArtifactKeyLocation(artifactKey)
    : resolveAnnotatedMarkdownLocation(documento.s3_textract_path!);
  const markdown = await readS3Object(bucket, key).catch(() => null);
  return markdown ? markdown.toString("utf-8") : null;
}

/**
 * Retorna o markdown OCR limpo, usando chaves novas ou o prefixo legado salvo no documento.
 */
export async function getDocumentoCleanMarkdown(escritorioId: string, documentoId: string) {
  await ensureDatabase();
  const documento = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    const doc = await repo.findOneBy({
      id: documentoId,
      escritorio_id: escritorioId,
    });
    return doc ?? null;
  });

  if (!documento) {
    return null;
  }

  const artifactKey = documento.clean_markdown_key?.trim();
  const legacyPrefix = documento.s3_textract_path;
  if (!artifactKey && !legacyPrefix) {
    return await readAiSubmittedText(documento);
  }

  const { bucket, key } = artifactKey
    ? resolveArtifactKeyLocation(artifactKey)
    : resolveCleanMarkdownLocation(legacyPrefix!);
  const markdown = await readS3Object(bucket, key).catch(() => null);
  return markdown ? markdown.toString("utf-8") : null;
}

/**
 * Resolve uma chave de artefato explícita, aceitando `s3://bucket/key` ou chave relativa.
 */
function resolveArtifactKeyLocation(artifactKey: string): { bucket: string; key: string } {
  const trimmed = artifactKey.trim();
  if (trimmed.startsWith("s3://")) {
    const withoutScheme = trimmed.slice(5);
    const slashIndex = withoutScheme.indexOf("/");
    if (slashIndex === -1) {
      return { bucket: withoutScheme, key: "" };
    }
    return {
      bucket: withoutScheme.slice(0, slashIndex),
      key: withoutScheme.slice(slashIndex + 1),
    };
  }

  return {
    bucket: settings.TEXTRACT_OUTPUT_BUCKET,
    key: trimmed,
  };
}

/**
 * Converte um path legado de OCR no bucket/chave do markdown anotado ou limpo.
 */
function resolveMarkdownLocation(s3Path: string, filename: "annotated.md" | "clean.md"): { bucket: string; key: string } {
  const trimmed = s3Path.trim();
  const markdownKey = `annotated_ocr_v3/${filename}`;
  if (trimmed.startsWith("s3://")) {
    const withoutScheme = trimmed.slice(5);
    const slashIndex = withoutScheme.indexOf("/");
    if (slashIndex === -1) {
      return {
        bucket: withoutScheme,
        key: markdownKey,
      };
    }

    const bucket = withoutScheme.slice(0, slashIndex);
    const key = withoutScheme.slice(slashIndex + 1);
    return {
      bucket,
      key: key.endsWith(".md") ? key.replace(/[^/]+\.md$/, filename) : `${key.replace(/\/+$/, "")}/${markdownKey}`,
    };
  }

  return {
    bucket: settings.TEXTRACT_OUTPUT_BUCKET,
    key: trimmed.endsWith(".md") ? trimmed.replace(/[^/]+\.md$/, filename) : `${trimmed.replace(/\/+$/, "")}/${markdownKey}`,
  };
}

/**
 * Resolve a localização do markdown anotado a partir do path legado de Textract.
 */
function resolveAnnotatedMarkdownLocation(s3Path: string): { bucket: string; key: string } {
  return resolveMarkdownLocation(s3Path, "annotated.md");
}

/**
 * Resolve a localização do markdown limpo a partir do path legado de Textract.
 */
function resolveCleanMarkdownLocation(s3Path: string): { bucket: string; key: string } {
  return resolveMarkdownLocation(s3Path, "clean.md");
}
