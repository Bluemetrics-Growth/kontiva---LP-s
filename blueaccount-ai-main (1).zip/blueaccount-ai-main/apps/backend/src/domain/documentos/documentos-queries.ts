/**
 * Submódulo de leitura de documentos: concentra consultas RLS para listagens,
 * detalhes e status resumido sem misturar mutations ou criação de arquivos.
 */
import { Brackets } from "typeorm";
import { runQueryWithRls } from "../../database/data-source.js";
import { Contrato, Documento, Relatorio } from "../../database/index.js";
import { Faturamento } from "../../database/modules/tenant/entities/faturamento.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginationInput,
} from "../pagination.js";
import { isAiSubmittedTextDocumento } from "./documentos-ocr.js";

/**
 * Lista todos os documentos do escritório com flags de contrato, relatório e faturamento.
 */
export async function listAllDocumentos(escritorioId: string) {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const docRepo = manager.getRepository(Documento);
    const docs = await docRepo.find({
      where: { escritorio_id: escritorioId },
      relations: ["cliente"],
      order: { created_at: "DESC" },
    });

    if (docs.length === 0) {
      return docs as (Documento & {
        tem_contrato: boolean;
        contrato_aprovado: boolean;
        tem_relatorio: boolean;
        tem_faturamento: boolean;
        contrato_id: string | null;
        relatorio_id: string | null;
        relatorio_status: "ativo" | "em_revisao" | null;
        relatorios_count: number;
      })[];
    }

    const contratoRepo = manager.getRepository(Contrato);
    const relRepo = manager.getRepository(Relatorio);
    const faturamentoRepo = manager.getRepository(Faturamento);
    const origens = docs.map((d) => d.id);
    // Ordenamos ativo/mais recente primeiro para que o primeiro registro visto por arquivo_origem
    // seja o que devemos linkar (um documento reprocessado pode ter registros antigos inativos).
    const contratos = await contratoRepo
      .createQueryBuilder("c")
      .select(["c.id", "c.arquivo_origem", "c.contrato_ativo", "c.created_at"])
      .where("c.escritorio_id = :eid", { eid: escritorioId })
      .andWhere("c.arquivo_origem IN (:...ids)", { ids: origens })
      .orderBy("c.contrato_ativo", "DESC")
      .addOrderBy("c.created_at", "DESC")
      .getMany();
    const relatorios = await relRepo
      .createQueryBuilder("r")
      .select(["r.id", "r.arquivo_origem", "r.relatorio_ativo", "r.created_at"])
      .where("r.escritorio_id = :eid", { eid: escritorioId })
      .andWhere("r.arquivo_origem IN (:...ids)", { ids: origens })
      .orderBy("r.relatorio_ativo", "DESC")
      .addOrderBy("r.created_at", "DESC")
      .getMany();
    const faturamentos = await faturamentoRepo
      .createQueryBuilder("f")
      .select("f.arquivo_origem")
      .where("f.escritorio_id = :eid", { eid: escritorioId })
      .andWhere("f.arquivo_origem IN (:...ids)", { ids: origens })
      .getMany();

    // Primeira ocorrência por arquivo_origem = registro ativo (ou mais recente), pela ordenação acima.
    const contratoIdPorOrigem = new Map<string, string>();
    for (const c of contratos) {
      if (c.arquivo_origem && !contratoIdPorOrigem.has(c.arquivo_origem)) {
        contratoIdPorOrigem.set(c.arquivo_origem, c.id);
      }
    }
    const relatorioPorOrigem = new Map<string, { id: string; status: "ativo" | "em_revisao" }>();
    const relatoriosCountPorOrigem = new Map<string, number>();
    for (const r of relatorios) {
      if (r.arquivo_origem) {
        relatoriosCountPorOrigem.set(r.arquivo_origem, (relatoriosCountPorOrigem.get(r.arquivo_origem) ?? 0) + 1);
      }
      if (r.arquivo_origem && !relatorioPorOrigem.has(r.arquivo_origem)) {
        relatorioPorOrigem.set(r.arquivo_origem, {
          id: r.id,
          status: r.relatorio_ativo ? "ativo" : "em_revisao",
        });
      }
    }
    const faturamentosConfirmados = new Set(faturamentos.map((f) => f.arquivo_origem));
    return docs.map((d) => Object.assign(d, {
      tem_contrato: contratoIdPorOrigem.has(d.id),
      contrato_aprovado: contratoIdPorOrigem.has(d.id),
      tem_relatorio: relatorioPorOrigem.has(d.id),
      tem_faturamento: faturamentosConfirmados.has(d.id),
      contrato_id: contratoIdPorOrigem.get(d.id) ?? null,
      relatorio_id: relatorioPorOrigem.get(d.id)?.id ?? null,
      relatorio_status: relatorioPorOrigem.get(d.id)?.status ?? null,
      relatorios_count: relatoriosCountPorOrigem.get(d.id) ?? 0,
      cadastro_ia: isAiSubmittedTextDocumento(d),
    })) as (Documento & {
      tem_contrato: boolean;
      contrato_aprovado: boolean;
      tem_relatorio: boolean;
      tem_faturamento: boolean;
      contrato_id: string | null;
      relatorio_id: string | null;
      relatorio_status: "ativo" | "em_revisao" | null;
      relatorios_count: number;
      cadastro_ia: boolean;
    })[];
  });
}

// ── Derivação de status/tipo em SQL ───────────────────────────────────────────
// Estas expressões espelham `deriveStatus()`/`deriveType()` de
// `apps/frontend/src/pages/DocumentosPage.tsx`. A tela filtra e conta por grupo no
// servidor (a listagem é paginada e o cliente só vê a página atual), mas continua
// derivando o badge de cada linha localmente para poder reagir ao polling de status.
// Ao mexer em uma das duas pontas, ajustar a outra junto.
// Um aditivo confirmado pertence à nova versão por `contrato_documentos_anexos`; o
// `arquivo_origem` da versão continua sendo o contrato-base para preservar a fonte
// original. Portanto, os dois vínculos significam que o documento já foi aprovado.
const SQL_TEM_CONTRATO = `(EXISTS(SELECT 1 FROM contratos c WHERE c.arquivo_origem = documento.id::text)
  OR EXISTS(
    SELECT 1
    FROM contrato_documentos_anexos anexo
    INNER JOIN contratos c ON c.id = anexo.contrato_id
    WHERE anexo.documento_id = documento.id
      AND anexo.escritorio_id = documento.escritorio_id
      AND c.escritorio_id = documento.escritorio_id
  ))`;
const SQL_TEM_FATURAMENTO = `EXISTS(SELECT 1 FROM faturamento f WHERE f.arquivo_origem = documento.id::text)`;
const SQL_CONTRATO_ID = `(SELECT contrato_vinculado.id
  FROM (
    SELECT c.id, c.contrato_ativo, c.created_at
    FROM contratos c
    WHERE c.arquivo_origem = documento.id::text
      AND c.escritorio_id = documento.escritorio_id
    UNION ALL
    SELECT c.id, c.contrato_ativo, c.created_at
    FROM contrato_documentos_anexos anexo
    INNER JOIN contratos c ON c.id = anexo.contrato_id
    WHERE anexo.documento_id = documento.id
      AND anexo.escritorio_id = documento.escritorio_id
      AND c.escritorio_id = documento.escritorio_id
  ) contrato_vinculado
  ORDER BY contrato_vinculado.contrato_ativo DESC, contrato_vinculado.created_at DESC
  LIMIT 1)`;
const SQL_RELATORIO_ID = `(SELECT r.id FROM relatorios r WHERE r.arquivo_origem = documento.id::text ORDER BY r.relatorio_ativo DESC, r.created_at DESC LIMIT 1)`;
const SQL_RELATORIO_STATUS = `(SELECT CASE WHEN r.relatorio_ativo THEN 'ativo' ELSE 'em_revisao' END FROM relatorios r WHERE r.arquivo_origem = documento.id::text ORDER BY r.relatorio_ativo DESC, r.created_at DESC LIMIT 1)`;
const SQL_RELATORIOS_COUNT = `(SELECT COUNT(*) FROM relatorios r WHERE r.arquivo_origem = documento.id::text)`;
// `hasRawExtractionPayload` no frontend exige objeto com chaves; `{}` não conta.
const SQL_TEM_PAYLOAD_BRUTO = `(documento.dados_extraidos_contrato IS NOT NULL AND documento.dados_extraidos_contrato <> '{}'::jsonb)`;

/**
 * Grupos de status usados pelos filtros/contadores da tela de documentos.
 * Os valores são contrato HTTP (query `grupo_status`) e batem com os ids da UI.
 */
export const GRUPOS_STATUS_DOCUMENTO = ["in_progress", "review", "processed", "problem"] as const;
export type GrupoStatusDocumento = (typeof GRUPOS_STATUS_DOCUMENTO)[number];

export const TIPOS_DOCUMENTO_LISTAGEM = ["contract", "billing", "simulation"] as const;
export type TipoDocumentoListagem = (typeof TIPOS_DOCUMENTO_LISTAGEM)[number];

// Ordem dos WHEN espelha a cascata de `deriveStatus()`; alterar a ordem muda o resultado.
const SQL_GRUPO_STATUS = `CASE
  WHEN documento.documento_ilegivel
    OR documento.status_upload = 'erro'
    OR documento.status_extracao = 'erro'
    OR documento.status_contrato = 'erro' THEN 'problem'
  WHEN documento.modulo = 'relatorios_periodicos' AND ${SQL_RELATORIO_ID} IS NOT NULL
    THEN CASE WHEN ${SQL_RELATORIO_STATUS} = 'em_revisao' THEN 'review' ELSE 'processed' END
  WHEN documento.status_extracao IN ('em_fila', 'processando') THEN 'in_progress'
  WHEN documento.status_contrato IN ('em_fila', 'processando') THEN 'in_progress'
  WHEN documento.modulo <> 'relatorios_periodicos'
    AND (${SQL_TEM_CONTRATO} OR ${SQL_TEM_FATURAMENTO}) THEN 'processed'
  WHEN ${SQL_TEM_PAYLOAD_BRUTO} THEN 'review'
  WHEN documento.status_extracao = 'concluido' THEN CASE
    WHEN documento.modulo = 'contratos'
      THEN CASE WHEN documento.status_contrato = 'concluido' THEN 'review' ELSE 'in_progress' END
    WHEN documento.modulo = 'relatorios_periodicos' THEN 'in_progress'
    ELSE 'processed'
  END
  ELSE 'in_progress'
END`;

const SQL_TIPO = `CASE
  WHEN documento.modulo = 'simulation_data' THEN 'simulation'
  WHEN documento.modulo IN ('relatorios_periodicos', 'cobrancas') THEN 'billing'
  ELSE 'contract'
END`;

export type ListagemDocumentosInput = PaginationInput & {
  query?: string;
  grupoStatus?: GrupoStatusDocumento;
  tipo?: TipoDocumentoListagem;
};

export type ResumoListagemDocumentos = {
  total: number;
  in_progress: number;
  review: number;
  processed: number;
  problem: number;
  ultimo_upload: string | null;
};

/**
 * Base compartilhada entre a página de resultados e o resumo/contadores: aplica
 * escritório, busca textual e filtro de tipo. O filtro de grupo de status fica
 * fora de propósito, para os contadores das abas não zerarem ao clicar em uma delas.
 */
function criarBaseListagemDocumentos(
  manager: Parameters<Parameters<typeof runQueryWithRls>[1]>[0],
  escritorioId: string,
  input: ListagemDocumentosInput,
) {
  const qb = manager
    .getRepository(Documento)
    .createQueryBuilder("documento")
    .leftJoin("documento.cliente", "cliente")
    .where("documento.escritorio_id = :escritorioId", { escritorioId });

  const termo = input.query?.trim();
  if (termo) {
    qb.andWhere(
      new Brackets((sub) => {
        sub
          .where("documento.filename_original ILIKE :query", { query: `%${termo}%` })
          .orWhere("cliente.razao_social ILIKE :query", { query: `%${termo}%` })
          .orWhere("documento.competencia ILIKE :query", { query: `%${termo}%` })
          // A tela mostra um id curto derivado do caminho de OCR (ou do próprio id).
          .orWhere("documento.s3_textract_path ILIKE :query", { query: `%${termo}%` })
          .orWhere("documento.id::text ILIKE :query", { query: `%${termo}%` });
      }),
    );
  }

  if (input.tipo) {
    qb.andWhere(`${SQL_TIPO} = :tipo`, { tipo: input.tipo });
  }

  return qb;
}

/**
 * Lista documentos paginados para telas operacionais, com busca textual, filtros de
 * grupo de status/tipo e resumo com os contadores usados nos cards e abas da tela.
 */
export async function listAllDocumentosPaginated(
  escritorioId: string,
  input: ListagemDocumentosInput = {},
) {
  await ensureDatabase();
  const { page, pageSize, skip } = normalizePagination(input);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = criarBaseListagemDocumentos(manager, escritorioId, input)
      .select("documento.id", "id")
      .addSelect("documento.filename_original", "filename_original")
      .addSelect("documento.storage_key", "storage_key")
      .addSelect("documento.s3_textract_path", "s3_textract_path")
      .addSelect("documento.modulo", "modulo")
      .addSelect("documento.simulacao_id", "simulacao_id")
      .addSelect("documento.size_bytes", "size_bytes")
      .addSelect("documento.status_upload", "status_upload")
      .addSelect("documento.status_extracao", "status_extracao")
      .addSelect("documento.status_contrato", "status_contrato")
      .addSelect("documento.erro_extracao", "erro_extracao")
      .addSelect("documento.erro_contrato", "erro_contrato")
      .addSelect("documento.competencia", "competencia")
      .addSelect("documento.created_at", "created_at")
      .addSelect("documento.documento_ilegivel", "documento_ilegivel")
      .addSelect(SQL_TEM_PAYLOAD_BRUTO, "tem_dados_extraidos")
      .addSelect("(documento.metadados_ia_contrato->'ingestion'->>'source_type' = 'ai_submitted_text')", "cadastro_ia")
      .addSelect("cliente.id", "cliente_id")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .addSelect(SQL_CONTRATO_ID, "contrato_id")
      .addSelect(SQL_TEM_CONTRATO, "contrato_aprovado")
      .addSelect(SQL_RELATORIO_ID, "relatorio_id")
      .addSelect(SQL_RELATORIO_STATUS, "relatorio_status")
      .addSelect(SQL_RELATORIOS_COUNT, "relatorios_count")
      .addSelect(SQL_TEM_FATURAMENTO, "tem_faturamento")
      .addSelect(SQL_GRUPO_STATUS, "grupo_status");

    if (input.grupoStatus) {
      qb.andWhere(`${SQL_GRUPO_STATUS} = :grupoStatus`, { grupoStatus: input.grupoStatus });
    }

    const total = await qb.clone().getCount();
    const rows = await qb.orderBy("documento.created_at", "DESC").offset(skip).limit(pageSize)
      .getRawMany<Record<string, unknown>>();
    const resumo = await carregarResumoListagemDocumentos(manager, escritorioId, input);

    const pagina = buildPaginatedResult(rows.map((row) => {
      const contratoId = row.contrato_id == null ? null : String(row.contrato_id);
      const relatorioId = row.relatorio_id == null ? null : String(row.relatorio_id);
      const relatorioStatus = row.relatorio_status === "ativo" || row.relatorio_status === "em_revisao"
        ? row.relatorio_status
        : null;
      return {
        id: String(row.id),
        filename_original: String(row.filename_original),
        storage_key: String(row.storage_key),
        s3_textract_path: row.s3_textract_path == null ? null : String(row.s3_textract_path),
        modulo: String(row.modulo),
        simulacao_id: row.simulacao_id == null ? null : String(row.simulacao_id),
        size_bytes: row.size_bytes == null ? null : String(row.size_bytes),
        status_upload: String(row.status_upload),
        status_extracao: String(row.status_extracao),
        status_contrato: row.status_contrato == null ? null : String(row.status_contrato),
        erro_extracao: row.erro_extracao == null ? null : String(row.erro_extracao),
        erro_contrato: row.erro_contrato == null ? null : String(row.erro_contrato),
        competencia: row.competencia == null ? null : String(row.competencia),
        created_at: row.created_at,
        documento_ilegivel: row.documento_ilegivel === true,
        cadastro_ia: row.cadastro_ia === true,
        dados_extraidos_contrato: row.tem_dados_extraidos === true ? { available: true } : null,
        cliente: row.cliente_id ? {
          id: String(row.cliente_id),
          razao_social: String(row.cliente_razao_social),
          cnpj: row.cliente_cnpj == null ? null : String(row.cliente_cnpj),
        } : null,
        tem_contrato: Boolean(contratoId),
        contrato_aprovado: row.contrato_aprovado === true || row.contrato_aprovado === "true",
        tem_relatorio: Boolean(relatorioId),
        tem_faturamento: row.tem_faturamento === true,
        contrato_id: contratoId,
        relatorio_id: relatorioId,
        relatorio_status: relatorioStatus,
        relatorios_count: Number(row.relatorios_count ?? 0),
        grupo_status: normalizarGrupoStatus(row.grupo_status),
      };
    }), total, page, pageSize);

    return { ...pagina, resumo };
  });
}

function normalizarGrupoStatus(valor: unknown): GrupoStatusDocumento | null {
  return GRUPOS_STATUS_DOCUMENTO.includes(valor as GrupoStatusDocumento)
    ? (valor as GrupoStatusDocumento)
    : null;
}

/**
 * Contadores por grupo de status + último upload, ignorando o filtro de grupo para
 * que as abas continuem mostrando o total de cada grupo depois de uma ser escolhida.
 */
async function carregarResumoListagemDocumentos(
  manager: Parameters<Parameters<typeof runQueryWithRls>[1]>[0],
  escritorioId: string,
  input: ListagemDocumentosInput,
): Promise<ResumoListagemDocumentos> {
  const rows = await criarBaseListagemDocumentos(manager, escritorioId, input)
    .select(SQL_GRUPO_STATUS, "grupo_status")
    .addSelect("COUNT(*)", "quantidade")
    .addSelect("MAX(documento.created_at)", "ultimo_upload")
    .groupBy("1")
    .getRawMany<Record<string, unknown>>();

  const resumo: ResumoListagemDocumentos = {
    total: 0,
    in_progress: 0,
    review: 0,
    processed: 0,
    problem: 0,
    ultimo_upload: null,
  };

  for (const row of rows) {
    const quantidade = Number(row.quantidade ?? 0);
    resumo.total += quantidade;
    const grupo = normalizarGrupoStatus(row.grupo_status);
    if (grupo) resumo[grupo] += quantidade;

    const ultimoUpload = row.ultimo_upload == null
      ? null
      : new Date(row.ultimo_upload as string | Date).toISOString();
    if (ultimoUpload && (!resumo.ultimo_upload || ultimoUpload > resumo.ultimo_upload)) {
      resumo.ultimo_upload = ultimoUpload;
    }
  }

  return resumo;
}

/**
 * Retorna status resumido de até 100 documentos para polling em lote.
 */
export async function getDocumentosStatusBatch(escritorioId: string, ids: string[]) {
  await ensureDatabase();
  const uniqueIds = [...new Set(ids.map((id) => id.trim()).filter(Boolean))].slice(0, 100);
  if (uniqueIds.length === 0) return [];
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const rows = await manager
      .getRepository(Documento)
      .createQueryBuilder("documento")
      .select("documento.id", "id")
      .addSelect("documento.status_upload", "status_upload")
      .addSelect("documento.status_extracao", "status_extracao")
      .addSelect("documento.status_contrato", "status_contrato")
      .addSelect("documento.erro_extracao", "erro_extracao")
      .addSelect("documento.erro_contrato", "erro_contrato")
      .addSelect("documento.processed_at", "processed_at")
      .addSelect("documento.contrato_processado_em", "contrato_processado_em")
      .addSelect("documento.documento_ilegivel", "documento_ilegivel")
      .addSelect("(documento.dados_extraidos_contrato IS NOT NULL)", "tem_dados_extraidos")
      .addSelect(SQL_TEM_CONTRATO, "contrato_aprovado")
      .addSelect(`(SELECT r.id FROM relatorios r WHERE r.arquivo_origem = documento.id::text ORDER BY r.relatorio_ativo DESC, r.created_at DESC LIMIT 1)`, "relatorio_id")
      .addSelect(`(SELECT CASE WHEN r.relatorio_ativo THEN 'ativo' ELSE 'em_revisao' END FROM relatorios r WHERE r.arquivo_origem = documento.id::text ORDER BY r.relatorio_ativo DESC, r.created_at DESC LIMIT 1)`, "relatorio_status")
      .addSelect(`(SELECT COUNT(*) FROM relatorios r WHERE r.arquivo_origem = documento.id::text)`, "relatorios_count")
      .addSelect("documento.updated_at", "updated_at")
      .where("documento.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("documento.id IN (:...ids)", { ids: uniqueIds })
      .getRawMany<Record<string, unknown>>();

    return rows.map((row) => {
      const relatorioId = row.relatorio_id == null ? null : String(row.relatorio_id);
      const relatorioStatus = row.relatorio_status === "ativo" || row.relatorio_status === "em_revisao"
        ? row.relatorio_status
        : null;

      return {
        id: String(row.id),
        status_upload: String(row.status_upload),
        status_extracao: String(row.status_extracao),
        status_contrato: row.status_contrato == null ? null : String(row.status_contrato),
        erro_extracao: row.erro_extracao == null ? null : String(row.erro_extracao),
        erro_contrato: row.erro_contrato == null ? null : String(row.erro_contrato),
        processed_at: row.processed_at,
        contrato_processado_em: row.contrato_processado_em,
        documento_ilegivel: row.documento_ilegivel === true,
        dados_extraidos_contrato: row.tem_dados_extraidos === true ? { available: true } : null,
        contrato_aprovado: row.contrato_aprovado === true || row.contrato_aprovado === "true",
        tem_relatorio: Boolean(relatorioId),
        relatorio_id: relatorioId,
        relatorio_status: relatorioStatus,
        relatorios_count: Number(row.relatorios_count ?? 0),
        updated_at: row.updated_at,
      };
    });
  });
}

/**
 * Lista documentos de um cliente específico em ordem de criação decrescente.
 */
export async function listDocumentos(escritorioId: string, clienteId: string) {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    return await repo.find({
      where: { escritorio_id: escritorioId, cliente_id: clienteId },
      order: { created_at: "DESC" },
    });
  });
}

/**
 * Busca um documento do escritório por ID, incluindo o relacionamento com cliente.
 */
export async function getDocumentoById(escritorioId: string, documentoId: string) {
  await ensureDatabase();
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Documento);
    return await repo.findOne({
      where: { id: documentoId, escritorio_id: escritorioId },
      relations: ["cliente"],
    });
  });
}

/** A aprovação humana deixa um contrato vinculado ao documento de origem. */
export async function temContratoAprovadoPorDocumento(escritorioId: string, documentoId: string): Promise<boolean> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.getRepository(Contrato).exists({
      where: { escritorio_id: escritorioId, arquivo_origem: documentoId },
    });
  });
}
