// Helpers puros de parsing/validação/normalização usados no fluxo de documentos
// (callbacks de OCR/extração, ingestão por texto de IA e telemetria de uso de LLM).
// Não dependem de Nest, AWS, banco ou config — só transformam/validam dados.

import {
  RegimeTributarioInvalidoError,
  normalizarRegimeTributario,
  validarRegimeComDocumento,
} from "../clientes/regime-tributario.js";

export interface AgentUsageLog {
  model_id: string | null;
  trace_id: string | null;
  input_tokens: number | null;
  output_tokens: number | null;
  total_tokens: number | null;
  latency_ms: number | null;
  cache_read_input_tokens: number | null;
  cache_write_input_tokens: number | null;
}

export function inputIsRelatoriosModulo(modulo: unknown): boolean {
  return modulo === "relatorios_periodicos";
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

export function unwrapIngestaoPayloadAgentResult(value: unknown): Record<string, unknown> | null {
  if (!isRecord(value)) return null;
  const result = value.result;
  if (!("_agent_usage" in value) || result === undefined) return value;
  if (typeof result === "string") {
    try {
      const parsed = JSON.parse(result) as unknown;
      return isRecord(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  return isRecord(result) ? result : null;
}

export function hasRawExtractionPayload(documento: { dados_extraidos_contrato?: unknown }): boolean {
  return isRecord(documento.dados_extraidos_contrato) && Object.keys(documento.dados_extraidos_contrato).length > 0;
}

export function nullableNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export function extractAgentUsageLog(output: Record<string, unknown>): AgentUsageLog | null {
  const usageSource = isRecord(output._usage)
    ? output._usage
    : isRecord(output.contratoCompleto) && isRecord(output.contratoCompleto._usage)
      ? output.contratoCompleto._usage
      : null;
  const agentUsage = usageSource?.agent;
  if (!isRecord(agentUsage)) return null;

  const modelId = typeof agentUsage.model_id === "string" && agentUsage.model_id.trim()
    ? agentUsage.model_id.trim()
    : typeof output.model_id === "string" && output.model_id.trim()
      ? output.model_id.trim()
      : null;
  const traceId = typeof output.traceId === "string" && output.traceId.trim()
    ? output.traceId.trim()
    : null;

  return {
    model_id: modelId,
    trace_id: traceId,
    input_tokens: nullableNumber(agentUsage.input_tokens),
    output_tokens: nullableNumber(agentUsage.output_tokens),
    total_tokens: nullableNumber(agentUsage.total_tokens),
    latency_ms: nullableNumber(agentUsage.latency_ms),
    cache_read_input_tokens: nullableNumber(agentUsage.cache_read_input_tokens),
    cache_write_input_tokens: nullableNumber(agentUsage.cache_write_input_tokens),
  };
}

export function formatOcrCallbackErrors(errors: unknown[] | undefined): string | null {
  if (!Array.isArray(errors) || errors.length === 0) return null;
  return errors
    .map((item) => {
      if (isRecord(item)) {
        const code = typeof item.code === "string" && item.code.trim() ? item.code.trim() : null;
        const message = typeof item.message === "string" && item.message.trim()
          ? item.message.trim()
          : JSON.stringify(item);
        return code ? `${code}: ${message}` : message;
      }
      return typeof item === "string" ? item : JSON.stringify(item);
    })
    .filter((item) => item && item !== "{}")
    .join("; ");
}

export function parseCallbackProcessedAt(value: string | null | undefined): Date {
  if (!value) return new Date();
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? new Date() : parsed;
}

export function trimOcrArtifactKey(value: string | null | undefined): string | null {
  const trimmed = value?.trim();
  return trimmed || null;
}

export function deriveOcrPrefixFromArtifactKey(key: string | null | undefined): string | null {
  const trimmed = key?.trim();
  if (!trimmed) return null;
  const artifactMarkers = [
    "/annotaded_ocr/",
    "/annotated_ocr/",
    "/annotated_ocr_v2/",
    "/annotated_ocr_v3/",
    "/raw_ocr/",
    "/raw_ocr_v3/",
  ];
  for (const marker of artifactMarkers) {
    const markerIndex = trimmed.indexOf(marker);
    if (markerIndex > 0) {
      return trimmed.slice(0, markerIndex);
    }
  }
  const parts = trimmed.split("/").filter(Boolean);
  return parts.length >= 3 ? parts.slice(0, 3).join("/") : null;
}

export function deriveAnnotatedMarkdownKeyFromDocumento(documento: {
  annotated_markdown_key?: string | null;
  s3_textract_path?: string | null;
}): string | null {
  const explicitKey = documento.annotated_markdown_key?.trim();
  if (explicitKey) {
    if (!explicitKey.startsWith("s3://")) return explicitKey;
    const withoutScheme = explicitKey.slice(5);
    const slashIndex = withoutScheme.indexOf("/");
    return slashIndex >= 0 ? withoutScheme.slice(slashIndex + 1) : null;
  }

  const prefix = documento.s3_textract_path?.trim();
  if (!prefix) return null;
  if (prefix.startsWith("s3://")) {
    const withoutScheme = prefix.slice(5);
    const slashIndex = withoutScheme.indexOf("/");
    if (slashIndex === -1) return null;
    const key = withoutScheme.slice(slashIndex + 1);
    return key.endsWith(".md") ? key : `${key.replace(/\/+$/, "")}/annotated_ocr_v3/annotated.md`;
  }

  return prefix.endsWith(".md") ? prefix : `${prefix.replace(/\/+$/, "")}/annotated_ocr_v3/annotated.md`;
}

// Validação server-side das seções de extração submetidas por IA. Espelha a forma
// dos schemas dos Lambdas (GENERIC_FIELDS_SCHEMA / EXCEDENTES_SCHEMA), mas torna o
// `id` (âncora de bloco do OCR anotado) opcional: no texto puro a rastreabilidade é
// o trecho verbatim em `fonte`. Não confia no contexto do modelo.
export const EXCEDENTE_TIPO_COBRANCA_IA = new Set([
  "por_faixa",
  "por_hora",
  "por_funcionario",
  "por_documento",
  "por_edificio",
  "por_obra",
  "outro",
]);

export function normalizarExcedentesItemsIA(
  value: { items?: unknown[] } | null | undefined,
): { items?: unknown[] } | null | undefined {
  if (!value || !Array.isArray(value.items)) return value;
  return {
    ...value,
    items: value.items.map((raw) => {
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) return raw;
      const item = raw as Record<string, unknown>;
      const tipoCobranca = item.tipo_cobranca;
      return {
        ...item,
        tipo_cobranca:
          typeof tipoCobranca === "string" && EXCEDENTE_TIPO_COBRANCA_IA.has(tipoCobranca)
            ? tipoCobranca
            : "outro",
      };
    }),
  };
}

export function validateSecaoItemsIA(secao: string, value: { items?: unknown }): string | null {
  if (!value || typeof value !== "object" || !Array.isArray(value.items)) {
    return `Seção "${secao}" deve ter um array "items".`;
  }
  for (const [i, raw] of value.items.entries()) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return `Item ${i} de "${secao}" deve ser um objeto.`;
    }
    const item = raw as Record<string, unknown>;
    if (typeof item.campo !== "string" || item.campo.trim() === "") {
      return `Item ${i} de "${secao}" requer "campo" (string).`;
    }
    if (!("valor_extraido" in item)) {
      return `Item ${i} de "${secao}" requer "valor_extraido".`;
    }
  }

  if (secao === "termos_gerais") {
    return validarRegimeEDocumentoExtraidos(value.items);
  }

  return null;
}

/**
 * Gate de coerência regime ↔ documento na extração de contrato.
 *
 * `regime_tributario` e `cnpj_cliente` são redundantes: "Pessoa Física" só existe
 * com CPF (11 dígitos), os outros quatro regimes só com CNPJ (14 dígitos). Um par
 * inconsistente prova que o modelo errou um dos dois campos, então rejeitamos a
 * seção em vez de gravar dado que se contradiz.
 *
 * Quando `cnpj_cliente` não vem no payload (correção parcial de seção), só o valor
 * canônico do regime é checado aqui; o pareamento fica para a escrita no cliente
 * (`fillClienteNullFieldsFromContrato`), que tem o documento gravado.
 */
function validarRegimeEDocumentoExtraidos(items: unknown[]): string | null {
  const valorDoCampo = (campo: string): unknown => {
    const item = items.find(
      (raw) => raw && typeof raw === "object" && (raw as Record<string, unknown>).campo === campo,
    ) as Record<string, unknown> | undefined;
    return item ? item.valor_extraido : undefined;
  };

  const regimeBruto = valorDoCampo("regime_tributario");
  if (regimeBruto === undefined) return null;

  try {
    const regime = normalizarRegimeTributario(regimeBruto);
    const documento = valorDoCampo("cnpj_cliente");
    if (typeof documento === "string") {
      validarRegimeComDocumento(regime, documento);
    }
  } catch (error) {
    if (error instanceof RegimeTributarioInvalidoError) return error.message;
    throw error;
  }

  return null;
}

export function validateExcedentesItemsIA(value: { items?: unknown }): string | null {
  if (!value || typeof value !== "object" || !Array.isArray(value.items)) {
    return `Seção "excedentes" deve ter um array "items".`;
  }
  for (const [i, raw] of value.items.entries()) {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return `Item ${i} de "excedentes" deve ser um objeto.`;
    }
    const item = raw as Record<string, unknown>;
    if (typeof item.referencia !== "string" || item.referencia.trim() === "") {
      return `Item ${i} de "excedentes" requer "referencia" (string).`;
    }
    if (typeof item.tipo_cobranca !== "string" || !EXCEDENTE_TIPO_COBRANCA_IA.has(item.tipo_cobranca)) {
      return `Item ${i} de "excedentes" tem "tipo_cobranca" inválido.`;
    }
  }
  return null;
}
