import { describe, expect, it } from "vitest";
import {
  normalizarExcedentesItemsIA,
  validateExcedentesItemsIA,
  validateSecaoItemsIA,
} from "../documentos-parsing.js";

function termosGerais(...campos: Array<{ campo: string; valor_extraido: unknown }>) {
  return { items: campos.map((c) => ({ ...c, fonte: "trecho literal" })) };
}

describe("validateSecaoItemsIA — gate regime ↔ documento", () => {
  it("aceita o par coerente CNPJ + regime de pessoa jurídica", () => {
    expect(
      validateSecaoItemsIA(
        "termos_gerais",
        termosGerais(
          { campo: "cnpj_cliente", valor_extraido: "12.345.678/0001-90" },
          { campo: "regime_tributario", valor_extraido: "Lucro Real" },
        ),
      ),
    ).toBeNull();
  });

  it("aceita o par coerente CPF + Pessoa Física", () => {
    expect(
      validateSecaoItemsIA(
        "termos_gerais",
        termosGerais(
          { campo: "cnpj_cliente", valor_extraido: "046.318.779-52" },
          { campo: "regime_tributario", valor_extraido: "Pessoa Física" },
        ),
      ),
    ).toBeNull();
  });

  it("rejeita regime de pessoa jurídica com CPF, citando os dois campos", () => {
    const erro = validateSecaoItemsIA(
      "termos_gerais",
      termosGerais(
        { campo: "cnpj_cliente", valor_extraido: "046.318.779-52" },
        { campo: "regime_tributario", valor_extraido: "Lucro Real" },
      ),
    );

    expect(erro).toContain("Lucro Real");
    expect(erro).toContain("046.318.779-52");
    expect(erro).toContain("11 dígitos");
  });

  it("rejeita Pessoa Física com CNPJ", () => {
    const erro = validateSecaoItemsIA(
      "termos_gerais",
      termosGerais(
        { campo: "cnpj_cliente", valor_extraido: "12.345.678/0001-90" },
        { campo: "regime_tributario", valor_extraido: "Pessoa Física" },
      ),
    );

    expect(erro).toContain("14 dígitos");
  });

  it("aceita variante reconhecível do regime", () => {
    expect(
      validateSecaoItemsIA(
        "termos_gerais",
        termosGerais(
          { campo: "cnpj_cliente", valor_extraido: "12.345.678/0001-90" },
          { campo: "regime_tributario", valor_extraido: "simples" },
        ),
      ),
    ).toBeNull();
  });

  it("rejeita regime fora da lista canônica", () => {
    const erro = validateSecaoItemsIA(
      "termos_gerais",
      termosGerais({ campo: "regime_tributario", valor_extraido: "Lucro Fictício" }),
    );

    expect(erro).toContain("não é reconhecido");
  });

  it("aceita regime null: o campo é opcional na extração", () => {
    expect(
      validateSecaoItemsIA("termos_gerais", termosGerais({ campo: "regime_tributario", valor_extraido: null })),
    ).toBeNull();
  });

  it("não cruza quando cnpj_cliente não veio no payload (correção parcial de seção)", () => {
    expect(
      validateSecaoItemsIA("termos_gerais", termosGerais({ campo: "regime_tributario", valor_extraido: "Lucro Real" })),
    ).toBeNull();
  });

  it("não aplica o gate em outras seções", () => {
    expect(
      validateSecaoItemsIA(
        "valores_contratados",
        termosGerais({ campo: "regime_tributario", valor_extraido: "Lucro Fictício" }),
      ),
    ).toBeNull();
  });

  it("mantém as validações estruturais anteriores", () => {
    expect(validateSecaoItemsIA("termos_gerais", { items: undefined })).toContain('deve ter um array "items"');
    expect(validateSecaoItemsIA("termos_gerais", { items: [{ valor_extraido: 1 }] })).toContain('requer "campo"');
    expect(validateSecaoItemsIA("termos_gerais", { items: [{ campo: "objeto" }] })).toContain('requer "valor_extraido"');
  });
});

describe("validateExcedentesItemsIA — tipos de cobrança imobiliários", () => {
  it.each(["por_edificio", "por_obra"])("aceita %s", (tipoCobranca) => {
    expect(
      validateExcedentesItemsIA({
        items: [{ referencia: "obras ativas", tipo_cobranca: tipoCobranca }],
      }),
    ).toBeNull();
  });

  it("normaliza tipo desconhecido para outro antes da validação", () => {
    const normalizado = normalizarExcedentesItemsIA({
      items: [{ referencia: "obras ativas", tipo_cobranca: "por_canteiro" }],
    });

    expect(normalizado?.items?.[0]).toMatchObject({ tipo_cobranca: "outro" });
    expect(validateExcedentesItemsIA(normalizado ?? {})).toBeNull();
  });
});
