import { beforeEach, describe, expect, it, vi } from "vitest";

const dataSourceMocks = vi.hoisted(() => ({
  runQueryWithRls: vi.fn(),
}));

const autenticacaoMocks = vi.hoisted(() => ({
  ensureDatabase: vi.fn(),
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: dataSourceMocks.runQueryWithRls,
}));

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: autenticacaoMocks.ensureDatabase,
}));

const { getDocumentosStatusBatch, listAllDocumentosPaginated } = await import("../documentos-queries.js");

function criarQueryBuilder(rows: Record<string, unknown>[]) {
  return {
    select: vi.fn().mockReturnThis(),
    addSelect: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    andWhere: vi.fn().mockReturnThis(),
    getRawMany: vi.fn().mockResolvedValue(rows),
  };
}

/**
 * QueryBuilder encadeável para a listagem paginada: `criarBaseListagemDocumentos` é
 * chamada duas vezes (página + resumo), então cada `createQueryBuilder` devolve o
 * próximo builder da fila.
 */
function criarQueryBuilderListagem(rows: Record<string, unknown>[], total = rows.length) {
  return {
    select: vi.fn().mockReturnThis(),
    addSelect: vi.fn().mockReturnThis(),
    leftJoin: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    andWhere: vi.fn().mockReturnThis(),
    orderBy: vi.fn().mockReturnThis(),
    groupBy: vi.fn().mockReturnThis(),
    offset: vi.fn().mockReturnThis(),
    limit: vi.fn().mockReturnThis(),
    clone: vi.fn(function (this: { getCount: unknown }) { return this; }),
    getCount: vi.fn().mockResolvedValue(total),
    getRawMany: vi.fn().mockResolvedValue(rows),
  };
}

function mockarListagem(builders: ReturnType<typeof criarQueryBuilderListagem>[]) {
  const fila = [...builders];
  dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx: unknown, callback: (m: unknown) => unknown) =>
    callback({
      getRepository: () => ({
        createQueryBuilder: () => fila.shift() ?? builders[builders.length - 1],
      }),
    }),
  );
}

describe("documentos queries", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    autenticacaoMocks.ensureDatabase.mockResolvedValue(undefined);
  });

  it("inclui vínculo e status do relatório no status-batch", async () => {
    const queryBuilder = criarQueryBuilder([
      {
        id: "doc-report-1",
        status_upload: "sucesso",
        status_extracao: "concluido",
        status_contrato: null,
        erro_extracao: null,
        processed_at: "2026-07-07T10:00:00.000Z",
        contrato_processado_em: null,
        documento_ilegivel: false,
        tem_dados_extraidos: true,
        contrato_aprovado: true,
        relatorio_id: "rel-1",
        relatorio_status: "ativo",
        relatorios_count: "2",
        updated_at: "2026-07-07T10:00:01.000Z",
      },
    ]);
    dataSourceMocks.runQueryWithRls.mockImplementation(async (_ctx, callback) =>
      callback({
        getRepository: () => ({
          createQueryBuilder: () => queryBuilder,
        }),
      }),
    );

    const result = await getDocumentosStatusBatch("office-1", ["doc-report-1"]);

    expect(result).toEqual([
      expect.objectContaining({
        id: "doc-report-1",
        tem_relatorio: true,
        relatorio_id: "rel-1",
        relatorio_status: "ativo",
        relatorios_count: 2,
        contrato_aprovado: true,
      }),
    ]);
    expect(queryBuilder.addSelect).toHaveBeenCalledWith(expect.stringContaining("relatorios r"), "relatorio_id");
    expect(queryBuilder.addSelect).toHaveBeenCalledWith(expect.stringContaining("relatorio_ativo"), "relatorio_status");
    expect(queryBuilder.addSelect).toHaveBeenCalledWith(expect.stringContaining("COUNT(*)"), "relatorios_count");
    expect(queryBuilder.addSelect).toHaveBeenCalledWith(
      expect.stringContaining("contrato_documentos_anexos"),
      "contrato_aprovado",
    );
  });

  describe("listagem paginada", () => {
    const linha = {
      id: "doc-1",
      filename_original: "contrato.pdf",
      storage_key: "office-1/doc-1.pdf",
      modulo: "contratos",
      status_upload: "sucesso",
      status_extracao: "concluido",
      created_at: "2026-07-01T10:00:00.000Z",
      relatorios_count: "0",
      grupo_status: "review",
    };

    it("aplica paginação, filtro de grupo e devolve o resumo por grupo", async () => {
      const pagina = criarQueryBuilderListagem([linha], 31);
      const resumo = criarQueryBuilderListagem([
        { grupo_status: "review", quantidade: "9", ultimo_upload: "2026-07-01T10:00:00.000Z" },
        { grupo_status: "problem", quantidade: "3", ultimo_upload: "2026-07-05T10:00:00.000Z" },
        // Grupo desconhecido entra no total, mas não corrompe os contadores conhecidos.
        { grupo_status: null, quantidade: "1", ultimo_upload: null },
      ]);
      mockarListagem([pagina, resumo]);

      const result = await listAllDocumentosPaginated("office-1", {
        page: 2,
        pageSize: 10,
        grupoStatus: "review",
      });

      expect(pagina.offset).toHaveBeenCalledWith(10);
      expect(pagina.limit).toHaveBeenCalledWith(10);
      expect(pagina.andWhere).toHaveBeenCalledWith(
        expect.stringContaining("CASE"),
        { grupoStatus: "review" },
      );
      expect(resumo.groupBy).toHaveBeenCalledWith("1");
      expect(result.total).toBe(31);
      expect(result.total_pages).toBe(4);
      expect(result.items[0]).toEqual(expect.objectContaining({ id: "doc-1", grupo_status: "review" }));
      expect(result.resumo).toEqual({
        total: 13,
        in_progress: 0,
        review: 9,
        processed: 0,
        problem: 3,
        ultimo_upload: "2026-07-05T10:00:00.000Z",
      });
    });

    it("expõe a versão vinculada quando o documento confirmado é um aditivo", async () => {
      const pagina = criarQueryBuilderListagem([{
        ...linha,
        contrato_id: "contrato-versao-2",
        contrato_aprovado: true,
        grupo_status: "processed",
      }]);
      mockarListagem([pagina, criarQueryBuilderListagem([])]);

      const result = await listAllDocumentosPaginated("office-1", { page: 1, pageSize: 10 });

      expect(result.items[0]).toEqual(expect.objectContaining({
        tem_contrato: true,
        contrato_aprovado: true,
        contrato_id: "contrato-versao-2",
        grupo_status: "processed",
      }));
      expect(pagina.addSelect).toHaveBeenCalledWith(
        expect.stringContaining("contrato_documentos_anexos"),
        "contrato_id",
      );
    });

    it("filtra por tipo e busca também pelo caminho de OCR e pelo id", async () => {
      const pagina = criarQueryBuilderListagem([linha], 1);
      mockarListagem([pagina, criarQueryBuilderListagem([])]);

      await listAllDocumentosPaginated("office-1", { page: 1, pageSize: 10, query: "abc", tipo: "billing" });

      expect(pagina.andWhere).toHaveBeenCalledWith(
        expect.stringContaining("'billing'"),
        { tipo: "billing" },
      );
      // A busca vira um bloco OR (Brackets), então validamos o SQL montado nele.
      const brackets = pagina.andWhere.mock.calls.map(([arg]) => arg).find((arg) => typeof arg !== "string");
      const sub = { where: vi.fn().mockReturnThis(), orWhere: vi.fn().mockReturnThis() };
      (brackets as { whereFactory: (qb: unknown) => void }).whereFactory(sub);
      const camposBuscados = [
        ...sub.where.mock.calls.map(([sql]) => sql),
        ...sub.orWhere.mock.calls.map(([sql]) => sql),
      ].join(" ");
      expect(camposBuscados).toContain("documento.filename_original");
      expect(camposBuscados).toContain("cliente.razao_social");
      expect(camposBuscados).toContain("documento.s3_textract_path");
      expect(camposBuscados).toContain("documento.id::text");
    });

    it("expõe o vínculo e permite filtrar documentos de dados da simulação", async () => {
      const pagina = criarQueryBuilderListagem([{ ...linha, modulo: "simulation_data", simulacao_id: "sim-1", grupo_status: "processed" }], 1);
      mockarListagem([pagina, criarQueryBuilderListagem([])]);

      const result = await listAllDocumentosPaginated("office-1", { page: 1, pageSize: 10, tipo: "simulation" });

      expect(result.items[0]).toEqual(expect.objectContaining({ modulo: "simulation_data", simulacao_id: "sim-1" }));
      expect(pagina.andWhere).toHaveBeenCalledWith(expect.stringContaining("simulation_data"), { tipo: "simulation" });
      expect(pagina.addSelect).toHaveBeenCalledWith("documento.simulacao_id", "simulacao_id");
    });

    it("não filtra por grupo de status quando nenhum é pedido", async () => {
      const pagina = criarQueryBuilderListagem([linha], 1);
      mockarListagem([pagina, criarQueryBuilderListagem([])]);

      await listAllDocumentosPaginated("office-1", { page: 1, pageSize: 10 });

      expect(pagina.andWhere).not.toHaveBeenCalled();
    });
  });
});
