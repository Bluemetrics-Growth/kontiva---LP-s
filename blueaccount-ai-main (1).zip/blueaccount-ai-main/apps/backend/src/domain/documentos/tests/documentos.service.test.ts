import { beforeEach, describe, expect, it, vi } from "vitest";

const documentosMocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();
  const runQueryWithRls = vi.fn();
  const put = vi.fn();
  const get = vi.fn();
  const createDocumentStorage = vi.fn();
  const buildDocumentStorageKey = vi.fn();
  const readS3Object = vi.fn();
  const convertAndCount = vi.fn();
  const repo = {
    find: vi.fn(),
    findOne: vi.fn(),
    findOneBy: vi.fn(),
    create: vi.fn(),
    save: vi.fn(),
    update: vi.fn(),
    findOneOrFail: vi.fn(),
  };

  return {
    ensureDatabase,
    runQueryWithRls,
    put,
    get,
    createDocumentStorage,
    buildDocumentStorageKey,
    readS3Object,
    convertAndCount,
    repo,
  };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: documentosMocks.ensureDatabase,
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: documentosMocks.runQueryWithRls,
}));

vi.mock("../../../infrastructure/document-storage.js", () => ({
  createDocumentStorage: documentosMocks.createDocumentStorage,
  buildDocumentStorageKey: documentosMocks.buildDocumentStorageKey,
  readS3Object: documentosMocks.readS3Object,
}));

vi.mock("../../../infrastructure/doc-convert-client.js", () => ({
  convertAndCount: documentosMocks.convertAndCount,
}));

vi.mock("../../../database/modules/tenant/entities/documento.entity.js", () => ({
  Documento: class Documento {},
}));

documentosMocks.createDocumentStorage.mockReturnValue({
  put: documentosMocks.put,
  get: documentosMocks.get,
});

const {
  listDocumentos,
  uploadDocumento,
  validateDocumentoFilename,
  getDocumentoOcrMarkdown,
  getDocumentoCleanMarkdown,
  updateDocumentoIngestionExecutionArn,
  updateDocumentoRawIngestionPayload,
  updateDocumentoExtracaoModuloStatus,
  marcarDocumentoFalhaAgente,
} = await import("../documentos.service.js");

describe("documentos service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    documentosMocks.runQueryWithRls.mockImplementation(async (_ctx: unknown, callback: (manager: { getRepository: () => typeof documentosMocks.repo }) => Promise<unknown>) => {
      return callback({
        getRepository: () => documentosMocks.repo,
      });
    });
    documentosMocks.createDocumentStorage.mockReturnValue({
      put: documentosMocks.put,
      get: documentosMocks.get,
    });
    documentosMocks.buildDocumentStorageKey.mockReturnValue("office-1/client-1/contratos/123-file.pdf");
    documentosMocks.put.mockResolvedValue({ key: "office-1/client-1/contratos/123-file.pdf", etag: "etag-1" });
    documentosMocks.readS3Object.mockResolvedValue(Buffer.from("markdown"));
    documentosMocks.repo.find.mockResolvedValue([]);
    documentosMocks.repo.create.mockImplementation((payload) => payload);
    documentosMocks.repo.save.mockImplementation(async (payload) => ({ ...payload, id: "doc-1" }));
    documentosMocks.repo.update.mockResolvedValue({ affected: 1, raw: [], generatedMaps: [] });
    documentosMocks.repo.findOneOrFail.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: "client-1",
      uploaded_by_usuario_id: "user-1",
      modulo: "contratos",
      filename_original: "contrato.pdf",
      storage_key: "office-1/client-1/contratos/123-file.pdf",
      checksum: "abc123",
      status_upload: "sucesso",
      status_extracao: "pendente",
    });
  });

  it("rejects unsupported file extensions", () => {
    expect(() => validateDocumentoFilename("arquivo.exe")).toThrow("Arquivo inválido. Use apenas PDF, DOCX ou CSV.");
  });

  it("lists documentos using RLS", async () => {
    documentosMocks.repo.find.mockResolvedValue([
      {
        id: "doc-1",
        modulo: "contratos",
        filename_original: "contrato.pdf",
      },
    ]);

    const result = await listDocumentos("office-1", "client-1");

    expect(documentosMocks.ensureDatabase).toHaveBeenCalledTimes(1);
    expect(documentosMocks.runQueryWithRls).toHaveBeenCalledWith({ escritorio_id: "office-1" }, expect.any(Function));
    expect(result).toEqual([
      {
        id: "doc-1",
        modulo: "contratos",
        filename_original: "contrato.pdf",
      },
    ]);
  });

  it("uploads documento and persists metadata", async () => {
    const result = await uploadDocumento({
      escritorioId: "office-1",
      clienteId: "client-1",
      usuarioId: "user-1",
      modulo: "contratos",
      filename: "contrato.pdf",
      content: Buffer.from("pdf"),
      contentType: "application/pdf",
      sizeBytes: 3,
      checksum: "abc123",
    });

    expect(documentosMocks.buildDocumentStorageKey).toHaveBeenCalledWith({
      escritorioId: "office-1",
      clienteId: "client-1",
      modulo: "contratos",
      filename: "contrato.pdf",
      competencia: undefined,
    });
    expect(documentosMocks.put).toHaveBeenCalledWith({
      key: "office-1/client-1/contratos/123-file.pdf",
      content: Buffer.from("pdf"),
      contentType: "application/pdf",
      metadata: {
        escritorio_id: "office-1",
        cliente_id: "client-1",
        modulo: "contratos",
      },
    });
    expect(result).toMatchObject({
      escritorio_id: "office-1",
      cliente_id: "client-1",
      uploaded_by_usuario_id: "user-1",
      modulo: "contratos",
      filename_original: "contrato.pdf",
      storage_key: "office-1/client-1/contratos/123-file.pdf",
      checksum: "abc123",
      status_upload: "sucesso",
      status_extracao: "pendente",
    });
  });

  it("uploads documento without cliente association when clienteId is not provided", async () => {
    documentosMocks.buildDocumentStorageKey.mockReturnValue("office-1/_sem_cliente/contratos/123-file.pdf");
    documentosMocks.repo.findOneOrFail.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: null,
      uploaded_by_usuario_id: "user-1",
      modulo: "contratos",
      filename_original: "contrato.pdf",
      storage_key: "office-1/_sem_cliente/contratos/123-file.pdf",
      checksum: "abc123",
      status_upload: "sucesso",
      status_extracao: "pendente",
    });

    const result = await uploadDocumento({
      escritorioId: "office-1",
      usuarioId: "user-1",
      modulo: "contratos",
      filename: "contrato.pdf",
      content: Buffer.from("pdf"),
      contentType: "application/pdf",
      sizeBytes: 3,
      checksum: "abc123",
    });

    expect(documentosMocks.buildDocumentStorageKey).toHaveBeenCalledWith({
      escritorioId: "office-1",
      clienteId: null,
      modulo: "contratos",
      filename: "contrato.pdf",
      competencia: undefined,
    });
    expect(documentosMocks.repo.create).toHaveBeenCalledWith(
      expect.objectContaining({ cliente_id: null }),
    );
    expect(documentosMocks.put).toHaveBeenCalledWith({
      key: "office-1/_sem_cliente/contratos/123-file.pdf",
      content: Buffer.from("pdf"),
      contentType: "application/pdf",
      metadata: {
        escritorio_id: "office-1",
        modulo: "contratos",
      },
    });
    expect(result).toMatchObject({
      escritorio_id: "office-1",
      cliente_id: null,
      storage_key: "office-1/_sem_cliente/contratos/123-file.pdf",
    });
  });

  it("passes competencia to storage key and persists it when provided", async () => {
    documentosMocks.buildDocumentStorageKey.mockReturnValue("office-1/client-1/relatorios_periodicos/2025-01/123-file.pdf");
    documentosMocks.repo.findOneOrFail.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: "client-1",
      modulo: "relatorios_periodicos",
      filename_original: "relatorio.pdf",
      storage_key: "office-1/client-1/relatorios_periodicos/2025-01/123-file.pdf",
      competencia: "2025-01",
      status_upload: "sucesso",
      status_extracao: "pendente",
    });

    await uploadDocumento({
      escritorioId: "office-1",
      clienteId: "client-1",
      usuarioId: "user-1",
      modulo: "relatorios_periodicos",
      filename: "relatorio.pdf",
      content: Buffer.from("pdf"),
      competencia: "2025-01",
    });

    expect(documentosMocks.buildDocumentStorageKey).toHaveBeenCalledWith({
      escritorioId: "office-1",
      clienteId: "client-1",
      modulo: "relatorios_periodicos",
      filename: "relatorio.pdf",
      competencia: "2025-01",
    });
    expect(documentosMocks.repo.create).toHaveBeenCalledWith(
      expect.objectContaining({ competencia: "2025-01" }),
    );
  });

  it("persists competencia as null when not provided", async () => {
    await uploadDocumento({
      escritorioId: "office-1",
      clienteId: "client-1",
      usuarioId: "user-1",
      modulo: "relatorios_periodicos",
      filename: "relatorio.pdf",
      content: Buffer.from("pdf"),
    });

    expect(documentosMocks.repo.create).toHaveBeenCalledWith(
      expect.objectContaining({ competencia: null }),
    );
  });

  it("skips office->pdf conversion for xlsx/csv uploaded to relatorios_periodicos (bulk planilha ingestion)", async () => {
    await uploadDocumento({
      escritorioId: "office-1",
      clienteId: null,
      usuarioId: "user-1",
      modulo: "relatorios_periodicos",
      filename: "relatorios.xlsx",
      content: Buffer.from("xlsx"),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      sizeBytes: 4,
    });

    // Sem isso, o CheckSpreadsheetMode da SM nunca casaria: mimeType e
    // filenameOriginal teriam virado application/pdf + .pdf antes da SM rodar.
    expect(documentosMocks.convertAndCount).not.toHaveBeenCalled();
    expect(documentosMocks.repo.create).toHaveBeenCalledWith(
      expect.objectContaining({
        filename_original: "relatorios.xlsx",
        mime_type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
    );
  });

  it("still converts xlsx to pdf when the module is not relatorios_periodicos", async () => {
    documentosMocks.convertAndCount.mockResolvedValue({
      content: Buffer.from("pdf"),
      filename: "contrato.pdf",
      contentType: "application/pdf",
      pageCount: 3,
      converted: true,
    });

    await uploadDocumento({
      escritorioId: "office-1",
      clienteId: "client-1",
      usuarioId: "user-1",
      modulo: "contratos",
      filename: "contrato.xlsx",
      content: Buffer.from("xlsx"),
      contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      sizeBytes: 4,
    });

    expect(documentosMocks.convertAndCount).toHaveBeenCalledTimes(1);
    expect(documentosMocks.repo.create).toHaveBeenCalledWith(
      expect.objectContaining({ filename_original: "contrato.pdf", mime_type: "application/pdf" }),
    );
  });

  it("reads OCR markdown from the textract bucket using the s3 uri stored in documento", async () => {
    documentosMocks.repo.findOne.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      s3_textract_path: "s3://kontiva-textract-output-dev/114b8200-6127-4447-91c6-6cd6694f2cf5/_sem_cliente/1e501c48-c8f0-4346-91b4-f12de8c2bea7",
    });
    documentosMocks.repo.findOneBy.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      s3_textract_path: "s3://kontiva-textract-output-dev/114b8200-6127-4447-91c6-6cd6694f2cf5/_sem_cliente/1e501c48-c8f0-4346-91b4-f12de8c2bea7",
    });
    documentosMocks.readS3Object.mockResolvedValue(Buffer.from("# anotado"));

    const markdown = await getDocumentoOcrMarkdown("office-1", "doc-1");

    expect(documentosMocks.readS3Object).toHaveBeenCalledWith(
      "kontiva-textract-output-dev",
      "114b8200-6127-4447-91c6-6cd6694f2cf5/_sem_cliente/1e501c48-c8f0-4346-91b4-f12de8c2bea7/annotated_ocr_v3/annotated.md",
    );
    expect(markdown).toBe("# anotado");
  });

  it("prefers stored OCR artifact keys when reading markdown", async () => {
    documentosMocks.repo.findOneBy.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      s3_textract_path: "office-1/client-1/doc-1",
      annotated_markdown_key: "office-1/client-1/doc-1/annotated_ocr_v3/custom-annotated.md",
      clean_markdown_key: "s3://custom-bucket/office-1/client-1/doc-1/clean.md",
    });
    documentosMocks.readS3Object
      .mockResolvedValueOnce(Buffer.from("# anotado direto"))
      .mockResolvedValueOnce(Buffer.from("# limpo direto"));

    await expect(getDocumentoOcrMarkdown("office-1", "doc-1")).resolves.toBe("# anotado direto");
    await expect(getDocumentoCleanMarkdown("office-1", "doc-1")).resolves.toBe("# limpo direto");

    expect(documentosMocks.readS3Object).toHaveBeenNthCalledWith(
      1,
      "kontiva-textract-output-dev",
      "office-1/client-1/doc-1/annotated_ocr_v3/custom-annotated.md",
    );
    expect(documentosMocks.readS3Object).toHaveBeenNthCalledWith(
      2,
      "custom-bucket",
      "office-1/client-1/doc-1/clean.md",
    );
  });

  it("falls back to storage_key raw text for AI-submitted documents (no OCR artifacts)", async () => {
    const aiDoc = {
      id: "doc-ai",
      escritorio_id: "office-1",
      storage_key: "office-1/_sem_cliente/contratos/contrato-ai.txt",
      mime_type: "text/plain",
      metadados_ia_contrato: { ingestion: { source_type: "ai_submitted_text" } },
    };
    documentosMocks.repo.findOneBy.mockResolvedValue(aiDoc);
    documentosMocks.get.mockResolvedValue(Buffer.from("Texto enviado pela IA"));

    await expect(getDocumentoCleanMarkdown("office-1", "doc-ai")).resolves.toBe("Texto enviado pela IA");
    await expect(getDocumentoOcrMarkdown("office-1", "doc-ai")).resolves.toBe("Texto enviado pela IA");

    expect(documentosMocks.get).toHaveBeenCalledWith("office-1/_sem_cliente/contratos/contrato-ai.txt");
    expect(documentosMocks.readS3Object).not.toHaveBeenCalled();
  });

  it("returns null when a non-AI document has no OCR artifacts", async () => {
    documentosMocks.repo.findOneBy.mockResolvedValue({
      id: "doc-2",
      escritorio_id: "office-1",
      storage_key: "office-1/client-1/contratos/file.pdf",
      mime_type: "application/pdf",
    });

    await expect(getDocumentoCleanMarkdown("office-1", "doc-2")).resolves.toBeNull();
    await expect(getDocumentoOcrMarkdown("office-1", "doc-2")).resolves.toBeNull();
    expect(documentosMocks.get).not.toHaveBeenCalled();
  });

  it("persists exact OCR artifact keys with ingestion metadata", async () => {
    documentosMocks.repo.findOneBy.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      ingestion_execution_arn: "arn:ocr",
      annotated_markdown_key: "office-1/client-1/doc-1/annotated_ocr_v3/annotated.md",
    });

    await updateDocumentoIngestionExecutionArn({
      escritorioId: "office-1",
      documentoId: "doc-1",
      ingestionExecutionArn: "arn:ocr",
      s3TextractPath: "office-1/client-1/doc-1",
      ocrArtifacts: {
        textractRawKey: "office-1/client-1/doc-1/raw_ocr_v3/textract.json",
        annotatedMarkdownKey: "office-1/client-1/doc-1/annotated_ocr_v3/annotated.md",
        cleanMarkdownKey: "office-1/client-1/doc-1/annotated_ocr_v3/clean.md",
        blocksParquetKey: null,
        ocrManifestKey: "office-1/client-1/doc-1/annotated_ocr_v3/ocr-manifest.json",
      },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-1", escritorio_id: "office-1" },
      {
        ingestion_execution_arn: "arn:ocr",
        s3_textract_path: "office-1/client-1/doc-1",
        textract_raw_key: "office-1/client-1/doc-1/raw_ocr_v3/textract.json",
        annotated_markdown_key: "office-1/client-1/doc-1/annotated_ocr_v3/annotated.md",
        clean_markdown_key: "office-1/client-1/doc-1/annotated_ocr_v3/clean.md",
        blocks_parquet_key: null,
        ocr_manifest_key: "office-1/client-1/doc-1/annotated_ocr_v3/ocr-manifest.json",
      },
    );
  });

  it("marks upload as failed when storage write fails after record creation", async () => {
    documentosMocks.put.mockRejectedValue(new Error("storage failed"));

    await expect(uploadDocumento({
      escritorioId: "office-1",
      clienteId: "client-1",
      usuarioId: "user-1",
      modulo: "contratos",
      filename: "contrato.pdf",
      content: Buffer.from("pdf"),
      contentType: "application/pdf",
    })).rejects.toThrow("storage failed");

    expect(documentosMocks.repo.save).toHaveBeenCalledTimes(1);
    expect(documentosMocks.repo.update).toHaveBeenNthCalledWith(1, { id: "doc-1", escritorio_id: "office-1" }, { status_upload: "uploadando", erro_upload: null });
    expect(documentosMocks.repo.update).toHaveBeenNthCalledWith(2, { id: "doc-1", escritorio_id: "office-1" }, expect.objectContaining({ status_upload: "erro", erro_upload: "storage failed" }));
  });

  it("updates raw ingestion payload and review-ready status for contratos", async () => {
    documentosMocks.repo.findOneBy
      .mockResolvedValueOnce({
        id: "doc-1",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "processando",
      })
      .mockResolvedValueOnce({
        id: "doc-1",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "concluido",
      });

    const result = await updateDocumentoRawIngestionPayload({
      escritorioId: "office-1",
      documentoId: "doc-1",
      rawPayload: { objeto: "Contabilidade" },
      payloadNormalizadoUi: { displayFields: [] },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-1", escritorio_id: "office-1" },
      expect.objectContaining({
        dados_extraidos_contrato: { objeto: "Contabilidade" },
        payload_normalizado_ui: { displayFields: [] },
        status_extracao: "concluido",
        status_contrato: "concluido",
        erro_extracao: null,
        erro_contrato: null,
        processed_at: expect.any(Date),
        contrato_processado_em: expect.any(Date),
      }),
    );
    expect(result).toMatchObject({
      id: "doc-1",
      status_extracao: "concluido",
      status_contrato: "concluido",
    });
  });

  it("stores amendment classification and proposal audit payload for contract documents", async () => {
    documentosMocks.repo.findOneBy
      .mockResolvedValueOnce({
        id: "doc-aditivo",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "processando",
      })
      .mockResolvedValueOnce({
        id: "doc-aditivo",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "concluido",
        tipo_documento_contratual: "aditivo",
      });

    await updateDocumentoRawIngestionPayload({
      escritorioId: "office-1",
      documentoId: "doc-aditivo",
      rawPayload: {
        tipo_documento_contratual: "aditivo",
        contrato_base_id: "contrato-base-1",
        classificacao: {
          tipo: "aditivo",
          confianca: 0.95,
          motivo: "Altera valor mensal.",
        },
        termosGerais: { items: [{ campo: "valor_mensal", valor_extraido: 5500 }] },
        valoresContratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 600 }] },
        excedentes: { items: [] },
      },
      payloadNormalizadoUi: {
        displayFields: [],
        payloadInsercaoDb: {
          valor_mensal: 5500,
          valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 600 }] },
        },
      },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-aditivo", escritorio_id: "office-1" },
      expect.objectContaining({
        tipo_documento_contratual: "aditivo",
        alteracao_proposta_contrato: expect.objectContaining({
          documento_id: "doc-aditivo",
          tipo_documento_contratual: "aditivo",
          contrato_base_id: "contrato-base-1",
          classificacao: {
            tipo: "aditivo",
            confianca: 0.95,
            motivo: "Altera valor mensal.",
          },
          deltas_extraidos: expect.objectContaining({
            termos_gerais: { items: [{ campo: "valor_mensal", valor_extraido: 5500 }] },
            valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 600 }] },
            excedentes: { items: [] },
          }),
          payload_insercao_db: expect.objectContaining({
            valor_mensal: 5500,
          }),
        }),
      }),
    );
  });

  it("does not build an amendment proposal for tipo desconhecido", async () => {
    documentosMocks.repo.findOneBy
      .mockResolvedValueOnce({
        id: "doc-desconhecido",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "processando",
      })
      .mockResolvedValueOnce({
        id: "doc-desconhecido",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "concluido",
        tipo_documento_contratual: "desconhecido",
      });

    await updateDocumentoRawIngestionPayload({
      escritorioId: "office-1",
      documentoId: "doc-desconhecido",
      rawPayload: {
        tipo_documento_contratual: "desconhecido",
        classificacao: { tipo: "desconhecido", confianca: 0.4, motivo: "Documento ambíguo." },
        termosGerais: { items: [] },
      },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-desconhecido", escritorio_id: "office-1" },
      expect.objectContaining({
        tipo_documento_contratual: "desconhecido",
        alteracao_proposta_contrato: null,
      }),
    );
  });

  it("extracts amendment classification nested in the SM callback (contractExtraction.agentResult)", async () => {
    documentosMocks.repo.findOneBy
      .mockResolvedValueOnce({
        id: "doc-aditivo-sm",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "processando",
      })
      .mockResolvedValueOnce({
        id: "doc-aditivo-sm",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "concluido",
        tipo_documento_contratual: "aditivo",
      });

    await updateDocumentoRawIngestionPayload({
      escritorioId: "office-1",
      documentoId: "doc-aditivo-sm",
      rawPayload: {
        termosGerais: { items: [] },
        contractExtraction: {
          engine: "agent",
          agentResult: {
            tipo_documento_contratual: "aditivo",
            contrato_base_id: "contrato-base-2",
            classificacao: { tipo: "aditivo", confianca: 0.9, motivo: "Aditivo de valor." },
          },
        },
      },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-aditivo-sm", escritorio_id: "office-1" },
      expect.objectContaining({
        tipo_documento_contratual: "aditivo",
        alteracao_proposta_contrato: expect.objectContaining({
          tipo_documento_contratual: "aditivo",
          contrato_base_id: "contrato-base-2",
          classificacao: {
            tipo: "aditivo",
            confianca: 0.9,
            motivo: "Aditivo de valor.",
          },
        }),
      }),
    );
  });

  it("marks contract extraction as concluded when raw payload updates an already OCR-concluded document", async () => {
    documentosMocks.repo.findOneBy
      .mockResolvedValueOnce({
        id: "doc-1",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "processando",
      })
      .mockResolvedValueOnce({
        id: "doc-1",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "processando",
      });

    await updateDocumentoRawIngestionPayload({
      escritorioId: "office-1",
      documentoId: "doc-1",
      rawPayload: { objeto: "Contabilidade revisada" },
      payloadNormalizadoUi: { displayFields: [{ campo: "objeto" }] },
    });

    expect(documentosMocks.repo.update).toHaveBeenCalledWith(
      { id: "doc-1", escritorio_id: "office-1" },
      expect.objectContaining({
        dados_extraidos_contrato: { objeto: "Contabilidade revisada" },
        erro_extracao: null,
        status_contrato: "concluido",
        erro_contrato: null,
        contrato_processado_em: expect.any(Date),
        payload_normalizado_ui: { displayFields: [{ campo: "objeto" }] },
      }),
    );
  });

  describe("updateDocumentoExtracaoModuloStatus guard anti-clobber", () => {
    it("sem preservarTerminal usa where só por id/escritório", async () => {
      documentosMocks.repo.findOneBy.mockResolvedValue({ id: "doc-1" });
      await updateDocumentoExtracaoModuloStatus({ escritorioId: "office-1", documentoId: "doc-1", status: "concluido" });
      const where = documentosMocks.repo.update.mock.calls[0][0];
      expect(where).toEqual({ id: "doc-1", escritorio_id: "office-1" });
    });

    it("com preservarTerminal adiciona guard de status_contrato terminal", async () => {
      documentosMocks.repo.findOneBy.mockResolvedValue({ id: "doc-1" });
      await updateDocumentoExtracaoModuloStatus({
        escritorioId: "office-1",
        documentoId: "doc-1",
        status: "processando",
        preservarTerminal: true,
      });
      const where = documentosMocks.repo.update.mock.calls[0][0];
      expect(Object.keys(where)).toContain("status_contrato");
      expect(where.id).toBe("doc-1");
      // A condição terminal impede o UPDATE de rebaixar um `concluido`/`erro` já gravado.
      expect(where.status_contrato).toBeDefined();
    });
  });

  describe("marcarDocumentoFalhaAgente", () => {
    it("marca contrato como erro (status_extracao + status_contrato)", async () => {
      documentosMocks.repo.findOne.mockResolvedValue({
        id: "doc-1",
        escritorio_id: "office-1",
        modulo: "contratos",
        status_extracao: "concluido", // concluido do OCR, mas o módulo ainda processando
        status_contrato: "processando",
      });
      documentosMocks.repo.findOneBy.mockResolvedValue({ id: "doc-1" });

      await marcarDocumentoFalhaAgente({ escritorioId: "office-1", documentoId: "doc-1", motivo: "boom" });

      const updates = documentosMocks.repo.update.mock.calls.map((c) => c[1]);
      expect(updates).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ status_extracao: "erro", erro_extracao: "boom" }),
          expect.objectContaining({ status_contrato: "erro" }),
        ]),
      );
    });

    it("não sobrescreve contrato com módulo já concluido", async () => {
      documentosMocks.repo.findOne.mockResolvedValue({
        id: "doc-1",
        modulo: "contratos",
        status_extracao: "concluido",
        status_contrato: "concluido",
      });

      await marcarDocumentoFalhaAgente({ escritorioId: "office-1", documentoId: "doc-1", motivo: "boom" });

      expect(documentosMocks.repo.update).not.toHaveBeenCalled();
    });

    it("não sobrescreve relatório já concluido (status_extracao)", async () => {
      documentosMocks.repo.findOne.mockResolvedValue({
        id: "doc-2",
        modulo: "relatorios_periodicos",
        status_extracao: "concluido",
        status_contrato: null,
      });

      await marcarDocumentoFalhaAgente({ escritorioId: "office-1", documentoId: "doc-2", motivo: "boom" });

      expect(documentosMocks.repo.update).not.toHaveBeenCalled();
    });

    it("marca relatório como erro sem tocar em status_contrato", async () => {
      documentosMocks.repo.findOne.mockResolvedValue({
        id: "doc-2",
        modulo: "relatorios_periodicos",
        status_extracao: "processando",
        status_contrato: null,
      });
      documentosMocks.repo.findOneBy.mockResolvedValue({ id: "doc-2" });

      await marcarDocumentoFalhaAgente({ escritorioId: "office-1", documentoId: "doc-2", motivo: "boom" });

      const updates = documentosMocks.repo.update.mock.calls.map((c) => c[1]);
      expect(updates).toEqual([expect.objectContaining({ status_extracao: "erro", erro_extracao: "boom" })]);
      expect(updates.some((u) => "status_contrato" in u)).toBe(false);
    });
  });
});
