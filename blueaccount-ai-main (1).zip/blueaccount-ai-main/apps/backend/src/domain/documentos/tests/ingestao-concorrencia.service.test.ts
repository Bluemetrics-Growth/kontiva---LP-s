import { beforeEach, describe, expect, it, vi } from "vitest";

type PermissaoMemoria = {
  documento_id: string;
  modulo: "contratos" | "relatorios_periodicos";
  liberada_em: Date | null;
  status_terminal: string | null;
};

const bancoMocks = vi.hoisted(() => ({
  AppDataSource: {
    isInitialized: true,
    initialize: vi.fn(),
    transaction: vi.fn(),
    query: vi.fn(),
  },
}));

vi.mock("../../../database/data-source.js", () => bancoMocks);
vi.mock("../../../settings.js", () => ({
  settings: {
    INGESTAO_CONCORRENCIA_LIMITE_GLOBAL: 20,
    INGESTAO_CONCORRENCIA_LIMITE_CONTRATOS: 12,
    INGESTAO_CONCORRENCIA_LIMITE_RELATORIOS: 8,
  },
}));

const {
  adquirirPermissaoProcessamentoIngestao,
  liberarPermissaoProcessamentoIngestao,
  obterEstadoConcorrenciaIngestao,
} = await import("../ingestao-concorrencia.service.js");

function criarBancoMemoria() {
  const permissoes = new Map<string, PermissaoMemoria>();
  const manager = {
    query: vi.fn(async (sql: string, params: unknown[] = []) => {
      if (sql.includes("ingestao_controle_concorrencia")) return [{ id: 1 }];
      if (sql.includes("SELECT \"documento_id\"")) {
        const permissao = permissoes.get(String(params[0]));
        return permissao ? [permissao] : [];
      }
      if (sql.includes("COUNT(*) FILTER")) {
        const modulo = params[0];
        const ativas = [...permissoes.values()].filter((item) => item.liberada_em === null);
        return [{
          total_ativo: String(ativas.length),
          modulo_ativo: String(ativas.filter((item) => item.modulo === modulo).length),
        }];
      }
      if (sql.includes("INSERT INTO")) {
        permissoes.set(String(params[0]), {
          documento_id: String(params[1]),
          modulo: params[2] as PermissaoMemoria["modulo"],
          liberada_em: null,
          status_terminal: null,
        });
        return [];
      }
      if (sql.includes("UPDATE \"public\".\"ingestao_permissoes_processamento\"")) {
        const permissao = permissoes.get(String(params[0]));
        if (permissao && permissao.liberada_em === null) {
          permissao.liberada_em = new Date();
          permissao.status_terminal = String(params[1]);
        }
        return [];
      }
      throw new Error(`SQL inesperado no teste: ${sql}`);
    }),
  };

  let fila = Promise.resolve();
  bancoMocks.AppDataSource.transaction.mockImplementation((callback: (manager: typeof manager) => Promise<unknown>) => {
    const execucao = fila.then(() => callback(manager));
    fila = execucao.then(() => undefined, () => undefined);
    return execucao;
  });
  return { permissoes, manager };
}

describe("concorrência de ingestão", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    bancoMocks.AppDataSource.isInitialized = true;
  });

  it("serializa 50 aquisições e respeita os limites global e por módulo", async () => {
    const { permissoes } = criarBancoMemoria();
    const tentativas = Array.from({ length: 50 }, (_, indice) => {
      const modulo = indice % 2 === 0 ? "contratos" as const : "relatorios_periodicos" as const;
      return adquirirPermissaoProcessamentoIngestao({
        executionArn: `arn:aws:states:us-east-1:123456789012:execution:sm:exec-${indice}`,
        documentoId: `doc-${indice}`,
        modulo,
      });
    });

    const resultados = await Promise.all(tentativas);
    expect(resultados.filter((item) => item.adquirida)).toHaveLength(20);
    const ativas = [...permissoes.values()].filter((item) => item.liberada_em === null);
    expect(ativas).toHaveLength(20);
    expect(ativas.filter((item) => item.modulo === "contratos")).toHaveLength(12);
    expect(ativas.filter((item) => item.modulo === "relatorios_periodicos")).toHaveLength(8);
  });

  it("torna aquisição e liberação idempotentes pelo executionArn", async () => {
    const { permissoes } = criarBancoMemoria();
    const input = {
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:sm:exec-1",
      documentoId: "doc-1",
      modulo: "contratos" as const,
    };

    await expect(adquirirPermissaoProcessamentoIngestao(input)).resolves.toEqual({ adquirida: true });
    await expect(adquirirPermissaoProcessamentoIngestao(input)).resolves.toEqual({ adquirida: true });
    expect(permissoes).toHaveLength(1);

    await expect(liberarPermissaoProcessamentoIngestao({
      executionArn: input.executionArn,
      statusTerminal: "SUCCEEDED",
    })).resolves.toEqual({ liberada: true });
    await expect(liberarPermissaoProcessamentoIngestao({
      executionArn: input.executionArn,
      statusTerminal: "FAILED",
    })).resolves.toEqual({ liberada: true });
    expect(permissoes.get(input.executionArn)?.status_terminal).toBe("SUCCEEDED");
  });

  it("trata nova aquisição após resposta perdida de um commit como sucesso idempotente", async () => {
    const { permissoes } = criarBancoMemoria();
    const input = {
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:sm:ambiguous-commit",
      documentoId: "doc-ambiguous",
      modulo: "relatorios_periodicos" as const,
    };

    // A primeira resposta seria perdida na rede, depois de a transação já ter confirmado.
    await adquirirPermissaoProcessamentoIngestao(input);
    await expect(adquirirPermissaoProcessamentoIngestao(input)).resolves.toEqual({ adquirida: true });
    expect(permissoes).toHaveLength(1);
  });

  it("permite nova tentativa após rollback/indisponibilidade da transação", async () => {
    bancoMocks.AppDataSource.transaction.mockRejectedValueOnce(new Error("database unavailable"));
    const input = {
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:sm:rollback",
      documentoId: "doc-rollback",
      modulo: "contratos" as const,
    };

    await expect(adquirirPermissaoProcessamentoIngestao(input)).rejects.toThrow("database unavailable");
    const { permissoes } = criarBancoMemoria();
    await expect(adquirirPermissaoProcessamentoIngestao(input)).resolves.toEqual({ adquirida: true });
    expect(permissoes).toHaveLength(1);
  });

  it("reinicializa o DataSource após restart do backend antes de adquirir", async () => {
    const { permissoes } = criarBancoMemoria();
    bancoMocks.AppDataSource.isInitialized = false;
    bancoMocks.AppDataSource.initialize.mockImplementation(async () => {
      bancoMocks.AppDataSource.isInitialized = true;
      return bancoMocks.AppDataSource;
    });

    await expect(adquirirPermissaoProcessamentoIngestao({
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:sm:restart",
      documentoId: "doc-restart",
      modulo: "contratos",
    })).resolves.toEqual({ adquirida: true });
    expect(bancoMocks.AppDataSource.initialize).toHaveBeenCalledOnce();
    expect(permissoes).toHaveLength(1);
  });

  it("expõe limites, ocupação e leases ativas para observabilidade admin", async () => {
    const adquiridaEm = new Date("2026-07-20T12:00:00.000Z");
    bancoMocks.AppDataSource.query.mockResolvedValueOnce([
      { execution_arn: "arn:c1", documento_id: "doc-c1", modulo: "contratos", adquirida_em: adquiridaEm },
      { execution_arn: "arn:c2", documento_id: "doc-c2", modulo: "contratos", adquirida_em: adquiridaEm },
      { execution_arn: "arn:r1", documento_id: "doc-r1", modulo: "relatorios_periodicos", adquirida_em: adquiridaEm },
    ]);

    const estado = await obterEstadoConcorrenciaIngestao();

    expect(estado.limites).toEqual({ global: 20, contratos: 12, relatorios: 8 });
    expect(estado.ativos).toEqual({ total: 3, contratos: 2, relatorios: 1 });
    expect(estado.leases).toHaveLength(3);
    expect(estado.leases[0]).toEqual({
      executionArn: "arn:c1",
      documentoId: "doc-c1",
      modulo: "contratos",
      adquiridaEm: "2026-07-20T12:00:00.000Z",
    });
  });

  it("falha fechado quando a linha singleton não existe", async () => {
    bancoMocks.AppDataSource.transaction.mockImplementation(async (callback: (manager: { query: () => Promise<unknown[]> }) => Promise<unknown>) => {
      return callback({ query: vi.fn().mockResolvedValue([]) });
    });
    await expect(adquirirPermissaoProcessamentoIngestao({
      executionArn: "arn:aws:states:us-east-1:123456789012:execution:sm:exec-1",
      documentoId: "doc-1",
      modulo: "contratos",
    })).rejects.toThrow("Controle de concorrência de ingestão não inicializado.");
  });
});
