/**
 * Barrel público do domínio de documentos.
 *
 * Mantém compatíveis os imports históricos de `documentos.service.js` enquanto
 * a implementação fica separada por concern nos submódulos abaixo.
 */
export * from "./documentos-shared.js";
export * from "./documentos-queries.js";
export * from "./documentos-ocr.js";
export * from "./documentos-status.js";
export * from "./documentos-upload.js";
