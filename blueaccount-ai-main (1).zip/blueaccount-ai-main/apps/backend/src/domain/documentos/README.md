# `src/domain/documentos`

Esta pasta concentra o caso de uso de documentos do escritório, com associação opcional a cliente.

## Responsabilidades

- validar uploads permitidos (PDF, DOCX, CSV)
- montar o `storage_key` com prefixo `escritorio_id/cliente_id|_sem_cliente/modulo/[competencia/]timestamp_unix-filename`
- persistir metadados de documento
- controlar `status_upload` e preparar `status_extracao`
- sincronizar `status_extracao` com a execução da Step Function de ingestão
- listar documentos por cliente e por módulo
- permitir que o documento nasça sem `cliente_id`
- ler o markdown OCR anotado no S3 e devolver um fallback de retry quando ainda não estiver disponível
- listar arquivos de origem de simulação registrados pelo fluxo dedicado, sem submetê-los ao OCR

## Módulos suportados

| Módulo | Aceita `competencia` |
|---|---|
| `contratos` | não |
| `relatorios_periodicos` | sim (opcional) |
| `cobrancas` | sim (opcional) |
| `simulation_data` | não; criado somente pelo importador da simulação |

## Campo `competencia`

O campo `competencia` representa o mês de referência do documento no formato `YYYY-MM` (ex: `2025-01`).

- É opcional para todos os módulos.
- Quando informado para `relatorios_periodicos` ou `cobrancas`, é incluído no path do storage key: `escritorioId/clienteId|_sem_cliente/modulo/2025-01/ts-filename`.
- Quando ausente, o path segue o padrão anterior: `escritorioId/clienteId|_sem_cliente/modulo/ts-filename`.
- O controller rejeita `competencia` com `400` se o módulo for `contratos`.
- O controller rejeita formato inválido com `400` (deve seguir `/^\d{4}-(0[1-9]|1[0-2])$/`).

A validação de formato e a restrição por módulo ficam no controller HTTP. O serviço recebe `competencia` já validada e a persiste diretamente.

`simulation_data` não passa pelo upload genérico deste domínio. O importador registra o `.xlsx`
diretamente com `simulacao_id`; a listagem o classifica como `simulation` e a UI abre a simulação de
origem. O documento permanece visível também quando a validação da planilha falha.

## Arquivos

- `documentos.service.ts`: barrel público; preserva o caminho histórico de imports e re-exporta os arquivos coesos abaixo
- `documentos-shared.ts`: validação de nome/extensão
- `documentos-queries.ts`: listagem, busca por ID e status batch
- `documentos-ocr.ts`: leitura de markdown OCR, fallback de texto submetido por IA e resolução de artefatos S3
- `documentos-status.ts`: mutations de status, metadados, payloads de ingestão e vínculos de cliente
- `documentos-upload.ts`: criação de documento por upload de arquivo ou texto submetido por IA
- `documentos-parsing.ts`: helpers puros de parsing/normalização usados pela orquestração de documentos

## Listagem paginada e grupo de status em SQL

`listAllDocumentosPaginated` (em `documentos-queries.ts`) é a listagem usada pela tela
`/documentos`. Além de paginar, ela filtra e conta por **grupo de status** dentro do banco, porque a
tela só recebe uma página por vez e não teria como contar o escritório inteiro no cliente.

- `SQL_GRUPO_STATUS` é uma expressão `CASE` que espelha, na mesma ordem de precedência,
  `deriveStatus()` de `apps/frontend/src/pages/DocumentosPage.tsx`. Os grupos são
  `in_progress`, `review`, `processed` e `problem` (`GRUPOS_STATUS_DOCUMENTO`).
- **Ao mexer em uma das duas pontas, ajustar a outra junto.** O badge de cada linha continua sendo
  derivado no frontend (para reagir ao polling de `status-batch` sem recarregar a página), então uma
  divergência entre as duas faz a linha aparecer em um filtro que contradiz o próprio badge.
- `criarBaseListagemDocumentos` concentra escritório + busca (`q`) + filtro de tipo, e é reusada pela
  consulta da página e pela do resumo. O resumo **não** aplica `grupo_status`, para os contadores das
  abas continuarem mostrando o total de cada grupo depois de uma aba ser escolhida.
- As subconsultas correlacionadas (`contratos`, `relatorios`, `faturamento` por `arquivo_origem`)
  dependem dos índices criados em `AddPerformanceIndexes1782400000000` e
  `AddIndexContratosArquivoOrigem1784800000000`.

Contrato HTTP e formato da resposta: `docs/API_ENDPOINTS.md` → `GET /api/documentos`.

## Regra prática

Se a lógica decide como um arquivo vira um registro de documento e como esse documento será listado, ela pertence aqui.
