import type { ContractExtractionPayload } from "./contrato-payload.js";

export interface ContratoQaExtracao {
  suspeita: boolean;
  motivo: string | null;
  campos_preenchidos: number;
  total_campos: number;
}

/** Abaixo deste número de campos preenchidos a extração é considerada suspeita. */
const MINIMO_CAMPOS_PREENCHIDOS = 3;

/** Campos que caracterizam um contrato; se nenhum vier preenchido, o documento provavelmente não é um contrato. */
const CAMPOS_CHAVE = new Set([
  "cnpj_cliente",
  "razao_social",
  "nome_cliente",
  "valor_original",
  "valor_mensal",
  "objeto",
]);

function isPreenchido(valor: unknown): boolean {
  if (valor == null) return false;
  if (typeof valor === "string") return valor.trim() !== "";
  if (Array.isArray(valor)) return valor.length > 0;
  return true;
}

/**
 * Avalia se a extração de contrato veio "quase vazia" — sintoma típico de
 * documento do tipo errado (ex.: relatório enviado no módulo de contratos),
 * OCR ruim ou modelo incompatível. O resultado vai embutido em
 * `payload_normalizado_ui.qa_extracao` e a tela de revisão exibe o alerta.
 */
export function avaliarQualidadeExtracaoContrato(payload: ContractExtractionPayload): ContratoQaExtracao {
  const items = [
    ...(payload.termosGerais?.items ?? []),
    ...(payload.valoresContratados?.items ?? []),
    ...(payload.excedentes?.items ?? []),
  ];
  const preenchidos = items.filter((item) => isPreenchido(item.valor_extraido));
  const temCampoChave = preenchidos.some((item) => CAMPOS_CHAVE.has(item.campo));

  let motivo: string | null = null;
  if (preenchidos.length < MINIMO_CAMPOS_PREENCHIDOS) {
    motivo = "Quase nenhum campo foi extraído do documento. Verifique se o arquivo enviado é realmente um contrato.";
  } else if (!temCampoChave) {
    motivo =
      "Nenhum campo essencial do contrato (CNPJ, razão social, valor ou objeto) foi extraído. Verifique se o arquivo enviado é realmente um contrato.";
  }

  return {
    suspeita: motivo != null,
    motivo,
    campos_preenchidos: preenchidos.length,
    total_campos: items.length,
  };
}
