import { AppDataSource } from "../../database/data-source.js";
import { IndiceInflacao } from "../../database/modules/public/entities/indice-inflacao.entity.js";
import { INDICES_REAJUSTE, normalizarIndiceReajuste, type IndiceReajuste } from "./indice-reajuste.js";

// A lista e a normalização moraram aqui; foram para `indice-reajuste.ts` (módulo puro)
// para que a extração de contrato possa usá-las sem importar o DataSource. Reexportado
// para não quebrar quem já importava deste serviço.
export { INDICES_REAJUSTE, normalizarIndiceReajuste };
export type { IndiceReajuste };

const SERIES_BCB: Record<IndiceReajuste, number> = { IPCA: 433, INPC: 188, "IGP-M": 189 };

const BCB_TIMEOUT_MS = 15_000;
const BCB_RETRY_DELAY_MS = 500;

/** Sinaliza que o BCB respondeu, mas ainda não publicou o índice da competência pedida. */
export class IndiceNaoPublicadoError extends Error {
  constructor(public readonly indice: IndiceReajuste, public readonly competencia: string) {
    super(`Índice ${indice} ainda não publicado pelo BCB para ${competencia}.`);
    this.name = "IndiceNaoPublicadoError";
  }
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function competenciaAnterior(competencia: string): string {
  const [mesRaw, anoRaw] = competencia.split("/");
  let mes = Number(mesRaw) - 1;
  let ano = Number(anoRaw);
  if (mes === 0) { mes = 12; ano -= 1; }
  return `${String(mes).padStart(2, "0")}/${ano}`;
}

export function ultimasDozeCompetencias(competenciaAtual: string): string[] {
  const competencias: string[] = [];
  let competencia = competenciaAnterior(competenciaAtual);
  for (let indice = 0; indice < 12; indice += 1) {
    competencias.unshift(competencia);
    competencia = competenciaAnterior(competencia);
  }
  return competencias;
}

function intervaloDaCompetencia(competencia: string): { inicio: string; fim: string } {
  const [mes, ano] = competencia.split("/");
  const ultimoDia = new Date(Date.UTC(Number(ano), Number(mes), 0)).getUTCDate();
  return { inicio: `01/${mes}/${ano}`, fim: `${String(ultimoDia).padStart(2, "0")}/${mes}/${ano}` };
}

function competenciaDaDataBcb(data: string): string {
  const [dia, mes, ano] = data.split("/");
  if (!dia || !mes || !ano) throw new Error(`Data inválida recebida do BCB: ${data}`);
  return `${mes}/${ano}`;
}

async function ensureDatabase(): Promise<void> {
  if (!AppDataSource.isInitialized) await AppDataSource.initialize();
}

/** Uma tentativa contra o BCB/SGS. Devolve as linhas cruas ou lança em falha de transporte (não-2xx/rede). */
async function requisitarBcb(indice: IndiceReajuste, competencia: string): Promise<Array<{ data?: string; valor?: string }>> {
  const { inicio, fim } = intervaloDaCompetencia(competencia);
  const url = new URL(`https://api.bcb.gov.br/dados/serie/bcdata.sgs.${SERIES_BCB[indice]}/dados`);
  url.searchParams.set("formato", "json");
  url.searchParams.set("dataInicial", inicio);
  url.searchParams.set("dataFinal", fim);
  const resposta = await fetch(url, { signal: AbortSignal.timeout(BCB_TIMEOUT_MS) });
  if (!resposta.ok) throw new Error(`BCB/SGS indisponível para ${indice} (${resposta.status}).`);
  return await resposta.json() as Array<{ data?: string; valor?: string }>;
}

async function buscarNoBcb(indice: IndiceReajuste, competencia: string): Promise<number> {
  // Falha de transporte (rede/timeout/não-2xx) é transitória: uma tentativa extra.
  // "Índice ainda não publicado" NÃO é transitório e não deve ser retentado.
  let dados: Array<{ data?: string; valor?: string }>;
  try {
    dados = await requisitarBcb(indice, competencia);
  } catch {
    await delay(BCB_RETRY_DELAY_MS);
    dados = await requisitarBcb(indice, competencia);
  }
  const linha = dados.find((item) => item.data && competenciaDaDataBcb(item.data) === competencia);
  const percentual = linha?.valor == null ? Number.NaN : Number(String(linha.valor).replace(",", "."));
  if (!Number.isFinite(percentual)) throw new IndiceNaoPublicadoError(indice, competencia);
  return percentual;
}

/** Retorna uma competência mensal; se ela não estiver completa localmente, atualiza todos os índices suportados. */
async function obterIndiceDaCompetencia(indice: IndiceReajuste, competencia: string): Promise<IndiceInflacao> {
  await ensureDatabase();
  const repo = AppDataSource.getRepository(IndiceInflacao);
  const existentes = await repo.find({ where: { competencia } });
  const existentesPorIndice = new Map(existentes.map((item) => [item.indice, item]));

  if (INDICES_REAJUSTE.some((nome) => !existentesPorIndice.has(nome))) {
    // Sequencial de propósito: evita rajada de requisições concorrentes ao BCB/SGS.
    for (const nome of INDICES_REAJUSTE) {
      const percentual = await buscarNoBcb(nome, competencia);
      await repo.upsert({ indice: nome, competencia, percentual_mensal: percentual, fonte: "BCB/SGS" }, ["indice", "competencia"]);
    }
  }

  const resultado = await repo.findOneBy({ indice, competencia });
  if (!resultado) throw new Error(`Índice ${indice} não disponível para ${competencia}.`);
  return resultado;
}

/** Calcula a variação composta dos 12 meses completos anteriores ao aniversário. */
export async function obterIndiceAcumuladoDozeMeses(
  indice: IndiceReajuste,
  competenciaAtual: string,
): Promise<{ competencia_inicio: string; competencia_fim: string; percentual_acumulado: number }> {
  const competencias = ultimasDozeCompetencias(competenciaAtual);
  // Sequencial de propósito: evita rajada de até 12×3 requisições concorrentes ao BCB/SGS.
  const indices: IndiceInflacao[] = [];
  for (const competencia of competencias) {
    indices.push(await obterIndiceDaCompetencia(indice, competencia));
  }
  const fator = indices.reduce((acumulado, item) => acumulado * (1 + Number(item.percentual_mensal) / 100), 1);
  return {
    competencia_inicio: competencias[0],
    competencia_fim: competencias.at(-1)!,
    percentual_acumulado: (fator - 1) * 100,
  };
}

/** Lista o histórico local de índices oficiais, ordenado da competência mais recente para a mais antiga. */
export async function listarIndicesInflacao(): Promise<Array<{
  indice: IndiceReajuste;
  competencia: string;
  percentual_mensal: number;
  fonte: string;
  coletado_em: Date;
}>> {
  await ensureDatabase();
  const indices = await AppDataSource.getRepository(IndiceInflacao).find();
  return indices
    .sort((a, b) => {
      const [mesA, anoA] = a.competencia.split("/").map(Number);
      const [mesB, anoB] = b.competencia.split("/").map(Number);
      return anoB - anoA || mesB - mesA || a.indice.localeCompare(b.indice);
    })
    .map((item) => ({
      indice: item.indice,
      competencia: item.competencia,
      percentual_mensal: Number(item.percentual_mensal),
      fonte: item.fonte,
      coletado_em: item.coletado_em,
    }));
}
