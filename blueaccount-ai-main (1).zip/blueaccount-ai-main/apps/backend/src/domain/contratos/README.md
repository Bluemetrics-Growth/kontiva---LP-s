# `src/domain/contratos`

Regra de negócio relacionada a contratos.

## Responsabilidades

- confirmar contrato extraído (criar/atualizar cliente, desativar contratos anteriores, persistir novo contrato)
- confirmar aditivos/anexos como nova versão revisada, preservando vínculo com o documento de origem
- atualizar contrato existente (cria nova versão, mantém histórico de edições)
- sincronizar contrato ativo com payload normalizado vindo do OCR
- aplicar regras de negócio na persistência (valor_mensal fallback, data_termino indeterminada)
- consultar e listar o histórico local dos índices IPCA, INPC e IGP-M obtidos do BCB/SGS para os reajustes anuais

## Fluxo de ingestão (atual)

**Etapa 1 — OCR + normalização (automática):**
1. Upload do PDF via `POST /documentos/upload`
2. State Machine (AWS Step Functions) executa OCR + extração estruturada
3. Callback chega via polling ou `POST /internal/documentos/:id/ingestao/raw-payload`
4. `buildContratoPayloadNormalizadoUi()` (função pura, sem IA) gera o `payload_normalizado_ui` com `displayFields` e `payloadInsercaoDb` (campos prontos para o banco)
5. Se já existir contrato ativo vinculado ao documento, `sincronizarContratoAtivoComPayload()` propaga o JSONB (`valores_contratados`, `excedentes`) para a tabela `contratos`

Para aditivos/anexos, a extração traz `tipo_documento_contratual` e CNPJ. O backend busca o contrato ativo do cliente, monta um draft revisável com os campos base + deltas extraídos, e só cria/ativa a nova versão quando o usuário confirma. O documento aprovado fica registrado em `contrato_documentos_anexos`.

**Etapa 2 — Confirmação pelo usuário:**
1. Frontend (`MvpReviewPage`) carrega `payload_normalizado_ui.payloadInsercaoDb` como valores iniciais
2. Usuário ajusta diretamente as colunas (inputs simples + editor JSON para colunas JSONB)
3. `POST /contratos/:documentoId/confirmar` → `confirmarContratoExtracted()`
4. Backend aplica `campos_editados` via `applyCamposEditadosToPayloadInsercaoDb()` e persiste
5. A aprovação agenda reconsolidação das competências existentes do cliente para marcar `valores_a_cobrar` antigos como `stale` quando o cálculo ativo tiver sido feito com insumos do contrato anterior
6. **Primeiro contrato do cliente** (não havia contrato antes — comum quando relatórios chegam antes via ingestão assíncrona em lote): além da reconsolidação, o backend
   - faz backfill da identificação do cliente a partir do contrato extraído — só quando `razao_social` é placeholder (`Cliente <cnpj>`) ou vazia e `nome_fantasia` é null (nunca sobrescreve nome real), via `fillClienteNullFieldsFromContrato(..., { preencherIdentificacao: true })`;
   - agenda a consolidação das competências já disponíveis (com relatório ativo) via `scheduleConsolidacaoCompetenciasComRelatorio()`, criando os `valores_a_cobrar` que antes não podiam existir por falta de contrato ativo

**Etapa 3 — Edição posterior:**
1. Frontend (`MvpDetalhesPage`) lê as colunas direto da tabela `contratos` (sem depender de `payload_normalizado_ui`)
2. `PATCH /contratos/:id` → `updateContrato()`
3. Backend cria nova versão do contrato (desativa a anterior) com os valores atualizados

## Edição direta de colunas

A partir desta versão, a UI edita **as colunas reais da tabela `contratos`** em vez de campos intermediários:

- Colunas primitivas (`tipo_contrato`, `valor_mensal`, datas, etc.) → inputs simples
- Colunas JSONB (`valores_contratados`, `excedentes`, `adicional_anual`) → editor chave-valor com fallback para JSON cru
- `valores_contratados` segue o padrão `{ items: [{ campo, valor_extraido }, ...] }` — UI mostra cada item como linha

`campos_editados` enviado pelo frontend usa **nomes de coluna DB**. O backend tem mapeamento residual de nomes da extração (`objeto` → `tipo_contrato`) em `reviewFieldToPersistenceField`.

## Regras de persistência (em `applyPersistencePayload`)

| Regra | Comportamento |
|-------|---------------|
| `valor_mensal` null + `valor_original` não-nulo | copia `valor_original` → `valor_mensal` |
| `data_termino` vazia ou variação de "indeterminado" | grava literal `"indeterminado"` |
| Datas (`data_inicio`, `data_emissao`, `inicio_faturamento`, `ultima_renovacao`) | aceita apenas `YYYY-MM-DD` de calendário real; entradas inválidas ou ausentes viram `null` |

## Fallback de `fonte` e campos de lista fechada

Cada item de extração traz `valor_extraido` (valor convertido) e `fonte` (trecho verbatim do documento). Quando o modelo não converte o valor (`valor_extraido: null`), `getField()` cai para a `fonte` — a cláusula é uma aproximação melhor que vazio num campo de texto livre.

Esse fallback é **bloqueado** em campo de lista fechada, registrado em `listas-fechadas-extracao.ts`:

| Campo | Lista | Fonte da verdade |
|-------|-------|------------------|
| `indice_reajuste` | IPCA, INPC, IGP-M (aceita `IGPM`) | `indice-reajuste.ts` |
| `regime_tributario` | Simples Nacional, Lucro Presumido, Lucro Real, MEI, Pessoa Física (+ variantes) | `../clientes/regime-tributario.ts` |

A `fonte` só é aceita nesses campos quando ela própria é um item da lista. Caso contrário o campo fica vazio para o revisor humano preencher. Sem esse gate, "reajustado anualmente pelo IPCA/IBGE" ia para a coluna `indice_reajuste` e o reajuste anual ignorava o contrato em silêncio (`normalizarIndiceReajuste` não casa a cláusula), e a cláusula de regime fazia `normalizarRegimeTributario` lançar — 400 na confirmação da revisão.

Ao adicionar campo de lista fechada na extração, registre-o em `listas-fechadas-extracao.ts` e repita a regra nas instruções do canal IA (`apps/mcp/src/content.ts`, travado por `apps/mcp/tests/extraction-instructions.test.ts`).

## Aplicação de `campos_editados`

`applyCamposEditadosToPayloadInsercaoDb` processa cada campo:

1. **`excedentes`**: `parseExcedentesEdit()` aceita array, `{items: array}` ou string JSON; aplica `sanitizeExcedenteItem()` removendo campos internos (`id`, `escritorio_id`, `contrato_id`, `created_at`, `updated_at`)
2. **`valores_contratados`**: substitui o JSONB inteiro. Quando substituído wholesale, pula `updateSnapshotItems` para outros campos (evita corromper o JSON do usuário)
3. **Colunas primitivas**: `normalizeEditedDbValue` aplica conversões específicas (números, JSON.parse para `adicional_anual`)
4. **Compatibilidade**: nomes legados (ex.: `objeto`) são mapeados para colunas DB via `reviewFieldToPersistenceField`

## Validação de cobrança

Frontend e backend impõem a regra: **se `valores_contratados` OU `excedentes` estão vazios, `instrucoes_de_cobranca` é obrigatória**.

- Frontend: aviso amarelo (`.rv-warning`) bloqueia o botão de save
- Backend: `assertCobrancaInstructionsWhenNeeded` como safety net (lança erro)

## Reajuste anual (`reajustarContratosCompetenciaAtual`)

Reajusta cada contrato ativo uma vez por ano, no aniversário da renovação.

- **Data de referência** (`dataReferenciaContrato`): `ultima_renovacao` quando presente, senão `data_inicio`; se ambas forem nulas, o contrato não é reajustado automaticamente.
- **Aniversário** (`ultimoAniversarioDeRenovacao`): o último aniversário (mesmo dia/mês da referência) que já ocorreu e está pelo menos um ano após a referência. Se o único candidato cai no mesmo ano da referência (ou seja, é a própria data de renovação/início), retorna `null` e não reajusta. Isso evita reajustar um contrato renovado neste ano cujo aniversário ainda não passou.
- **Ao reajustar**, a nova versão do contrato recebe `ultima_renovacao = data do reajuste` (o aniversário aplicado), além de `data_ultimo_reajuste` e `ultima_competencia_reajuste`. Como a renovação avança, o próximo aniversário passa a ser um ano depois, então a dedup anual acontece naturalmente (o aniversário do mesmo ano volta a ser `null`).
- **Auto-reparo**: o flag `valores_a_cobrar.contrato_reajustado` só é escrito por `aplicarReajusteNoValorACobrar`. Se o contrato foi reajustado mas o VAC não recebeu o flag (falha parcial), o lote reaplica via `repararReajusteSeNecessario`. Como a renovação avançada zera o aniversário, esse reparo é acionado pelo ramo sem-aniversário usando `data_ultimo_reajuste`/`ultima_competencia_reajuste`.

## Lock de versão de contrato na renovação

Qualquer avanço de `ultima_renovacao` — reajuste automático **e** renovação/aditivo manual (`confirmarContratoExtracted`, `updateContrato`, `criarContratoManual`) — trava os VACs de competências anteriores na versão de contrato que os gerou. Sem isso, cada reconsolidação/`gerarCobranca` re-aponta `valores_a_cobrar.contrato_id` para o contrato ativo atual e reescreveria retroativamente a base contratual de períodos já calculados/cobrados.

- O guard `renovacaoAvancou(anterior, novo)` garante que só avanços reais travam (correções que não movem a data não travam).
- O congelamento é feito por `bloquearVacsAnterioresARenovacao` (domínio `valores-a-cobrar/bloqueio-contrato-renovacao.ts`), dentro da mesma transação que desativa a versão anterior. VACs pagos e já travados são ignorados (idempotente).
- O lock vale **só daqui para frente** (sem re-pin histórico de VACs que já derivaram).

## Campos JSONB do contrato

| Campo | Estrutura | Propósito |
|-------|-----------|-----------|
| `valores_contratados` | `{ items: [{ campo, valor_extraido }, ...] }` | Snapshot dos valores extraídos. Usado por `consolidar.service.ts` e `gerar-cobranca.service.ts` na cobrança |
| `excedentes` | `{ items: [{ campo, referencia, valor_extraido, tipo_cobranca, quantidade_inicial, ... }] }` | Snapshot dos excedentes. Usado para cobrança |
| `adicional_anual` | array de objetos | Acréscimos anuais previstos |

A tabela relacional `clausulas_excedentes` continua existindo (sincronizada via `syncExcedentes()` na confirmação), mas a fonte de verdade para cobrança é o JSONB.

## Arquivos

- `contrato.service.ts`: `confirmarContratoExtracted`, `updateContrato`, `sincronizarContratoAtivoComPayload`, `applyPersistencePayload`, `syncExcedentes`, `getContratoById`
- `contrato-documento-anexo.entity.ts`: vínculo entre versões de contrato e documentos de aditivo/anexo
- `contrato-payload.ts`: `normalizeContractExtractionPayload`, `buildContratoPersistenceDraft`, `buildContratoPayloadNormalizadoUi`, `applyCamposEditadosToPayloadInsercaoDb`, `parseExcedentesEdit`, `sanitizeExcedenteItem`, `montarPayloadInsercaoDbContrato`
- `contrato-qa.ts`: `avaliarQualidadeExtracaoContrato` — detecta extração "quase vazia" (documento errado no módulo, OCR ruim, modelo incompatível); resultado embutido em `payload_normalizado_ui.qa_extracao` e exibido como alerta na tela de revisão

## Testes

- `tests/contrato.service.test.ts`
- `tests/contrato-qa.test.ts`

## Regra prática

Se a mudança depender do significado do contrato, ela nasce aqui — não no controller, não no modules-layer service.

Ao aprovar ou editar uma nova versão de contrato, preserve o gatilho de `scheduleReconsolidacaoClienteContrato`: ele mantém os cálculos de cobrança auditáveis e sinaliza `stale` sem invalidar registros pagos.
