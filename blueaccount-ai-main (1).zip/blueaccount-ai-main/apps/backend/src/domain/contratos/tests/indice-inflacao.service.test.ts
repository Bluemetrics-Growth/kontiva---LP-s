import { describe, expect, it } from "vitest";
import { normalizarIndiceReajuste } from "../indice-inflacao.service.js";

describe("normalizarIndiceReajuste", () => {
  it("aceita os índices suportados e a grafia compatível de IGP-M", () => {
    expect(normalizarIndiceReajuste(" IPCA ")).toBe("IPCA");
    expect(normalizarIndiceReajuste("inpc")).toBe("INPC");
    expect(normalizarIndiceReajuste("IGPM")).toBe("IGP-M");
  });

  it("recusa índices que não possuem série configurada no BCB", () => {
    expect(normalizarIndiceReajuste("INCC")).toBeNull();
    expect(normalizarIndiceReajuste(null)).toBeNull();
  });
});
