import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const contratosMocks = vi.hoisted(() => {
  const contratoRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
    createQueryBuilder: vi.fn(),
    maximum: vi.fn(),
    count: vi.fn(),
    create: vi.fn((value) => value),
    save: vi.fn(),
  };
  const clienteRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
    save: vi.fn(),
  };
  const excRepo = {
    create: vi.fn((value) => value),
    save: vi.fn(),
  };
  const documentoRepo = {
    findOne: vi.fn(),
    update: vi.fn(),
  };
  // Lock de renovação (bloquearVacsAnterioresARenovacao) faz UPDATE via query builder.
  const bloqueioExecute = vi.fn(async () => ({ affected: 0 }));
  const valoresACobrarQb = {
    update: vi.fn(() => valoresACobrarQb),
    set: vi.fn(() => valoresACobrarQb),
    where: vi.fn(() => valoresACobrarQb),
    andWhere: vi.fn(() => valoresACobrarQb),
    execute: bloqueioExecute,
  };
  const valoresACobrarRepo = {
    findOne: vi.fn(),
    find: vi.fn(async () => []),
    createQueryBuilder: vi.fn(() => valoresACobrarQb),
  };
  const relatorioRepo = {
    find: vi.fn(async () => []),
  };
  const getDocumentoById = vi.fn();
  const findOrCreateClienteByCnpj = vi.fn();
  const consultarCnpjSemBloquear = vi.fn();
  const managerQuery = vi.fn().mockResolvedValue([]);
  const runQueryWithRls = vi.fn((_rls, callback) => {
    return callback({
      query: managerQuery,
      getRepository: vi.fn((entity: { name?: string }) => {
      if (entity?.name === "Contrato") return contratoRepo;
      if (entity?.name === "Cliente") return clienteRepo;
      if (entity?.name === "ClausulasExcedentes") return excRepo;
      if (entity?.name === "Documento") return documentoRepo;
      if (entity?.name === "ValoresACobrar") return valoresACobrarRepo;
      if (entity?.name === "Relatorio") return relatorioRepo;
      throw new Error(`Unexpected repository ${entity?.name ?? "unknown"}`);
      }),
    });
  });

  return {
    contratoRepo,
    clienteRepo,
    excRepo,
    documentoRepo,
    valoresACobrarRepo,
    valoresACobrarQb,
    relatorioRepo,
    bloqueioExecute,
    getDocumentoById,
    findOrCreateClienteByCnpj,
    consultarCnpjSemBloquear,
    managerQuery,
    runQueryWithRls,
  };
});

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: contratosMocks.runQueryWithRls,
}));

vi.mock("../../../agent/index.js", () => ({
  IngestaoPayloadAgent: class {
    prepararPayloadFrontend = vi.fn(async () => ({ tipo: "payload_frontend" }));
  },
}));

vi.mock("../../complexidades-cobranca/complexidade-cobranca.service.js", () => ({
  assertBillingComplexityActive: vi.fn(async (nivel) => Number(nivel ?? 1) || 1),
}));

vi.mock("../../documentos/documentos.service.js", () => ({
  getDocumentoById: contratosMocks.getDocumentoById,
}));

vi.mock("../../clientes/cliente.service.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../clientes/cliente.service.js")>();
  return {
    ...actual,
    findOrCreateClienteByCnpj: contratosMocks.findOrCreateClienteByCnpj,
  };
});

// Consulta pública de CNPJ: mockada por padrão como "sem resultado", para os testes existentes (que
// não versam sobre o enriquecimento) continuarem exercitando o fluxo de contrato sem tocar rede/DB.
vi.mock("../../fornecedores/consulta-cnpj.service.js", () => ({
  consultarCnpjSemBloquear: contratosMocks.consultarCnpjSemBloquear,
}));

const { updateContrato, listContratos, confirmarContratoExtracted, criarContratoManual, getContratoById, getContratoAtivoByCnpj, ultimoAniversarioDeRenovacao } = await import("../contrato.service.js");
const { copyValorOriginalToValorMensalWhenMissing } = await import("../contrato-payload.js");

describe("ultimoAniversarioDeRenovacao", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-07-22T12:00:00"));
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  const contrato = (overrides: Record<string, unknown>) => overrides as never;

  it("não retorna aniversário quando a renovação foi neste ano e o aniversário ainda não passou", () => {
    // Renovado em 2025-11-10, hoje 2026-07-22: próximo aniversário (2026-11-10) ainda não passou.
    expect(ultimoAniversarioDeRenovacao(contrato({ ultima_renovacao: "2025-11-10" }))).toBeNull();
  });

  it("retorna o aniversário já ocorrido no ano corrente", () => {
    // Renovado em 2025-03-15: aniversário 2026-03-15 já passou em 2026-07-22.
    expect(ultimoAniversarioDeRenovacao(contrato({ ultima_renovacao: "2025-03-15" }))).toEqual({
      competencia: "03/2026",
      data: "2026-03-15",
    });
  });

  it("usa a data de início quando não há renovação", () => {
    expect(ultimoAniversarioDeRenovacao(contrato({ data_inicio: "2024-01-05" }))).toEqual({
      competencia: "01/2026",
      data: "2026-01-05",
    });
  });

  it("retorna null quando a referência é futura", () => {
    expect(ultimoAniversarioDeRenovacao(contrato({ ultima_renovacao: "2027-01-01" }))).toBeNull();
  });
});

describe("contrato service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    contratosMocks.contratoRepo.save.mockImplementation(async (contrato) => ({
      ...contrato,
      id: contrato.id ?? "contract-2",
    }));
    contratosMocks.contratoRepo.maximum.mockResolvedValue(1);
    // Por padrão o cliente já possui contrato(s): não é o primeiro contrato.
    contratosMocks.contratoRepo.count.mockResolvedValue(1);
    contratosMocks.clienteRepo.save.mockImplementation(async (cliente) => cliente);
    contratosMocks.documentoRepo.findOne.mockResolvedValue(null);
    contratosMocks.documentoRepo.update.mockResolvedValue({ affected: 1 });
    contratosMocks.findOrCreateClienteByCnpj.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Cliente Teste",
    });
    // Grupo econômico: cliente isolado por padrão (nenhum membro aponta para ele).
    contratosMocks.clienteRepo.find.mockResolvedValue([]);
    contratosMocks.consultarCnpjSemBloquear.mockResolvedValue(null);
  });

  it("replaces the active contract and saves extracted clauses", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "antigo",
      valor_original: 500,
      valor_mensal: 500,
      instrucoes_de_cobranca: "Cobrar conforme orientação vigente.",
      extracao_bruta: {
        termosGerais: {
          items: [
            { campo: "objeto", valor_extraido: "original do documento" },
            { campo: "valor_original", valor_extraido: 500 },
            { campo: "regime_tributario", valor_extraido: "Lucro Presumido" },
            { campo: "endereco", valor_extraido: "Rua A, 123" },
            { campo: "representante", valor_extraido: "Maria Silva" },
          ],
        },
        valoresContratados: {
          items: [
            { campo: "numero_de_documentos", valor_extraido: 100 },
          ],
        },
        excedentes: {
          items: [
            {
              referencia: "documentos_fiscais",
              valor_extraido: 2,
              tipo_cobranca: "por_documento",
              quantidade_inicial: 10,
            },
          ],
        },
      },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", {
      campos_editados: {
        objeto: "mensal",
        valor_original: 1000,
        excedentes: [
          {
            campo: "excedentes",
            referencia: "documentos_fiscais",
            valor_extraido: 3,
            tipo_cobranca: "por_documento",
            quantidade_inicial: 20,
          },
        ],
      },
      edicoes: {
        valor_original: {
          campo: "valor_original",
          valor_original: 500,
          valor_editado: 1000,
        },
      },
      extracao_bruta: {
        termosGerais: {
          items: [
            { campo: "objeto", valor_extraido: "não deve ser usado" },
            { campo: "valor_original", valor_extraido: 9999 },
          ],
        },
      },
    }, "Maria Editora");

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.managerQuery).toHaveBeenCalledWith(
      expect.stringContaining("contrato_ativo = false"),
      ["client-1", "office-1"],
    );
    expect(contratosMocks.contratoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      cliente_id: "client-1",
      versao_do_contrato: 2,
      tipo_contrato: "mensal",
      valor_original: 1000,
      valor_mensal: 1000,
      edicoes: expect.objectContaining({
        valor_original: {
          campo: "valor_original",
          valor_original: 500,
          valor_editado: 1000,
          usuario_nome: "Maria Editora",
        },
      }),
      extracao_bruta: expect.objectContaining({
        termosGerais: expect.objectContaining({
          items: expect.arrayContaining([
            expect.objectContaining({ campo: "objeto", valor_extraido: "mensal" }),
          ]),
        }),
      }),
      valores_contratados: expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({ campo: "numero_de_documentos", valor_extraido: 100 }),
        ]),
      }),
      excedentes: expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({ referencia: "documentos_fiscais", valor_extraido: 3, quantidade_inicial: 20 }),
        ]),
      }),
    }));
    expect(contratosMocks.excRepo.save).toHaveBeenCalledTimes(1);
    expect(contratosMocks.excRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      referencia: "documentos_fiscais",
      quantidade_inicial: 20,
      valor: 3,
    }));
    expect(contratosMocks.clienteRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      id: "client-1",
      regime_tributario: "Lucro Presumido",
      endereco: "Rua A, 123",
      representante_legal: "Maria Silva",
      informacoes_gerais: expect.objectContaining({
        regime_tributario: "Lucro Presumido",
        endereco: "Rua A, 123",
        representante: "Maria Silva",
      }),
    }));
  });

  it("updates cliente regime and address when a revised contract has new values", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "antigo",
      valor_original: 500,
      valor_mensal: 500,
      instrucoes_de_cobranca: "Cobrar conforme instruções revisadas.",
      extracao_bruta: {
        termosGerais: {
          items: [
            { campo: "objeto", valor_extraido: "serviços" },
            { campo: "regime_tributario", valor_extraido: "Lucro Real" },
            { campo: "endereco", valor_extraido: "Rua Nova" },
            { campo: "representante", valor_extraido: "Novo Representante" },
          ],
        },
      },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: "Simples Nacional",
      endereco: "Rua Antiga",
      representante_legal: "Representante Atual",
      informacoes_gerais: { origem: "cadastro" },
    });

    const result = await updateContrato("office-1", "contract-1", {});

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.clienteRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      id: "client-1",
      regime_tributario: "Lucro Real",
      endereco: "Rua Nova",
      representante_legal: "Representante Atual",
      informacoes_gerais: expect.objectContaining({
        origem: "cadastro",
        regime_tributario: "Lucro Real",
        endereco: "Rua Nova",
        representante: "Novo Representante",
      }),
    }));
  });

  it("schedules billing reconsolidation after confirming an extracted contract", async () => {
    const setImmediateSpy = vi
      .spyOn(global, "setImmediate")
      .mockImplementation((() => undefined) as typeof setImmediate);
    contratosMocks.getDocumentoById.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: "client-1",
      dados_extraidos_contrato: {
        idArquivo: "doc-1",
        termosGerais: {
          items: [
            { campo: "cnpj_cliente", valor_extraido: "11222333000144" },
            { campo: "razao_social", valor_extraido: "Cliente Teste" },
            { campo: "objeto", valor_extraido: "Contabilidade" },
            { campo: "valor_original", valor_extraido: 1000 },
          ],
        },
        valoresContratados: {
          items: [{ campo: "numero_de_documentos", valor_extraido: 100 }],
        },
        excedentes: {
          items: [{ referencia: "documentos", valor_extraido: 2, quantidade_inicial: 100 }],
        },
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          arquivo_origem: "doc-1",
          tipo_contrato: "Contabilidade",
          valor_original: 1000,
          valor_mensal: 1000,
          instrucoes_de_cobranca: "Cobrar conforme contrato revisado.",
          valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 100 }] },
          excedentes: { items: [{ referencia: "documentos", valor_extraido: 2, quantidade_inicial: 100 }] },
        },
      },
    });
    contratosMocks.contratoRepo.find.mockResolvedValue([]);
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    try {
      const result = await confirmarContratoExtracted("office-1", "doc-1", {
        cnpj: "11222333000144",
      });

      expect(result).toEqual({ ok: true, contratoId: "contract-2", clienteId: "client-1" });
      // Reconsolidação de VACs existentes + backfill de competências com relatório
      // sem VAC (agora incondicional, não só no primeiro contrato do cliente).
      expect(setImmediateSpy).toHaveBeenCalledTimes(2);
    } finally {
      setImmediateSpy.mockRestore();
    }
  });

  it("also schedules consolidation of available competencias on the first contract", async () => {
    const setImmediateSpy = vi
      .spyOn(global, "setImmediate")
      .mockImplementation((() => undefined) as typeof setImmediate);
    contratosMocks.contratoRepo.count.mockResolvedValue(0);
    contratosMocks.getDocumentoById.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: "client-1",
      dados_extraidos_contrato: {
        idArquivo: "doc-1",
        termosGerais: {
          items: [
            { campo: "cnpj_cliente", valor_extraido: "11222333000144" },
            { campo: "razao_social", valor_extraido: "Cliente Teste" },
            { campo: "objeto", valor_extraido: "Contabilidade" },
            { campo: "valor_original", valor_extraido: 1000 },
          ],
        },
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          arquivo_origem: "doc-1",
          tipo_contrato: "Contabilidade",
          valor_original: 1000,
          valor_mensal: 1000,
          instrucoes_de_cobranca: "Cobrar conforme contrato revisado.",
        },
      },
    });
    contratosMocks.contratoRepo.find.mockResolvedValue([]);
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      razao_social: "Cliente 11222333000144",
      nome_fantasia: null,
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    try {
      const result = await confirmarContratoExtracted("office-1", "doc-1", {
        cnpj: "11222333000144",
      });

      expect(result).toEqual({ ok: true, contratoId: "contract-2", clienteId: "client-1" });
      // 1) reconsolidação por contrato + 2) consolidação das competências disponíveis
      expect(setImmediateSpy).toHaveBeenCalledTimes(2);
    } finally {
      setImmediateSpy.mockRestore();
    }
  });

  it("still confirms an extracted contract when the CNPJ lookup is unavailable", async () => {
    // consultarCnpjSemBloquear já absorve 404/indisponibilidade e devolve null — é assim que uma
    // falha real da consulta se manifesta para quem chama. A confirmação do contrato não deve falhar.
    contratosMocks.consultarCnpjSemBloquear.mockResolvedValue(null);
    contratosMocks.getDocumentoById.mockResolvedValue({
      id: "doc-1",
      escritorio_id: "office-1",
      cliente_id: "client-1",
      dados_extraidos_contrato: {
        idArquivo: "doc-1",
        termosGerais: {
          items: [
            { campo: "cnpj_cliente", valor_extraido: "11222333000144" },
            { campo: "razao_social", valor_extraido: "Cliente Teste" },
            { campo: "objeto", valor_extraido: "Contabilidade" },
            { campo: "valor_original", valor_extraido: 1000 },
          ],
        },
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          arquivo_origem: "doc-1",
          tipo_contrato: "Contabilidade",
          valor_original: 1000,
          valor_mensal: 1000,
          instrucoes_de_cobranca: "Cobrar conforme contrato revisado.",
        },
      },
    });
    contratosMocks.contratoRepo.find.mockResolvedValue([]);
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await confirmarContratoExtracted("office-1", "doc-1", { cnpj: "11222333000144" });

    expect(result).toEqual({ ok: true, contratoId: "contract-2", clienteId: "client-1" });
  });

  it("still creates a manual contract when the CNPJ lookup is unavailable", async () => {
    contratosMocks.consultarCnpjSemBloquear.mockResolvedValue(null);
    contratosMocks.contratoRepo.find.mockResolvedValue([]);

    const result = await criarContratoManual("office-1", {
      cnpj: "11222333000144",
      items: [{ campo: "instrucoes_de_cobranca", valor_extraido: "Cobrar via boleto mensal." }],
    });

    expect(result).toEqual({ ok: true, contratoId: "contract-2", clienteId: "client-1" });
    expect(contratosMocks.consultarCnpjSemBloquear).toHaveBeenCalledWith("11222333000144");
  });

  it("still updates a contract when the CNPJ lookup is unavailable", async () => {
    contratosMocks.consultarCnpjSemBloquear.mockResolvedValue(null);
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "mensal",
      valor_original: 500,
      valor_mensal: 500,
      instrucoes_de_cobranca: "Cobrar mensalidade fixa conforme contrato vigente.",
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      cnpj: "11222333000144",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", { campos_editados: {} });

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    // A leitura leve pré-transação também deve ter consultado o CNPJ do cliente.
    expect(contratosMocks.consultarCnpjSemBloquear).toHaveBeenCalledWith("11222333000144");
  });

  it("maps reviewed UI fields to persistence fields when editing an existing contract", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "antigo",
      valor_original: 500,
      valor_mensal: 500,
      extracao_bruta: {
        termosGerais: {
          items: [
            { campo: "objeto", valor_extraido: "antigo" },
            { campo: "valor_original", valor_extraido: 500 },
            { campo: "periodicidade_reajuste", valor_extraido: "anual" },
          ],
        },
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          tipo_contrato: "antigo",
          valor_original: 500,
          valor_mensal: 500,
        },
      },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", {
      campos_editados: {
        objeto: "novo objeto revisado",
        valor_original: 750,
        data_emissao: "2026-05-08",
        data_inicio: "2026-06-01",
        data_termino: "2027-05-31",
        ultima_renovacao: "2026-06-01",
        dia_vencimento: "10",
        mes_vencimento: "6",
        inicio_faturamento: "2026-06-01",
        indice_reajuste: "IPCA",
        periodicidade_reajuste: "mensal",
        desconto_por_adimplencia: "5%",
        multa_por_inadimplencia: "2%",
        instrucoes_de_cobranca: "Valor fixo mensal por serviço contratado, sem excedentes.",
        adicional_anual: '[{"descricao":"13a mensalidade","valor":750}]',
        arquivo_origem: "contrato-revisado.pdf",
      },
    });

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.contratoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      cliente_id: "client-1",
      versao_do_contrato: 2,
      tipo_contrato: "novo objeto revisado",
      valor_original: 750,
      valor_mensal: 750,
      data_emissao: "2026-05-08",
      data_inicio: "2026-06-01",
      data_termino: "2027-05-31",
      ultima_renovacao: "2026-06-01",
      dia_vencimento: 10,
      mes_vencimento: "6",
      inicio_faturamento: "2026-06-01",
      indice_reajuste: "IPCA",
      desconto_por_adimplencia: "5%",
      multa_por_inadimplencia: "2%",
      instrucoes_de_cobranca: "Valor fixo mensal por serviço contratado, sem excedentes.",
      adicional_anual: [{ descricao: "13a mensalidade", valor: 750 }],
      arquivo_origem: "contrato-revisado.pdf",
      extracao_bruta: expect.objectContaining({
        termosGerais: expect.objectContaining({
          items: expect.arrayContaining([
            expect.objectContaining({ campo: "periodicidade_reajuste", valor_extraido: "mensal" }),
          ]),
        }),
      }),
      payload_normalizado_ui: expect.objectContaining({
        payloadInsercaoDb: expect.objectContaining({
          tipo_contrato: "novo objeto revisado",
          valor_original: 750,
          valor_mensal: 750,
          data_emissao: "2026-05-08",
          data_inicio: "2026-06-01",
          data_termino: "2027-05-31",
          ultima_renovacao: "2026-06-01",
          dia_vencimento: 10,
          mes_vencimento: "6",
          inicio_faturamento: "2026-06-01",
          indice_reajuste: "IPCA",
          desconto_por_adimplencia: "5%",
          multa_por_inadimplencia: "2%",
          instrucoes_de_cobranca: "Valor fixo mensal por serviço contratado, sem excedentes.",
          adicional_anual: [{ descricao: "13a mensalidade", valor: 750 }],
          arquivo_origem: "contrato-revisado.pdf",
          extracao_bruta: expect.objectContaining({
            termosGerais: expect.objectContaining({
              items: expect.arrayContaining([
                expect.objectContaining({ campo: "periodicidade_reajuste", valor_extraido: "mensal" }),
              ]),
            }),
          }),
        }),
      }),
    }));
  });

  it("persists edited contracted values inside the JSON snapshots", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "mensal",
      valor_original: 500,
      valor_mensal: 500,
      instrucoes_de_cobranca: "Cobrar mensalidade fixa e excedentes revisados.",
      extracao_bruta: {
        termosGerais: {
          items: [
            { campo: "objeto", valor_extraido: "mensal" },
          ],
        },
        valoresContratados: {
          items: [
            { campo: "numero_de_documentos", valor_extraido: 100 },
            { campo: "numero_de_colaboradores", valor_extraido: 10 },
          ],
        },
      },
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          tipo_contrato: "mensal",
          valor_original: 500,
          valor_mensal: 500,
          extracao_bruta: {
            idArquivo: "doc-1",
            valoresContratados: {
              items: [
                { campo: "numero_de_documentos", valor_extraido: 100 },
                { campo: "numero_de_colaboradores", valor_extraido: 10 },
              ],
            },
          },
          valores_contratados: {
            items: [
              { campo: "numero_de_documentos", valor_extraido: 100 },
              { campo: "numero_de_colaboradores", valor_extraido: 10 },
            ],
          },
        },
      },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", {
      campos_editados: {
        numero_de_documentos: "250",
        numero_de_colaboradores: 25,
      },
    });

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.contratoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      valores_contratados: expect.objectContaining({
        items: expect.arrayContaining([
          expect.objectContaining({ campo: "numero_de_documentos", valor_extraido: 250 }),
          expect.objectContaining({ campo: "numero_de_colaboradores", valor_extraido: 25 }),
        ]),
      }),
      extracao_bruta: expect.objectContaining({
        valoresContratados: expect.objectContaining({
          items: expect.arrayContaining([
            expect.objectContaining({ campo: "numero_de_documentos", valor_extraido: 250 }),
            expect.objectContaining({ campo: "numero_de_colaboradores", valor_extraido: 25 }),
          ]),
        }),
      }),
      payload_normalizado_ui: expect.objectContaining({
        payloadInsercaoDb: expect.objectContaining({
          valores_contratados: expect.objectContaining({
            items: expect.arrayContaining([
              expect.objectContaining({ campo: "numero_de_documentos", valor_extraido: 250 }),
              expect.objectContaining({ campo: "numero_de_colaboradores", valor_extraido: 25 }),
            ]),
          }),
        }),
      }),
    }));
  });

  it("copies valor_original to valor_mensal in the saved details payload when monthly value is missing", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "mensal",
      valor_original: 500,
      valor_mensal: null,
      instrucoes_de_cobranca: "Cobrar mensalidade fixa conforme valor original.",
      payload_normalizado_ui: {
        payloadInsercaoDb: {
          tipo_contrato: "mensal",
          valor_original: 500,
          valor_mensal: null,
          instrucoes_de_cobranca: "Cobrar mensalidade fixa conforme valor original.",
          valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 100 }] },
          excedentes: { items: [{ campo: "excedentes", referencia: "documentos", valor_extraido: 2, tipo_cobranca: "por_documento" }] },
        },
      },
      valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 100 }] },
      excedentes: { items: [{ campo: "excedentes", referencia: "documentos", valor_extraido: 2, tipo_cobranca: "por_documento" }] },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", { campos_editados: {} });

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.contratoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      valor_original: 500,
      valor_mensal: 500,
      payload_normalizado_ui: expect.objectContaining({
        payloadInsercaoDb: expect.objectContaining({
          valor_original: 500,
          valor_mensal: 500,
        }),
      }),
    }));
  });

  it("carries ultima_renovacao from the existing contract into a revised version", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      cliente_id: "client-1",
      escritorio_id: "office-1",
      tipo_contrato: "mensal",
      valor_original: 500,
      valor_mensal: 500,
      data_inicio: "2024-05-01",
      data_termino: "indeterminado",
      ultima_renovacao: "2026-05-01",
      instrucoes_de_cobranca: "Cobrar mensalidade fixa conforme contrato vigente.",
      valores_contratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 100 }] },
      excedentes: { items: [{ campo: "excedentes", referencia: "documentos", valor_extraido: 2, tipo_cobranca: "por_documento" }] },
    });
    contratosMocks.clienteRepo.findOne.mockResolvedValue({
      id: "client-1",
      escritorio_id: "office-1",
      regime_tributario: null,
      endereco: null,
      representante_legal: null,
      informacoes_gerais: null,
    });

    const result = await updateContrato("office-1", "contract-1", { campos_editados: {} });

    expect(result).toEqual({ ok: true, contratoId: "contract-2" });
    expect(contratosMocks.contratoRepo.save).toHaveBeenCalledWith(expect.objectContaining({
      ultima_renovacao: "2026-05-01",
      payload_normalizado_ui: null,
    }));
  });

  it("returns ultima_renovacao in the contract list projection", async () => {
    contratosMocks.contratoRepo.find.mockResolvedValue([
      {
        id: "contract-1",
        numero_contrato: undefined,
        versao_do_contrato: 1,
        contrato_ativo: true,
        cliente: { id: "client-1", razao_social: "Cliente LTDA", cnpj: "123" },
        data_inicio: "2024-05-01",
        data_termino: "indeterminado",
        ultima_renovacao: "2026-05-01",
        indice_reajuste: "IPCA",
        valor_original: 500,
        valor_mensal: 500,
        arquivo_origem: "doc-1",
        tipo_contrato: "mensal",
        instrucoes_de_cobranca: "Cobrar mensalidade fixa.",
        created_at: new Date("2026-05-14T00:00:00Z"),
      },
    ]);

    const result = await listContratos("office-1");

    expect(result[0]).toMatchObject({
      id: "contract-1",
      vigencia_inicio: "2024-05-01",
      vigencia_fim: "indeterminado",
      ultima_renovacao: "2026-05-01",
    });
  });

  it("returns null when the contract does not exist", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue(null);

    const result = await updateContrato("office-1", "missing", {});

    expect(result).toBeNull();
  });

  it("flags cadastro_ia as true when the linked documento came from the AI text channel", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      escritorio_id: "office-1",
      arquivo_origem: "doc-ia-1",
    });
    contratosMocks.documentoRepo.findOne.mockResolvedValue({
      id: "doc-ia-1",
      escritorio_id: "office-1",
      mime_type: "text/plain",
      dados_extraidos_contrato: null,
    });

    const result = await getContratoById("office-1", "contract-1");

    expect(result).toEqual(expect.objectContaining({ cadastro_ia: true }));
  });

  it("flags cadastro_ia as false for a contract linked to a regular PDF documento", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      escritorio_id: "office-1",
      arquivo_origem: "doc-pdf-1",
    });
    contratosMocks.documentoRepo.findOne.mockResolvedValue({
      id: "doc-pdf-1",
      escritorio_id: "office-1",
      mime_type: "application/pdf",
      dados_extraidos_contrato: null,
    });

    const result = await getContratoById("office-1", "contract-1");

    expect(result).toEqual(expect.objectContaining({ cadastro_ia: false }));
  });

  it("flags cadastro_ia as false when the contract has no linked documento", async () => {
    contratosMocks.contratoRepo.findOne.mockResolvedValue({
      id: "contract-1",
      escritorio_id: "office-1",
      arquivo_origem: null,
      extracao_bruta: null,
    });

    const result = await getContratoById("office-1", "contract-1");

    expect(result).toEqual(expect.objectContaining({ cadastro_ia: false }));
  });

  it("fetches the active contract by CNPJ with RLS scope", async () => {
    const getOne = vi.fn().mockResolvedValue({
      id: "contract-1",
      cliente: { id: "client-1", cnpj: "11.222.333/0001-44", razao_social: "Cliente Teste" },
      documentos_anexos: [
        {
          id: "anexo-1",
          documento_id: "doc-aditivo",
          tipo_documento_contratual: "aditivo",
          created_at: new Date("2026-07-01T00:00:00Z"),
        },
      ],
    });
    const qb = {
      innerJoinAndSelect: vi.fn().mockReturnThis(),
      leftJoinAndSelect: vi.fn().mockReturnThis(),
      where: vi.fn().mockReturnThis(),
      andWhere: vi.fn().mockReturnThis(),
      orderBy: vi.fn().mockReturnThis(),
      getOne,
    };
    contratosMocks.contratoRepo.createQueryBuilder.mockReturnValue(qb);

    const result = await getContratoAtivoByCnpj("office-1", "11.222.333/0001-44");

    expect(result).toMatchObject({
      id: "contract-1",
      documentos_anexos: [
        {
          documento_id: "doc-aditivo",
          tipo_documento_contratual: "aditivo",
        },
      ],
    });
    expect(qb.where).toHaveBeenCalledWith("contrato.escritorio_id = :escritorioId", { escritorioId: "office-1" });
    expect(qb.andWhere).toHaveBeenCalledWith("cliente.cnpj = :cnpj", {
      cnpj: "11.222.333/0001-44",
    });
  });

  it("normalizes the review payload before persistence when valor_mensal is absent", () => {
    expect(copyValorOriginalToValorMensalWhenMissing({
      valor_original: "1.250,50",
      valor_mensal: null,
    })).toEqual({
      valor_original: "1.250,50",
      valor_mensal: 1250.5,
    });
  });
});
