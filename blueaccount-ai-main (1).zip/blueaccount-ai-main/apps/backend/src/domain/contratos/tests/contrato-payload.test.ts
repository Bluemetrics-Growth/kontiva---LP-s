import { describe, expect, it } from "vitest";
import {
  applyCamposEditadosToPayloadInsercaoDb,
  buildContratoPersistenceDraft,
  getField,
  normalizarDataContrato,
  resolverUltimaRenovacaoInicial,
} from "../contrato-payload.js";

describe("resolverUltimaRenovacaoInicial", () => {
  it("mantém apenas a renovação ISO válida quando informada", () => {
    expect(resolverUltimaRenovacaoInicial("2026-01-10")).toBe("2026-01-10");
  });

  it("não cai para a data de início quando não há renovação", () => {
    expect(resolverUltimaRenovacaoInicial(null)).toBeNull();
    expect(resolverUltimaRenovacaoInicial("  ")).toBeNull();
  });

  it("retorna null quando não há renovação nem início", () => {
    expect(resolverUltimaRenovacaoInicial(null)).toBeNull();
    expect(resolverUltimaRenovacaoInicial("")).toBeNull();
  });
});

describe("datas de contrato", () => {
  it("mantém somente datas ISO de calendário válidas", () => {
    expect(normalizarDataContrato("2024-02-29")).toBe("2024-02-29");
    expect(normalizarDataContrato("2025-02-29")).toBeNull();
    expect(normalizarDataContrato("31/01/2025")).toBeNull();
    expect(normalizarDataContrato("2025-13-01")).toBeNull();
  });

  it("não preenche ultima_renovacao a partir de data_inicio", () => {
    const draft = buildContratoPersistenceDraft({
      payload: {
        termosGerais: {
          items: [{ campo: "data_inicio", valor_extraido: "2025-03-01" }],
        },
      },
      documentoId: "doc-1",
    });

    expect(draft.data_inicio).toBe("2025-03-01");
    expect(draft.ultima_renovacao).toBeNull();
  });

  it("preserva a renovação explícita do payload", () => {
    const draft = buildContratoPersistenceDraft({
      payload: {
        termosGerais: {
          items: [
            { campo: "data_inicio", valor_extraido: "2025-03-01" },
            { campo: "ultima_renovacao", valor_extraido: "2026-03-01" },
          ],
        },
      },
      documentoId: "doc-1",
    });

    expect(draft.ultima_renovacao).toBe("2026-03-01");
  });

  it("converte datas inválidas de extração e edição para null", () => {
    const draft = buildContratoPersistenceDraft({
      payload: { termosGerais: { items: [
        { campo: "data_inicio", valor_extraido: "01/03/2025" },
        { campo: "data_emissao", valor_extraido: "2025-02-30" },
        { campo: "inicio_faturamento", valor_extraido: "2025-03-01" },
      ] } },
      documentoId: "doc-1",
    });
    expect(draft).toMatchObject({ data_inicio: null, data_emissao: null, inicio_faturamento: "2025-03-01" });

    expect(applyCamposEditadosToPayloadInsercaoDb(draft, { data_inicio: "2025-04-31" }).data_inicio).toBeNull();
  });

  it("respeita uma limpeza explícita de data mesmo quando há fallback", () => {
    const draft = buildContratoPersistenceDraft({
      payload: { termosGerais: { items: [] } },
      documentoId: "doc-1",
      camposEditados: { data_inicio: "" },
      fallback: { data_inicio: "2025-03-01" } as never,
    });
    expect(draft.data_inicio).toBeNull();
  });
});

describe("fallback de fonte em campo de lista fechada", () => {
  const item = (campo: string, valor_extraido: unknown, fonte?: string) =>
    [{ campo, valor_extraido, ...(fonte === undefined ? {} : { fonte }) }] as never;

  it("ignora a cláusula quando a extração não resolveu o índice de reajuste", () => {
    expect(
      getField(item("indice_reajuste", null, "IPCA/IBGE, todo mês de maio, iniciando-se em maio/2027"), "indice_reajuste"),
    ).toBe("");
  });

  it("ignora a cláusula quando a extração não resolveu o regime tributário", () => {
    expect(
      getField(
        item("regime_tributario", null, "Empresa tributada pelo Lucro Presumido (premissa adotada nesta minuta)."),
        "regime_tributario",
      ),
    ).toBe("");
  });

  it("aceita a fonte quando ela é, ela mesma, um item da lista", () => {
    expect(getField(item("indice_reajuste", null, "IGPM"), "indice_reajuste")).toBe("IGPM");
    expect(getField(item("regime_tributario", null, " simples nacional "), "regime_tributario")).toBe("simples nacional");
  });

  it("mantém o fallback de fonte em campo de texto livre", () => {
    expect(getField(item("instrucoes_de_cobranca", null, "Boleto até o dia 10"), "instrucoes_de_cobranca")).toBe(
      "Boleto até o dia 10",
    );
    expect(getField(item("mes_vencimento", null, "mês subsequente à competência"), "mes_vencimento")).toBe(
      "mês subsequente à competência",
    );
  });

  it("não usa a fonte quando há valor extraído, mesmo em campo de lista fechada", () => {
    expect(getField(item("indice_reajuste", "INPC", "correção monetária pelo INPC"), "indice_reajuste")).toBe("INPC");
  });

  it("não grava a cláusula de reajuste no draft de persistência", () => {
    const draft = buildContratoPersistenceDraft({
      payload: {
        termosGerais: {
          items: item("indice_reajuste", null, "reajustado anualmente pelo IPCA/IBGE"),
        },
      },
      documentoId: "doc-1",
    });
    expect(draft.indice_reajuste).toBeNull();
  });
});
