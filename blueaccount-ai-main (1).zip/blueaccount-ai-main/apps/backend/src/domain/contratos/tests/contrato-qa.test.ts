import { describe, expect, it } from "vitest";
import { avaliarQualidadeExtracaoContrato } from "../contrato-qa.js";
import type { ContractExtractionPayload } from "../contrato-payload.js";

const payloadCompleto: ContractExtractionPayload = {
  termosGerais: {
    items: [
      { campo: "cnpj_cliente", valor_extraido: "12.345.678/0001-99" },
      { campo: "objeto", valor_extraido: "Contabilidade mensal" },
      { campo: "valor_original", valor_extraido: 1500 },
      { campo: "data_inicio", valor_extraido: "2026-01-01" },
    ],
  },
  valoresContratados: { items: [{ campo: "numero_de_documentos", valor_extraido: 50 }] },
  excedentes: { items: [] },
};

describe("avaliarQualidadeExtracaoContrato", () => {
  it("não marca suspeita quando a extração tem campos-chave preenchidos", () => {
    const qa = avaliarQualidadeExtracaoContrato(payloadCompleto);
    expect(qa.suspeita).toBe(false);
    expect(qa.motivo).toBeNull();
    expect(qa.campos_preenchidos).toBe(5);
    expect(qa.total_campos).toBe(5);
  });

  it("marca suspeita quando quase nenhum campo foi extraído", () => {
    const qa = avaliarQualidadeExtracaoContrato({
      termosGerais: {
        items: [
          { campo: "cnpj_cliente", valor_extraido: null },
          { campo: "objeto", valor_extraido: "" },
          { campo: "valor_original", valor_extraido: null },
          { campo: "data_inicio", valor_extraido: "2026-01-01" },
        ],
      },
      valoresContratados: { items: [] },
      excedentes: { items: [] },
    });
    expect(qa.suspeita).toBe(true);
    expect(qa.motivo).toMatch(/Quase nenhum campo/);
    expect(qa.campos_preenchidos).toBe(1);
    expect(qa.total_campos).toBe(4);
  });

  it("marca suspeita quando extração payload está vazia", () => {
    const qa = avaliarQualidadeExtracaoContrato({});
    expect(qa.suspeita).toBe(true);
    expect(qa.campos_preenchidos).toBe(0);
    expect(qa.total_campos).toBe(0);
  });

  it("marca suspeita quando nenhum campo-chave de contrato foi extraído", () => {
    const qa = avaliarQualidadeExtracaoContrato({
      termosGerais: {
        items: [
          { campo: "data_inicio", valor_extraido: "2026-01-01" },
          { campo: "dia_vencimento", valor_extraido: 10 },
          { campo: "indice_reajuste", valor_extraido: "IPCA" },
        ],
      },
      valoresContratados: { items: [] },
      excedentes: { items: [] },
    });
    expect(qa.suspeita).toBe(true);
    expect(qa.motivo).toMatch(/campo essencial/);
  });
});
