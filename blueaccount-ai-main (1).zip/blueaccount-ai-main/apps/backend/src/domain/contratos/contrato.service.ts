import { runQueryWithRls } from "../../database/data-source.js";
import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import { Cliente } from "../../database/modules/tenant/entities/cliente.entity.js";
import { ClausulasExcedentes } from "../../database/modules/tenant/entities/clausulas-excedentes.entity.js";
import { ContratoDocumentoAnexo } from "../../database/modules/tenant/entities/contrato-documento-anexo.entity.js";
import { Documento } from "../../database/modules/tenant/entities/documento.entity.js";
import type { TipoDocumentoContratual } from "../../database/modules/tenant/entities/documento.entity.js";
import { registrarEdicoesManuais, type EdicoesManuais } from "../edicoes.js";
import { round2 } from "../dinheiro.js";
import { Brackets, type Repository } from "typeorm";
import { fillClienteNullFieldsFromContrato, findOrCreateClienteByCnpj, normalizarCnpj, type ClienteDadosContratoInput } from "../clientes/cliente.service.js";
import { validarAtivacaoContrato } from "../clientes/grupo.service.js";
import { consultarCnpjSemBloquear } from "../fornecedores/consulta-cnpj.service.js";
import { normalizarRegimeTributario } from "../clientes/regime-tributario.js";
import { getDocumentoById } from "../documentos/documentos.service.js";
import { isAiSubmittedTextDocumento } from "../documentos/documentos-ocr.js";
import { assertBillingComplexityActive } from "../complexidades-cobranca/complexidade-cobranca.service.js";
import {
  consolidarCompetencia,
  scheduleConsolidacaoCompetenciasComRelatorio,
  scheduleReconsolidacaoClienteContrato,
} from "../valores-a-cobrar/consolidar.service.js";
import { ValoresACobrar } from "../../database/modules/tenant/entities/valores-a-cobrar.entity.js";
import { IndiceNaoPublicadoError, normalizarIndiceReajuste, obterIndiceAcumuladoDozeMeses } from "./indice-inflacao.service.js";
import {
  applyCamposEditadosToPayloadInsercaoDb,
  buildContratoDisplayFields,
  buildContratoPersistenceDraft,
  buildExcedentesSnapshot,
  buildValoresContratadosSnapshot,
  copyValorOriginalToValorMensalWhenMissing,
  montarPayloadInsercaoDbContrato,
  type ContractExtractionPayload,
  type ExcedenteItem,
  type ExtractionItem,
  getReviewedField,
  normalizarDataContrato,
  normalizeContractExtractionPayload,
  resolverUltimaRenovacaoInicial,
} from "./contrato-payload.js";
import {
  bloquearVacsAnterioresARenovacao,
  destravarVacsAposRetroacaoRenovacao,
  renovacaoAvancou,
  renovacaoRetroagiu,
} from "../valores-a-cobrar/bloqueio-contrato-renovacao.js";
import {
  buildPaginatedResult,
  normalizePagination,
  type PaginationInput,
} from "../pagination.js";

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function isTipoAnexoContrato(value: unknown): value is TipoDocumentoContratual {
  return value === "aditivo" || value === "renovacao" || value === "cancelamento" || value === "correcao";
}

function getTipoDocumentoContratualFromPayload(payload: ContractExtractionPayload): TipoDocumentoContratual {
  return payload.tipoDocumentoContratual ?? "contrato_novo";
}

function getCamposEditados(input: Record<string, unknown>): Record<string, unknown> {
  return isRecord(input.campos_editados) ? input.campos_editados : {};
}

function getPayloadInsercaoDb(payloadNormalizadoUi: unknown): Record<string, unknown> | null {
  if (!isRecord(payloadNormalizadoUi)) return null;
  return isRecord(payloadNormalizadoUi.payloadInsercaoDb) ? payloadNormalizadoUi.payloadInsercaoDb : null;
}

function withPayloadInsercaoDb(
  payloadNormalizadoUi: unknown,
  payloadInsercaoDb: Record<string, unknown>,
): Record<string, unknown> | null {
  if (!isRecord(payloadNormalizadoUi)) return null;
  return {
    ...payloadNormalizadoUi,
    payloadInsercaoDb,
  };
}

function normalizeDataTermino(value: unknown): string {
  if (typeof value !== "string") return "indeterminado";
  const trimmed = value.trim();
  if (!trimmed) return "indeterminado";

  const normalized = trimmed
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();

  if (
    normalized.includes("indeterminado") ||
    normalized.includes("sem prazo") ||
    normalized.includes("sem termino")
  ) {
    return "indeterminado";
  }

  return trimmed;
}

function applyPersistencePayload(contrato: Contrato, payload: Record<string, unknown>): void {
  contrato.tipo_contrato = (payload.tipo_contrato as string | null | undefined) ?? null;
  contrato.valor_original = (payload.valor_original as number | null | undefined) ?? null;
  contrato.valor_mensal = (payload.valor_mensal as number | null | undefined) ?? null;
  contrato.complexidade_cobranca = Number(payload.complexidade_cobranca ?? 1) || 1;
  contrato.indice_reajuste = (payload.indice_reajuste as string | null | undefined) ?? null;
  contrato.data_inicio = normalizarDataContrato(payload.data_inicio);
  contrato.data_termino = normalizeDataTermino(payload.data_termino);
  // Renovação é opcional; o reajuste usa data_inicio quando não houver renovação.
  contrato.ultima_renovacao = resolverUltimaRenovacaoInicial(
    payload.ultima_renovacao as string | null | undefined,
  );
  contrato.data_emissao = normalizarDataContrato(payload.data_emissao);
  contrato.dia_vencimento = (payload.dia_vencimento as number | null | undefined) ?? null;
  contrato.mes_vencimento = (payload.mes_vencimento as string | null | undefined) ?? null;
  contrato.inicio_faturamento = normalizarDataContrato(payload.inicio_faturamento);
  contrato.data_ultimo_reajuste = normalizarDataContrato(contrato.data_ultimo_reajuste);
  contrato.desconto_por_adimplencia = (payload.desconto_por_adimplencia as string | null | undefined) ?? null;
  contrato.multa_por_inadimplencia = (payload.multa_por_inadimplencia as string | null | undefined) ?? null;
  contrato.instrucoes_de_cobranca = (payload.instrucoes_de_cobranca as string | null | undefined) ?? null;
  contrato.adicional_anual = (payload.adicional_anual as Record<string, unknown>[] | null | undefined) ?? null;
  contrato.arquivo_origem = (payload.arquivo_origem as string | null | undefined) ?? null;
  contrato.extracao_bruta = (payload.extracao_bruta as Record<string, unknown> | null | undefined) ?? null;
  contrato.valores_contratados = (payload.valores_contratados as Record<string, unknown> | null | undefined) ?? null;
  contrato.excedentes = (payload.excedentes as Record<string, unknown> | null | undefined) ?? null;

  if (contrato.valor_mensal == null && contrato.valor_original != null) {
    contrato.valor_mensal = contrato.valor_original;
  }
}

function hasAvailableContractSnapshot(value: unknown): boolean {
  if (!isRecord(value)) return false;
  if (Array.isArray(value.items)) return value.items.length > 0;
  return Object.keys(value).length > 0;
}

function documentosAnexosResumo(contrato: { documentos_anexos?: ContratoDocumentoAnexo[] | null }) {
  return (contrato.documentos_anexos ?? []).map((anexo) => ({
    id: anexo.id,
    documento_id: anexo.documento_id,
    tipo_documento_contratual: anexo.tipo_documento_contratual,
    created_at: anexo.created_at,
  }));
}

async function registrarDocumentoAnexoContrato(
  manager: Parameters<Parameters<typeof runQueryWithRls>[1]>[0],
  input: {
    escritorioId: string;
    contratoId: string;
    documentoId: string;
    tipoDocumentoContratual: TipoDocumentoContratual;
  },
): Promise<void> {
  if (!isTipoAnexoContrato(input.tipoDocumentoContratual)) return;
  await manager
    .createQueryBuilder()
    .insert()
    .into(ContratoDocumentoAnexo)
    .values({
      escritorio_id: input.escritorioId,
      contrato_id: input.contratoId,
      documento_id: input.documentoId,
      tipo_documento_contratual: input.tipoDocumentoContratual,
    })
    .orIgnore()
    .execute();
}

function assertCobrancaInstructionsWhenNeeded(payload: Record<string, unknown>): void {
  const instrucoesCobranca = String(payload.instrucoes_de_cobranca ?? "").trim();
  const hasValoresContratados = hasAvailableContractSnapshot(payload.valores_contratados);
  const hasExcedentes = hasAvailableContractSnapshot(payload.excedentes);

  if ((!hasValoresContratados || !hasExcedentes) && !instrucoesCobranca) {
    throw new Error("Instruções de cobrança são obrigatórias quando valores contratados ou excedentes não estiverem disponíveis");
  }
}

async function getNextContratoVersion(
  contratoRepo: Repository<Contrato>,
  escritorioId: string,
  clienteId: string,
): Promise<number> {
  const currentMax = await contratoRepo.maximum("versao_do_contrato", {
    escritorio_id: escritorioId,
    cliente_id: clienteId,
  });
  const parsedMax = Number(currentMax ?? 0);
  return (Number.isFinite(parsedMax) ? parsedMax : 0) + 1;
}

const contratoPersistenceTermFields = new Set([
  "objeto",
  "tipo_contrato",
  "valor_original",
  "valor_mensal",
  "complexidade_cobranca",
  "indice_reajuste",
  "data_inicio",
  "data_termino",
  "ultima_renovacao",
  "data_emissao",
  "dia_vencimento",
  "mes_vencimento",
  "inicio_faturamento",
  "desconto_por_adimplencia",
  "multa_por_inadimplencia",
  "instrucoes_de_cobranca",
  "periodicidade_reajuste",
  "ultimo_reajuste",
  "proximo_reajuste",
]);

const clienteKnownGeneralFields = [
  "cnpj_cliente",
  "nome_cliente",
  "razao_social",
  "nome_fantasia",
  "regime_tributario",
  "endereco",
  "representante",
  "representante_legal",
];

function buildClienteDadosContrato(input: Record<string, unknown>, termos: ExtractionItem[]): ClienteDadosContratoInput {
  const informacoesGerais: Record<string, unknown> = {};

  // Normaliza uma vez e reusa: o regime vai tanto para a coluna do cliente quanto
  // para o snapshot em informacoes_gerais, e os dois não podem divergir.
  const regimeTributario = normalizarRegimeTributario(getReviewedField(input, termos, "regime_tributario"));

  for (const item of termos) {
    if (!item.campo || contratoPersistenceTermFields.has(item.campo)) continue;
    const value = item.campo === "regime_tributario" ? regimeTributario : getReviewedField(input, termos, item.campo);
    if (value) {
      informacoesGerais[item.campo] = value;
    }
  }

  for (const campo of clienteKnownGeneralFields) {
    const value = campo === "regime_tributario" ? regimeTributario : getReviewedField(input, termos, campo);
    if (value) {
      informacoesGerais[campo] = value;
    }
  }

  return {
    razao_social:
      getReviewedField(input, termos, "razao_social") ||
      getReviewedField(input, termos, "nome_cliente") ||
      null,
    nome_fantasia: getReviewedField(input, termos, "nome_fantasia") || null,
    regime_tributario: regimeTributario,
    endereco: getReviewedField(input, termos, "endereco") || null,
    representante_legal:
      getReviewedField(input, termos, "representante_legal") ||
      getReviewedField(input, termos, "representante") ||
      null,
    informacoes_gerais: Object.keys(informacoesGerais).length > 0 ? informacoesGerais : null,
  };
}

async function syncExcedentes(
  manager: Parameters<Parameters<typeof runQueryWithRls>[1]>[0],
  excedentes: ExcedenteItem[],
  contratoId: string,
  escritorioId: string,
) {
  const excRepo = manager.getRepository(ClausulasExcedentes);
  for (const exc of excedentes) {
    if (!exc.quantidade_inicial) continue;
    await excRepo.save(
      excRepo.create({
        escritorio_id: escritorioId,
        contrato_id: contratoId,
        referencia: exc.referencia,
        quantidade_inicial: exc.quantidade_inicial,
        valor: Number(exc.valor_extraido) || 0,
        tipo_cobranca: (exc.tipo_cobranca || "por_faixa") as "por_faixa" | "por_hora" | "por_funcionario" | "por_documento" | "por_edificio" | "por_obra" | "outro",
      }),
    );
  }
}

function getExcedentesItems(snapshot: unknown): ExcedenteItem[] | null {
  if (!isRecord(snapshot) || !Array.isArray(snapshot.items)) return null;
  return snapshot.items as ExcedenteItem[];
}

// ── Domain functions ──────────────────────────────────────────────────────────

export async function updateContrato(escritorioId: string, contratoId: string, input: Record<string, unknown>, usuarioNome?: string | null) {
  // Leitura leve, fora da transação principal, só para achar o CNPJ do cliente: a consulta de CNPJ
  // é uma chamada de rede e nunca pode acontecer dentro de uma transação RLS aberta.
  const clienteCnpjParaConsulta = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratoExistente = await manager.getRepository(Contrato).findOne({
      where: { id: contratoId, escritorio_id: escritorioId },
      select: { cliente_id: true },
    });
    if (!contratoExistente) return null;
    const clienteExistente = await manager.getRepository(Cliente).findOne({
      where: { id: contratoExistente.cliente_id, escritorio_id: escritorioId },
      select: { cnpj: true },
    });
    return clienteExistente?.cnpj ?? null;
  });
  const consulta = clienteCnpjParaConsulta ? await consultarCnpjSemBloquear(clienteCnpjParaConsulta) : null;

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratoRepo = manager.getRepository(Contrato);
    const contratoAntigo = await contratoRepo.findOne({
      where: { id: contratoId, escritorio_id: escritorioId },
    });
    if (!contratoAntigo) return null;

    await validarAtivacaoContrato(manager, escritorioId, contratoAntigo.cliente_id);

    await manager.query(
      `UPDATE contratos SET contrato_ativo = false WHERE cliente_id = $1 AND escritorio_id = $2 AND contrato_ativo = true`,
      [contratoAntigo.cliente_id, escritorioId],
    );

    const payload = contratoAntigo.extracao_bruta
      ? normalizeContractExtractionPayload(contratoAntigo.extracao_bruta as Record<string, unknown>)
      : undefined;
    const termos = payload?.termosGerais?.items ?? [];
    const excedentes = payload?.excedentes?.items ?? [];
    const documentoId =
      contratoAntigo.arquivo_origem ||
      payload?.documentoId ||
      payload?.idArquivo ||
      null;
    const persistenceDocumentoId = documentoId ?? contratoAntigo.id;
    const documento = documentoId
      ? await manager.getRepository(Documento).findOne({
          where: { id: documentoId, escritorio_id: escritorioId },
        })
      : null;

    const novoContrato = new Contrato();
    novoContrato.cliente_id = contratoAntigo.cliente_id;
    novoContrato.escritorio_id = escritorioId;
    novoContrato.contrato_ativo = true;
    novoContrato.versao_do_contrato = await getNextContratoVersion(
      contratoRepo,
      escritorioId,
      contratoAntigo.cliente_id,
    );
    const camposEditados = getCamposEditados(input);
    const payloadInsercaoDbBase = {
      ...montarPayloadInsercaoDbContrato(contratoAntigo),
      ...(
        getPayloadInsercaoDb(documento?.payload_normalizado_ui) ??
        getPayloadInsercaoDb(contratoAntigo.payload_normalizado_ui) ??
        (payload
          ? buildContratoPersistenceDraft({ payload, documentoId: persistenceDocumentoId, camposEditados, fallback: contratoAntigo })
          : {})
      ),
    };
    const payloadInsercaoDb = copyValorOriginalToValorMensalWhenMissing(
      applyCamposEditadosToPayloadInsercaoDb(payloadInsercaoDbBase, camposEditados),
    );
    payloadInsercaoDb.complexidade_cobranca = await assertBillingComplexityActive(
      payloadInsercaoDb.complexidade_cobranca ?? 1,
    );
    assertCobrancaInstructionsWhenNeeded(payloadInsercaoDb);
    applyPersistencePayload(novoContrato, payloadInsercaoDb);
    // Reajuste é idempotente por competência; uma edição manual não deve liberar
    // a aplicação do mesmo índice novamente sobre a nova versão.
    novoContrato.ultima_competencia_reajuste = contratoAntigo.ultima_competencia_reajuste;
    novoContrato.data_ultimo_reajuste = contratoAntigo.data_ultimo_reajuste;
    novoContrato.edicoes = registrarEdicoesManuais({
      edicoesAtuais: contratoAntigo.edicoes,
      edicoesRecebidas: input.edicoes,
      usuarioNome,
    });
    if (!novoContrato.extracao_bruta) {
      novoContrato.extracao_bruta = contratoAntigo.extracao_bruta;
    }
    if (!novoContrato.valores_contratados) {
      novoContrato.valores_contratados =
        contratoAntigo.valores_contratados ??
        (payload ? buildValoresContratadosSnapshot(payload) : null);
    }
    if (!novoContrato.excedentes) {
      novoContrato.excedentes =
        contratoAntigo.excedentes ??
        (payload ? buildExcedentesSnapshot(payload) : null);
    }
    novoContrato.arquivo_origem =
      (payloadInsercaoDb.arquivo_origem as string | null | undefined) ?? documentoId;
    novoContrato.payload_normalizado_ui =
      withPayloadInsercaoDb(documento?.payload_normalizado_ui, payloadInsercaoDb) ??
      withPayloadInsercaoDb(contratoAntigo.payload_normalizado_ui, payloadInsercaoDb);

    const novoContratoSalvo = await contratoRepo.save(novoContrato);

    // Renovação manual (a nova versão avança `ultima_renovacao`): congela os VACs
    // anteriores na versão que os gerou. Correções que não movem a data não travam.
    if (renovacaoAvancou(contratoAntigo.ultima_renovacao, novoContratoSalvo.ultima_renovacao)) {
      await bloquearVacsAnterioresARenovacao(manager, {
        escritorioId,
        clienteId: contratoAntigo.cliente_id,
        contratoAnteriorId: contratoAntigo.id,
        versaoAnterior: contratoAntigo.versao_do_contrato,
        novaDataRenovacao: novoContratoSalvo.ultima_renovacao ?? "",
      });
    } else if (renovacaoRetroagiu(contratoAntigo.ultima_renovacao, novoContratoSalvo.ultima_renovacao)) {
      // Correção retroagindo `ultima_renovacao`: destrava os VACs que ficam de
      // novo elegíveis, voltando-os a resolver pelo contrato ativo atual.
      await destravarVacsAposRetroacaoRenovacao(manager, {
        escritorioId,
        clienteId: contratoAntigo.cliente_id,
        novaDataRenovacao: novoContratoSalvo.ultima_renovacao ?? "",
        dataRenovacaoAnterior: contratoAntigo.ultima_renovacao ?? "",
      });
    }

    await syncExcedentes(
      manager,
      getExcedentesItems(payloadInsercaoDb.excedentes) ?? excedentes,
      novoContratoSalvo.id,
      escritorioId,
    );
    await fillClienteNullFieldsFromContrato(
      manager,
      escritorioId,
      novoContratoSalvo.cliente_id,
      buildClienteDadosContrato(input, termos),
      { consulta },
    );

    // Insumo alterado: contrato é insumo de cobrança mas não dispara consolidação
    // por conta própria. Reconsolida as competências do cliente em background para
    // marcar stale os cálculos cujos insumos mudaram (nova versão do contrato).
    scheduleReconsolidacaoClienteContrato(escritorioId, novoContratoSalvo.cliente_id);
    // Editar `data_inicio`/`ultima_renovacao` pode tornar elegíveis competências
    // que já têm relatório mas nunca ganharam VAC (bloqueadas antes pelo gate de
    // competência). Idempotente via upsert dedup — reprocessa sem duplicar.
    scheduleConsolidacaoCompetenciasComRelatorio(escritorioId, novoContratoSalvo.cliente_id);

    return { ok: true as const, contratoId: novoContratoSalvo.id };
  });
}

function competenciaAtual(): string {
  const agora = new Date();
  return `${String(agora.getMonth() + 1).padStart(2, "0")}/${agora.getFullYear()}`;
}

function dataReferenciaContrato(contrato: Contrato): string | null {
  const valor = contrato.ultima_renovacao?.trim() || contrato.data_inicio?.trim() || "";
  const data = /^\d{4}-\d{2}-\d{2}/.exec(valor)?.[0] ?? "";
  return data || null;
}

export function ultimoAniversarioDeRenovacao(contrato: Contrato): { competencia: string; data: string } | null {
  const referencia = dataReferenciaContrato(contrato);
  if (!referencia) return null;
  const [anoReferencia, mes, dia] = referencia.split("-").map(Number);
  const hoje = new Date();
  if (new Date(`${referencia}T00:00:00`).getTime() > hoje.getTime()) return null;

  const montarData = (ano: number) => {
    const ultimoDia = new Date(ano, mes, 0).getDate();
    return new Date(ano, mes - 1, Math.min(dia, ultimoDia));
  };
  let aniversario = montarData(hoje.getFullYear());
  if (aniversario > hoje) aniversario = montarData(hoje.getFullYear() - 1);
  // O aniversário precisa estar pelo menos um ano após a referência. Mesmo ano significa
  // a própria data de referência (renovação/início), que não dispara reajuste.
  if (aniversario.getFullYear() <= anoReferencia) return null;
  return {
    competencia: `${String(aniversario.getMonth() + 1).padStart(2, "0")}/${aniversario.getFullYear()}`,
    data: [aniversario.getFullYear(), String(aniversario.getMonth() + 1).padStart(2, "0"), String(aniversario.getDate()).padStart(2, "0")].join("-"),
  };
}

type SnapshotReajuste = NonNullable<ValoresACobrar["reajuste_contrato"]>;

/**
 * Aplica o snapshot do reajuste ao VAC da competência: consolida (idempotente, faz upsert do VAC)
 * e grava a flag + metadados de comunicação. Reutilizado pelo caminho novo e pelo reparo.
 */
async function aplicarReajusteNoValorACobrar(
  escritorioId: string,
  clienteId: string,
  competenciaReajuste: string,
  snapshot: SnapshotReajuste,
): Promise<void> {
  const consolidacao = await consolidarCompetencia(escritorioId, clienteId, competenciaReajuste);
  if (!consolidacao.ok) throw new Error(consolidacao.motivo);
  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const vac = await manager.getRepository(ValoresACobrar).findOne({ where: { id: consolidacao.valoresACobrarId, escritorio_id: escritorioId } });
    if (!vac || vac.status === "pago") return;
    vac.contrato_reajustado = true;
    vac.reajuste_contrato = snapshot;
    await manager.getRepository(ValoresACobrar).save(vac);
  });
  scheduleReconsolidacaoClienteContrato(escritorioId, clienteId);
}

/** Recupera o snapshot já persistido na edição `reajuste_automatico` do contrato ativo. */
function extrairSnapshotReajuste(contrato: Contrato, competenciaReajuste: string): SnapshotReajuste | null {
  const edicao = (contrato.edicoes as EdicoesManuais | null)?.["reajuste_automatico"];
  const motivo = edicao?.motivo;
  if (!edicao || !motivo || typeof motivo !== "object") return null;
  const meta = motivo as Record<string, unknown>;
  if (meta.competencia !== competenciaReajuste) return null;
  const valorAnterior = Number(edicao.valor_original);
  const valorReajustado = Number(edicao.valor_editado);
  const percentual = Number(meta.percentual_acumulado);
  if (![valorAnterior, valorReajustado, percentual].every(Number.isFinite)) return null;
  if (typeof meta.indice !== "string" || typeof meta.competencia_inicio !== "string" || typeof meta.competencia_fim !== "string") return null;
  return {
    indice: meta.indice,
    competencia_inicio: meta.competencia_inicio,
    competencia_fim: meta.competencia_fim,
    percentual_acumulado: percentual,
    valor_anterior: valorAnterior,
    valor_reajustado: valorReajustado,
  };
}

/** Reparo idempotente: se o contrato já foi reajustado mas o VAC não recebeu a flag, reaplica. */
async function repararReajusteSeNecessario(escritorioId: string, contratoAtivo: Contrato, competenciaReajuste: string): Promise<boolean> {
  const snapshot = extrairSnapshotReajuste(contratoAtivo, competenciaReajuste);
  if (!snapshot) return false;
  const vac = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) =>
    manager.getRepository(ValoresACobrar).findOne({
      where: { cliente_id: contratoAtivo.cliente_id, escritorio_id: escritorioId, competencia: competenciaReajuste },
    }),
  );
  // VAC ausente = consolidação nunca rodou (reaplica); pago/já-flagado = nada a fazer.
  if (vac && (vac.status === "pago" || vac.contrato_reajustado === true)) return false;
  await aplicarReajusteNoValorACobrar(escritorioId, contratoAtivo.cliente_id, competenciaReajuste, snapshot);
  return true;
}

/**
 * Contrato já reajustado neste aniversário: tenta reparar um VAC sem flag antes de contar
 * como `ja_processados`. Erros de reparo viram `falhas` sem interromper o lote.
 */
async function tratarJaProcessado(
  escritorioId: string,
  clienteId: string,
  competenciaReajuste: string,
  contratoId: string,
  resultado: ResultadoLoteReajuste,
): Promise<void> {
  try {
    const ativo = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) =>
      manager.getRepository(Contrato).findOne({ where: { cliente_id: clienteId, escritorio_id: escritorioId, contrato_ativo: true } }),
    );
    if (ativo && (await repararReajusteSeNecessario(escritorioId, ativo, competenciaReajuste))) {
      resultado.reparados += 1;
      return;
    }
  } catch (err) {
    resultado.falhas.push({ contrato_id: contratoId, motivo: err instanceof Error ? err.message : String(err) });
    return;
  }
  resultado.ja_processados += 1;
}

export type ResultadoLoteReajuste = {
  competencia: string;
  reajustados: number;
  reparados: number;
  ja_processados: number;
  ignorados: Array<{ contrato_id: string; motivo: string }>;
  falhas: Array<{ contrato_id: string; motivo: string }>;
};

/** Reajusta contratos uma vez por ano, no aniversário da renovação. */
export async function reajustarContratosCompetenciaAtual(escritorioId: string): Promise<ResultadoLoteReajuste> {
  const competencia = competenciaAtual();
  const contratos = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) =>
    manager.getRepository(Contrato).find({ where: { escritorio_id: escritorioId, contrato_ativo: true } }),
  );
  const resultado: ResultadoLoteReajuste = { competencia, reajustados: 0, reparados: 0, ja_processados: 0, ignorados: [], falhas: [] };

  for (const contrato of contratos) {
    const dataReferencia = dataReferenciaContrato(contrato);
    const aniversario = ultimoAniversarioDeRenovacao(contrato);
    if (!dataReferencia || !aniversario) {
      // Sem novo aniversário a processar. Se o contrato já foi reajustado (a renovação avança
      // para a data do reajuste), ainda tentamos reparar um VAC que não recebeu a flag.
      if (contrato.data_ultimo_reajuste && contrato.ultima_competencia_reajuste) {
        await tratarJaProcessado(escritorioId, contrato.cliente_id, contrato.ultima_competencia_reajuste, contrato.id, resultado);
      } else {
        resultado.ignorados.push({ contrato_id: contrato.id, motivo: "Contrato sem aniversário de renovação já ocorrido." });
      }
      continue;
    }
    const competenciaReajuste = aniversario.competencia;
    if (contrato.data_ultimo_reajuste && contrato.data_ultimo_reajuste >= aniversario.data) {
      await tratarJaProcessado(escritorioId, contrato.cliente_id, competenciaReajuste, contrato.id, resultado);
      continue;
    }
    const indice = normalizarIndiceReajuste(contrato.indice_reajuste);
    if (!indice) {
      resultado.ignorados.push({ contrato_id: contrato.id, motivo: "Índice de reajuste ausente ou não suportado." });
      continue;
    }
    const valorAnterior = Number(contrato.valor_mensal ?? contrato.valor_original);
    if (!Number.isFinite(valorAnterior) || valorAnterior <= 0) {
      resultado.ignorados.push({ contrato_id: contrato.id, motivo: "Valor mensal inválido ou ausente." });
      continue;
    }
    const vacPago = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) =>
      manager.getRepository(ValoresACobrar).findOne({
        where: { cliente_id: contrato.cliente_id, escritorio_id: escritorioId, competencia: competenciaReajuste, status: "pago" },
      }),
    );
    if (vacPago) {
      resultado.ignorados.push({ contrato_id: contrato.id, motivo: "A cobrança desta competência já foi paga." });
      continue;
    }

    try {
      const indiceInflacao = await obterIndiceAcumuladoDozeMeses(indice, competenciaReajuste);
      const valorReajustado = round2(valorAnterior * (1 + indiceInflacao.percentual_acumulado / 100));
      const novoContrato = await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
        const contratoRepo = manager.getRepository(Contrato);
        const atual = await contratoRepo.findOne({ where: { id: contrato.id, escritorio_id: escritorioId, contrato_ativo: true } });
        if (!atual) return null;
        if (atual.data_ultimo_reajuste && atual.data_ultimo_reajuste >= aniversario.data) return "ja_processado" as const;
        await manager.query(
          `UPDATE contratos SET contrato_ativo = false WHERE id = $1 AND escritorio_id = $2 AND contrato_ativo = true`,
          [atual.id, escritorioId],
        );
        const proximo = contratoRepo.create({
          escritorio_id: atual.escritorio_id,
          cliente_id: atual.cliente_id,
          versao_do_contrato: await getNextContratoVersion(contratoRepo, escritorioId, atual.cliente_id),
          complexidade_cobranca: atual.complexidade_cobranca,
          tipo_contrato: atual.tipo_contrato,
          data_emissao: atual.data_emissao,
          data_inicio: atual.data_inicio,
          dia_vencimento: atual.dia_vencimento,
          inicio_faturamento: atual.inicio_faturamento,
          mes_vencimento: atual.mes_vencimento,
          data_termino: atual.data_termino,
          // Reajuste renova o contrato: a data de renovação passa a ser a data do reajuste.
          ultima_renovacao: aniversario.data,
          valor_original: atual.valor_original,
          valor_mensal: valorReajustado,
          desconto_por_adimplencia: atual.desconto_por_adimplencia,
          multa_por_inadimplencia: atual.multa_por_inadimplencia,
          indice_reajuste: atual.indice_reajuste,
          ultima_competencia_reajuste: competenciaReajuste,
          data_ultimo_reajuste: aniversario.data,
          instrucoes_de_cobranca: atual.instrucoes_de_cobranca,
          adicional_anual: atual.adicional_anual,
          arquivo_origem: atual.arquivo_origem,
          extracao_bruta: atual.extracao_bruta,
          valores_contratados: atual.valores_contratados,
          excedentes: atual.excedentes,
          payload_normalizado_ui: atual.payload_normalizado_ui,
          // Shape de EdicaoManual válida: só `valor_original`/`valor_editado`/`motivo` sobrevivem
          // à normalização. Os metadados do índice ficam em `motivo` e são recuperáveis no reparo.
          edicoes: registrarEdicoesManuais({ edicoesAtuais: atual.edicoes, edicoesRecebidas: { reajuste_automatico: { valor_original: valorAnterior, valor_editado: valorReajustado, motivo: { competencia: competenciaReajuste, indice, competencia_inicio: indiceInflacao.competencia_inicio, competencia_fim: indiceInflacao.competencia_fim, percentual_acumulado: indiceInflacao.percentual_acumulado } } }, usuarioNome: "sistema:reajuste" }),
          contrato_ativo: true,
        });
        const salvo = await contratoRepo.save(proximo);
        await syncExcedentes(manager, getExcedentesItems(salvo.excedentes) ?? [], salvo.id, escritorioId);
        // Renovação (reajuste avança `ultima_renovacao`): congela os VACs de
        // competências anteriores na versão que os gerou, para o reajuste não
        // reescrever retroativamente períodos já calculados/cobrados.
        await bloquearVacsAnterioresARenovacao(manager, {
          escritorioId,
          clienteId: atual.cliente_id,
          contratoAnteriorId: atual.id,
          versaoAnterior: atual.versao_do_contrato,
          novaDataRenovacao: aniversario.data,
        });
        return salvo;
      });
      if (novoContrato === "ja_processado") { await tratarJaProcessado(escritorioId, contrato.cliente_id, competenciaReajuste, contrato.id, resultado); continue; }
      if (!novoContrato) { resultado.falhas.push({ contrato_id: contrato.id, motivo: "Contrato deixou de estar ativo durante o processamento." }); continue; }

      await aplicarReajusteNoValorACobrar(escritorioId, novoContrato.cliente_id, competenciaReajuste, {
        indice,
        competencia_inicio: indiceInflacao.competencia_inicio,
        competencia_fim: indiceInflacao.competencia_fim,
        percentual_acumulado: indiceInflacao.percentual_acumulado,
        valor_anterior: valorAnterior,
        valor_reajustado: valorReajustado,
      });
      resultado.reajustados += 1;
    } catch (err) {
      if (err instanceof IndiceNaoPublicadoError) {
        resultado.ignorados.push({ contrato_id: contrato.id, motivo: "Índice ainda não publicado pelo BCB para a competência." });
      } else {
        resultado.falhas.push({ contrato_id: contrato.id, motivo: err instanceof Error ? err.message : String(err) });
      }
    }
  }
  return resultado;
}

export async function listContratosByCliente(escritorioId: string, clienteId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Contrato);
    const contratos = await repo.find({
      where: { cliente_id: clienteId, escritorio_id: escritorioId },
      relations: ["clausulas_excedentes", "cliente", "documentos_anexos"],
      order: { contrato_ativo: "DESC", created_at: "DESC" },
    });

    return contratos.map((c: any) => ({
      ...c,
      excedentes: c.clausulas_excedentes || [],
      documentos_anexos: documentosAnexosResumo(c),
    }));
  });
}

export async function listContratos(escritorioId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Contrato);
    const contratos = await repo.find({
      where: { escritorio_id: escritorioId },
      relations: ["cliente"],
      order: { contrato_ativo: "DESC", created_at: "DESC" },
    });

    return contratos
      .filter((c: any) => c.cliente?.ativo !== false)
      .map((c: any) => ({
      id: c.id,
      numero_contrato: c.numero_contrato,
      versao_do_contrato: c.versao_do_contrato,
      contrato_ativo: c.contrato_ativo,
      cliente: c.cliente ? {
        id: c.cliente.id,
        razao_social: c.cliente.razao_social,
        cnpj: c.cliente.cnpj,
      } : null,
      vigencia_inicio: c.data_inicio,
      vigencia_fim: c.data_termino,
      ultima_renovacao: c.ultima_renovacao,
      indice_reajuste: c.indice_reajuste,
      valor_original: c.valor_original,
      valor_mensal: c.valor_mensal,
      complexidade_cobranca: c.complexidade_cobranca ?? 1,
      arquivo_origem: c.arquivo_origem,
      tipo_contrato: c.tipo_contrato,
      instrucoes_de_cobranca: c.instrucoes_de_cobranca,
      created_at: c.created_at,
    }));
  });
}

export async function listContratosPaginated(
  escritorioId: string,
  input: PaginationInput & { clienteId?: string; query?: string } = {},
) {
  const { page, pageSize, skip } = normalizePagination(input);
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const qb = manager
      .getRepository(Contrato)
      .createQueryBuilder("contrato")
      .innerJoin("contrato.cliente", "cliente")
      .select("contrato.id", "id")
      .addSelect("contrato.versao_do_contrato", "versao_do_contrato")
      .addSelect("contrato.contrato_ativo", "contrato_ativo")
      .addSelect("contrato.data_inicio", "vigencia_inicio")
      .addSelect("contrato.data_termino", "vigencia_fim")
      .addSelect("contrato.ultima_renovacao", "ultima_renovacao")
      .addSelect("contrato.indice_reajuste", "indice_reajuste")
      .addSelect("contrato.valor_original", "valor_original")
      .addSelect("contrato.valor_mensal", "valor_mensal")
      .addSelect("contrato.complexidade_cobranca", "complexidade_cobranca")
      .addSelect("contrato.arquivo_origem", "arquivo_origem")
      .addSelect("contrato.tipo_contrato", "tipo_contrato")
      .addSelect("contrato.created_at", "created_at")
      .addSelect("cliente.id", "cliente_id")
      .addSelect("cliente.razao_social", "cliente_razao_social")
      .addSelect("cliente.cnpj", "cliente_cnpj")
      .where("contrato.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("cliente.ativo = true");

    if (input.clienteId) qb.andWhere("contrato.cliente_id = :clienteId", { clienteId: input.clienteId });
    if (input.query?.trim()) {
      qb.andWhere(
        new Brackets((sub) => {
          sub
            .where("cliente.razao_social ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("cliente.cnpj ILIKE :query", { query: `%${input.query!.trim()}%` })
            .orWhere("contrato.tipo_contrato ILIKE :query", { query: `%${input.query!.trim()}%` });
        }),
      );
    }

    const total = await qb.clone().getCount();
    const rows = await qb
      .orderBy("contrato.contrato_ativo", "DESC")
      .addOrderBy("contrato.created_at", "DESC")
      .offset(skip)
      .limit(pageSize)
      .getRawMany<Record<string, unknown>>();

    return buildPaginatedResult(rows.map((row) => ({
      id: String(row.id),
      versao_do_contrato: Number(row.versao_do_contrato ?? 1),
      contrato_ativo: row.contrato_ativo === true,
      cliente: {
        id: String(row.cliente_id),
        razao_social: String(row.cliente_razao_social),
        cnpj: String(row.cliente_cnpj),
      },
      vigencia_inicio: row.vigencia_inicio == null ? null : String(row.vigencia_inicio),
      vigencia_fim: row.vigencia_fim == null ? null : String(row.vigencia_fim),
      ultima_renovacao: row.ultima_renovacao == null ? null : String(row.ultima_renovacao),
      indice_reajuste: row.indice_reajuste == null ? null : String(row.indice_reajuste),
      valor_original: row.valor_original == null ? null : Number(row.valor_original),
      valor_mensal: row.valor_mensal == null ? null : Number(row.valor_mensal),
      complexidade_cobranca: Number(row.complexidade_cobranca ?? 1),
      arquivo_origem: row.arquivo_origem == null ? null : String(row.arquivo_origem),
      tipo_contrato: row.tipo_contrato == null ? null : String(row.tipo_contrato),
      created_at: row.created_at,
    })), total, page, pageSize);
  });
}

export async function getContratoById(escritorioId: string, contratoId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const repo = manager.getRepository(Contrato);
    const contrato = await repo.findOne({
      where: { id: contratoId, escritorio_id: escritorioId },
      relations: ["clausulas_excedentes", "cliente", "documentos_anexos"],
    });

    if (!contrato) return null;

    const documentoId =
      contrato.arquivo_origem ||
      (contrato.extracao_bruta?.idArquivo as string | undefined) ||
      (contrato.extracao_bruta?.documentoId as string | undefined) ||
      null;
    const documento = documentoId
      ? await manager.getRepository(Documento).findOne({
          where: { id: documentoId, escritorio_id: escritorioId },
        })
      : null;

    return {
      ...contrato,
      documentos_anexos: documentosAnexosResumo(contrato),
      dados_extraidos_contrato: documento?.dados_extraidos_contrato ?? null,
      cadastro_ia: documento ? isAiSubmittedTextDocumento(documento) : false,
    };
  });
}

export async function getContratoAtivoByCnpj(escritorioId: string, cnpj: string) {
  let cnpjNormalizado: string;
  try {
    cnpjNormalizado = normalizarCnpj(cnpj);
  } catch {
    return null;
  }

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contrato = await manager
      .getRepository(Contrato)
      .createQueryBuilder("contrato")
      .innerJoinAndSelect("contrato.cliente", "cliente")
      .leftJoinAndSelect("contrato.documentos_anexos", "documentos_anexos")
      .where("contrato.escritorio_id = :escritorioId", { escritorioId })
      .andWhere("contrato.contrato_ativo = true")
      .andWhere("cliente.ativo = true")
      .andWhere("cliente.cnpj = :cnpj", { cnpj: cnpjNormalizado })
      .orderBy("contrato.created_at", "DESC")
      .getOne();

    if (!contrato) return null;
    return {
      ...contrato,
      documentos_anexos: documentosAnexosResumo(contrato),
    };
  });
}

export async function generateContratosSummaryDomain(escritorioId: string) {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratos = await manager
      .getRepository(Contrato)
      .createQueryBuilder("contrato")
      .select("SUM(COALESCE(valor_mensal, valor_original))", "mrr")
      .addSelect("COUNT(1)", "contagem_contratos")
      .getRawOne();

    return {
      mrr: contratos.mrr || 0,
      contagem_contratos: contratos.contagem_contratos || 0,
    };
  });
}

export async function sincronizarContratoAtivoComPayload(
  escritorioId: string,
  documentoId: string,
  payloadNormalizadoUi: Record<string, unknown>,
): Promise<void> {
  const payloadInsercaoDb = getPayloadInsercaoDb(payloadNormalizadoUi);
  if (!payloadInsercaoDb) return;

  const novosValoresContratados = payloadInsercaoDb.valores_contratados as Record<string, unknown> | null | undefined;
  const novosExcedentes = payloadInsercaoDb.excedentes as Record<string, unknown> | null | undefined;
  if (!novosValoresContratados && !novosExcedentes) return;

  await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratoRepo = manager.getRepository(Contrato);
    const contrato = await contratoRepo.findOne({
      where: { escritorio_id: escritorioId, arquivo_origem: documentoId, contrato_ativo: true },
    });
    if (!contrato) return;

    const updates: Record<string, unknown> = {
      payload_normalizado_ui: withPayloadInsercaoDb(contrato.payload_normalizado_ui, payloadInsercaoDb) ?? contrato.payload_normalizado_ui,
    };
    if (novosValoresContratados) updates.valores_contratados = novosValoresContratados;
    if (novosExcedentes) updates.excedentes = novosExcedentes;

    await contratoRepo.update({ id: contrato.id, escritorio_id: escritorioId }, updates);

    // Edição in-place do contrato ativo (sem bump de versão nem trigger próprio):
    // reconsolida as competências do cliente para marcar stale os cálculos afetados.
    scheduleReconsolidacaoClienteContrato(escritorioId, contrato.cliente_id);
  });
}

export async function confirmarContratoExtracted(
  escritorioId: string,
  documentoId: string,
  input: Record<string, unknown>,
  usuarioNome?: string | null,
) {
  const cnpj = String(input.cnpj || "").trim();

  if (!cnpj) throw new Error("CNPJ é obrigatório");

  // Fora de qualquer runQueryWithRls: chamada de rede não pode acontecer dentro de uma transação
  // aberta. `findOrCreateClienteByCnpj` (abaixo) também consulta internamente — roda duas vezes
  // nesse fluxo, mas a segunda bate no cache já populado pela primeira, não na BrasilAPI de novo.
  const consulta = await consultarCnpjSemBloquear(cnpj);

  const documento = await getDocumentoById(escritorioId, documentoId);
  if (!documento) throw new Error("Documento não encontrado");
  const payload = documento.dados_extraidos_contrato
    ? normalizeContractExtractionPayload(documento.dados_extraidos_contrato as Record<string, unknown>)
    : undefined;
  if (!payload) throw new Error("Documento não possui extração bruta de contrato");
  const tipoDocumentoContratual = getTipoDocumentoContratualFromPayload(payload);

  const termos = payload.termosGerais?.items ?? [];
  const excedentes = payload.excedentes?.items ?? [];

  const razaoSocial =
    getReviewedField(input, termos, "razao_social") ||
    getReviewedField(input, termos, "nome_cliente") ||
    undefined;

  const cliente = await findOrCreateClienteByCnpj({ escritorioId, cnpj, razaoSocial });

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratoRepo = manager.getRepository(Contrato);

    await validarAtivacaoContrato(manager, escritorioId, cliente.id);

    // Primeiro contrato do cliente (não tinha contrato antes): dispara o backfill de
    // identificação e a consolidação das competências já disponíveis (ver abaixo).
    const ehPrimeiroContrato =
      (await contratoRepo.count({ where: { cliente_id: cliente.id, escritorio_id: escritorioId } })) === 0;

    const contratosAtivos = await contratoRepo.find({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId, contrato_ativo: true },
    });

    for (const contrato of contratosAtivos) {
      contrato.contrato_ativo = false;
      await contratoRepo.save(contrato);
    }

    const camposEditados = getCamposEditados(input);
    const payloadInsercaoDbBase =
      getPayloadInsercaoDb(documento.payload_normalizado_ui) ??
      buildContratoPersistenceDraft({ payload, documentoId, camposEditados });
    const payloadInsercaoDb = copyValorOriginalToValorMensalWhenMissing(
      applyCamposEditadosToPayloadInsercaoDb(payloadInsercaoDbBase, camposEditados),
    );
    payloadInsercaoDb.complexidade_cobranca = await assertBillingComplexityActive(
      payloadInsercaoDb.complexidade_cobranca ?? 1,
    );
    assertCobrancaInstructionsWhenNeeded(payloadInsercaoDb);

    const novoContrato = contratoRepo.create({
      ...payloadInsercaoDb,
      cliente_id: cliente.id,
      escritorio_id: escritorioId,
      contrato_ativo: true,
      versao_do_contrato: await getNextContratoVersion(
        contratoRepo,
        escritorioId,
        cliente.id,
      ),
      edicoes: registrarEdicoesManuais({
        edicoesAtuais: null,
        edicoesRecebidas: input.edicoes,
        usuarioNome,
      }),
      payload_normalizado_ui: withPayloadInsercaoDb(documento.payload_normalizado_ui, payloadInsercaoDb),
    });

    const contratoSalvo = await contratoRepo.save(novoContrato);

    // Renovação/aditivo (nova versão supera uma ativa e avança `ultima_renovacao`):
    // congela os VACs anteriores na versão anterior.
    const contratoSuperado = contratosAtivos[0];
    if (contratoSuperado && renovacaoAvancou(contratoSuperado.ultima_renovacao, contratoSalvo.ultima_renovacao)) {
      await bloquearVacsAnterioresARenovacao(manager, {
        escritorioId,
        clienteId: cliente.id,
        contratoAnteriorId: contratoSuperado.id,
        versaoAnterior: contratoSuperado.versao_do_contrato,
        novaDataRenovacao: contratoSalvo.ultima_renovacao ?? "",
      });
    } else if (
      contratoSuperado &&
      renovacaoRetroagiu(contratoSuperado.ultima_renovacao, contratoSalvo.ultima_renovacao)
    ) {
      // Correção retroagindo `ultima_renovacao`: destrava os VACs que ficam de
      // novo elegíveis, voltando-os a resolver pelo contrato ativo atual.
      await destravarVacsAposRetroacaoRenovacao(manager, {
        escritorioId,
        clienteId: cliente.id,
        novaDataRenovacao: contratoSalvo.ultima_renovacao ?? "",
        dataRenovacaoAnterior: contratoSuperado.ultima_renovacao ?? "",
      });
    }

    const contratoBaseId =
      payload.contratoBaseId ??
      (isTipoAnexoContrato(tipoDocumentoContratual) ? contratosAtivos[0]?.id : undefined);
    if (contratoBaseId) {
      await registrarDocumentoAnexoContrato(manager, {
        escritorioId,
        contratoId: contratoSalvo.id,
        documentoId,
        tipoDocumentoContratual,
      });
    }

    await syncExcedentes(
      manager,
      getExcedentesItems(payloadInsercaoDb.excedentes) ?? excedentes,
      contratoSalvo.id,
      escritorioId,
    );
    await fillClienteNullFieldsFromContrato(
      manager,
      escritorioId,
      cliente.id,
      buildClienteDadosContrato(input, termos),
      { preencherIdentificacao: ehPrimeiroContrato, consulta },
    );
    await manager.getRepository(Documento).update(
      { id: documentoId, escritorio_id: escritorioId },
      { cliente_id: cliente.id, tipo_documento_contratual: tipoDocumentoContratual },
    );

    scheduleReconsolidacaoClienteContrato(escritorioId, cliente.id);
    // Não restringe mais a `ehPrimeiroContrato`: um aditivo/renovação também pode
    // retroagir `data_inicio`/`ultima_renovacao` e tornar elegíveis competências
    // que já têm relatório mas nunca ganharam VAC. Idempotente via upsert dedup.
    scheduleConsolidacaoCompetenciasComRelatorio(escritorioId, cliente.id);

    return { ok: true, contratoId: contratoSalvo.id, clienteId: cliente.id };
  });
}

async function findClienteEntityById(escritorioId: string, clienteId: string): Promise<Cliente | null> {
  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return await manager.getRepository(Cliente).findOne({
      where: { id: clienteId, escritorio_id: escritorioId },
    });
  });
}

/**
 * Cria um contrato a partir de dados estruturados, sem documento de OCR de origem.
 * Reaproveita o mesmo pipeline de persistência de `confirmarContratoExtracted`
 * (resolver cliente, desativar contratos ativos, montar/validar payload, versionar,
 * sincronizar excedentes), mas lê a extração diretamente do corpo da requisição.
 * O cliente é resolvido por `cliente_id` (existente) ou `cnpj` (find-or-create).
 */
export async function criarContratoManual(
  escritorioId: string,
  input: Record<string, unknown>,
  usuarioNome?: string | null,
) {
  const clienteIdInput = typeof input.cliente_id === "string" ? input.cliente_id.trim() : "";
  const cnpj = typeof input.cnpj === "string" ? input.cnpj.trim() : "";

  if (!clienteIdInput && !cnpj) {
    throw new Error("Informe cliente_id ou cnpj para criar o contrato.");
  }

  const rawPayload = isRecord(input.payload) ? input.payload : input;
  const payload = normalizeContractExtractionPayload(rawPayload);
  const termos = payload.termosGerais?.items ?? [];
  const excedentes = payload.excedentes?.items ?? [];

  let cliente: Cliente;
  if (clienteIdInput) {
    const found = await findClienteEntityById(escritorioId, clienteIdInput);
    if (!found) throw new Error("Cliente não encontrado");
    cliente = found;
  } else {
    const razaoSocial =
      getReviewedField(input, termos, "razao_social") ||
      getReviewedField(input, termos, "nome_cliente") ||
      undefined;
    cliente = await findOrCreateClienteByCnpj({ escritorioId, cnpj, razaoSocial });
  }
  // Fora de qualquer runQueryWithRls, cobrindo os dois ramos (cliente_id ou cnpj): chamada de rede
  // não pode acontecer dentro de uma transação aberta.
  const consulta = await consultarCnpjSemBloquear(cliente.cnpj);

  return await runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const contratoRepo = manager.getRepository(Contrato);

    await validarAtivacaoContrato(manager, escritorioId, cliente.id);

    // Primeiro contrato do cliente (não tinha contrato antes): dispara o backfill de
    // identificação e a consolidação das competências já disponíveis (ver abaixo).
    const ehPrimeiroContrato =
      (await contratoRepo.count({ where: { cliente_id: cliente.id, escritorio_id: escritorioId } })) === 0;

    // Desativa todos os contratos anteriores deste cliente
    const contratosAtivos = await contratoRepo.find({
      where: { cliente_id: cliente.id, escritorio_id: escritorioId, contrato_ativo: true },
    });
    for (const contrato of contratosAtivos) {
      contrato.contrato_ativo = false;
      await contratoRepo.save(contrato);
    }

    const camposEditados = getCamposEditados(input);
    const payloadInsercaoDbBase = buildContratoPersistenceDraft({ payload, documentoId: null, camposEditados });
    const payloadInsercaoDb = copyValorOriginalToValorMensalWhenMissing(
      applyCamposEditadosToPayloadInsercaoDb(payloadInsercaoDbBase, camposEditados),
    );
    payloadInsercaoDb.complexidade_cobranca = await assertBillingComplexityActive(
      payloadInsercaoDb.complexidade_cobranca ?? 1,
    );
    assertCobrancaInstructionsWhenNeeded(payloadInsercaoDb);

    const novoContrato = contratoRepo.create({
      ...payloadInsercaoDb,
      cliente_id: cliente.id,
      escritorio_id: escritorioId,
      contrato_ativo: true,
      versao_do_contrato: await getNextContratoVersion(contratoRepo, escritorioId, cliente.id),
      edicoes: registrarEdicoesManuais({
        edicoesAtuais: null,
        edicoesRecebidas: input.edicoes,
        usuarioNome,
      }),
      payload_normalizado_ui: {
        displayFields: buildContratoDisplayFields(payload),
        payloadInsercaoDb,
      },
    });

    const contratoSalvo = await contratoRepo.save(novoContrato);

    // Renovação manual (nova versão supera uma ativa e avança `ultima_renovacao`):
    // congela os VACs anteriores na versão anterior.
    const contratoSuperado = contratosAtivos[0];
    if (contratoSuperado && renovacaoAvancou(contratoSuperado.ultima_renovacao, contratoSalvo.ultima_renovacao)) {
      await bloquearVacsAnterioresARenovacao(manager, {
        escritorioId,
        clienteId: cliente.id,
        contratoAnteriorId: contratoSuperado.id,
        versaoAnterior: contratoSuperado.versao_do_contrato,
        novaDataRenovacao: contratoSalvo.ultima_renovacao ?? "",
      });
    } else if (
      contratoSuperado &&
      renovacaoRetroagiu(contratoSuperado.ultima_renovacao, contratoSalvo.ultima_renovacao)
    ) {
      // Correção retroagindo `ultima_renovacao`: destrava os VACs que ficam de
      // novo elegíveis, voltando-os a resolver pelo contrato ativo atual.
      await destravarVacsAposRetroacaoRenovacao(manager, {
        escritorioId,
        clienteId: cliente.id,
        novaDataRenovacao: contratoSalvo.ultima_renovacao ?? "",
        dataRenovacaoAnterior: contratoSuperado.ultima_renovacao ?? "",
      });
    }

    await syncExcedentes(
      manager,
      getExcedentesItems(payloadInsercaoDb.excedentes) ?? excedentes,
      contratoSalvo.id,
      escritorioId,
    );
    await fillClienteNullFieldsFromContrato(
      manager,
      escritorioId,
      cliente.id,
      buildClienteDadosContrato(input, termos),
      { preencherIdentificacao: ehPrimeiroContrato, consulta },
    );

    // Não restringe mais a `ehPrimeiroContrato`: uma renovação manual também pode
    // retroagir `data_inicio`/`ultima_renovacao` e tornar elegíveis competências
    // que já têm relatório mas nunca ganharam VAC. Idempotente via upsert dedup.
    scheduleConsolidacaoCompetenciasComRelatorio(escritorioId, cliente.id);

    return { ok: true, contratoId: contratoSalvo.id, clienteId: cliente.id };
  });
}
