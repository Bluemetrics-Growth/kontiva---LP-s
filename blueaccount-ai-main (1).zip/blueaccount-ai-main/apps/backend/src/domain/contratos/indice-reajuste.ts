/**
 * Índice de reajuste: lista canônica e normalização.
 *
 * Módulo puro de propósito — `indice-inflacao.service.ts` importa o DataSource, e
 * `contrato-payload.ts` (que precisa saber se um texto é um índice válido) não pode
 * arrastar o banco para o seu grafo de import. O serviço reexporta o que está aqui,
 * então quem já importava de lá não muda.
 */

export const INDICES_REAJUSTE = ["IPCA", "INPC", "IGP-M"] as const;
export type IndiceReajuste = (typeof INDICES_REAJUSTE)[number];

/**
 * Normaliza o índice para um dos três valores canônicos. Só aceita o nome do índice,
 * não uma cláusula que o mencione: "IPCA/IBGE, todo mês de maio" vira `null`, porque
 * gravar a cláusula no lugar do índice faz o reajuste ser silenciosamente ignorado
 * (ver `aplicarReajusteAnual` em contrato.service.ts).
 */
export function normalizarIndiceReajuste(valor: string | null | undefined): IndiceReajuste | null {
  const normalizado = valor?.trim().toUpperCase().replace(/\s+/g, "") ?? "";
  if (normalizado === "IPCA") return "IPCA";
  if (normalizado === "INPC") return "INPC";
  if (normalizado === "IGP-M" || normalizado === "IGPM") return "IGP-M";
  return null;
}
