import { Contrato } from "../../database/modules/tenant/entities/contrato.entity.js";
import type { TipoDocumentoContratual } from "../../database/modules/tenant/entities/documento.entity.js";
import { avaliarQualidadeExtracaoContrato } from "./contrato-qa.js";
import { textoPertenceAListaFechada } from "./listas-fechadas-extracao.js";

export interface ExtractionItem {
  campo: string;
  valor_extraido: unknown;
}

export interface ExcedenteItem {
  campo: string;
  referencia: string;
  valor_extraido: unknown;
  tipo_cobranca: string;
  descricao?: string;
  quantidade_inicial?: number;
}

export interface ContractExtractionPayload {
  idArquivo?: string;
  documentoId?: string;
  idCliente?: string;
  tipoDocumentoContratual?: TipoDocumentoContratual;
  classificacaoConfianca?: number;
  classificacaoMotivo?: string;
  contratoBaseId?: string;
  termosGerais?: { items: ExtractionItem[] };
  valoresContratados?: { items: ExtractionItem[] };
  excedentes?: { items: ExcedenteItem[] };
}

export const CAMPOS_DATA_CONTRATO = new Set([
  "data_inicio",
  "data_emissao",
  "inicio_faturamento",
  "ultima_renovacao",
  "data_ultimo_reajuste",
]);

/** Normaliza somente datas ISO reais, sem depender de parsing permissivo do runtime. */
export function normalizarDataContrato(valor: unknown): string | null {
  if (typeof valor !== "string") return null;
  const data = valor.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) return null;

  const [ano, mes, dia] = data.split("-").map(Number);
  const date = new Date(Date.UTC(ano, mes - 1, dia));
  return date.getUTCFullYear() === ano && date.getUTCMonth() === mes - 1 && date.getUTCDate() === dia
    ? data
    : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function sectionItems<T>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[];
  if (isRecord(value) && Array.isArray(value.items)) return value.items as T[];
  return [];
}

function isValoresContratadosCampo(campo: string): boolean {
  return [
    "numero_de_documentos",
    "numero_de_colaboradores",
    "numero_de_prolabores",
    "numero_de_estabelecimentos",
    "outros_servicos_contratados",
    "faixas_de_cobranca",
    "base_de_calculo",
    "valor_mensal",
  ].includes(campo);
}

function normalizeTipoDocumentoContratual(value: unknown): TipoDocumentoContratual | undefined {
  const normalized = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (["contrato_novo", "aditivo", "renovacao", "cancelamento", "correcao", "desconhecido"].includes(normalized)) {
    return normalized as TipoDocumentoContratual;
  }
  if (normalized === "anexo") return "aditivo";
  if (normalized === "nao_contrato" || normalized === "não_contrato") return "desconhecido";
  return undefined;
}

function extractClassificacao(source: Record<string, unknown>): {
  tipoDocumentoContratual?: TipoDocumentoContratual;
  classificacaoConfianca?: number;
  classificacaoMotivo?: string;
  contratoBaseId?: string;
} {
  const classificacao = isRecord(source.classificacao) ? source.classificacao : {};
  const tipoDocumentoContratual =
    normalizeTipoDocumentoContratual(source.tipo_documento_contratual) ??
    normalizeTipoDocumentoContratual(source.tipoDocumentoContratual) ??
    normalizeTipoDocumentoContratual(classificacao.tipo_documento_contratual) ??
    normalizeTipoDocumentoContratual(classificacao.tipo);
  const confiancaRaw = source.classificacao_confianca ?? source.classificacaoConfianca ?? classificacao.confianca;
  const confianca = typeof confiancaRaw === "number" && Number.isFinite(confiancaRaw) ? confiancaRaw : undefined;
  const motivoRaw = source.classificacao_motivo ?? source.classificacaoMotivo ?? classificacao.motivo;
  const contratoBase = isRecord(source.contrato_base) ? source.contrato_base : {};
  const contratoBaseRaw = source.contrato_base_id ?? source.contratoBaseId ?? contratoBase.id;
  // Caminho de arquivo com engine agent: a classificação chega aninhada no resumo
  // do ContractAgent (`agentResult`), não no topo do payload da SM.
  if (!tipoDocumentoContratual && isRecord(source.agentResult)) {
    return extractClassificacao(source.agentResult);
  }
  return {
    ...(tipoDocumentoContratual ? { tipoDocumentoContratual } : {}),
    ...(confianca !== undefined ? { classificacaoConfianca: confianca } : {}),
    ...(typeof motivoRaw === "string" && motivoRaw.trim() ? { classificacaoMotivo: motivoRaw.trim() } : {}),
    ...(typeof contratoBaseRaw === "string" && contratoBaseRaw.trim() ? { contratoBaseId: contratoBaseRaw.trim() } : {}),
  };
}

export function normalizeContractExtractionPayload(input: Record<string, unknown>): ContractExtractionPayload {
  const source = isRecord(input.contractExtraction) ? input.contractExtraction : input;
  const flatItems = sectionItems<Record<string, unknown>>(source.items);

  if (flatItems.length > 0) {
    return {
      idArquivo: typeof input.idArquivo === "string" ? input.idArquivo : undefined,
      documentoId: typeof input.documentoId === "string" ? input.documentoId : undefined,
      idCliente: typeof input.idCliente === "string" ? input.idCliente : undefined,
      ...extractClassificacao(source),
      termosGerais: {
        items: flatItems.filter((item) =>
          typeof item.campo === "string" &&
          item.campo !== "excedentes" &&
          !isValoresContratadosCampo(item.campo),
        ) as unknown as ExtractionItem[],
      },
      valoresContratados: {
        items: flatItems.filter((item) =>
          typeof item.campo === "string" &&
          isValoresContratadosCampo(item.campo),
        ) as unknown as ExtractionItem[],
      },
      excedentes: {
        items: flatItems.filter((item) => item.campo === "excedentes") as unknown as ExcedenteItem[],
      },
    };
  }

  return {
    idArquivo: typeof input.idArquivo === "string" ? input.idArquivo : undefined,
    documentoId: typeof input.documentoId === "string" ? input.documentoId : undefined,
    idCliente: typeof input.idCliente === "string" ? input.idCliente : undefined,
    ...extractClassificacao(source),
    termosGerais: { items: sectionItems<ExtractionItem>(source.termosGerais) },
    valoresContratados: { items: sectionItems<ExtractionItem>(source.valoresContratados) },
    excedentes: { items: sectionItems<ExcedenteItem>(source.excedentes) },
  };
}

/**
 * Valor extraído de um campo, com fallback para o trecho verbatim (`fonte`) quando o
 * modelo não converteu o valor.
 *
 * O fallback é intencional em campo de texto livre (a cláusula é melhor que vazio), mas
 * proibido em campo de lista fechada quando o trecho não é um item da lista — ver
 * `listas-fechadas-extracao.ts` para o estrago que ele causa em `indice_reajuste` e
 * `regime_tributario`. Nesses casos devolve "", que é como o campo ausente já se
 * comporta: o revisor humano preenche na tela.
 */
export function getField(items: ExtractionItem[], campo: string): string {
  const item = items.find((i) => i.campo === campo) as (ExtractionItem & { fonte?: unknown }) | undefined;
  if (!item) return "";

  // `!= null` e não truthiness: `valor_extraido: 0` é valor extraído, não ausência, e
  // continua devolvendo "" como antes (0 não passa pelo String(...) do retorno).
  if (item.valor_extraido != null) {
    return item.valor_extraido ? String(item.valor_extraido).trim() : "";
  }

  const fonte = item.fonte ? String(item.fonte).trim() : "";
  if (!fonte) return "";
  return textoPertenceAListaFechada(campo, fonte) ? fonte : "";
}

export function getEditedField(input: Record<string, unknown>, campo: string): string | null {
  const edited = input.campos_editados;
  if (!edited || typeof edited !== "object" || Array.isArray(edited)) return null;
  if (!Object.prototype.hasOwnProperty.call(edited, campo)) return null;

  const value = (edited as Record<string, unknown>)[campo];
  return value == null ? "" : String(value).trim();
}

export function getReviewedField(input: Record<string, unknown>, items: ExtractionItem[], campo: string): string {
  return getEditedField(input, campo) ?? getField(items, campo);
}

function getReviewedDate(
  input: Record<string, unknown>,
  items: ExtractionItem[],
  campo: string,
  fallback: string | null | undefined,
): string | null {
  const edited = getEditedField(input, campo);
  if (edited !== null) return normalizarDataContrato(edited);

  const extracted = getField(items, campo);
  return normalizarDataContrato(extracted || fallback);
}

export function cleanItems(items: ExtractionItem[]): { campo: string; valor_extraido: unknown }[] {
  return items.map(({ campo, valor_extraido }) => ({ campo, valor_extraido }));
}

export function cleanExcedentes(items: ExcedenteItem[]): Omit<ExcedenteItem, never>[] {
  return items.map(({ campo, referencia, descricao, valor_extraido, tipo_cobranca, quantidade_inicial }) => ({
    campo,
    referencia,
    ...(descricao !== undefined ? { descricao } : {}),
    valor_extraido,
    tipo_cobranca,
    ...(quantidade_inicial !== undefined ? { quantidade_inicial } : {}),
  }));
}

export function buildValoresContratadosSnapshot(payload: ContractExtractionPayload): Record<string, unknown> | null {
  return payload.valoresContratados?.items.length ? { items: cleanItems(payload.valoresContratados.items) } : null;
}

export function buildExcedentesSnapshot(payload: ContractExtractionPayload): Record<string, unknown> | null {
  return payload.excedentes?.items.length ? { items: cleanExcedentes(payload.excedentes.items) } : null;
}

export function buildContratoDisplayFields(payload: ContractExtractionPayload): Record<string, unknown>[] {
  return [
    ...(payload.termosGerais?.items ?? []).map(({ campo, valor_extraido }) => ({ campo, valor_extraido })),
    ...(payload.valoresContratados?.items ?? []).map(({ campo, valor_extraido }) => ({ campo, valor_extraido })),
    ...(payload.excedentes?.items ?? []).map(({ campo, referencia, valor_extraido }) => ({
      campo,
      referencia,
      valor_extraido,
    })),
  ];
}

export function buildContratoPayloadNormalizadoUi(input: {
  payload: ContractExtractionPayload;
  documentoId: string;
}): Record<string, unknown> {
  const payloadInsercaoDb = buildContratoPersistenceDraft(input);
  return {
    displayFields: buildContratoDisplayFields(input.payload),
    payloadInsercaoDb,
    qa_extracao: avaliarQualidadeExtracaoContrato(input.payload),
    tipo_documento_contratual: input.payload.tipoDocumentoContratual ?? "contrato_novo",
    classificacao_documento: {
      tipo_documento_contratual: input.payload.tipoDocumentoContratual ?? "contrato_novo",
      confianca: input.payload.classificacaoConfianca ?? null,
      motivo: input.payload.classificacaoMotivo ?? null,
      contrato_base_id: input.payload.contratoBaseId ?? null,
    },
  };
}

export function montarPayloadInsercaoDbContrato(contrato: Pick<
  Contrato,
  | "tipo_contrato"
  | "valor_original"
  | "valor_mensal"
  | "complexidade_cobranca"
  | "indice_reajuste"
  | "data_inicio"
  | "data_termino"
  | "ultima_renovacao"
  | "data_emissao"
  | "dia_vencimento"
  | "mes_vencimento"
  | "inicio_faturamento"
  | "desconto_por_adimplencia"
  | "multa_por_inadimplencia"
  | "instrucoes_de_cobranca"
  | "adicional_anual"
  | "arquivo_origem"
  | "extracao_bruta"
  | "valores_contratados"
  | "excedentes"
>): Record<string, unknown> {
  return {
    tipo_contrato: contrato.tipo_contrato,
    valor_original: contrato.valor_original,
    valor_mensal: contrato.valor_mensal,
    complexidade_cobranca: contrato.complexidade_cobranca,
    indice_reajuste: contrato.indice_reajuste,
    data_inicio: contrato.data_inicio,
    data_termino: contrato.data_termino,
    ultima_renovacao: contrato.ultima_renovacao,
    data_emissao: contrato.data_emissao,
    dia_vencimento: contrato.dia_vencimento,
    mes_vencimento: contrato.mes_vencimento,
    inicio_faturamento: contrato.inicio_faturamento,
    desconto_por_adimplencia: contrato.desconto_por_adimplencia,
    multa_por_inadimplencia: contrato.multa_por_inadimplencia,
    instrucoes_de_cobranca: contrato.instrucoes_de_cobranca,
    adicional_anual: contrato.adicional_anual,
    arquivo_origem: contrato.arquivo_origem,
    extracao_bruta: contrato.extracao_bruta,
    valores_contratados: contrato.valores_contratados,
    excedentes: contrato.excedentes,
  };
}

/**
 * `ultima_renovacao` é opcional. Datas ausentes ou inválidas não recebem fallback:
 * o reajuste anual usa `data_inicio` como referência quando necessário.
 */
export function resolverUltimaRenovacaoInicial(
  ultimaRenovacao: string | null | undefined,
): string | null {
  return normalizarDataContrato(ultimaRenovacao);
}

export function buildContratoPersistenceDraft(input: {
  payload: ContractExtractionPayload;
  documentoId: string | null;
  camposEditados?: Record<string, unknown>;
  fallback?: Partial<Contrato>;
}): Record<string, unknown> {
  const { payload, documentoId, fallback } = input;
  const reviewInput = { campos_editados: input.camposEditados ?? {} };
  const termos = payload.termosGerais?.items ?? [];
  const valores = payload.valoresContratados?.items ?? [];
  const diaVencimentoStr = getReviewedField(reviewInput, termos, "dia_vencimento");
  const diaVencimento = diaVencimentoStr ? parseInt(diaVencimentoStr) : null;
  const valorOriginal = parseNullableNumber(getReviewedField(reviewInput, termos, "valor_original")) ?? 0;
  const valorMensal =
    parseNullableNumber(getReviewedField(reviewInput, termos, "valor_mensal")) ??
    parseNullableNumber(getReviewedField(reviewInput, valores, "valor_mensal")) ??
    null;
  const valoresContratados = buildValoresContratadosSnapshot(payload);
  const excedentes = buildExcedentesSnapshot(payload);
  const extracaoBruta = {
    idArquivo: documentoId,
    termosGerais: payload.termosGerais?.items.length ? { items: cleanItems(payload.termosGerais.items) } : undefined,
    valoresContratados: valoresContratados ?? undefined,
    excedentes: excedentes ?? undefined,
  };

  return {
    tipo_contrato: getReviewedField(reviewInput, termos, "objeto") || fallback?.tipo_contrato || null,
    valor_original: valorOriginal || valorMensal || fallback?.valor_original || 0,
    valor_mensal: valorMensal ?? fallback?.valor_mensal ?? null,
    complexidade_cobranca: fallback?.complexidade_cobranca ?? 1,
    indice_reajuste: getReviewedField(reviewInput, termos, "indice_reajuste") || fallback?.indice_reajuste || null,
    data_inicio: getReviewedDate(reviewInput, termos, "data_inicio", fallback?.data_inicio),
    data_termino: getReviewedField(reviewInput, termos, "data_termino") || fallback?.data_termino || null,
    ultima_renovacao: resolverUltimaRenovacaoInicial(
      getReviewedDate(reviewInput, termos, "ultima_renovacao", fallback?.ultima_renovacao),
    ),
    data_emissao: getReviewedDate(reviewInput, termos, "data_emissao", fallback?.data_emissao),
    dia_vencimento: diaVencimento ?? fallback?.dia_vencimento ?? null,
    mes_vencimento: getReviewedField(reviewInput, termos, "mes_vencimento") || fallback?.mes_vencimento || null,
    inicio_faturamento: getReviewedDate(reviewInput, termos, "inicio_faturamento", fallback?.inicio_faturamento),
    desconto_por_adimplencia: getReviewedField(reviewInput, termos, "desconto_por_adimplencia") || fallback?.desconto_por_adimplencia || null,
    multa_por_inadimplencia: getReviewedField(reviewInput, termos, "multa_por_inadimplencia") || fallback?.multa_por_inadimplencia || null,
    instrucoes_de_cobranca: getReviewedField(reviewInput, termos, "instrucoes_de_cobranca") || fallback?.instrucoes_de_cobranca || null,
    arquivo_origem: documentoId,
    extracao_bruta: extracaoBruta,
    valores_contratados: valoresContratados,
    excedentes,
  };
}

export function applyCamposEditadosToPayloadInsercaoDb(
  payloadInsercaoDb: Record<string, unknown>,
  camposEditados: Record<string, unknown>,
): Record<string, unknown> {
  const next = { ...payloadInsercaoDb };
  const valoresContratadosReplaced = Object.prototype.hasOwnProperty.call(camposEditados, "valores_contratados");
  for (const [campo, valor] of Object.entries(camposEditados)) {
    const editedExtractionValue = normalizeEditedExtractionValue(campo, valor);

    if (campo === "excedentes") {
      const parsed = parseExcedentesEdit(valor);
      if (parsed) {
        next.excedentes = parsed;
        next.extracao_bruta = isRecord(next.extracao_bruta)
          ? { ...next.extracao_bruta, excedentes: parsed }
          : next.extracao_bruta;
      }
      continue;
    }

    if (campo === "valores_contratados") {
      const parsed = parseJsonObjectIfString(valor);
      if (parsed) next.valores_contratados = parsed;
      continue;
    }

    if (Object.prototype.hasOwnProperty.call(next, campo)) {
      next[campo] = normalizeEditedDbValue(campo, valor);
    } else {
      const dbCampo = reviewFieldToPersistenceField(campo);
      if (dbCampo && (Object.prototype.hasOwnProperty.call(next, dbCampo) || editableContratoPersistenceFields.has(dbCampo))) {
        next[dbCampo] = normalizeEditedDbValue(dbCampo, valor);
      }
    }

    if (!valoresContratadosReplaced) {
      next.valores_contratados = updateSnapshotItems(next.valores_contratados, campo, editedExtractionValue);
    }
    next.extracao_bruta = updateRawExtractionItems(next.extracao_bruta, "termosGerais", campo, editedExtractionValue);
    next.extracao_bruta = updateRawExtractionItems(next.extracao_bruta, "valoresContratados", campo, editedExtractionValue);
  }
  if (
    Object.prototype.hasOwnProperty.call(camposEditados, "valor_original") &&
    !Object.prototype.hasOwnProperty.call(camposEditados, "valor_mensal") &&
    Object.prototype.hasOwnProperty.call(next, "valor_mensal")
  ) {
    next.valor_mensal = next.valor_original;
  }
  return next;
}

export function copyValorOriginalToValorMensalWhenMissing(
  payloadInsercaoDb: Record<string, unknown>,
): Record<string, unknown> {
  const valorMensal = parseNullableNumber(payloadInsercaoDb.valor_mensal);
  const valorOriginal = parseNullableNumber(payloadInsercaoDb.valor_original);

  if (valorMensal == null && valorOriginal != null) {
    return { ...payloadInsercaoDb, valor_mensal: valorOriginal };
  }

  return payloadInsercaoDb;
}

function updateSnapshotItems(snapshot: unknown, campo: string, valor: unknown): unknown {
  if (!isRecord(snapshot) || !Array.isArray(snapshot.items)) return snapshot;
  let changed = false;
  const items = snapshot.items.map((item) => {
    if (!isRecord(item) || item.campo !== campo) return item;
    changed = true;
    return { ...item, valor_extraido: valor };
  });
  return changed ? { ...snapshot, items } : snapshot;
}

function updateRawExtractionItems(rawExtraction: unknown, section: string, campo: string, valor: unknown): unknown {
  if (!isRecord(rawExtraction)) return rawExtraction;
  const updatedSection = updateSnapshotItems(rawExtraction[section], campo, valor);
  return updatedSection === rawExtraction[section]
    ? rawExtraction
    : { ...rawExtraction, [section]: updatedSection };
}

function reviewFieldToPersistenceField(campo: string): string | null {
  switch (campo) {
    case "objeto":
      return "tipo_contrato";
    case "instrucoes_de_cobranca":
      return "instrucoes_de_cobranca";
    default:
      return editableContratoPersistenceFields.has(campo) ? campo : null;
  }
}

function normalizeEditedDbValue(campo: string, valor: unknown): unknown {
  if (CAMPOS_DATA_CONTRATO.has(campo)) {
    return normalizarDataContrato(valor);
  }
  if (["valor_original", "valor_mensal"].includes(campo)) {
    return parseNullableNumber(valor);
  }
  if (campo === "complexidade_cobranca") {
    const parsed = Number.parseInt(String(valor ?? ""), 10);
    return Number.isNaN(parsed) ? 1 : parsed;
  }
  if (campo === "dia_vencimento") {
    const parsed = Number.parseInt(String(valor ?? ""), 10);
    return Number.isNaN(parsed) ? null : parsed;
  }
  if (campo === "adicional_anual") {
    if (valor == null || String(valor).trim() === "") return null;
    if (typeof valor !== "string") return valor;
    try {
      const parsed = JSON.parse(valor);
      return Array.isArray(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  return valor;
}

const editableContratoPersistenceFields = new Set([
  "tipo_contrato",
  "data_emissao",
  "data_inicio",
  "dia_vencimento",
  "inicio_faturamento",
  "mes_vencimento",
  "data_termino",
  "ultima_renovacao",
  "valor_original",
  "valor_mensal",
  "complexidade_cobranca",
  "desconto_por_adimplencia",
  "multa_por_inadimplencia",
  "indice_reajuste",
  "instrucoes_de_cobranca",
  "adicional_anual",
  "arquivo_origem",
]);

const EXCEDENTE_INTERNAL_FIELDS = new Set(["id", "escritorio_id", "contrato_id", "created_at", "updated_at"]);

function sanitizeExcedenteItem(item: unknown): unknown {
  if (!isRecord(item)) return item;
  return Object.fromEntries(Object.entries(item).filter(([k]) => !EXCEDENTE_INTERNAL_FIELDS.has(k)));
}

function parseExcedentesEdit(valor: unknown): Record<string, unknown> | null {
  let raw: unknown = valor;
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw);
    } catch {
      return null;
    }
  }
  let items: unknown[] | null = null;
  if (Array.isArray(raw)) items = raw;
  else if (isRecord(raw) && Array.isArray(raw.items)) items = raw.items;
  if (!items) return null;
  return { items: items.map(sanitizeExcedenteItem) };
}

function parseJsonObjectIfString(valor: unknown): Record<string, unknown> | null {
  if (isRecord(valor)) return valor;
  if (typeof valor === "string") {
    try {
      const parsed = JSON.parse(valor);
      return isRecord(parsed) ? parsed : null;
    } catch {
      return null;
    }
  }
  return null;
}

function normalizeEditedExtractionValue(campo: string, valor: unknown): unknown {
  if ([
    "numero_de_documentos",
    "numero_de_colaboradores",
    "numero_de_prolabores",
    "numero_de_estabelecimentos",
  ].includes(campo)) {
    return parseNullableNumber(valor);
  }
  return valor;
}

function parseNullableNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const raw = String(value).replace(/[^\d,.-]/g, "").trim();
  if (!raw) return null;
  const normalized = raw.includes(",")
    ? raw.replace(/\./g, "").replace(",", ".")
    : raw;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}
