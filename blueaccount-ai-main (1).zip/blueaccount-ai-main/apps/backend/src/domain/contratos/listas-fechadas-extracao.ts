import { normalizarRegimeTributario } from "../clientes/regime-tributario.js";
import { normalizarIndiceReajuste } from "./indice-reajuste.js";

/**
 * Campos de extração cujo valor pertence a uma lista fechada.
 *
 * Existe por causa do fallback de `fonte` em `getField` (contrato-payload.ts): quando o
 * modelo não consegue extrair o valor (`valor_extraido: null`), o trecho verbatim do
 * documento é usado no lugar. Para campo de texto livre isso é útil — a cláusula é uma
 * aproximação melhor que vazio. Para campo de lista fechada é dano puro, porque o trecho
 * nunca é um item da lista:
 *
 * - `indice_reajuste` com "IPCA/IBGE, todo mês de maio, iniciando-se em maio/2027" não
 *   casa em `normalizarIndiceReajuste`, então o reajuste anual ignora o contrato em
 *   silêncio ("Índice de reajuste ausente ou não suportado");
 * - `regime_tributario` com a cláusula inteira faz `normalizarRegimeTributario` **lançar**
 *   `RegimeTributarioInvalidoError` — 400 na confirmação da revisão, com mensagem que
 *   culpa o contador por um texto que ele nunca digitou.
 *
 * Então o fallback só vale quando a própria `fonte` é um item da lista (a extração pode
 * ter deixado `valor_extraido` vazio com o trecho já sendo exatamente "IPCA").
 */
const LISTAS_FECHADAS_EXTRACAO: Record<string, (valor: string) => boolean> = {
  indice_reajuste: (valor) => normalizarIndiceReajuste(valor) !== null,
  // normalizarRegimeTributario lança no irreconhecível (é o gate de acurácia da
  // extração); aqui só queremos o teste de pertencimento, sem o lançamento.
  regime_tributario: (valor) => {
    try {
      return normalizarRegimeTributario(valor) !== null;
    } catch {
      return false;
    }
  },
};

/** `true` quando o campo tem lista fechada de valores válidos. */
export function ehCampoDeListaFechada(campo: string): boolean {
  return Object.prototype.hasOwnProperty.call(LISTAS_FECHADAS_EXTRACAO, campo);
}

/**
 * `true` quando o texto é um item da lista fechada do campo (aceitando as variantes que
 * o normalizador do campo reconhece: "IGPM" → IGP-M, "PF" → Pessoa Física).
 * Campo sem lista fechada devolve `true`: não há lista para violar.
 */
export function textoPertenceAListaFechada(campo: string, texto: string): boolean {
  const pertence = LISTAS_FECHADAS_EXTRACAO[campo];
  return pertence ? pertence(texto) : true;
}
