import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => {
  const ensureDatabase = vi.fn();
  const runQueryWithRls = vi.fn();

  const agenteRepo = {
    find: vi.fn(),
    findOne: vi.fn(),
    create: vi.fn(),
    save: vi.fn(),
    remove: vi.fn(),
    delete: vi.fn(),
  };

  return { ensureDatabase, runQueryWithRls, agenteRepo };
});

vi.mock("../../autenticacao/autenticacao.service.js", () => ({
  ensureDatabase: mocks.ensureDatabase,
}));

vi.mock("../../../database/data-source.js", () => ({
  runQueryWithRls: mocks.runQueryWithRls,
}));

const { listAgentes, getAgente, createAgente, patchAgente, deleteAgente } =
  await import("../agentes.service.js");

function makeManager() {
  return {
    find: mocks.agenteRepo.find,
    findOne: mocks.agenteRepo.findOne,
    create: (_entity: unknown, data: unknown) => ({ ...data as object }),
    save: mocks.agenteRepo.save,
    remove: mocks.agenteRepo.remove,
    delete: mocks.agenteRepo.delete,
  };
}

describe("agentes service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.runQueryWithRls.mockImplementation(
      async (_rls: unknown, cb: (m: ReturnType<typeof makeManager>) => Promise<unknown>) =>
        cb(makeManager()),
    );
  });

  describe("listAgentes", () => {
    it("returns all agentes ordered by created_at desc", async () => {
      const agentes = [{ id: "a1", nome: "Agente A" }, { id: "a2", nome: "Agente B" }];
      mocks.agenteRepo.find.mockResolvedValue(agentes);

      const result = await listAgentes("escritorio-1");

      expect(mocks.ensureDatabase).toHaveBeenCalledTimes(1);
      expect(mocks.agenteRepo.find).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ order: { created_at: "DESC" } }),
      );
      expect(result).toEqual(agentes);
    });
  });

  describe("getAgente", () => {
    it("returns agente when found", async () => {
      const agente = { id: "a1", nome: "Agente A" };
      mocks.agenteRepo.findOne.mockResolvedValue(agente);

      const result = await getAgente("escritorio-1", "a1");

      expect(result).toEqual(agente);
      expect(mocks.agenteRepo.findOne).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ where: { id: "a1" } }),
      );
    });

    it("returns null when not found", async () => {
      mocks.agenteRepo.findOne.mockResolvedValue(null);

      const result = await getAgente("escritorio-1", "nao-existe");

      expect(result).toBeNull();
    });
  });

  describe("createAgente", () => {
    it("creates agente with required and optional fields", async () => {
      const saved = { id: "a1", nome: "Novo Agente", descricao: "Desc", instrucoes: "Instrução", ativo: true, configuracoes: null };
      mocks.agenteRepo.save.mockResolvedValue(saved);

      const result = await createAgente("escritorio-1", {
        nome: "Novo Agente",
        descricao: "Desc",
        instrucoes: "Instrução",
      });

      expect(mocks.agenteRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ nome: "Novo Agente", ativo: true }),
      );
      expect(result).toEqual(saved);
    });

    it("defaults nullable fields to null", async () => {
      const saved = { id: "a2", nome: "Simples", descricao: null, instrucoes: null, configuracoes: null, ativo: true };
      mocks.agenteRepo.save.mockResolvedValue(saved);

      await createAgente("escritorio-1", { nome: "Simples" });

      expect(mocks.agenteRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ descricao: null, instrucoes: null, configuracoes: null }),
      );
    });
  });

  describe("patchAgente", () => {
    it("updates provided fields and returns patched agente", async () => {
      const existing = { id: "a1", nome: "Antigo", descricao: null, instrucoes: null, ativo: true, configuracoes: null };
      mocks.agenteRepo.findOne.mockResolvedValue(existing);
      mocks.agenteRepo.save.mockResolvedValue({ ...existing, nome: "Novo", ativo: false });

      const result = await patchAgente("escritorio-1", "a1", { nome: "Novo", ativo: false });

      expect(mocks.agenteRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ nome: "Novo", ativo: false }),
      );
      expect(result).toMatchObject({ nome: "Novo", ativo: false });
    });

    it("returns null when agente not found", async () => {
      mocks.agenteRepo.findOne.mockResolvedValue(null);

      const result = await patchAgente("escritorio-1", "nao-existe", { nome: "X" });

      expect(result).toBeNull();
      expect(mocks.agenteRepo.save).not.toHaveBeenCalled();
    });

    it("updates instrucoes to null when explicitly set", async () => {
      const existing = { id: "a1", nome: "Agente", instrucoes: "Instrução antiga", ativo: true };
      mocks.agenteRepo.findOne.mockResolvedValue(existing);
      mocks.agenteRepo.save.mockResolvedValue({ ...existing, instrucoes: null });

      await patchAgente("escritorio-1", "a1", { instrucoes: null });

      expect(mocks.agenteRepo.save).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ instrucoes: null }),
      );
    });
  });

  describe("deleteAgente", () => {
    it("removes agente and returns true", async () => {
      const agente = { id: "a1", nome: "Agente A" };
      mocks.agenteRepo.findOne.mockResolvedValue(agente);
      mocks.agenteRepo.delete.mockResolvedValue({ affected: 1 });
      mocks.agenteRepo.remove.mockResolvedValue(undefined);

      const result = await deleteAgente("escritorio-1", "a1");

      expect(result).toBe(true);
      expect(mocks.agenteRepo.delete).toHaveBeenCalledWith(
        expect.anything(),
        { agente_id: "a1" },
      );
      expect(mocks.agenteRepo.remove).toHaveBeenCalledWith(expect.anything(), agente);
    });

    it("returns false when agente not found", async () => {
      mocks.agenteRepo.findOne.mockResolvedValue(null);

      const result = await deleteAgente("escritorio-1", "nao-existe");

      expect(result).toBe(false);
      expect(mocks.agenteRepo.remove).not.toHaveBeenCalled();
    });
  });
});
