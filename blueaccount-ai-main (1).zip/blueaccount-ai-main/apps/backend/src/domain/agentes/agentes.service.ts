import { runQueryWithRls } from "../../database/data-source.js";
import { AcaoAi } from "../../database/modules/tenant/entities/acao-ai.entity.js";
import { Agente } from "../../database/modules/tenant/entities/agente.entity.js";
import { ensureDatabase } from "../autenticacao/autenticacao.service.js";

export type AgenteCreateInput = {
  nome: string;
  descricao?: string | null;
  instrucoes?: string | null;
  configuracoes?: Record<string, unknown> | null;
};

export type AgentePatchInput = {
  nome?: string;
  descricao?: string | null;
  instrucoes?: string | null;
  ativo?: boolean;
  configuracoes?: Record<string, unknown> | null;
};

export async function listAgentes(escritorioId: string): Promise<Agente[]> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.find(Agente, { order: { created_at: "DESC" } });
  });
}

export async function getAgente(escritorioId: string, agenteId: string): Promise<Agente | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    return manager.findOne(Agente, { where: { id: agenteId } });
  });
}

export async function createAgente(escritorioId: string, input: AgenteCreateInput): Promise<Agente> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const agente = manager.create(Agente, {
      nome: input.nome,
      descricao: input.descricao ?? null,
      instrucoes: input.instrucoes ?? null,
      configuracoes: input.configuracoes ?? null,
      ativo: true,
    });
    return manager.save(Agente, agente);
  });
}

export async function patchAgente(
  escritorioId: string,
  agenteId: string,
  input: AgentePatchInput,
): Promise<Agente | null> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const agente = await manager.findOne(Agente, { where: { id: agenteId } });
    if (!agente) return null;

    if (input.nome !== undefined) agente.nome = input.nome;
    if ("descricao" in input) agente.descricao = input.descricao ?? null;
    if ("instrucoes" in input) agente.instrucoes = input.instrucoes ?? null;
    if (input.ativo !== undefined) agente.ativo = input.ativo;
    if ("configuracoes" in input) agente.configuracoes = input.configuracoes ?? null;

    return manager.save(Agente, agente);
  });
}

export async function resolveOrCreateSistemaAgente(escritorioId: string): Promise<Agente> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const existing = await manager.findOne(Agente, {
      where: { ativo: true },
      order: { created_at: "ASC" },
    });
    if (existing) return existing;

    const agente = manager.create(Agente, {
      nome: "Sistema",
      descricao: "Agente padrão para ações fixas geradas por regras.",
      instrucoes: null,
      configuracoes: null,
      ativo: true,
    });
    return manager.save(Agente, agente);
  });
}

export async function deleteAgente(escritorioId: string, agenteId: string): Promise<boolean> {
  await ensureDatabase();
  return runQueryWithRls({ escritorio_id: escritorioId }, async (manager) => {
    const agente = await manager.findOne(Agente, { where: { id: agenteId } });
    if (!agente) return false;
    await manager.delete(AcaoAi, { agente_id: agenteId });
    await manager.remove(Agente, agente);
    return true;
  });
}
