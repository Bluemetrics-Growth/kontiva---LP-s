# `src/domain/agentes`

Domínio de regras puras para a entidade `Agente`.

## Responsabilidade

- listar agentes do escritório;
- carregar detalhe por id;
- criar, atualizar e remover agentes;
- manter as regras de persistência e RLS fora do controller Nest.

As ações geradas por IA ficam em `src/domain/acoes-ai`. A orquestração HTTP/Nest dos dois concerns fica em `src/modules/agentes`.

## Arquivos

- `agentes.service.ts` — casos de uso de CRUD da entidade `Agente`.
- `tests/agentes.service.test.ts` — cobertura de domínio.

## Regra prática

Use este domínio quando a mudança for sobre cadastro/configuração de agentes. Use `src/domain/acoes-ai` quando a mudança for sobre ações, histórico, regras ou execução de IA.
