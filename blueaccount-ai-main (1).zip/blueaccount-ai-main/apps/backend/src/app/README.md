# `src/app`

Esta pasta concentra o bootstrap da aplicação BlueAccount.

O objetivo aqui é manter a inicialização do servidor separada da regra de negócio, para que o restante do projeto possa crescer em camadas mais específicas.

## Responsabilidade desta pasta

`src/app` deve cuidar apenas de:

- criar o bootstrap da aplicação Nest
- inicializar o servidor HTTP
- manter o ponto de entrada do backend fino e previsível

## Arquivos atuais

- [`app.module.ts`](./app.module.ts)

## Fluxo atual

1. [`src/server.ts`](../server.ts) lê a porta e chama [`bootstrap()`](../main.ts)
2. [`main.ts`](../main.ts) sobe o Nest e garante o banco via infraestrutura
3. [`AppModule`](./app.module.ts) importa os módulos base de [`src/modules`](../modules)
4. `main.ts` expõe os assets públicos com o próprio `NestApplication`
5. o servidor passa a escutar a porta configurada

Os módulos principais da aplicação já vivem no runtime Nest.

## O que fica aqui

Esta pasta pode receber, no futuro:

- composição do bootstrap Nest
- bootstrap de observabilidade
- inicialização de integrações que precisam existir antes do `listen()`

Um detalhe importante: `src/domain/extracao` agora cria os agentes sob demanda, para que o bootstrap não dispare efeitos colaterais de IA ou logging no import.
Os assets públicos continuam sendo servidos a partir de `src/public`, mas agora isso é feito pelo próprio bootstrap Nest.

## O que não deve ficar aqui

Evite colocar nesta pasta:

- regras de cálculo de cobrança
- queries complexas de domínio
- validações de negócio
- transformações de dados específicas de um caso de uso
- lógica de persistência detalhada
- composição de rotas da API

Essas responsabilidades devem sair para `src/domain`, `src/http` e `src/infrastructure` conforme as próximas refatorações.

## Testes

Os testes de bootstrap ficam em:

- [`tests/start-server.test.ts`](./tests/start-server.test.ts)

Eles existem para garantir que a composição da aplicação não quebre enquanto a estrutura é reorganizada.

## Regra prática

Se a mudança for sobre "como o servidor sobe", ela provavelmente pertence a `src/app`.

Se a mudança for sobre "o que a aplicação faz", ela provavelmente pertence a outra camada.
