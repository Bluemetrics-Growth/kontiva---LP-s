import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { Settings } from "../../settings.js";

describe("Settings", () => {
  const tempDirs: string[] = [];

  afterEach(() => {
    vi.unstubAllEnvs();
    for (const dir of tempDirs.splice(0)) {
      rmSync(dir, { recursive: true, force: true });
    }
  });

  it("lets process env override values loaded from an env file", () => {
    const dir = mkdtempSync(join(tmpdir(), "kontiva-settings-"));
    tempDirs.push(dir);
    const envFile = join(dir, ".env");
    writeFileSync(envFile, "DOCUMENT_UPLOAD_FILE_SYSTEM_PATH=from-file\n", "utf8");
    vi.stubEnv("DOCUMENT_UPLOAD_FILE_SYSTEM_PATH", "from-process");

    const settings = new Settings(envFile);

    expect(settings.DOCUMENT_UPLOAD_FILE_SYSTEM_PATH).toBe("from-process");
  });

  it("exposes a trimmed optional Step Functions endpoint", () => {
    const dir = mkdtempSync(join(tmpdir(), "kontiva-settings-"));
    tempDirs.push(dir);
    const envFile = join(dir, ".env");
    writeFileSync(envFile, "STEP_FUNCTIONS_ENDPOINT= http://localhost:8083/ \n", "utf8");
    // get() prioriza process.env; limpar a var garante que lemos o valor do arquivo
    // (o .env raiz do dev pode ter STEP_FUNCTIONS_ENDPOINT quando o harness local está ativo).
    vi.stubEnv("STEP_FUNCTIONS_ENDPOINT", undefined);

    expect(new Settings(envFile).STEP_FUNCTIONS_ENDPOINT).toBe("http://localhost:8083/");
  });
});
