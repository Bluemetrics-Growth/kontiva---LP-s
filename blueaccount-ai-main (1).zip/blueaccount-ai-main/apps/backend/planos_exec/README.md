# Planos de Execução - BlueAccount Backend

Documentação técnica, arquitetura e planos de desenvolvimento.

## 📋 Índice

- [Arquitetura](#arquitetura)
- [Ordem de Decisão](#ordem-de-decisão)
- [Padrões de Código](#padrões-de-código)
- [Roadmap](#roadmap)

---

## Arquitetura

### Visão Geral das Camadas

```
┌──────────────────────────────────┐
│  HTTP Layer (NestJS Controllers) │  ← Entrada de requisições
└──────────────┬───────────────────┘
               │
┌──────────────┴──────────────────┐
│  Modules (Nest Services)         │  ← Orquestração
│  - Controllers                   │  ← Roteamento
│  - Validação                     │  ← Guards, middleware
└──────────────┬───────────────────┘
               │
┌──────────────┴──────────────────┐
│  Domain Layer                    │  ← Lógica de negócio pura
│  - Regras de validação           │  ← Sem dependências Nest
│  - Cálculos                      │  ← Testável em isolamento
│  - Orquestração de dados         │
└──────────────┬───────────────────┘
               │
┌──────────────┴──────────────────┐
│  Infrastructure                  │  ← Integrações técnicas
│  - AWS (Cognito, Bedrock, S3)    │  ← Abstraído via interfaces
│  - Logging                       │  ← Factory pattern para IA
│  - External APIs                 │
└──────────────┬───────────────────┘
               │
┌──────────────┴──────────────────┐
│  Database Layer                  │  ← Persistência
│  - TypeORM                       │  ← Multi-schema (tenant)
│  - RLS (Row-Level Security)      │  ← Isolamento por tenant
│  - Migrations                    │  ← Versionamento de schema
└──────────────────────────────────┘
```

### Multi-Tenant com RLS

**Isolamento por Schema:**
```sql
public schema         ← escritorios, usuarios, admin_sessions
tenant_<id> schema    ← clientes, contratos, documentos, etc (por cliente)
```

**Segurança:**
```typescript
// Toda query executa com tenant_id setado
runQueryWithRls({ escritorio_id }, async (manager) => {
  // SELECT * FROM clientes
  // ↓ Aplicado automaticamente:
  // SELECT * FROM clientes WHERE escritorio_id = $1
});
```

---

## Ordem de Decisão

**Pergunta:** Onde colocar novo código?

### 1. É regra de negócio (validação, cálculo, lógica)?
→ **`src/domain/{modulo}/`**
- Pura, sem dependências NestJS
- Testável em isolamento
- Reutilizável em outros contextos

### 2. É orquestração Nest (controller, service)?
→ **`src/modules/{modulo}/`**
- Controller: HTTP routing
- Service: delega para domain
- Deve ser leve

### 3. É integração técnica (AWS, auth, logging)?
→ **`src/infrastructure/`**
- Abstraído via interfaces
- Fácil de mockar em testes
- Não misturar com domain

### 4. É tipo de banco/schema?
→ **`src/database/`**
- Entity: modelo TypeORM
- Migration: versionamento
- RLS: políticas de segurança

---

## Padrões de Código

### Novo Módulo

**Estrutura:**
```
src/modules/{novo}/
├── {novo}.module.ts       ← Composição Nest
├── {novo}.controller.ts   ← HTTP entry
├── {novo}.service.ts      ← Orquestração → domain
└── README.md              ← Documentação

src/domain/{novo}/
├── {novo}.service.ts      ← Lógica pura
└── tests/
    └── {novo}.service.test.ts
```

**Controller Pattern:**
```typescript
@Controller('{resource}')
@UseGuards(AuthGuard)
export class SomeController {
  constructor(private service: SomeService) {}
  
  @Get()
  async list(@Req() req: AuthRequest) {
    return this.service.list(req.auth.escritorio_id);
  }
  
  // GET, POST, PATCH, DELETE...
}
```

**Service Pattern:**
```typescript
@Injectable()
export class SomeService {
  constructor(private domainService: SomeDomainService) {}
  
  async list(escritorioId: string) {
    return this.domainService.listByEscritorio(escritorioId);
  }
}
```

**Domain Pattern:**
```typescript
export async function listByEscritorio(
  escritorioId: string
): Promise<Resultado[]> {
  // Validação
  if (!escritorioId) throw new Error('escritorio_id required');
  
  // Cálculo/transformação
  const dados = await db.query(/* ... */);
  
  // Retorno
  return dados.map(transformar);
}
```

### Validação com Zod

```typescript
import { z } from 'zod';

// Schema
const CreateSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
  age: z.number().int().positive().optional(),
});

type CreateInput = z.infer<typeof CreateSchema>;

// Uso
export async function create(input: unknown): Promise<Result> {
  const data = CreateSchema.parse(input); // ZodError se inválido
  // ... resto da lógica
}
```

### Testes

```typescript
describe('SomeDomainService', () => {
  describe('create', () => {
    it('should create with valid input', async () => {
      const result = await create({
        email: 'test@test.com',
        name: 'Test',
      });
      expect(result.id).toBeDefined();
    });
    
    it('should throw on invalid email', async () => {
      await expect(
        create({ email: 'invalid', name: 'Test' })
      ).rejects.toThrow();
    });
  });
});
```

---

## Roadmap

### Fase Atual (Sprint)

- ✅ Autenticação com Cognito
- ✅ CRUD de clientes
- ✅ Upload e OCR de documentos
- ✅ Extração de contratos via IA
- ✅ Extração de relatórios via IA
- ✅ Consolidação de valores_a_cobrar
- ✅ Aprovação de serviços_contratados

### Próxima Fase

- [ ] IA calcula `valores_calculados` (análise vs contratado)
- [ ] Workflow de aprovação/rejeição de cobrança
- [ ] Geração de relatórios/faturas em PDF
- [ ] Dashboard de métricas por cliente

### Médio Prazo

- [ ] E2E tests (API + Frontend)
- [ ] Webhooks (documento enviado, extração concluída)
- [ ] Rate limiting e throttling
- [ ] Audit logs de mudanças

### Longo Prazo

- [ ] Integrações com ERPs (SAP, Omie, Totvs)
- [ ] Suporte a XML, EDI, CNAB
- [ ] Machine learning para análise de riscos
- [ ] API pública para integradores

---

## Referências Rápidas

### Executar Testes
```bash
npm run test              # Uma vez
npm run test:watch       # Contínuo
npm run test:cov         # Coverage
```

### Migrations
```bash
npm run migration:generate -- --name=AddField
npm run migration:run
npm run migration:sync-tenants
npm run migration:revert
```

### Dev
```bash
npm run dev:backend       # Com hot-reload
npm run build             # Build para produção
```

### Debugar RLS
```bash
# Terminal 1: Backend
npm run dev:backend

# Terminal 2: psql
psql $DATABASE_URL
SELECT current_setting('app.current_tenant_id');
SELECT * FROM pg_policies WHERE tablename = 'clientes';
```

---

**Última atualização:** 2026-04-29

Para documentação de módulos específicos, veja os READMEs em `src/modules/*/`.
