#!/usr/bin/env node
// Guarda de chaves primárias UUIDv7.
//
// A partir da migration 1786500000000, toda coluna `uuid` de chave primária nasce com
// `DEFAULT uuid_generate_v7()` (ordenado por tempo). O problema é que o TypeORM continua emitindo
// `DEFAULT uuid_generate_v4()` ao gerar CREATE TABLE — o gerador é fixo no driver
// (`typeorm/driver/postgres/PostgresDriver.js`, getter `uuidGenerator`) e não tem hook para função
// customizada. Ou seja: toda tabela nova sai de fábrica em v4 e precisa ser corrigida à mão.
//
// Esta guarda falha o build quando uma migration NOVA (timestamp acima do corte) ainda menciona
// `uuid_generate_v4()` ou `gen_random_uuid()`.
//
// Exceção legítima (ex.: um `down()` que restaura o default antigo): anote a linha com
// `// uuid-guard-ok: <motivo>` na própria linha ou na de cima.
//
// Roda sem dependências. `node scripts/verificar-uuid-v7.mjs` a partir de apps/backend.

import { readdirSync, readFileSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath } from "node:url";

const backendRoot = join(dirname(fileURLToPath(import.meta.url)), "..");
const migrationDirs = [
  join(backendRoot, "src/database/modules/public/migrations"),
  join(backendRoot, "src/database/modules/tenant/migrations"),
];

/**
 * Migrations com timestamp até este valor são históricas: já rodaram em produção e tiveram seus
 * DEFAULTs convertidos pelo DO-block das migrations 1786500000000/1786600000000. Não devem ser
 * editadas — o corte é o timestamp da última migration anterior à virada.
 */
const CORTE_UUID_V7 = 1786400000000;

const ALLOW_MARKER = "uuid-guard-ok";
const RE_GERADOR_LEGADO = /\b(uuid_generate_v4|gen_random_uuid)\s*\(\s*\)/g;

/** True se a linha do achado (ou a anterior) tiver o marcador de exceção. */
function temExcecao(linhas, indiceZeroBased) {
  const atual = linhas[indiceZeroBased] ?? "";
  const anterior = linhas[indiceZeroBased - 1] ?? "";
  return atual.includes(ALLOW_MARKER) || anterior.includes(ALLOW_MARKER);
}

/**
 * True para linhas que são só comentário. Ao contrário da guarda de RLS, esta ignora prosa: um
 * doc-comment explicando por que o default antigo era `uuid_generate_v4()` não é uma violação.
 *
 * O teste é deliberadamente conservador — só descarta a linha quando ela COMEÇA com marcador de
 * comentário. Comentário no fim de uma linha de código não é removido, então nenhum literal de
 * string (ex.: uma URL com `//`) some junto.
 */
function ehLinhaDeComentario(linha) {
  const t = linha.trim();
  return t.startsWith("*") || t.startsWith("//") || t.startsWith("/*");
}

/** Extrai o timestamp do nome do arquivo (`<timestamp>-nome.ts`); null se não casar o padrão. */
function extrairTimestamp(nomeArquivo) {
  const m = /^(\d+)-/.exec(nomeArquivo);
  return m ? Number(m[1]) : null;
}

const violacoes = [];
let analisados = 0;

for (const dir of migrationDirs) {
  for (const nome of readdirSync(dir)) {
    if (!nome.endsWith(".ts")) continue;

    const timestamp = extrairTimestamp(nome);
    if (timestamp === null || timestamp <= CORTE_UUID_V7) continue;

    analisados += 1;
    const caminho = join(dir, nome);
    const conteudo = readFileSync(caminho, "utf8");
    const linhas = conteudo.split("\n");
    const rel = relative(backendRoot, caminho);

    for (const m of conteudo.matchAll(RE_GERADOR_LEGADO)) {
      const linha0 = conteudo.slice(0, m.index).split("\n").length - 1;
      if (ehLinhaDeComentario(linhas[linha0] ?? "")) continue;
      if (temExcecao(linhas, linha0)) continue;
      violacoes.push({ rel, linha: linha0 + 1, trecho: (linhas[linha0] ?? "").trim(), gerador: m[1] });
    }
  }
}

if (violacoes.length > 0) {
  console.error(`\n[uuid-guard] ${violacoes.length} chave(s) primária(s) nascendo em UUIDv4:\n`);
  for (const v of violacoes) {
    console.error(`  ${v.rel}:${v.linha}`);
    console.error(`    ${v.trecho}`);
    console.error(`    → ${v.gerador}() gera UUID aleatório; troque por uuid_generate_v7().\n`);
  }
  console.error("O TypeORM emite `DEFAULT uuid_generate_v4()` em toda tabela nova que ele gera —");
  console.error("edite a migration à mão trocando por `DEFAULT uuid_generate_v7()`.");
  console.error("Se o uso for intencional (ex.: `down()` restaurando o default antigo), anote a linha");
  console.error("com `// uuid-guard-ok: <motivo>`.\n");
  process.exit(1);
}

console.log(`[uuid-guard] OK — ${analisados} migration(s) acima do corte ${CORTE_UUID_V7}, nenhuma violação.`);
