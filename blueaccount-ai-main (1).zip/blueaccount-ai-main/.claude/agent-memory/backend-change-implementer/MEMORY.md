# Memory Index

- [Cliente response shape omits jsonb allowlists](project_cliente_response_shape_omits_jsonb_allowlists.md) — create/patch response never echoes cnaes_*/ncms_permitidos, only ClienteDetalhe (GET) does
