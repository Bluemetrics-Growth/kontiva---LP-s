# Claude hooks

This folder contains **Claude Code** hooks that run before tool calls.

- `pre_tool_use`: blocks commit attempts (via the Git tool or `git commit` commands).

If you need to allow commits temporarily, rename or remove `pre_tool_use` (or adjust its rules).
