---
name: blueaccount-mcp-navigator
description: Use after blueaccount-project-navigator for any work in the Kontiva MCP server at `apps/mcp` of the BlueAccount/Kontiva MVP monorepo — adding or editing a tool, resource, or prompt, the API client, OAuth/session forwarding, transport, audit headers, or connector-safe sanitization. Explains the per-concern layout, the acyclic dependency rule, and the tool-surface guardrails (what MCP may never expose).
---

# BlueAccount MCP Navigator

Use this skill before changing code in `apps/mcp`, the TypeScript MCP server that exposes a
small, chatbot-safe subset of the Kontiva HTTP API to AI agents (Claude, ChatGPT, Strands, etc.).

It is the companion to `blueaccount-project-navigator`: that skill picks the app; this one maps
the inside of `apps/mcp` after the navigator points you here.

Read first: `apps/mcp/README.md` (run instructions, env vars, the tool catalogue, and the same
source layout summarized below) and `docs/AI_AGENT_TOOLS.md` (the tool-surface boundary — what MCP
may and may not expose).

## Start Here

1. Decide what kind of change it is: a tool, a resource, a prompt, client/transport/auth wiring,
   or a shared helper. The layout below maps each to exactly one place.
2. Reuse the existing pattern in that file instead of inventing a new one.
3. Keep the dependency direction acyclic (see below).
4. Preserve the public surface: the only entry point is `registerKontivaTools` in
   `src/tools/index.ts`, imported by `src/server.ts`.
5. Respect the guardrails enforced by `tests/tool-surface.test.ts`.

## Naming

Follow the project-wide Portuguese naming rule for new project-owned helpers, files, domains, and
internal types when the name is not protocol-facing. Preserve MCP tool names, OAuth/MCP protocol
fields, env vars, HTTP route contracts, SDK/framework names, and other external/public contracts in
their existing language.

## Layout (`apps/mcp/src/`)

`server.ts` stays at the root — McpServer creation, stdio/HTTP transport, profile-bound session management,
OAuth metadata, the `/mcp` + `/mcp/internal` routes, and `DISCOVERY_TOOL_NAMES`. `profiles.ts` owns the
assistant/internal/full capability allowlists.
Everything else is split by concern:

- `client/` — HTTP + auth access to the backend.
  - `api-client.ts`: `KontivaApiClient` (auth headers, cookie/token handling, request auditing),
    plus `APP_COOKIE_NAME`, `ADMIN_COOKIE_NAME`, `LEGACY_*`, types `ApiRequestOptions`/`HttpMethod`.
  - `oauth-flow.ts`: PKCE flow state (`generatePkce`, `storeFlow`, `exchangeCodeForToken`, …).
  - `index.ts`: barrel re-exporting both. Import the client from `client/index.js` everywhere.
- `tools/` — one file per business domain, each exporting `registerXTools(server, client)`:
  - `navegacao.ts` — `describe_platform_usage`, `montar_link`, `faq` (tool), and tool-mirrors of
    the autonomous-billing and manual-contract guides. No API calls.
  - `health-auth.ts` — `kontiva_health`, `kontiva_auth_status` (cold-start, low/no auth).
  - `clientes.ts`, `contratos.ts`, `documentos.ts`, `valores-a-cobrar.ts`, `auditoria.ts`,
    `cobrancas.ts`, `conectores.ts`, `acoes-ai.ts`, `simulacoes.ts`.
  - `index.ts` — exports `registerKontivaTools`; wires resources, every domain, then prompts.
    This is the only file `server.ts` imports for tools.
- `resources/index.ts` — `registerResources`: the four read-only resources
  (`kontiva://api/endpoints`, `kontiva://relatorios/tipos`, and the two versioned MCP Apps UI resources).
- `resources/interface-cobranca.ts` — registers `ui://widget/kontiva-resumo-cobranca-v2.html`,
  inlining the generated React bundle with a closed outbound CSP.
- `prompts/index.ts` — `registerPrompts`: the seven MCP prompts. The internal profile exposes
  exactly the five prompts required by the billing, contract, and report runtimes; the assistant/full
  profiles are filtered declaratively by `profiles.ts`.
- `shared.ts` — cross-cutting helpers: the `registerJsonTool` factory + `callApi` transport,
  structured logging, all response `sanitize*` functions, deterministic app-link builders
  (`buildAppLink`, `buildReviewUrl`, `PAGE_KEYS`), and small object utils (`asArray`, `asRecord`,
  `compactObject`, `pickDefined`). Imports only `client/`.
- `content.ts` — static markdown + prompt builders shared by **both** a tool and a prompt
  (`buildFaqGuide`, `buildGerarCobrancaAutonomaPrompt`, `fetchTiposRelatorioTexto`,
  `preencherContratoGuide`, `platformUsageMarkdown`, `endpointReferenceMarkdown`).
- `../web/` — isolated React MCP Apps UI. It consumes sanitized `structuredContent`, keeps PT/EN
  messages together, and builds into `dist/interface`; it never receives credentials or calls the API directly.

### Dependency direction (keep acyclic)

```
client → shared → content → { tools/*, resources, prompts } → tools/index → server
```

The same guide text backs both a tool (`tools/navegacao.ts`) and a prompt (`prompts/index.ts`).
That shared text lives in `content.ts` specifically to avoid a `tools → prompts` cycle. Do **not**
move prompt/markdown builders into `prompts/`, and do not import from `tools/`/`prompts/`/
`resources/` anywhere except `tools/index.ts` and `server.ts`.

## Where each change goes

- **New tool for an existing domain** → add a `registerJsonTool(server, client, {…})` (for a
  thin API passthrough) or a `server.registerTool(…)` (for custom logic) in the matching
  `tools/<domain>.ts`. Then add the name to `DISCOVERY_TOOL_NAMES` in `server.ts`, classify it in
  `profiles.ts`, and add it to the catalogue in `README.md`. MCP initialization is always authenticated.
- **New domain** → new `tools/<domain>.ts` exporting `registerXTools`; call it from
  `tools/index.ts`.
- **New resource** → `resources/index.ts` (split a dedicated resource file when it owns a UI bundle).
  **New prompt** → `prompts/index.ts` (put any text it
  shares with a tool in `content.ts`).
- **Client/transport/auth** (cookies, bearer tokens, audit headers, base URLs) → `client/` for the
  request layer, `server.ts` for transport/session/OAuth metadata.
- **A new sanitizer / helper used by more than one domain** → `shared.ts` (export it, then import
  from `../shared.js`). A helper used by exactly one tool can stay module-level in that domain file
  (e.g. `getDocumentoMarkdownFromSource` in `contratos.ts`, `compareSimulacoes` in `simulacoes.ts`).

Imports use `.js` extensions (Node16 ESM): `../client/index.js`, `../shared.js`, `../content.js`.

## Guardrails (`tests/tool-surface.test.ts`)

The test concatenates all `src/**/*.ts` (except `server.ts` and test files) and asserts on the
text. Keep these true:

- Never register the forbidden charge-issuance / agent-invocation tools (e.g.
  `kontiva_enviar_cobranca`, `kontiva_gerar_acoes*`). MCP may read and create manually, never fire
  an external charge or invoke an agent.
- `approval_hash` must never appear in discovery or the README.
- `kontiva_gerar_cobranca` must expose a `review_url` (human review required); MCP never issues.
- Every `server.registerTool("name", …)` must also appear in `DISCOVERY_TOOL_NAMES` and the README.

## Verify (from `apps/mcp`)

```bash
npm run type-check        # broken imports / cycles / dangling fragments
npm run test:tool-surface # forbidden-tool + discovery + prompt-sentinel guards
npm run test:catalog      # profile membership, catalog budgets, coverage baseline
npm run test:tool-contracts # async/pagination/error response contracts
npm run test:http-profiles # authenticated initialize and cross-profile session isolation
npm run build             # emit + correct relative .js import paths in dist/
```

For a behavior check, run `npm run test:catalog`: the production assistant profile must remain within
45 tools / 80 KB with simulations disabled (including the bundled skill discovery descriptions),
while the internal profile must remain exactly nine tools
and five prompts.
Do not commit — leave changes in the working tree for review (see `CLAUDE.md`).
