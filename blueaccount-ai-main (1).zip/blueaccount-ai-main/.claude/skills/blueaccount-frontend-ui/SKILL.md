---
name: blueaccount-frontend-ui
description: Use after blueaccount-project-navigator for any visual or page work in `apps/frontend` of the BlueAccount/Kontiva MVP — creating, editing, refactoring, or reviewing React pages, routes, components, layout, page headers, typography, color, CSS, loading/empty/error states, sidebar navigation, or any new user-visible text (columns, labels, titles, placeholders). Enforces the Kontiva design system, design-token reuse, and mandatory PT+EN i18n for every new string. Skill body is in Portuguese to match the frontend domain vocabulary.
---

# BlueAccount Frontend UI

Manter as paginas do produto coerentes com o shell e o design system Kontiva existentes. Basear decisoes nos arquivos atuais do frontend; nao criar uma linguagem visual paralela.

## Fluxo Obrigatorio

1. Usar primeiro a skill `blueaccount-project-navigator`.
2. Ler `apps/frontend/README.md`, `apps/frontend/src/README.md` e `apps/frontend/src/pages/README.md`.
3. Identificar o shell da pagina:
   - tela autenticada de produto: workspace Kontiva;
   - login ou fluxo publico: seguir a pagina publica vizinha;
   - `/admin`: preservar o layout legado indicado em `src/pages/README.md`.
4. Ler a pagina mais proxima do mesmo fluxo e seus CSS importados antes de editar.
5. Manter orquestracao de rota em `src/pages`, UI reutilizavel em `src/components`, acesso HTTP em `src/lib/api.ts` e estilos Kontiva em `src/kontiva` quando pertencem ao shell/tela.
6. Avaliar explicitamente o impacto de UX e atualizar o guia de uso afetado antes de concluir.
7. Validar visualmente a tela alterada e executar testes/build aplicaveis.

## UX E Guias De Uso Sao Parte Da Mudanca

Toda alteracao em `apps/frontend` deve considerar a experiencia de quem executa a tarefa na tela,
nao apenas a aparencia ou o teste de componente. Antes de implementar, identificar e registrar:

- **quem** usa a tela e qual permissao/papel importa;
- **qual tarefa** a pessoa consegue iniciar, concluir, revisar ou desfazer;
- os estados de entrada, carregamento, vazio, erro, bloqueio, confirmacao e sucesso;
- navegacao, contexto de origem/destino, responsividade, foco por teclado e texto acessivel;
- qualquer dado, permissao, efeito irreversivel ou proximo passo que precise ficar claro.

### Regra obrigatoria de documentacao

Ao alterar uma experiencia visivel, atualizar no mesmo change o guia em
`apps/frontend/src/content/how-to/` que ensina aquele fluxo. Se ele nao existir, criar um guia novo
com frontmatter no proprio Markdown: `slug`, `titulo`, `resumo`, `categoria`, `ordem`, `objetivo`,
`publico`, `pre_requisitos`, `permissoes`, `rotas` e `proximos_guias`. Isso inclui rotas,
navegacao, formularios, acoes, estados, regras de validacao, mensagens, permissao, integracoes
visiveis e mudancas no resultado de uma tarefa.

Para uma mudanca estritamente visual, documentar no guia do fluxo a orientacao que a pessoa passa a
precisar para se localizar ou concluir a tarefa. Se a mudanca nao altera instrucao para o usuario
(por exemplo, cor, espacamento ou correcao interna sem efeito de uso), registrar no resumo de
validacao que o guia foi avaliado e nao exigiu ajuste. Nunca criar um guia artificial para detalhe
interno que o usuario nao executa.

Os guias devem permanecer orientados a tarefa e escaneaveis: abrir com objetivo e pre-requisitos,
usar titulos `##` com verbos, passos numerados curtos, avisos para risco/bloqueio, e links para o
proximo fluxo. Manter uma unica fonte de verdade: texto e metadados no mesmo `.md`; o
`catalogo.ts` apenas valida e deriva o indice publico.

## Naming de Codigo

Mesmo quando o pedido estiver em ingles, nomes novos controlados pelo projeto devem seguir o
vocabulario local. Para componentes, hooks, helpers, arquivos e tipos, espelhar o idioma e o padrao
do dominio vizinho antes de criar um nome novo. Nomes de bibliotecas, props/protocolos externos,
rotas publicas e contratos de API podem preservar o idioma exigido pelo contrato.

Texto visivel ao usuario segue a regra de i18n desta skill: toda string nova nasce em PT e EN via
`translation.json`, sem literal hardcoded em JSX/TSX.

## Referencias Do Workspace Kontiva

Para telas autenticadas com sidebar, usar como referencias primarias:

- `apps/frontend/src/pages/MvpHomePage.tsx`
- `apps/frontend/src/pages/MvpContratosPage.tsx`
- `apps/frontend/src/kontiva/kontiva.css`
- `apps/frontend/src/kontiva/mvp-home.css`

Consultar tambem a pagina/CSS do dominio modificado, por exemplo `mvp-relatorios.css`, `mvp-documents.css`, `mvp-excedentes.css` ou `mvp-faturamento.css`. Existem overrides e estilos em evolucao; preservar o padrao efetivamente carregado pela tela em vez de copiar regras cegamente.

## Tipografia

Reutilizar os tokens definidos em `src/kontiva/kontiva.css`:

| Uso | Token | Fonte |
| --- | --- | --- |
| Titulos, marca e headings | `var(--font-display)` | `Space Grotesk` |
| Texto corrido, botoes e inputs | `var(--font-body)` | `Inter` |
| Destaque editorial em titulo | `var(--font-serif-italic)` / `.serif-accent` | `Instrument Serif` italic |
| Labels tecnicos, breadcrumbs e chips | `var(--font-mono)` | `Inter` |

Aplicar estas regras:

- Usar `h1`/`h2`/`h3` existentes para titulos e manter a hierarquia da pagina vizinha.
- Usar `.serif-accent` somente como destaque curto dentro de titulo, nao como fonte de corpo.
- Usar `.eyebrow` para a categoria acima do titulo, com texto curto em uppercase e ponto ciano quando o padrao do fluxo o exibir.
- Nao introduzir novas familias tipograficas nem valores `font-family` locais quando um token cobre o caso.

## Cores

Usar prioritariamente os tokens Kontiva:

| Finalidade | Token | Valor de referencia |
| --- | --- | --- |
| Texto/titulo principal e acoes escuras | `var(--azul-profundo)` | `#0A1F3F` |
| Variacao escura de interacao | `var(--azul-profundo-2)` | `#122A52` |
| Destaque, foco e acao primaria | `var(--ciano)` | `#00D4FF` |
| Fundo sutil de destaque | `var(--ciano-suave)` | `#E0F9FF` |
| Superficie/card | `var(--branco)` | `#FFFFFF` |
| Fundo do workspace e areas neutras | `var(--cinza-claro)` | `#F2F4F7` |
| Texto auxiliar | `var(--cinza-texto)` | `#6B7280` |
| Texto secundario forte | `var(--cinza-escuro)` | `#374151` |

Aplicar estas regras:

- Preferir tokens e `color-mix(...)` ja usados pelo CSS Kontiva a hexadecimais novos.
- Reservar ciano para foco, destaque, estado ativo e CTA; nao saturar superficies comuns.
- Manter fundos claros e titulos azul-profundo nas telas workspace padrao.
- Para sucesso, alerta ou erro, reutilizar a variante existente no dominio antes de definir nova cor semantica.
- Se uma alteracao realmente exigir um token global novo, adiciona-lo no arquivo de tokens apropriado e revisar impacto nas demais paginas.

## Topo De Pagina

### Paginas Workspace

Em toda pagina autenticada de produto, preservar esta anatomia, adaptando apenas textos e acoes:

```tsx
<main className="ws-main">
  <div className="ws-topbar">
    <div className="ws-crumb">
      <span>Secao</span>
      <span className="ws-crumb__sep">/</span>
      <span className="ws-crumb__active">Pagina</span>
    </div>
  </div>

  <div className="ws-body cl-body">
    <div className="cl-wrap">
      <header className="cl-head">
        <div>
          <div className="eyebrow">
            <span className="dot-cyan" /> Contexto
          </div>
          <h1>
            Titulo <span className="serif-accent">principal</span>.
          </h1>
          <p>Descricao curta da finalidade da tela.</p>
        </div>
        <div className="cl-head-actions">{/* CTA da pagina, quando houver */}</div>
      </header>
    </div>
  </div>
</main>
```

Usar `ws-heading` para estados de onboarding/upload cujo fluxo existente ja o utilize. Usar `cl-head` para listagens, dashboards e cockpits operacionais. Usar nomes especificos existentes, como `home-dashboard-head`, quando estiver estendendo a propria tela que ja possui essa variante.

### Excecoes De Shell

- Nao inserir `ws-topbar` automaticamente em `/login`, `/admin/login` ou fluxos publicos; seguir o shell publico existente.
- Nao migrar `/admin` para o workspace por uma alteracao visual isolada; essa pagina usa `TopNav` e `StatusBar` legados.
- Em rotas de review, detalhe ou processamento, inspecionar a tela vizinha antes de decidir entre topbar completa e variante propria.

## Navegacao: Adicionar Rota a Sidebar

O menu do workspace e definido em `src/kontiva/workspace-nav.ts`. Para expor uma nova rota na sidebar, adicionar uma entrada ao array `WS_NAV`:

```ts
{ key: "minha-rota", label: "Label", icon: IIcone as any, path: "/minha-rota" }
```

- `key` deve ser unico e coincidir com o `activeNav` passado ao `WorkspaceSidebar` da pagina correspondente.
- O componente `WorkspaceSidebar` e instanciado localmente em cada pagina (nao e global); passar `activeNav="minha-rota"` para destacar o item correto.
- Adicionar a rota em `App.tsx` dentro do bloco de `PrivateRoute` antes de testar a navegacao.

## Tokens Globais: styles/variables.css e styles/base.css

Alem de `kontiva.css`, existem dois arquivos de tokens globais em `src/styles`:

- `variables.css`: variaveis CSS de escopo global (cores de sistema, espacamentos, radii). Preferir estas variaveis a valores literais quando cobrem o caso.
- `base.css`: reset e estilos base de HTML semantico (headings, listas, links, body). Nao adicionar overrides de tag HTML em CSS de pagina quando `base.css` ja define o padrao.

Ambos sao carregados via `main.tsx` antes do CSS Kontiva. Nao duplicar variaveis aqui definidas nos arquivos de dominio.

## Paginas de Simulacao (Reforma Tributaria)

`MvpSimulacoesPage` (`/simulacoes`) e `MvpSimulacaoEditorPage` (`/simulacoes/:id`) cobrem o fluxo de simulacao tributaria IBS/CBS/ICMS/ISS.

CSS especifico: `mvp-simulacoes.css` (classes `sim-*`). Reutilizar `mvp-cliente-detail.css` para stats e header de detalhe (classes `cdt-*`, `cl-stat`, `cls-*`).

Componentes internos de referencia: `EditableCell`, `AliquotaCell`, `DataCell`, `AliquotaStat`, `EntradasSection`, `EntradaRow`, `ResultadoPanel`, `Dica`, `GlossarioPanel`. Ver `apps/frontend/src/pages/README.md` para descricao completa.

Padrao de persistencia: cada edicao e enviada imediatamente ao backend e o estado local e substituido pelo retorno da API. Excecao: campos de data usam `DataCell`, que mantem rascunho local e so envia no blur/Enter com data completa, porque `<input type="date">` emite anos parciais durante a digitacao e o recarregamento do estado zerava o campo.

Texto explicativo: campos e resultados desta tela expoem o significado via `Dica` (bolha em hover/foco) e via o painel `GlossarioPanel`. Ao adicionar coluna, alíquota ou linha de resultado nova, adicionar tambem a dica correspondente em `simulations.editor.hints.*` (PT e EN).

## Padrao de Edicao Inline (Contratos e Relatorios)

Telas de revisao e detalhe usam edicao direta sobre colunas da tabela `contratos`, sem chamar agente normalizador:

- **Colunas primitivas**: `<input>` simples por coluna.
- **`instrucoes_de_cobranca`**: `<textarea>` em card separado.
- **Colunas JSONB** (`valores_contratados`, `excedentes`, `adicional_anual`): editores especializados.
  - `valores_contratados` usa `ItemsListEditor` com `JsonbCell` (input primitivo ou textarea JSON aninhado por item).
  - `excedentes` e `adicional_anual` usam `JsonbColumnEditor` (chave-valor recursivo com fallback JSON cru).
- **Aviso de cobranca** (`.rv-warning`): banner amarelo que bloqueia o save quando `valores_contratados` OU `excedentes` estiver vazio e `instrucoes_de_cobranca` tambem estiver vazio.
- **Tabs**: `MvpDetalhesPage` usa "Campos da tabela | Extracao bruta | Documento | Edicoes" como padrao para telas de detalhe de contrato existente.

Esses componentes estao inline nas paginas; refatorar para `src/components` se a duplicacao incomodar.

## Padrao de QA de Relatorios

`MvpRevisaoRelatorioPage` implementa um sistema de qualidade de dados (`RelatorioQaReport`) com dois niveis de severidade:

- **`critical`**: aplica classe `qa-field--critical`; bloqueia confirmacao enquanto o campo estiver marcado.
- **`warning`**: aplica classe `qa-field--warning`; exige checkbox de ciencia do usuario antes de permitir salvar.

Ao extender ou criar telas de revisao que validem campos extraidos, reutilizar este padrao em vez de criar logica de bloqueio ad hoc. O backend e que define a severidade; a UI so aplica as classes e controla o estado de bloqueio.

## Estados de Loading, Erro e Vazio

Usar as classes existentes em vez de criar estilos locais:

| Situacao | Classe/elemento | Exemplo de uso |
| --- | --- | --- |
| Lista vazia ou sem resultados | `cl-empty` | `<div className="cl-empty">Nenhum item.</div>` |
| Loading de pagina de detalhe | `cdt-loading` | `<div className="cdt-loading">Carregando...</div>` |
| Pagina de erro/nao encontrado | `cdt-error-page` + `cdt-error-message` | wrapper + mensagem |
| Erro inline em formulario | `cl-error` | abaixo do campo com problema |

Sempre envolver o estado de loading no mesmo shell de workspace (sidebar + `ws-main`) para evitar saltos de layout.

## Internacionalizacao (i18n): PT e EN Obrigatorios

REGRA INEGOCIAVEL: todo texto novo visivel ao usuario deve nascer em portugues E ingles. Nunca hardcodar uma string literal em JSX/TSX. Isso vale para qualquer texto gerado: titulo de pagina, label de coluna, header de tabela, botao, placeholder, tooltip, mensagem de estado vazio/erro/loading, eyebrow, descricao, opcao de select, texto de badge, aria-label e afins.

O frontend usa `react-i18next` com toggle PT/EN. As chaves vivem em `apps/frontend/src/i18n/locales/pt/translation.json` e `apps/frontend/src/i18n/locales/en/translation.json`, agrupadas por dominio (`shell`, `common`, `home`, etc.). PT e a lingua-fonte/fallback; **toda chave precisa existir nos dois arquivos** ou o EN cai no fallback PT e a traducao fica incompleta.

Ao gerar texto novo (coluna, pagina, componente, etc.):

1. Importar `useTranslation` e chamar `const { t } = useTranslation();`.
2. Substituir cada string visivel por `t("dominio.chave")` em vez de literal.
3. Adicionar a chave nos DOIS arquivos `translation.json` (pt e en) no mesmo dominio, mantendo a mesma estrutura/aninhamento nos dois. Nunca adicionar so em um.
4. Para titulos com destaque serif, separar `...titleLead` e `...titleAccent`. Para listas, usar `t(chave, { returnObjects: true }) as string[]`.
5. Para datas/numeros/moeda, usar `useFormatters()` (`i18n/useFormatters.ts`) em vez de `Intl.*("pt-BR", ...)` fixo. A moeda continua BRL; apenas o locale acompanha o idioma.
6. Labels de sidebar usam `labelKey` em `kontiva/workspace-nav.ts`, resolvido em `WorkspaceSidebar`.

Referencia completa do padrao em `apps/frontend/src/README.md`, secao Internacionalizacao (i18n).

## Checklist De Implementacao

Antes de concluir uma alteracao de frontend, confirmar:

1. A pagina reutiliza `--font-display`, `--font-body`, `--font-serif-italic` e `--font-mono` conforme sua funcao.
2. A paleta usa tokens Kontiva em vez de cores novas desconectadas.
3. O topo corresponde ao shell correto e mantem breadcrumb, eyebrow, titulo, descricao e CTA quando aplicaveis.
4. O CSS foi colocado ao lado do padrao atual do dominio, sem duplicar regra global desnecessariamente.
5. Estados de loading, erro e sucesso continuam tratados.
6. Todo texto novo visivel usa `t(...)` e a chave existe em `locales/pt/translation.json` E `locales/en/translation.json` (nenhuma string literal hardcodada).
7. Teste relacionado foi executado ou a lacuna foi registrada quando a mudanca altera comportamento.
