---
name: blueaccount-services-navigator
description: Use after blueaccount-project-navigator for any work in `apps/services` of the BlueAccount/Kontiva MVP monorepo — OCR pipelines, contract/report extraction, async ingestion payloads, SAM templates, Step Functions, Lambda events/src/shared code, document conversion, AgentCore Python runtimes, callbacks/callback tokens, deployment config, service tests, or services README docs. Maps SAM workflow services, the local ingestion harness, and cross-app callback contracts.
---

# BlueAccount Services Navigator

Use this skill after `blueaccount-project-navigator` points the task at `apps/services`.

## Start Here

1. Read `apps/services/README.md`.
2. Decide whether the change belongs to a SAM workflow service, the isolated `doc-convert` Lambda,
   or an AgentCore runtime under `apps/services/agents`.
3. Read the README inside the exact service folder before editing implementation files.
4. Read the backend module README only when the service input, callback, SQS message, or API-facing
   contract changes.
5. For agent behavior that calls MCP tools, also read `apps/mcp/README.md` and `docs/AI_AGENT_TOOLS.md`.

## Choose The Runtime

- `ocr-pipeline`, `contratos`, `relatorios`, and `ingestao-payload` are AWS SAM services with
  Step Functions, TypeScript Lambdas, `template.yaml`, `statemachine`, `events`, and service-local
  source trees.
- `doc-convert` is an isolated container-image Lambda for Office-to-PDF conversion and page counts.
- `agents` contains Python AgentCore runtimes such as `kontiva_agent`, `cobranca`,
  `ingestao_payload`, `contract`, and `relatorio_extracao`.

If the work is ingestion, normalization, OCR, extraction, polling, callbacks, or async pipeline
orchestration, start in the SAM service. If the work is prompt/tool/runtime behavior, model
execution, or deterministic fallback logic inside an AgentCore runtime, start in `apps/services/agents`.

## Services Guardrails

- Keep workflow contracts aligned across `template.yaml`, state machine definitions, `events`, `src`,
  tests, and the service README.
- Reuse a service's `src/shared` helpers when that directory exists.
- Match local structure in `ingestao-payload` and `agents`; they do not necessarily follow the
  `src/shared` convention.
- Preserve deterministic business logic in Python agents where possible so tests can run without AWS.
- Treat callbacks, callback tokens, S3 artifact paths, and payload field names as cross-app contracts.
- Do not move product business rules into services unless the async workflow or runtime owns that rule.

## Documentation

Update `apps/services/README.md` or the nearest service README when changing workflow steps,
runtime ownership, callback contracts, artifact shapes, deployment commands, or developer entry
points. If the backend publishes or consumes the changed contract, update the backend module README
or API docs in the same change.

## Verify

Choose verification based on the touched service:

```bash
cd apps/services/<servico>
npm run type-check
npm run build
sam validate --lint --region us-east-1
```

For services with Jest tests, run the local `npm run test`. For AgentCore runtimes:

```bash
cd apps/services/agents
python3 -m unittest discover tests
agentcore validate
```

Use `agentcore dev` only when behavior needs local runtime exercise and required credentials are
available.

## Local ingestion harness (reports + contracts)

For changes touching the reports OR contracts ingestion flow (Step Functions, the OCR pipeline, the
reports/contract extraction Lambdas, the `RelatorioExtracaoAgent`, or the `ContractAgent`), **at
least suggest** running the full local harness before deploying. It runs the orchestration and SAM
Lambdas locally against real AWS S3/Textract/Bedrock, so it exercises the state machines end-to-end
without touching a deployed stack.

- One command: `./runapp.py --harness` (`-s`) starts backend + MCP + the harness (OCR + reports +
  contracts); add `-f` for the frontend. `sam build` is reused unless `--rebuild` is passed.
- Full guide, prerequisites, and manual per-step debugging: `docs/LOCAL_REPORTS_AGENT_HARNESS.md`.
- Contracts: the default `engine=converse` path is fully local (Bedrock Converse Lambdas only);
  `engine=agent` uses the local `ContractAgent` (`:8081`). Backend `.env` needs
  `CONTRATOS_STATE_MACHINE_ARN=...:blueaccount-contract-ocr-extraction-local`.
- Caveat: `WAIT_TIME_SCALE=0.01` collapses the Textract poll waits, so local wall-clock is not a
  latency signal. The reports PDF-direct path (`engine=agent` + `reportAgentInputMode=pdf`) skips OCR,
  so it does not exercise the SAM OCR endpoints or Textract — use `engine=converse` or a non-PDF-direct
  office to cover that branch. Keep a smoke test in dev AWS for IAM and service compatibility.
